from __future__ import annotations

import hashlib
import json
import os
import re
import sys
import traceback
import subprocess
import urllib.error
import urllib.request
import ssl
from datetime import datetime, timedelta, timezone
from pathlib import Path
import tkinter as tk
from tkinter import messagebox

LICENSE_ENDPOINT = "https://daa287.github.io/segelboot-proviant/v1/licenses.json"
APP_TITLE = "Meridian Analyzer Pro"
OFFLINE_DAYS_ALLOWED = 30
REQUEST_TIMEOUT_SECONDS = 12


def _app_data_dir() -> Path:
    base = Path(os.environ.get("LOCALAPPDATA") or (Path.home() / "AppData" / "Local"))
    path = base / "Meridian" / "Meridian Analyzer Pro"
    path.mkdir(parents=True, exist_ok=True)
    return path


def _config_dir() -> Path:
    path = _app_data_dir() / "config"
    path.mkdir(parents=True, exist_ok=True)
    return path


def _logs_dir() -> Path:
    path = _app_data_dir() / "logs"
    path.mkdir(parents=True, exist_ok=True)
    return path


def _license_file() -> Path:
    return _config_dir() / "license.json"


def _startup_log_file() -> Path:
    return _logs_dir() / "startup_error.log"


def _now_utc() -> datetime:
    return datetime.now(timezone.utc)


def _write_startup_error(message: str, exc: BaseException | None = None) -> None:
    try:
        lines = ["=" * 72, _now_utc().isoformat(), message]
        if exc is not None:
            lines.append("".join(traceback.format_exception(type(exc), exc, exc.__traceback__)))
        with _startup_log_file().open("a", encoding="utf-8") as f:
            f.write("\n".join(lines) + "\n")
    except Exception:
        pass


def normalize_license_key(value: str) -> str:
    value = (value or "").strip().upper()
    value = re.sub(r"\s+", "", value)
    value = re.sub(r"-+", "-", value)
    return value


def _compact_license_key(value: str) -> str:
    return re.sub(r"[\s\-]+", "", (value or "").strip().upper())


def sha256_hex(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def license_hash_candidates(raw_key: str) -> list[str]:
    # Das WordPress Plugin hasht den erzeugten Schlüssel inklusive Bindestrichen.
    # Zur Sicherheit akzeptiert der Guard zusätzlich ältere Varianten ohne Bindestriche,
    # falls bereits lokal ein anders normalisierter Hash gespeichert wurde.
    normalized = normalize_license_key(raw_key)
    compact = _compact_license_key(raw_key)
    candidates: list[str] = []
    for value in (normalized, compact, (raw_key or "").strip()):
        if value:
            digest = sha256_hex(value)
            if digest not in candidates:
                candidates.append(digest)
    return candidates


def _looks_like_sha256(value: object) -> bool:
    return isinstance(value, str) and bool(re.fullmatch(r"[a-fA-F0-9]{64}", value.strip()))


def _is_active_record(record: dict) -> bool:
    for key in ("active", "is_active", "enabled", "valid"):
        if key in record:
            return bool(record.get(key))
    for key in ("status", "state"):
        if str(record.get(key, "")).lower() in {"active", "valid", "enabled", "1", "true"}:
            return True
        if str(record.get(key, "")).lower() in {"inactive", "disabled", "revoked", "expired", "0", "false"}:
            return False
    return True


def _extract_active_hashes(payload: object) -> set[str]:
    hashes: set[str] = set()

    def walk(obj: object, parent_active: bool = True) -> None:
        if _looks_like_sha256(obj) and parent_active:
            hashes.add(str(obj).strip().lower())
            return
        if isinstance(obj, list):
            for item in obj:
                walk(item, parent_active)
            return
        if isinstance(obj, dict):
            active = parent_active and _is_active_record(obj)
            for key, value in obj.items():
                key_l = str(key).lower()
                if _looks_like_sha256(key) and active:
                    value_l = str(value).lower()
                    if value is True or value_l in {"active", "valid", "enabled", "1", "true"}:
                        hashes.add(str(key).strip().lower())
                if _looks_like_sha256(value) and active and ("hash" in key_l or "license" in key_l or "key" in key_l):
                    hashes.add(str(value).strip().lower())
                else:
                    walk(value, active)

    walk(payload)
    return hashes


def _request_headers() -> dict[str, str]:
    return {
        "User-Agent": "Meridian Analyzer Pro License Guard/1.1",
        "Accept": "application/json",
        "Cache-Control": "no-cache",
        "Pragma": "no-cache",
    }


def _fetch_endpoint_with_urllib() -> bytes:
    req = urllib.request.Request(LICENSE_ENDPOINT, headers=_request_headers(), method="GET")
    context = None
    try:
        import certifi  # type: ignore
        context = ssl.create_default_context(cafile=certifi.where())
    except Exception:
        context = ssl.create_default_context()
    with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT_SECONDS, context=context) as response:
        return response.read()


def _fetch_endpoint_with_powershell() -> bytes:
    script = (
        "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; "
        "$ProgressPreference='SilentlyContinue'; "
        "(Invoke-WebRequest -UseBasicParsing -TimeoutSec 20 -Headers @{Accept='application/json';'Cache-Control'='no-cache'} "
        f"-Uri '{LICENSE_ENDPOINT}').Content"
    )
    completed = subprocess.run(
        ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
        capture_output=True,
        timeout=25,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    if completed.returncode != 0:
        stderr = completed.stderr.decode("utf-8", errors="replace").strip()
        raise RuntimeError(f"PowerShell Abruf fehlgeschlagen: {stderr or completed.returncode}")
    return completed.stdout


def _fetch_endpoint_with_curl() -> bytes:
    completed = subprocess.run(
        ["curl.exe", "-fsSL", "--connect-timeout", "12", "--max-time", "20", "-H", "Accept: application/json", LICENSE_ENDPOINT],
        capture_output=True,
        timeout=25,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    if completed.returncode != 0:
        stderr = completed.stderr.decode("utf-8", errors="replace").strip()
        raise RuntimeError(f"curl Abruf fehlgeschlagen: {stderr or completed.returncode}")
    return completed.stdout


def _fetch_endpoint_raw() -> bytes:
    errors: list[str] = []
    for name, fetcher in (("urllib", _fetch_endpoint_with_urllib), ("powershell", _fetch_endpoint_with_powershell), ("curl", _fetch_endpoint_with_curl)):
        try:
            raw = fetcher()
            if raw:
                return raw
            errors.append(f"{name}: leere Antwort")
        except Exception as exc:
            errors.append(f"{name}: {type(exc).__name__}: {exc}")
    raise RuntimeError("Lizenzserver konnte nicht abgerufen werden. " + " | ".join(errors))


def fetch_active_hashes() -> set[str]:
    raw = _fetch_endpoint_raw()
    payload = json.loads(raw.decode("utf-8-sig", errors="replace"))
    hashes = _extract_active_hashes(payload)
    if not hashes:
        raise RuntimeError("Der Lizenzserver hat keine aktiven Lizenz Hashes geliefert.")
    return hashes


def _load_saved_license() -> dict:
    path = _license_file()
    if not path.exists():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        return data if isinstance(data, dict) else {}
    except Exception as exc:
        _write_startup_error("Gespeicherte Lizenz konnte nicht gelesen werden.", exc)
        return {}


def _save_successful_license(license_hash: str) -> None:
    data = {
        "license_hash": license_hash.lower(),
        "last_success_utc": _now_utc().isoformat(),
        "endpoint": LICENSE_ENDPOINT,
    }
    _license_file().write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def _last_success_is_within_offline_window(saved: dict) -> bool:
    value = saved.get("last_success_utc")
    if not value:
        return False
    try:
        last_success = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if last_success.tzinfo is None:
            last_success = last_success.replace(tzinfo=timezone.utc)
    except Exception:
        return False
    return _now_utc() - last_success <= timedelta(days=OFFLINE_DAYS_ALLOWED)


def _online_hash_is_valid(license_hash: str) -> bool:
    active_hashes = fetch_active_hashes()
    return license_hash.lower() in active_hashes


def _try_saved_license() -> tuple[bool, str]:
    saved = _load_saved_license()
    license_hash = str(saved.get("license_hash", "")).strip().lower()
    if not _looks_like_sha256(license_hash):
        return False, "Keine gespeicherte Lizenz vorhanden."
    try:
        if _online_hash_is_valid(license_hash):
            _save_successful_license(license_hash)
            return True, "Lizenz online bestätigt."
        return False, "Die gespeicherte Lizenz ist nicht mehr aktiv."
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        if _last_success_is_within_offline_window(saved):
            return True, "Offline Start mit letzter erfolgreicher Lizenzprüfung."
        _write_startup_error("Online Lizenzprüfung nicht möglich und Offline Zeitraum abgelaufen.", exc)
        return False, "Keine Internetverbindung. Bitte verbinde dich mit dem Internet, um die Lizenz erneut zu prüfen."
    except Exception as exc:
        _write_startup_error("Fehler bei der Online Lizenzprüfung.", exc)
        return False, "Die Lizenzprüfung konnte nicht abgeschlossen werden. Details stehen in startup_error.log."


def _activate_license_key(raw_key: str) -> tuple[bool, str]:
    normalized = normalize_license_key(raw_key)
    if not normalized:
        return False, "Bitte gib einen Lizenzschlüssel ein."
    hashes_to_try = license_hash_candidates(normalized)
    try:
        active_hashes = fetch_active_hashes()
        for license_hash in hashes_to_try:
            if license_hash.lower() in active_hashes:
                _save_successful_license(license_hash)
                return True, "Lizenz erfolgreich aktiviert."
        return False, "Der Lizenzschlüssel ist ungültig oder nicht aktiv."
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        _write_startup_error("Lizenzserver konnte bei der Aktivierung nicht erreicht werden.", exc)
        return False, "Der Lizenzserver konnte nicht erreicht werden. Bitte prüfe deine Internetverbindung."
    except Exception as exc:
        _write_startup_error("Fehler bei der Lizenzaktivierung.", exc)
        return False, "Die Lizenzprüfung konnte nicht abgeschlossen werden. Details stehen in startup_error.log."


def _center_window(window: tk.Tk, width: int = 430, height: int = 210) -> None:
    window.update_idletasks()
    screen_w = window.winfo_screenwidth()
    screen_h = window.winfo_screenheight()
    x = max(0, (screen_w - width) // 2)
    y = max(0, (screen_h - height) // 2)
    window.geometry(f"{width}x{height}+{x}+{y}")


def show_license_dialog() -> bool:
    root = tk.Tk()
    root.title(APP_TITLE)
    root.resizable(False, False)
    root.configure(bg="#050812")
    _center_window(root)

    result = {"ok": False}
    key_var = tk.StringVar()
    status_var = tk.StringVar(value="")

    frame = tk.Frame(root, bg="#050812", padx=28, pady=22)
    frame.pack(fill="both", expand=True)

    title = tk.Label(frame, text=APP_TITLE, bg="#050812", fg="#F7FAFF", font=("Segoe UI", 16, "bold"))
    title.pack(anchor="w")

    info = tk.Label(frame, text="Bitte gib deinen Lizenzschlüssel ein.", bg="#050812", fg="#D7E3F1", font=("Segoe UI", 10))
    info.pack(anchor="w", pady=(10, 8))

    entry = tk.Entry(frame, textvariable=key_var, width=44, font=("Segoe UI", 10), show="")
    entry.pack(fill="x")
    entry.focus_set()

    status = tk.Label(frame, textvariable=status_var, bg="#050812", fg="#FFB86B", font=("Segoe UI", 9), wraplength=370, justify="left")
    status.pack(anchor="w", pady=(8, 0))

    def activate() -> None:
        button.configure(state="disabled")
        root.configure(cursor="watch")
        root.update_idletasks()
        ok, message = _activate_license_key(key_var.get())
        root.configure(cursor="")
        button.configure(state="normal")
        if ok:
            result["ok"] = True
            root.destroy()
            return
        status_var.set(message)
        messagebox.showerror(APP_TITLE, message, parent=root)

    button = tk.Button(frame, text="Aktivieren", command=activate, font=("Segoe UI", 10, "bold"), width=16)
    button.pack(pady=(14, 0))
    root.bind("<Return>", lambda _event: activate())

    root.mainloop()
    return bool(result["ok"])


def ensure_license_or_exit() -> bool:
    ok, message = _try_saved_license()
    if ok:
        return True
    if message and message != "Keine gespeicherte Lizenz vorhanden.":
        try:
            messagebox.showwarning(APP_TITLE, message)
        except Exception:
            print(message, file=sys.stderr)
    return show_license_dialog()


def run_with_license_guard(start_application) -> None:
    try:
        if ensure_license_or_exit():
            start_application()
    except Exception as exc:
        _write_startup_error("Unerwarteter Fehler im Lizenzmodul oder beim Programmstart.", exc)
        try:
            messagebox.showerror(APP_TITLE, f"Beim Start ist ein Fehler aufgetreten.\n\nDetails stehen in:\n{_startup_log_file()}")
        except Exception:
            print(f"Beim Start ist ein Fehler aufgetreten. Details stehen in: {_startup_log_file()}", file=sys.stderr)
        raise
