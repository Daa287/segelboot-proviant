import csv
import gzip
import io
import json
import math
import re
import struct
import time
import zipfile
import zlib
import xml.etree.ElementTree as ET
import hashlib
import html as html_lib
import urllib.request
import urllib.error
import urllib.parse
import http.cookiejar
import functools
import copy
import os
import threading
import queue
import ssl
import shutil
import subprocess
import tempfile
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta
from pathlib import Path
import tkinter as tk
from tkinter import messagebox, ttk

# ============================================================================
# CHANGELOG 0.0.3 (gegenueber 0.0.1)
# ----------------------------------------------------------------------------
# NEU:
#   1. WeeklyArchiveStore: persistiert pro COT Report Datum die berechneten
#      Top 3 aller drei Engines (Classic/Flow/Hybrid) inklusive finaler
#      Watchlist Qualitaet. Zusaetzlich kann die Engine im Nachhinein die
#      tatsaechliche Kursbewegung nachtragen (realized_return_pct, hit).
#      Das ist die Grundlage fuer eine spaetere echte Kalibrierung der Scores
#      gegen tatsaechliche Ergebnisse. Bisher gab es dafuer keinerlei
#      persistente Datenbasis.
#   2. Engine Konsens/Konflikt Erkennung (consensus_setup_key,
#      build_direction_conflict_index, annotate_direction_conflicts,
#      build_consensus_records): zeigt sichtbar an, wenn zwei Engines
#      dasselbe Paar in entgegengesetzte Richtungen einstufen, und wie viele
#      Engines bei einem Setup uebereinstimmen. WICHTIG: Das ist bewusst nur
#      ein TRANSPARENTES LABEL in der UI, kein automatischer Punktebonus auf
#      final_quality. Ein Bonus ohne Backtest Beleg waere nur eine weitere
#      unvalidierte Konstante.
#   3. USD Proxy Hardening: Waehrungen ohne validen Dollar Index Datensatz
#      (is_proxy=True) werden jetzt HART aus der Forex Top 3 Auswahl
#      ausgeschlossen statt nur mit einem Punktabzug gedaempft. Sie bleiben
#      im Gesamtranking und Audit sichtbar, koennen aber kein Top 3 Setup
#      mehr belegen, weil ihre Richtung mathematisch aus den uebrigen
#      Waehrungen gespiegelt ist (keine unabhaengige Information).
#
# BEWUSST NICHT GEAENDERT (fehlt noch die Datenbasis dafuer):
#   - Score Kalibrierung gegen tatsaechliche Trefferquote
#   - Korrelationsbereinigung der COT Komponenten
#   - Datengetriebene statt fixe Schwellenwerte
#   Diese Punkte brauchen zuerst mehrere Monate Wochenarchiv Daten (siehe 1.).
# ============================================================================

APP_VERSION = "1.0.0"
APP_NAME = f"Meridian Analyzer Pro {APP_VERSION}"
UPDATE_ENDPOINT = "https://daa287.github.io/segelboot-proviant/v1/update"
UPDATE_TIMEOUT_SECONDS = 6
ENTRY_ENGINE_URL = "https://de.tradingview.com/script/ySbSy0Ga/"
APP_DIR = Path(__file__).resolve().parent

def _get_writable_app_dir():
    """Return the per user writable data folder.

    Installed applications may live under Program Files, where normal users must not
    write logs, cache files, downloaded market data or configuration. The analyzer
    therefore always writes mutable data to LOCALAPPDATA, while readonly assets stay
    next to the program files.
    """
    base = Path(os.environ.get("LOCALAPPDATA") or (Path.home() / "AppData" / "Local"))
    path = base / "Meridian" / "Meridian Analyzer Pro"
    path.mkdir(parents=True, exist_ok=True)
    return path

USER_DATA_DIR = _get_writable_app_dir()

ENGINE_CLASSIC = "classic_meridian"
ENGINE_FLOW = "flow_momentum"
ENGINE_HYBRID = "hybrid_intelligence"
ENGINE_LABELS = {
    ENGINE_CLASSIC: "Classic Meridian",
    ENGINE_FLOW: "Flow Momentum",
    ENGINE_HYBRID: "Hybrid Intelligence",
}
ENGINE_KEYS_BY_LABEL = {label: key for key, label in ENGINE_LABELS.items()}
DEFAULT_ANALYSIS_ENGINE = ENGINE_HYBRID
ENTRY_PROFILE_VERSION = "Meridian3"
ENTRY_PROFILE_ENGINE_CODES = {
    ENGINE_CLASSIC: "CL",
    ENGINE_FLOW: "FM",
    ENGINE_HYBRID: "HI",
}
ENTRY_PROFILE_CODE_LABELS = {
    "CL": "Classic Meridian",
    "FM": "Flow Momentum",
    "HI": "Hybrid Intelligence",
    "ALL": "Alle 3 Engines",
}
ENTRY_PROFILE_ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ|,:"
BOND_CACHE_SCHEMA_VERSION = 3
BOND_HISTORY_SCHEMA_VERSION = 2
BOND_OFFICIAL_CACHE_HOURS = 12
BOND_RESERVE_CACHE_HOURS = 6
YIELD_IMPULSE_WEIGHT = 30.0
YIELD_IMPULSE_SHORT_DAYS = 5
YIELD_IMPULSE_LONG_DAYS = 20
YIELD_IMPULSE_MIN_HISTORY_POINTS = 35
MACRO_PREFETCH_WORKERS = 6
BOE_DAILY_ARCHIVE_URL = (
    "https://www.bankofengland.co.uk/-/media/boe/files/statistics/"
    "yield-curves/glcnominalddata.zip"
)


def entry_profile_signature(payload):
    """Kompakte Prüfsignatur für das geschützte Pine Profilformat."""
    value = 73471
    for index, character in enumerate(str(payload or "")):
        position = ENTRY_PROFILE_ALPHABET.find(character)
        code = position + 1 if position >= 0 else 97
        value = (value * 131 + code * (index + 17) + 7919) % 1000003
    return str(value)


def normalize_entry_profile_pair(pair):
    text = str(pair or "").upper().replace("/", "").replace(" ", "")
    return text if re.fullmatch(r"[A-Z]{6}", text) else ""


def normalize_entry_profile_report_date(report_date):
    """Normalisiert den offiziellen CFTC Datenstand für das Pine Profil."""
    if isinstance(report_date, datetime):
        return report_date.strftime("%Y%m%d"), report_date.strftime("%d.%m.%Y")

    raw = str(report_date or "").strip()
    for date_format in ("%Y-%m-%d", "%d.%m.%Y", "%Y/%m/%d"):
        try:
            parsed = datetime.strptime(raw, date_format)
            return parsed.strftime("%Y%m%d"), parsed.strftime("%d.%m.%Y")
        except ValueError:
            continue
    raise ValueError("Der offizielle CFTC Datenstand konnte nicht für das TradingView Profil übernommen werden.")


def build_entry_profile_token(engine_code, rows, report_date):
    """Erzeugt ein vom Pine Script prüfbares Profil aus finalen Makrozeilen."""
    engine_code = str(engine_code or "").upper()
    if engine_code not in ENTRY_PROFILE_CODE_LABELS:
        raise ValueError("Unbekannte Analyzer Engine für das TradingView Profil.")
    report_date_code, report_date_text = normalize_entry_profile_report_date(report_date)

    maximum_rows = 9 if engine_code == "ALL" else 3
    entries = []
    normalized_rows = []
    seen = set()
    for row in list(rows or []):
        pair_code = normalize_entry_profile_pair(row.get("pair"))
        direction = str(row.get("direction", "")).upper()
        direction_code = "L" if direction == "LONG" else "S" if direction == "SHORT" else ""
        if not pair_code or not direction_code:
            continue
        key = (pair_code, direction_code)
        if key in seen:
            continue
        seen.add(key)
        entries.append(f"{pair_code}:{direction_code}")
        normalized_rows.append(row)
        if len(entries) >= maximum_rows:
            break

    if not entries:
        raise ValueError("Für das TradingView Profil sind keine gültigen Makro Kandidaten vorhanden.")

    payload = "|".join((
        ENTRY_PROFILE_VERSION,
        engine_code,
        report_date_code,
        ",".join(entries),
    ))
    return {
        "token": f"{payload}|{entry_profile_signature(payload)}",
        "engine_code": engine_code,
        "engine_label": ENTRY_PROFILE_CODE_LABELS[engine_code],
        "rows": normalized_rows,
        "report_date_code": report_date_code,
        "report_date_text": report_date_text,
    }
ENGINE_PROFILE_WEIGHTS = {
    ENGINE_CLASSIC: {
        "commercial_bias": 0.40,
        "fresh_capital_flow": 0.30,
        "relative_strength": 0.15,
        "open_interest": 0.10,
        "flow_acceleration": 0.05,
    },
    ENGINE_FLOW: {
        "commercial_change": 0.30,
        "change_4w": 0.25,
        "change_1w": 0.20,
        "flow_acceleration": 0.15,
        "open_interest_change": 0.10,
    },
    ENGINE_HYBRID: {
        "commercial_position_context": 0.20,
        "commercial_flow": 0.30,
        "large_spec_flow": 0.25,
        "flow_acceleration": 0.15,
        "four_week_context": 0.10,
    },
}
ENGINE_REASONS = {
    ENGINE_CLASSIC: "Ruhige, Commercial orientierte COT Auswertung für Swing und Position Trading.",
    ENGINE_FLOW: "Schnelle Flow Auswertung für frühe institutionelle Kapitalrotationen.",
    ENGINE_HYBRID: "Ausgewogene Kontextauswertung aus Positionierung, Flow, Large Specs und Signalqualität.",
}
ENGINE_PROFILE_INFO = {
    ENGINE_CLASSIC: {
        "subtitle": "Konservativer Commercial Ansatz",
        "summary": "Classic Meridian nutzt den Commercial Bias als stabilen Richtungsanker und lässt jüngere Kapitalflüsse diese Richtung bestätigen oder abschwächen. Die Engine reagiert bewusst ruhiger, filtert kurzfristiges Rauschen stärker und bevorzugt etablierte Positionierung statt schneller Wechsel.",
        "accent": "blue",
        "suitable": "Swing Trader und Position Trader, die wenige, ruhigere und stärker bestätigte COT Setups bevorzugen.",
        "style": "Konservativ, geduldig, trendfolgend",
        "strength": "Stabilere Signale und weniger hektische Richtungswechsel.",
        "tradeoff": "Neue institutionelle Rotation kann später erkannt werden als bei Flow Momentum.",
        "rules": [
            ("Commercial Bias", "40 %", "Institutioneller Long oder Short Überhang dient als stabiler Richtungsanker."),
            ("Frischer Kapitalfluss", "30 %", "Neue Commercial Positionen bestätigen oder schwächen den bestehenden Bias."),
            ("Relative Stärke", "15 %", "Starke Währungen werden bevorzugt gegen schwache Währungen kombiniert."),
            ("Open Interest", "10 %", "Prüft, ob die Bewegung von echter Marktteilnahme getragen wird."),
            ("Flow Beschleunigung", "5 %", "Feinfilter für zunehmenden oder nachlassenden Kapitalfluss."),
        ],
    },
    ENGINE_FLOW: {
        "subtitle": "Schnelle institutionelle Rotation",
        "summary": "Flow Momentum priorisiert aktuelle Positionsveränderungen über den langfristigen Bestand. Eine Woche, vier Wochen, Beschleunigung und Open Interest zeigen, wo institutionelles Kapital gerade neu auf oder abgebaut wird. Die Engine reagiert schneller und kann Richtungswechsel früher erkennen.",
        "accent": "green",
        "suitable": "Aktive Swing Trader und Trader, die frühe Rotationen, frisch entstehende Trends und häufigere Watchlist Wechsel suchen.",
        "style": "Dynamisch, reaktionsschnell, rotationsorientiert",
        "strength": "Erkennt frische Kapitalbewegungen und mögliche Trendwechsel früher.",
        "tradeoff": "Reagiert empfindlicher auf kurzfristige Schwankungen und kann häufiger umschalten.",
        "rules": [
            ("Commercial Veränderung", "30 %", "Misst die jüngste institutionelle Positionsverschiebung."),
            ("Vier Wochen Veränderung", "25 %", "Erkennt den Aufbau eines neuen mittelfristigen Kapitalflusses."),
            ("Eine Woche Veränderung", "20 %", "Reagiert unmittelbar auf den neuesten offiziellen CFTC Report."),
            ("Flow Beschleunigung", "15 %", "Bewertet, ob die Rotation an Tempo gewinnt oder nachlässt."),
            ("Open Interest Veränderung", "10 %", "Prüft, ob neues Kapital die Bewegung unterstützt."),
        ],
    },
    ENGINE_HYBRID: {
        "subtitle": "Ausgewogene institutionelle Kontextlogik",
        "summary": "Hybrid Intelligence behandelt die Commercial Position als 104 Wochen Kontext, nicht als automatische Marktrichtung. Commercial Flow, Large Spec Flow, Beschleunigung und Vier Wochen Entwicklung werden unabhängig bewertet und dürfen einander bestätigen, neutralisieren oder die Richtung drehen. Open Interest bewertet zusätzlich die Belastbarkeit des Signals.",
        "accent": "yellow",
        "suitable": "Trader, die zwischen Stabilität und früher Reaktion abwägen möchten und eine ausgewogene Standard Engine für die Wochenanalyse suchen.",
        "style": "Ausgewogen, kontextbasiert, mehrdimensional",
        "strength": "Verbindet strukturelle Positionierung mit aktueller Dynamik und unabhängiger Bestätigung.",
        "tradeoff": "Kann bei gemischten institutionellen Signalen bewusst neutraler bewerten und dadurch weniger eindeutige Setups liefern.",
        "rules": [
            ("Commercial Kontext", "20 %", "Ordnet die aktuelle Position im unveränderten 104 Wochen Kontext ein, ohne allein die Richtung festzulegen."),
            ("Commercial Flow", "30 %", "Bewertet Long Aufbau und Short Abbau beziehungsweise die gegenteilige Kapitalbewegung."),
            ("Large Spec Flow", "25 %", "Liefert eine unabhängige zweite Richtungskomponente."),
            ("Beschleunigung", "15 %", "Erkennt, ob der Positionsfluss an Tempo gewinnt oder nachlässt."),
            ("Vier Wochen Kontext", "10 %", "Prüft die Stabilität der jüngsten Positionsentwicklung."),
            ("Hybrid Paarbildung", "Danach", "Kombiniert starke mit schwachen Währungen und hält die Forex Top 3 diversifiziert."),
            ("Qualitätsgrenze", "Aktiv", "Nur ausreichend belastbare Setups gelangen in die Top 3."),
            ("Fallback Logik", "Aktiv", "Hält die Watchlist auch bei schwierigen Marktphasen nachvollziehbar funktionsfähig."),
        ],
    },
}
SETTINGS_PATH = USER_DATA_DIR / "app_settings.json"

def load_app_settings():
    try:
        data = json.loads(SETTINGS_PATH.read_text(encoding="utf-8")) if SETTINGS_PATH.exists() else {}
    except Exception:
        data = {}
    engine = data.get("analysis_engine", DEFAULT_ANALYSIS_ENGINE)
    if engine not in ENGINE_LABELS:
        engine = DEFAULT_ANALYSIS_ENGINE
    return {"analysis_engine": engine}

def save_app_settings(settings):
    try:
        SETTINGS_PATH.parent.mkdir(parents=True, exist_ok=True)
        SETTINGS_PATH.write_text(json.dumps(settings, indent=2, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass

DATA_DIR = USER_DATA_DIR / "cot_data"
DATA_DIR.mkdir(parents=True, exist_ok=True)
AUDIT_DIR = USER_DATA_DIR / "audit"
AUDIT_DIR.mkdir(parents=True, exist_ok=True)
SEASONALITY_DIR = USER_DATA_DIR / "seasonality_data"
SEASONALITY_DIR.mkdir(parents=True, exist_ok=True)
MACRO_DIR = USER_DATA_DIR / "macro_data"
MACRO_DIR.mkdir(parents=True, exist_ok=True)
WEEKLY_ARCHIVE_DIR = USER_DATA_DIR / "weekly_archive"
WEEKLY_ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
WEEKLY_ARCHIVE_PATH = WEEKLY_ARCHIVE_DIR / "meridian_weekly_archive.json.gz"
WEEKLY_ARCHIVE_BACKUP_PATH = WEEKLY_ARCHIVE_DIR / "meridian_weekly_archive.backup.json.gz"
WEEKLY_ARCHIVE_MAX_WEEKS = 60
WEEKLY_ARCHIVE_SCHEMA_VERSION = 2
WEEKLY_ARCHIVE_MAX_COMPRESSED_BYTES = 8 * 1024 * 1024
# Schema 2 (0.0.3): Outcomes werden pro Zeithorizont getrennt gespeichert
# (Key Suffix ":{horizon}d"), damit ein spaeterer Abgleich einen frueheren
# Zeithorizont Wert nicht mehr ueberschreibt. Historische Schema 1 Eintraege
# ohne Horizont Suffix bleiben lesbar, werden aber nicht mehr neu geschrieben.
WEEKLY_ARCHIVE_OUTCOME_HORIZONS_DAYS = (5, 14, 28)

# Meridian Commercial COT Index:
# Die CFTC liefert keinen COT Index. Der Analyzer berechnet ihn selbst
# aus der Commercial Netto Position im unveränderten 104 Wochen Kontext.
COT_INDEX_LOOKBACK_WEEKS = 104

CFTC_HIST_URLS = [
    "https://www.cftc.gov/files/dea/history/deacot{year}.zip",
    "https://www.cftc.gov/files/dea/history/fut_fin_txt_{year}.zip",
    "https://www.cftc.gov/files/dea/history/fut_disagg_txt_{year}.zip",
]

COLORS = {
    "bg": "#050812",
    "card": "#0E1623",
    "card2": "#121D2C",
    "header": "#101B2B",
    "line": "#2A3B55",
    "text": "#F7FAFF",
    "muted": "#9CB3CB",
    "green": "#00E676",
    "red": "#FF3B5C",
    "yellow": "#F7C948",
    "blue": "#4DA3FF",
    "button": "#1A2638",
    "dark": "#07101B",
    "orange": "#FF9F43",
}

MARKETS = {
    "EUR": ["EURO FX"],
    "GBP": ["BRITISH POUND", "POUND STERLING"],
    "JPY": ["JAPANESE YEN"],
    "CHF": ["SWISS FRANC"],
    "CAD": ["CANADIAN DOLLAR"],
    "AUD": ["AUSTRALIAN DOLLAR"],
    "NZD": ["NZ DOLLAR", "NEW ZEALAND DOLLAR"],
    "USD": ["U.S. DOLLAR INDEX", "US DOLLAR INDEX", "DOLLAR INDEX"],
}

SINGLE_ASSET_MARKETS = {
    "XAU": {
        "label": "Gold",
        "pair": "XAU/USD",
        "aliases": ["GOLD"],
        # Der liquide Gold Future liefert bei Yahoo den stabileren Tagesimpuls.
        "yahoo": ("GC=F", "XAUUSD=X"),
    },
    "XAG": {
        "label": "Silber",
        "pair": "XAG/USD",
        "aliases": ["SILVER"],
        # Der liquide Silber Future liefert bei Yahoo den stabileren Tagesimpuls.
        "yahoo": ("SI=F", "XAGUSD=X"),
    },
    "NAS100": {
        "label": "Nasdaq 100",
        "pair": "NAS100/USD",
        "aliases": ["NASDAQ MINI", "E-MINI NASDAQ 100", "NASDAQ 100"],
        "yahoo": ("^NDX", "NQ=F"),
    },
    "SP500": {
        "label": "S&P 500",
        "pair": "SP500/USD",
        "aliases": ["E-MINI S&P 500", "S&P 500 STOCK INDEX", "S&P 500"],
        "yahoo": ("^GSPC", "ES=F"),
    },
}

MAJOR_PAIRS = [
    "EUR/USD", "GBP/USD", "AUD/USD", "NZD/USD",
    "USD/JPY", "USD/CHF", "USD/CAD",
    "EUR/GBP", "EUR/JPY", "EUR/CHF", "EUR/CAD", "EUR/AUD", "EUR/NZD",
    "GBP/JPY", "GBP/CHF", "GBP/CAD", "GBP/AUD", "GBP/NZD",
    "AUD/JPY", "AUD/CAD", "AUD/CHF", "AUD/NZD",
    "NZD/JPY", "NZD/CAD", "NZD/CHF",
    "CAD/JPY", "CAD/CHF",
    "CHF/JPY",
]

YAHOO_PAIR_SYMBOLS = {pair: pair.replace("/", "") + "=X" for pair in MAJOR_PAIRS}
YAHOO_PAIR_SYMBOLS.update({cfg["pair"]: cfg["yahoo"] for cfg in SINGLE_ASSET_MARKETS.values()})
SEASONALITY_LOOKAHEAD_WEEKS = 4
SEASONALITY_MIN_YEARS = 8


DEFAULT_ENGINE_CONFIG = {
    "lookback_weeks": 4,
    "weights": {
        # Meridian Flow Methodik: Ebene 1 ist der aktuelle Commercial Netto Überhang.
        # Ebene 2 misst konkrete Long/Short Positionsverschiebungen bei Commercials
        # und Large Specs. Der COT Index bleibt Diagnose, aber kein Richtungsgeber.
        "commercial_current_bias": 0.52,
        "commercial_long_short_flow": 0.20,
        "large_spec_long_short_flow": 0.18,
        "flow_acceleration": 0.06,
        "oi_participation": 0.04,
    }
}

CONFIG_PATH = USER_DATA_DIR / "meridian_cot_engine_config.json"
DEFAULT_CONFIG_PATH = APP_DIR / "meridian_cot_engine_config.json"

SCORE_COMPONENT_LABELS = {
    "commercial_current_bias": "Commercial Netto Überhang aktuell",
    "commercial_long_short_flow": "Commercial Long/Short Flow",
    "large_spec_long_short_flow": "Large Spec Long/Short Flow",
    "flow_acceleration": "Flow Beschleunigung",
    "oi_participation": "Open Interest Teilnahme",
    "commercial_position": "Commercial COT Index Kontext",
    "commercial_weekly_change": "Commercial Kapitalfluss",
    "large_spec_position": "Large Specs Position",
    "large_spec_weekly_change": "Large Specs Kapitalfluss",
    "open_interest_confirmation": "Open Interest Teilnahme",
    "flow_trend_filter": "Meridian Bestätigungsfilter",
    "cot_freshness": "COT Freshness",
}

def load_engine_config():
    config = json.loads(json.dumps(DEFAULT_ENGINE_CONFIG))
    config_source = CONFIG_PATH if CONFIG_PATH.exists() else DEFAULT_CONFIG_PATH
    if config_source.exists():
        try:
            user_config = json.loads(config_source.read_text(encoding="utf-8"))
            if isinstance(user_config, dict):
                config.update({k: v for k, v in user_config.items() if k != "weights"})
                if isinstance(user_config.get("weights"), dict):
                    config["weights"].update(user_config["weights"])
        except Exception:
            pass
    weights = config.get("weights", {}).copy()
    total = sum(max(0.0, float(v)) for v in weights.values()) or 1.0
    config["weights"] = {k: max(0.0, float(v)) / total for k, v in weights.items()}
    config["lookback_weeks"] = int(config.get("lookback_weeks", 4) or 4)
    config["lookback_weeks"] = max(2, min(8, config["lookback_weeks"]))
    return config

def confidence_from_score(score):
    # Noch keine Trefferwahrscheinlichkeit. Erst nach Backtest Kalibrierung als Probability nutzbar.
    # Bewusst gedeckelt: Eine Research Engine sollte praktisch nie 100 Prozent ausgeben.
    return clamp(50 + (score - 50) * 0.95, 50, 95)

def pair_confidence_from_gaps(abs_diff, momentum_gap, commercial_gap, alignment_gap, consistency_gap, participation_gap, quality):
    # Meridian Engine: Paar Confidence bleibt eine Research Überzeugung, keine Trefferwahrscheinlichkeit.
    # Haupttreiber ist die relative Währungsstärke. Frischer Momentum Gap und klare Commercial/Spec
    # Unterschiede bestätigen den Score. Qualität deckelt nicht, sondern wirkt nur leicht unterstützend.
    raw = (
        50
        + abs_diff * 1.45
        + momentum_gap * 0.16
        + commercial_gap * 0.12
        + alignment_gap * 0.05
        + consistency_gap * 0.08
        + participation_gap * 0.04
        + max(0, quality - 50) * 0.04
    )
    return clamp(raw, 50, 95)


def pair_matrix_confidence(abs_diff, position_edge, flow_edge, momentum_edge, oi_edge, quality):
    # Meridian 2.0 Final: Meridian Commercial Bias Matrix.
    # Die vier Ebenen werden bewusst getrennt, damit aktuelle Wochenveränderung nicht
    # doppelt als Flow, Momentum und Freshness gezählt wird.
    relative_strength_score = clamp(50 + abs_diff * 1.85, 50, 95)
    position_score = clamp(50 + position_edge * 0.58, 0, 100)
    flow_score = clamp(50 + flow_edge * 0.70, 0, 100)
    momentum_score = clamp(50 + momentum_edge * 0.56, 0, 100)
    oi_score = clamp(50 + oi_edge * 0.45, 0, 100)

    core_scores = (position_score, flow_score, momentum_score, oi_score)
    supportive = sum(1 for v in core_scores if v >= 58)
    conflicts = sum(1 for v in core_scores if v <= 42)
    confluence_bonus = supportive * 1.35 - conflicts * 2.75

    # Keine einzelne Kennzahl darf das Paar alleine in die Top 3 drücken.
    # Deshalb wird bei fehlender Flow Bestätigung und bei starken Konflikten gedämpft.
    conflict_drag = 0.0
    if flow_score < 50 and position_score > 62:
        conflict_drag += 3.0
    if position_score < 50 and flow_score > 62:
        conflict_drag += 2.0
    if conflicts >= 2:
        conflict_drag += 4.0

    raw = (
        position_score * 0.40
        + flow_score * 0.30
        + relative_strength_score * 0.15
        + oi_score * 0.10
        + momentum_score * 0.05
        + confluence_bonus
        - conflict_drag
        + max(0, quality - 50) * 0.015
    )
    return clamp(raw, 50, 95), {
        "relative_strength_score": round(relative_strength_score, 1),
        "position_score": round(position_score, 1),
        "flow_score": round(flow_score, 1),
        "momentum_score": round(momentum_score, 1),
        "market_activity_score": round(oi_score, 1),
        "supportive_factors": supportive,
        "conflict_factors": conflicts,
        "confluence_bonus": round(confluence_bonus, 1),
        "conflict_drag": round(conflict_drag, 1),
    }

def clamp(v, lo=0, hi=100):
    return max(lo, min(hi, v))

def safe_float(v, default=0.0):
    try:
        if v is None:
            return default
        s = str(v).strip().replace(",", "")
        if s in ("", ".", "NA", "N/A"):
            return default
        return float(s)
    except Exception:
        return default

def seasonality_quality_adjustment(score):
    """Dynamischer Saisonbeitrag zur COT Basis, begrenzt auf acht Punkte."""
    value = safe_float(score, 50.0)
    return round(clamp((value - 50.0) * 0.20, -8.0, 8.0), 1)

def macro_quality_adjustment(score):
    """Dynamischer Makrobeitrag zur COT Basis, begrenzt auf fünf Punkte."""
    value = safe_float(score, 50.0)
    return round(clamp((value - 50.0) / 6.0, -5.0, 5.0), 1)

def final_watchlist_quality_breakdown(cot_score, seasonality_score, macro_score=50.0, event_penalty=0.0):
    """COT bleibt Richtungsanker, Saison und Makro verfeinern nur die Qualität."""
    cot_basis = clamp(safe_float(cot_score, 50.0), 0.0, 100.0)
    season_adjustment = seasonality_quality_adjustment(seasonality_score)
    macro_adjustment = macro_quality_adjustment(macro_score)
    timing_penalty = round(clamp(safe_float(event_penalty, 0.0), 0.0, 4.0), 1)
    final_quality = round(clamp(cot_basis + season_adjustment + macro_adjustment - timing_penalty, 0.0, 100.0), 1)
    return {
        "cot_basis": round(cot_basis, 1),
        "seasonality_adjustment": season_adjustment,
        "macro_adjustment": macro_adjustment,
        "event_penalty": timing_penalty,
        "final_quality": final_quality,
    }


# ============================================================================
# Engine Konsens und Konflikt Erkennung (neu in 0.0.3)
# ----------------------------------------------------------------------------
# Diese Funktionen vergleichen die Top 3 Ergebnisse der drei Analyse Engines
# (Classic Meridian, Flow Momentum, Hybrid Intelligence) miteinander. Sie
# VERAENDERN KEINE SCORES. Sie liefern ausschliesslich Transparenz-Labels:
# - Zeigt zwei Engines fuer dasselbe Paar entgegengesetzte Richtungen,
#   wird das als WIDERSPRUCH markiert statt stillschweigend nebeneinander
#   als "Champion" praesentiert zu werden.
# - Stimmen mehrere Engines unabhaengig in Paar UND Richtung ueberein, wird
#   das als Konsens Stufe angezeigt (reine Information, kein Bonus).
# ============================================================================

CONSENSUS_ENGINE_ORDER = (ENGINE_CLASSIC, ENGINE_FLOW, ENGINE_HYBRID)
DIRECTION_CONFLICT_LABEL = "WIDERSPRUCH"
DIRECTION_CONFLICT_MESSAGE = (
    "Mindestens zwei Engines berechnen dieses Währungspaar unabhängig voneinander "
    "in entgegengesetzte Richtungen. Die Marktlage ist aktuell nicht eindeutig."
)


def consensus_setup_key(pair, direction):
    """Normalisierter Schlüssel (Paarcode, Richtung) für Konsens/Konflikt Vergleiche."""
    pair_code = normalize_entry_profile_pair(pair)
    bias = str(direction or "").strip().upper()
    if not pair_code or bias not in ("LONG", "SHORT"):
        return None
    return (pair_code, bias)


def build_direction_conflict_index(rows_by_engine):
    """Findet Paare, bei denen Engines sich in der Richtung widersprechen.

    rows_by_engine: {engine_key: [row, row, row]} - je Engine die Top 3 Zeilen
    mit mindestens 'pair' und 'direction'.
    Rückgabe: {pair_code: {..conflict info..}} nur für tatsächlich strittige Paare.
    """
    grouped = {}
    for engine_key in CONSENSUS_ENGINE_ORDER:
        rows = list((rows_by_engine or {}).get(engine_key, []) or [])[:3]
        seen_pairs_this_engine = set()
        for row in rows:
            row = row or {}
            key = consensus_setup_key(row.get("pair"), row.get("direction"))
            if key is None:
                continue
            pair_code, direction = key
            if pair_code in seen_pairs_this_engine:
                continue
            seen_pairs_this_engine.add(pair_code)
            grouped.setdefault(pair_code, {}).setdefault(direction, []).append(engine_key)

    conflicts = {}
    for pair_code, directions in grouped.items():
        long_engines = list(dict.fromkeys(directions.get("LONG", [])))
        short_engines = list(dict.fromkeys(directions.get("SHORT", [])))
        involved = set(long_engines) | set(short_engines)
        if not long_engines or not short_engines or len(involved) < 2:
            continue
        long_labels = [ENGINE_LABELS.get(k, str(k)) for k in long_engines]
        short_labels = [ENGINE_LABELS.get(k, str(k)) for k in short_engines]
        conflicts[pair_code] = {
            "pair_code": pair_code,
            "pair": f"{pair_code[:3]}/{pair_code[3:]}",
            "label": DIRECTION_CONFLICT_LABEL,
            "message": DIRECTION_CONFLICT_MESSAGE,
            "long_engine_keys": long_engines,
            "short_engine_keys": short_engines,
            "long_engine_labels": long_labels,
            "short_engine_labels": short_labels,
            "detail": f"LONG: {', '.join(long_labels)}   |   SHORT: {', '.join(short_labels)}",
        }
    return conflicts


def annotate_direction_conflicts(rows_by_engine):
    """Reichert die Top 3 Zeilen jeder Engine um Konflikt Informationen an.

    Verändert keine Scores. Fügt nur die Felder direction_conflict (bool),
    champion_eligible (bool) und bei Konflikt weitere Detailfelder hinzu.
    Rückgabe: (annotated_rows_by_engine, conflict_index)
    """
    conflict_index = build_direction_conflict_index(rows_by_engine)
    annotated = {}
    for engine_key in CONSENSUS_ENGINE_ORDER:
        engine_rows = []
        for source_row in list((rows_by_engine or {}).get(engine_key, []) or [])[:3]:
            item = dict(source_row or {})
            pair_code = normalize_entry_profile_pair(item.get("pair"))
            conflict = conflict_index.get(pair_code)
            item["direction_conflict"] = bool(conflict)
            item["champion_eligible"] = not bool(conflict)
            if conflict:
                item["direction_conflict_label"] = conflict["label"]
                item["direction_conflict_message"] = conflict["message"]
                item["direction_conflict_detail"] = conflict["detail"]
                item["direction_conflict_long_engines"] = list(conflict["long_engine_labels"])
                item["direction_conflict_short_engines"] = list(conflict["short_engine_labels"])
            else:
                for field in (
                    "direction_conflict_label", "direction_conflict_message",
                    "direction_conflict_detail", "direction_conflict_long_engines",
                    "direction_conflict_short_engines",
                ):
                    item.pop(field, None)
            engine_rows.append(item)
        annotated[engine_key] = engine_rows
    return annotated, conflict_index


def build_consensus_records(rows_by_engine, include_single=False):
    """Gruppiert (Paar, Richtung) über alle Engines und zählt Übereinstimmungen.

    Reine Diagnose/Anzeige-Funktion, kein Einfluss auf final_quality Scores.
    include_single=True liefert auch Paare, die nur eine Engine gewählt hat
    (nützlich für den Quality-Filter-Kontext, siehe unten).
    """
    grouped = {}
    for engine_key in CONSENSUS_ENGINE_ORDER:
        rows = list((rows_by_engine or {}).get(engine_key, []) or [])[:3]
        for fallback_rank, row in enumerate(rows, 1):
            row = row or {}
            key = consensus_setup_key(row.get("pair"), row.get("direction"))
            if key is None:
                continue
            try:
                rank = int(row.get("rank") or fallback_rank)
            except Exception:
                rank = fallback_rank
            members = grouped.setdefault(key, {})
            if engine_key in members:
                continue
            members[engine_key] = {
                "engine_key": engine_key,
                "engine_label": ENGINE_LABELS.get(engine_key, str(engine_key)),
                "rank": rank,
                "row": row,
            }

    records = []
    for (pair_code, direction), member_map in grouped.items():
        members = [member_map[k] for k in CONSENSUS_ENGINE_ORDER if k in member_map]
        engine_count = len(members)
        if engine_count < (1 if include_single else 2):
            continue
        if engine_count == 3:
            level = "TRIPLE CONSENSUS"
        elif engine_count == 2:
            level = "CONSENSUS KANDIDAT"
        else:
            level = "EINZELENGINE KANDIDAT"
        quality_values = [
            safe_float(member["row"].get("final_quality", member["row"].get("final_confluence", member["row"].get("confidence", 50))), 50)
            for member in members
        ]
        records.append({
            "pair_code": pair_code,
            "pair": f"{pair_code[:3]}/{pair_code[3:]}",
            "direction": direction,
            "engine_count": engine_count,
            "engine_labels": [m["engine_label"] for m in members],
            "level": level,
            "rank_sum": sum(m["rank"] for m in members),
            "average_quality": round(sum(quality_values) / max(1, len(quality_values)), 1),
        })

    records.sort(key=lambda r: (-r["engine_count"], r["rank_sum"], -r["average_quality"], r["pair"]))
    return records


# ============================================================================
# Wochenarchiv (neu in 0.0.3)
# ----------------------------------------------------------------------------
# Persistiert je COT Report Datum, was jede Engine als Top 3 berechnet hat,
# und erlaubt es, spaeter die tatsaechliche Kursbewegung nachzutragen. Das
# ist die Grundlage fuer eine spaetere echte Kalibrierung der Meridian Scores
# gegen reale Ergebnisse (vorher gab es dafuer keine persistente Datenbasis).
# Format: gzip komprimiertes JSON, rollierendes Fenster der letzten N Wochen.
# ============================================================================

def weekly_archive_json_value(value, depth=0):
    """Reduziert beliebige Python Werte auf ein kompaktes, JSON sicheres Format."""
    if depth > 12:
        return None
    if value is None or isinstance(value, (bool, int, float)):
        return value
    if isinstance(value, str):
        return value[:6000]
    if isinstance(value, datetime):
        return value.isoformat(timespec="seconds")
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, dict):
        return {
            str(k)[:160]: weekly_archive_json_value(v, depth + 1)
            for k, v in value.items()
            if not str(k).startswith("_meridian_")
        }
    if isinstance(value, (list, tuple, set)):
        return [weekly_archive_json_value(v, depth + 1) for v in list(value)[:120]]
    return str(value)[:1000]


class WeeklyArchiveStore:
    """Threadsicherer, dateibasierter Speicher für Wochenschnappschüsse.

    Jede Woche (identifiziert durch das offizielle CFTC Report Datum) bekommt
    genau einen Eintrag mit den Top 3 aller drei Engines. Spaeter kann pro
    Eintrag ein "outcome" Block nachgetragen werden, der die tatsaechliche
    Kursbewegung seit dem Report Datum enthaelt.
    """

    def __init__(self, path=WEEKLY_ARCHIVE_PATH, backup_path=WEEKLY_ARCHIVE_BACKUP_PATH):
        self.path = Path(path)
        self.backup_path = Path(backup_path)
        self._lock = threading.RLock()
        self.last_error = ""

    @staticmethod
    def _empty_document():
        return {
            "schema_version": WEEKLY_ARCHIVE_SCHEMA_VERSION,
            "max_weeks": WEEKLY_ARCHIVE_MAX_WEEKS,
            "weeks": [],
        }

    @staticmethod
    def _date_sort_key(entry):
        raw = str((entry or {}).get("report_date") or "")
        try:
            return datetime.strptime(raw[:10], "%Y-%m-%d")
        except Exception:
            return datetime.min

    def _read_path(self, path):
        with gzip.open(path, "rt", encoding="utf-8") as handle:
            document = json.load(handle)
        if not isinstance(document, dict) or not isinstance(document.get("weeks"), list):
            raise ValueError("Ungültiges Wochenarchiv Format")
        return document

    # Migration nach dem 5MG -> Meridian Rename (0.0.3): nur der Classic Key
    # hat sich geändert (classic_5mg -> classic_meridian). Bereits vor dem
    # Rename archivierte Wochen liegen noch unter dem alten Schlüssel und
    # würden sonst in der UI als "Keine Daten" erscheinen, obwohl die Werte
    # noch vorhanden sind. Reines Umhängen des Keys, keine Wertänderung.
    LEGACY_ENGINE_KEY_MIGRATIONS = {"classic_5mg": ENGINE_CLASSIC}

    def _migrate_legacy_engine_keys(self, document):
        migrated = False
        for week in document.get("weeks") or []:
            engines = week.get("engines")
            if not isinstance(engines, dict):
                continue
            for old_key, new_key in self.LEGACY_ENGINE_KEY_MIGRATIONS.items():
                if old_key in engines and new_key not in engines:
                    engines[new_key] = engines.pop(old_key)
                    migrated = True
            outcomes = week.get("outcome")
            if isinstance(outcomes, dict):
                renamed_outcomes = {}
                for key, value in outcomes.items():
                    new_outcome_key = key
                    for old_key, new_key in self.LEGACY_ENGINE_KEY_MIGRATIONS.items():
                        if key.startswith(old_key + ":"):
                            new_outcome_key = new_key + key[len(old_key):]
                            migrated = True
                            break
                    renamed_outcomes[new_outcome_key] = value
                week["outcome"] = renamed_outcomes
        return migrated

    def load(self):
        """Lädt das Archiv. Fällt bei defekter Hauptdatei auf das Backup zurück."""
        self.last_error = ""
        for candidate in (self.path, self.backup_path):
            if not candidate.exists():
                continue
            try:
                document = self._read_path(candidate)
            except Exception as exc:
                self.last_error = f"{candidate.name}: {exc}"
                continue
            document["schema_version"] = WEEKLY_ARCHIVE_SCHEMA_VERSION
            document["max_weeks"] = WEEKLY_ARCHIVE_MAX_WEEKS
            document["weeks"] = sorted(
                list(document.get("weeks") or []), key=self._date_sort_key, reverse=True
            )[:WEEKLY_ARCHIVE_MAX_WEEKS]
            if self._migrate_legacy_engine_keys(document):
                try:
                    self._write(document)
                except Exception:
                    pass  # Migration wird beim naechsten erfolgreichen Schreibvorgang nachgeholt
            return document
        return self._empty_document()

    def _write(self, document):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temp_path = self.path.with_suffix(self.path.suffix + ".tmp")
        safe_document = weekly_archive_json_value(document)

        def write_temp():
            with gzip.open(temp_path, "wt", encoding="utf-8", compresslevel=9) as handle:
                json.dump(safe_document, handle, ensure_ascii=False, separators=(",", ":"))

        write_temp()
        # Falls die Datei trotz Kompression zu groß wird, älteste Wochen entfernen
        # statt die Speicherung ganz zu verweigern.
        while (
            temp_path.stat().st_size > WEEKLY_ARCHIVE_MAX_COMPRESSED_BYTES
            and len(safe_document.get("weeks") or []) > 1
        ):
            safe_document["weeks"] = sorted(
                safe_document["weeks"], key=self._date_sort_key, reverse=True
            )[:-1]
            write_temp()

        if temp_path.stat().st_size > WEEKLY_ARCHIVE_MAX_COMPRESSED_BYTES:
            temp_path.unlink(missing_ok=True)
            raise ValueError("Der lokale Wochenstand überschreitet die sichere Archivgröße.")

        if self.path.exists():
            try:
                self._read_path(self.path)  # nur sichern, wenn aktuelle Datei valide ist
                shutil.copy2(self.path, self.backup_path)
            except Exception:
                pass
        os.replace(temp_path, self.path)

    def list_weeks(self):
        return copy.deepcopy(self.load().get("weeks") or [])

    def get_week(self, report_date):
        requested = str(report_date or "")[:10]
        for entry in self.load().get("weeks") or []:
            if str(entry.get("report_date") or "")[:10] == requested:
                return copy.deepcopy(entry)
        return None

    def merge_week(self, report_date, engines=None, champions=None):
        """Speichert/aktualisiert die Engine Ergebnisse einer Woche.

        engines: {engine_key: payload_dict} - payload sollte mindestens
        'top3' (Liste der Top 3 Zeilen) enthalten.
        Gibt True zurück, wenn tatsächlich etwas geschrieben wurde.
        """
        try:
            report_code, report_text = normalize_entry_profile_report_date(report_date)
            normalized_date = datetime.strptime(report_code, "%Y%m%d").strftime("%Y-%m-%d")
        except Exception as exc:
            self.last_error = f"Ungültiges Report Datum für Archiv: {exc}"
            return False

        now_text = datetime.now().isoformat(timespec="seconds")
        with self._lock:
            document = self.load()
            weeks = list(document.get("weeks") or [])
            entry = next(
                (w for w in weeks if str(w.get("report_date") or "")[:10] == normalized_date), None
            )
            if entry is None:
                entry = {
                    "report_date": normalized_date,
                    "report_date_text": report_text,
                    "created_at": now_text,
                    "updated_at": now_text,
                    "engines": {},
                    "champions": {},
                    "outcome": {},
                }
                weeks.append(entry)

            changed = False
            stored_engines = entry.setdefault("engines", {})
            for engine_key, raw_payload in (engines or {}).items():
                if engine_key not in ENGINE_LABELS or not isinstance(raw_payload, dict):
                    continue
                payload = weekly_archive_json_value(raw_payload)
                previous = stored_engines.get(engine_key) or {}
                # depth_level: 1 = nur COT Top 3, 2 = plus Seasonality, 3 = plus Makro.
                # Ein späterer, ärmerer Snapshot (z.B. erneuter reiner COT Lauf)
                # darf einen bereits angereicherten Eintrag nicht überschreiben.
                try:
                    incoming_level = int(safe_float(payload.get("depth_level"), 1))
                except Exception:
                    incoming_level = 1
                try:
                    previous_level = int(safe_float(previous.get("depth_level"), 0))
                except Exception:
                    previous_level = 0
                if previous and previous_level > incoming_level:
                    continue
                fingerprint = hashlib.sha256(
                    json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
                ).hexdigest()
                if previous.get("content_hash") == fingerprint:
                    continue
                payload["content_hash"] = fingerprint
                payload["saved_at"] = now_text
                stored_engines[engine_key] = payload
                changed = True

            if champions is not None:
                safe_champions = weekly_archive_json_value(champions)
                champion_hash = hashlib.sha256(
                    json.dumps(safe_champions, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
                ).hexdigest()
                if entry.get("champions_hash") != champion_hash:
                    entry["champions"] = safe_champions
                    entry["champions_hash"] = champion_hash
                    changed = True

            if not changed:
                return False

            entry["updated_at"] = now_text
            document["weeks"] = sorted(weeks, key=self._date_sort_key, reverse=True)[:WEEKLY_ARCHIVE_MAX_WEEKS]
            self._write(document)
            return True

    def record_outcome(self, report_date, pair, direction, engine_key, horizon_days, outcome):
        """Trägt die tatsächliche Kursbewegung für einen konkreten Zeithorizont nach.

        horizon_days identifiziert den Zeithorizont (z.B. 5, 14, 28 Handelstage
        seit Report Datum) und wird Teil des Outcome Keys. Dadurch überschreibt
        ein späterer Abgleich mit einem anderen Horizont nicht den Wert eines
        früheren Horizonts - jedes Setup kann mehrere unabhängige Ergebnisse
        über die Zeit ansammeln (z.B. 5 Tage Reaktion UND 28 Tage Ergebnis).
        outcome sollte z.B. enthalten: measured_at, reference_date,
        reference_price, horizon_price, horizon_date, raw_return_pct,
        signal_return_pct, hit (bool).
        """
        pair_code = normalize_entry_profile_pair(pair)
        bias = str(direction or "").strip().upper()
        if not pair_code or bias not in ("LONG", "SHORT"):
            return False
        try:
            horizon = int(horizon_days)
        except Exception:
            return False
        with self._lock:
            document = self.load()
            weeks = list(document.get("weeks") or [])
            normalized_date = str(report_date or "")[:10]
            entry = next(
                (w for w in weeks if str(w.get("report_date") or "")[:10] == normalized_date), None
            )
            if entry is None:
                return False
            key = f"{engine_key}:{pair_code}:{bias}:{horizon}d"
            outcomes = entry.setdefault("outcome", {})
            outcomes[key] = weekly_archive_json_value({
                "pair": f"{pair_code[:3]}/{pair_code[3:]}",
                "direction": bias,
                "engine_key": engine_key,
                "horizon_days": horizon,
                **(outcome or {}),
            })
            entry["updated_at"] = datetime.now().isoformat(timespec="seconds")
            document["weeks"] = sorted(weeks, key=self._date_sort_key, reverse=True)[:WEEKLY_ARCHIVE_MAX_WEEKS]
            self._write(document)
            return True


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def norm_key(k):
    return re.sub(r"[^a-z0-9]", "", str(k).lower())

def normalized_row_lookup(row):
    lookup = row.get("_meridian_norm_lookup")
    if lookup is None:
        lookup = {norm_key(k): v for k, v in row.items()}
        row["_meridian_norm_lookup"] = lookup
    return lookup

def row_get(row, names, default=0.0):
    lookup = normalized_row_lookup(row)
    for name in names:
        nk = norm_key(name)
        if nk in lookup:
            return safe_float(lookup[nk], default)
    return default

def row_get_text(row, names):
    lookup = normalized_row_lookup(row)
    for name in names:
        nk = norm_key(name)
        if nk in lookup:
            return str(lookup[nk])
    return ""

def parse_date(row):
    for k, v in row.items():
        if "date" not in norm_key(k):
            continue
        s = str(v).strip()
        for fmt in ("%Y-%m-%d", "%m/%d/%Y", "%m/%d/%y", "%y%m%d", "%Y%m%d"):
            try:
                return datetime.strptime(s, fmt)
            except Exception:
                pass
    return None

@functools.lru_cache(maxsize=8192)
def match_currency(market_name):
    # CFTC Legacy enthält neben den Hauptwährungsfutures auch Cross Rate Kontrakte
    # wie EURO FX/BRITISH POUND XRATE. Diese dürfen NICHT als EUR oder GBP Rohdaten
    # verwendet werden, sonst stimmen die Transparenzzahlen nicht mit InsiderWeek
    # beziehungsweise dem offiziellen Hauptkontrakt überein.
    up = str(market_name or "").upper().strip()
    if "/" in up or "XRATE" in up:
        return None
    primary = up.split(" - ")[0].strip()
    exact_map = {
        "EURO FX": "EUR",
        "BRITISH POUND": "GBP",
        "POUND STERLING": "GBP",
        "JAPANESE YEN": "JPY",
        "SWISS FRANC": "CHF",
        "CANADIAN DOLLAR": "CAD",
        "AUSTRALIAN DOLLAR": "AUD",
        "NZ DOLLAR": "NZD",
        "NEW ZEALAND DOLLAR": "NZD",
        "U.S. DOLLAR INDEX": "USD",
        "US DOLLAR INDEX": "USD",
        "USD INDEX": "USD",
        "U S DOLLAR INDEX": "USD",
        "DOLLAR INDEX": "USD",
        "ICE U.S. DOLLAR INDEX": "USD",
        "ICE US DOLLAR INDEX": "USD",
    }
    if primary in exact_map:
        return exact_map[primary]
    compact = re.sub(r"[^A-Z0-9]", "", primary)
    if compact in ("USDOLLARINDEX", "USDOLLARINDEX", "USDX", "DOLLARINDEX", "ICEUSDOLLARINDEX"):
        return "USD"
    return None

@functools.lru_cache(maxsize=8192)
def match_single_asset(market_name):
    # Final 2.0: Metalle und Index Futures werden bewusst als Single Assets
    # geführt. Sie werden nicht in die Forex Cross Pair Matrix gemischt, sondern als
    # eigene COT Kandidaten gerankt.
    up = str(market_name or "").upper().strip()
    if not up:
        return None
    if "/" in up or "XRATE" in up:
        return None
    primary = up.split(" - ")[0].strip()
    compact_primary = re.sub(r"[^A-Z0-9]", "", primary)
    for asset, cfg in SINGLE_ASSET_MARKETS.items():
        for alias in cfg.get("aliases", []):
            alias_up = str(alias).upper().strip()
            compact_alias = re.sub(r"[^A-Z0-9]", "", alias_up)
            if primary == alias_up or compact_primary == compact_alias:
                return asset
    return None

def _validate_downloaded_zip(path):
    if not path.exists():
        raise RuntimeError("Download Datei wurde nicht erstellt")
    if path.stat().st_size < 500:
        raise RuntimeError("Download Datei zu klein")
    if not zipfile.is_zipfile(path):
        raise RuntimeError("Download ist keine gueltige ZIP Datei")
    with zipfile.ZipFile(path, "r") as z:
        names = [n for n in z.namelist() if n.lower().endswith((".txt", ".csv"))]
        if not names:
            raise RuntimeError("CFTC ZIP enthaelt keine Text oder CSV Datei")
    return path

def _format_download_error(label, exc):
    msg = str(exc).strip()
    return f"{label}: {type(exc).__name__}: {msg}" if msg else f"{label}: {type(exc).__name__}"

def download_url(url, path):
    path.parent.mkdir(parents=True, exist_ok=True)
    errors = []
    headers = {
        "User-Agent": f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) Meridian-Analyzer/{APP_VERSION}",
        "Accept": "application/zip,application/octet-stream,*/*",
    }

    try:
        req = urllib.request.Request(url, headers=headers)
        context = ssl.create_default_context()
        with urllib.request.urlopen(req, timeout=60, context=context) as response:
            status = getattr(response, "status", 200)
            if status and int(status) >= 400:
                raise RuntimeError(f"HTTP Status {status}")
            path.write_bytes(response.read())
        return _validate_downloaded_zip(path)
    except Exception as exc:
        errors.append(_format_download_error("urllib", exc))
        try:
            if path.exists():
                path.unlink()
        except Exception:
            pass

    curl = shutil.which("curl")
    if curl:
        try:
            cmd = [
                curl,
                "--fail",
                "--location",
                "--silent",
                "--show-error",
                "--max-time",
                "60",
                "--user-agent",
                headers["User-Agent"],
                "--output",
                str(path),
                url,
            ]
            subprocess.run(cmd, check=True, capture_output=True, text=True)
            return _validate_downloaded_zip(path)
        except Exception as exc:
            detail = exc
            if isinstance(exc, subprocess.CalledProcessError):
                stderr = (exc.stderr or "").strip()
                detail = RuntimeError(stderr or f"curl Exit Code {exc.returncode}")
            errors.append(_format_download_error("curl", detail))
            try:
                if path.exists():
                    path.unlink()
            except Exception:
                pass

    powershell = shutil.which("powershell") or shutil.which("powershell.exe") or shutil.which("pwsh") or shutil.which("pwsh.exe")
    if powershell:
        try:
            ps = (
                "$ProgressPreference='SilentlyContinue'; "
                "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12; "
                "Invoke-WebRequest -Uri $args[0] -OutFile $args[1] -MaximumRedirection 5 -TimeoutSec 60 "
                f"-Headers @{{'User-Agent'='{headers['User-Agent']}'}}"
            )
            subprocess.run([powershell, "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps, url, str(path)], check=True, capture_output=True, text=True)
            return _validate_downloaded_zip(path)
        except Exception as exc:
            detail = exc
            if isinstance(exc, subprocess.CalledProcessError):
                stderr = (exc.stderr or "").strip()
                detail = RuntimeError(stderr or f"PowerShell Exit Code {exc.returncode}")
            errors.append(_format_download_error("PowerShell", detail))
            try:
                if path.exists():
                    path.unlink()
            except Exception:
                pass

    raise RuntimeError("; ".join(errors) if errors else "Kein Downloader verfuegbar")

def read_zip_tables(path):
    rows = []
    with zipfile.ZipFile(path, "r") as z:
        names = [n for n in z.namelist() if n.lower().endswith((".txt", ".csv"))]
        for name in names:
            raw = z.open(name).read().decode("latin1", errors="ignore")
            for delimiter in [",", "\t", ";"]:
                try:
                    reader = csv.DictReader(io.StringIO(raw), delimiter=delimiter)
                    if reader.fieldnames and len(reader.fieldnames) > 10:
                        parsed = [r for r in reader if r]
                        if parsed:
                            rows.extend(parsed)
                            break
                except Exception:
                    continue
            if rows:
                break
    return rows

def normalize_record(row, curr):
    market = row_get_text(row, [
        "Market_and_Exchange_Names",
        "Market and Exchange Names",
        "Market_and_Exchange_Name",
    ])
    if not market:
        for k, v in row.items():
            if "market" in str(k).lower() and "exchange" in str(k).lower():
                market = str(v)
                break

    date = parse_date(row)
    if not date:
        return None

    oi = row_get(row, ["Open_Interest_All", "Open Interest All", "Open Interest", "Open_Interest"])
    if abs(oi) <= 0:
        return None

    nc_long = row_get(row, ["NonComm_Positions_Long_All", "Noncommercial Positions Long All", "NonComm Long All"])
    nc_short = row_get(row, ["NonComm_Positions_Short_All", "Noncommercial Positions Short All", "NonComm Short All"])
    comm_long = row_get(row, ["Comm_Positions_Long_All", "Commercial Positions Long All", "Comm Long All"])
    comm_short = row_get(row, ["Comm_Positions_Short_All", "Commercial Positions Short All", "Comm Short All"])

    if nc_long == 0 and nc_short == 0:
        nc_long = row_get(row, ["Lev_Money_Positions_Long_All", "M_Money_Positions_Long_All", "Managed_Money_Positions_Long_All"])
        nc_short = row_get(row, ["Lev_Money_Positions_Short_All", "M_Money_Positions_Short_All", "Managed_Money_Positions_Short_All"])

    if comm_long == 0 and comm_short == 0:
        comm_long = row_get(row, ["Dealer_Positions_Long_All", "Prod_Merc_Positions_Long_All", "Producer_Merchant_Positions_Long_All"])
        comm_short = row_get(row, ["Dealer_Positions_Short_All", "Prod_Merc_Positions_Short_All", "Producer_Merchant_Positions_Short_All"])

    ch_oi = row_get(row, [
        "Change in Open Interest (All)", "Change_in_Open_Interest_All",
        "Change Open Interest All", "Change_Open_Interest_All"
    ])
    ch_nc_long = row_get(row, [
        "Change in Noncommercial-Long (All)", "Change_in_NonComm_Long_All",
        "Change NonComm Long All", "Change_NonComm_Long_All"
    ])
    ch_nc_short = row_get(row, [
        "Change in Noncommercial-Short (All)", "Change_in_NonComm_Short_All",
        "Change NonComm Short All", "Change_NonComm_Short_All"
    ])
    ch_comm_long = row_get(row, [
        "Change in Commercial-Long (All)", "Change_in_Comm_Long_All",
        "Change Comm Long All", "Change_Comm_Long_All"
    ])
    ch_comm_short = row_get(row, [
        "Change in Commercial-Short (All)", "Change_in_Comm_Short_All",
        "Change Comm Short All", "Change_Comm_Short_All"
    ])

    comm_net = comm_long - comm_short
    spec_net = nc_long - nc_short
    comm_change = ch_comm_long - ch_comm_short
    spec_change = ch_nc_long - ch_nc_short

    return {
        "date": date,
        "currency": curr,
        "market": market,
        "source_file": str(row.get("_meridian_source_file", "")),
        "source_sha256": str(row.get("_meridian_source_sha256", "")),
        "source_row": str(row.get("_meridian_source_row", "")),
        "source_url": str(row.get("_meridian_source_url", "")),
        "cftc_contract_market_code": row_get_text(row, ["CFTC Contract Market Code", "CFTC_Contract_Market_Code"]),
        "cftc_market_code": row_get_text(row, ["CFTC Market Code in Initials", "CFTC_Market_Code_in_Initials"]),
        "cftc_commodity_code": row_get_text(row, ["CFTC Commodity Code", "CFTC_Commodity_Code"]),
        "open_interest": oi,
        "commercial_long": comm_long,
        "commercial_short": comm_short,
        "large_spec_long": nc_long,
        "large_spec_short": nc_short,
        "commercial_long_change": ch_comm_long,
        "commercial_short_change": ch_comm_short,
        "large_spec_long_change": ch_nc_long,
        "large_spec_short_change": ch_nc_short,
        "commercial_net": comm_net,
        "spec_net": spec_net,
        "commercial_change": comm_change,
        "spec_change": spec_change,
        "open_interest_change": ch_oi,
        "commercial_net_oi": comm_net / oi,
        "spec_net_oi": spec_net / oi,
        "commercial_change_oi": comm_change / oi,
        "spec_change_oi": spec_change / oi,
        "open_interest_change_oi": ch_oi / oi,
    }

def percentile_rank(values, current):
    values = [v for v in values if v is not None and not math.isnan(v)]
    if not values:
        return 50.0
    return clamp(100 * sum(1 for v in values if v <= current) / len(values))

def minmax_index(values, current):
    values = [v for v in values if v is not None and not math.isnan(v)]
    if len(values) < 2:
        return 50.0
    mn, mx = min(values), max(values)
    if mx == mn:
        return 50.0
    return clamp((current - mn) / (mx - mn) * 100)

def avg(values):
    values = [v for v in values if v is not None]
    return sum(values) / len(values) if values else 50.0

def directional_score(value, scale=0.025):
    # Wandelt Veränderung relativ zum Open Interest in einen 0 bis 100 Richtungswert um.
    # 50 ist neutral. Positive Werte sind bullisch, negative Werte bearisch.
    if scale <= 0:
        scale = 0.025
    return clamp(50 + math.tanh(value / scale) * 50)

def consistency_score(values):
    values = [v for v in values if v is not None]
    if not values:
        return 50.0
    total = sum(values)
    direction = 1 if total >= 0 else -1
    aligned = sum(1 for v in values if v * direction > 0)
    magnitude = directional_score(total, 0.060)
    consistency = aligned / max(1, len(values)) * 100
    return clamp(magnitude * 0.65 + consistency * 0.35)


def range_percentile_score(series, key, current, end=None, lookback=156):
    # Bewertet aktuelle Netto Position im historischen Kontext.
    # 0 bedeutet nahe historischer Unterkante, 100 nahe historischer Oberkante.
    if end is None:
        end = len(series)
    hist = [safe_float(r.get(key, 0.0), 0.0) for r in series[max(0, end - lookback):end]]
    if len(hist) < 20:
        return directional_score(current, 0.18)
    lo, hi = min(hist), max(hist)
    if abs(hi - lo) < 1e-12:
        return 50.0
    return clamp((safe_float(current, 0.0) - lo) / (hi - lo) * 100.0)

def directional_freshness_score(flow_1w, flow_4w):
    # Für Wochenfilter zählt frischer Kapitalfluss stärker als alte Lagerbestände.
    # Der Score bleibt richtungsbezogen: über 50 bullisch, unter 50 bearisch.
    base = directional_score(flow_1w * 0.62 + flow_4w * 0.38, 0.035)
    fresh_boost = clamp(abs(flow_1w) / 0.025 * 12.0, 0, 12)
    if base >= 50:
        return clamp(base + fresh_boost)
    return clamp(base - fresh_boost)

def flow_trend_score(flow_values):
    # Meridian Engine: bewertet nicht nur die letzte Woche, sondern ob der institutionelle
    # Flow über vier Wochen konsistent und beschleunigend ist. Positive Werte sind
    # bullisch, negative Werte bearisch, 50 ist neutral.
    values = [v for v in flow_values if v is not None]
    if not values:
        return 50.0
    total = sum(values)
    total_score = directional_score(total, 0.055)
    direction = 1 if total >= 0 else -1
    aligned = sum(1 for v in values if v * direction > 0) / max(1, len(values))
    if len(values) >= 4:
        previous_avg = sum(values[:-1]) / max(1, len(values[:-1]))
        acceleration = values[-1] - previous_avg
    else:
        acceleration = values[-1]
    acceleration_score = directional_score(acceleration, 0.018)
    return clamp(total_score * 0.55 + aligned * 100 * 0.25 + acceleration_score * 0.20)



def linear_slope(values):
    values = [safe_float(v, 0.0) for v in values]
    n = len(values)
    if n < 2:
        return 0.0
    x_mean = (n - 1) / 2.0
    y_mean = sum(values) / n
    denom = sum((i - x_mean) ** 2 for i in range(n)) or 1.0
    return sum((i - x_mean) * (values[i] - y_mean) for i in range(n)) / denom

def four_week_trend_quality(values, desired_direction=1):
    # Liefert die Transparenzwerte hinter dem 4W Trend.
    # Wichtig: total_delta allein reicht nicht, weil +30 aus einem sauberen Trend oder aus Chaos entstehen kann.
    values = [safe_float(v, 0.0) for v in values if v is not None]
    if len(values) < 2:
        return {
            "values": values, "deltas": [], "total_delta": 0.0, "slope": 0.0,
            "aligned_count": 0, "delta_count": 0, "alignment_pct": 0.0,
            "consistency_pct": 0.0, "quality_pct": 0.0
        }
    deltas = [values[i] - values[i - 1] for i in range(1, len(values))]
    total_delta = values[-1] - values[0]
    slope = linear_slope(values) * max(1, len(values) - 1)
    directional_deltas = [d * desired_direction for d in deltas]
    aligned_count = sum(1 for d in directional_deltas if d > 0)
    alignment_pct = aligned_count / max(1, len(deltas)) * 100.0

    positive_steps = [max(0.0, d) for d in directional_deltas]
    if sum(positive_steps) <= 1e-12:
        consistency_pct = 0.0
    else:
        avg_step = sum(positive_steps) / len(positive_steps)
        variance = sum((v - avg_step) ** 2 for v in positive_steps) / len(positive_steps)
        std = math.sqrt(variance)
        # Je niedriger die Streuung der positiven Wochenbeiträge, desto sauberer der institutionelle Aufbau.
        consistency_pct = clamp(100.0 - (std / (abs(avg_step) + 1e-12)) * 50.0, 0, 100)

    quality_pct = clamp(alignment_pct * 0.65 + consistency_pct * 0.35)
    return {
        "values": values,
        "deltas": deltas,
        "total_delta": total_delta,
        "slope": slope,
        "aligned_count": aligned_count,
        "delta_count": len(deltas),
        "alignment_pct": alignment_pct,
        "consistency_pct": consistency_pct,
        "quality_pct": quality_pct,
    }

def four_week_trend_score(values, desired_direction=1, scale=0.055):
    # Bewertet die letzten 4 COT Reports als echten Netto Positions Trend.
    # desired_direction = 1 bedeutet: steigende Netto Position ist bullisch für dieses Teilmodell.
    # desired_direction = -1 bedeutet: fallende Netto Position ist bullisch für dieses Teilmodell.
    values = [safe_float(v, 0.0) for v in values if v is not None]
    if len(values) < 2:
        return 50.0
    tq = four_week_trend_quality(values, desired_direction)
    total_score = directional_score(desired_direction * tq["total_delta"], scale)
    slope_score = directional_score(desired_direction * tq["slope"], scale)
    # v3.4.5: nicht nur Endwert minus Startwert, sondern zusätzlich Richtungstreue und Konstanz.
    return clamp(total_score * 0.40 + slope_score * 0.25 + tq["alignment_pct"] * 0.20 + tq["consistency_pct"] * 0.15)



def recency_weighted_trend_score(values, desired_direction=1, scale=0.055):
    # Swing Filter: Die letzten 4 Reports bleiben wichtig, aber die jüngste Woche zählt stärker.
    # Dadurch kippt der Score schneller, wenn frisches institutionelles Geld die alte 4W Struktur bricht.
    values = [safe_float(v, 0.0) for v in values if v is not None]
    if len(values) < 2:
        return 50.0
    deltas = [desired_direction * (values[i] - values[i - 1]) for i in range(1, len(values))]
    weights = [0.20, 0.30, 0.50][-len(deltas):]
    if len(weights) != len(deltas):
        weights = [1.0 / len(deltas)] * len(deltas)
    weighted_delta = sum(d * w for d, w in zip(deltas, weights))
    total_delta = desired_direction * (values[-1] - values[0])
    last_delta = deltas[-1]
    consistency = sum(1 for d in deltas if d > 0) / max(1, len(deltas)) * 100.0
    weighted_score = directional_score(weighted_delta, scale * 0.48)
    total_score = directional_score(total_delta, scale)
    last_score = directional_score(last_delta, scale * 0.40)
    return clamp(weighted_score * 0.38 + total_score * 0.24 + last_score * 0.23 + consistency * 0.15)

def acceleration_score(values, desired_direction=1, scale=0.035):
    # Bewertet, ob der aktuelle Positionsflow gegenüber den vorherigen Wochen beschleunigt.
    values = [safe_float(v, 0.0) for v in values if v is not None]
    if len(values) < 3:
        return 50.0
    deltas = [desired_direction * (values[i] - values[i - 1]) for i in range(1, len(values))]
    previous_avg = sum(deltas[:-1]) / max(1, len(deltas[:-1]))
    current = deltas[-1]
    acceleration = current - previous_avg
    return clamp(directional_score(acceleration, scale) * 0.70 + directional_score(current, scale) * 0.30)

def oi_participation_score(oi_values, directional_flow_score):
    # Für 2 bis 5 Tage Swing Trades ist Open Interest kein reiner Falling Filter.
    # Steigendes OI bestätigt frischen Flow, fallendes OI bestätigt eher Positionierungsauslauf.
    values = [safe_float(v, 0.0) for v in oi_values if v is not None]
    if len(values) < 2:
        return 50.0
    latest_oi = values[-1] if abs(values[-1]) > 0 else 1.0
    oi_change_1w = (values[-1] - values[-2]) / latest_oi
    oi_change_4w = (values[-1] - values[0]) / latest_oi
    expansion = directional_score(oi_change_1w * 0.65 + oi_change_4w * 0.35, 0.035)
    contraction = 100.0 - expansion
    if directional_flow_score >= 58:
        # Frischer bullischer oder bearischer Flow ist besser, wenn neue Teilnahme dazukommt.
        return clamp(expansion * 0.72 + 50.0 * 0.28)
    if directional_flow_score <= 42:
        return clamp(expansion * 0.72 + 50.0 * 0.28)
    # Ohne klaren Flow ist fallendes OI leicht positiv, weil es alte Positionen abbaut, aber nicht stark genug für ein Setup.
    return clamp(contraction * 0.45 + 50.0 * 0.55)

def oi_falling_score(oi_values):
    # Open Interest ist bewusst nur Bestätigung. Fallendes OI nach Positionsumschichtung
    # verstärkt das Signal, steigendes OI dämpft es leicht.
    values = [safe_float(v, 0.0) for v in oi_values if v is not None]
    if len(values) < 2:
        return 50.0
    base = four_week_trend_score(values, desired_direction=-1, scale=0.080)
    peak_before_end = max(values[:-1]) if len(values) > 2 else values[0]
    has_rollover = values[-1] < peak_before_end
    if has_rollover:
        base = clamp(base + 8)
    return base

def score_color(score):
    if score >= 62:
        return COLORS["green"]
    if score <= 38:
        return COLORS["red"]
    return COLORS["yellow"]

def research_category(score):
    score = safe_float(score, 50)
    if score >= 82:
        return "A+", "Premium Setup", COLORS["green"]
    if score >= 74:
        return "A", "Starkes Setup", COLORS["green"]
    if score >= 62:
        return "B", "Gutes Setup", COLORS["green"]
    if score >= 54:
        return "C", "Beobachtenswert", COLORS["yellow"]
    return "D", "Nur Watchlist Kandidat", COLORS["muted"]

def quality_label(score):
    letter, label, _ = research_category(score)
    explanations = {
        "A+": "Premium Setup: mehrere Faktoren sprechen klar in dieselbe Richtung.",
        "A": "Starkes Setup: hohe Meridian Qualität mit sauberem Commercial Bias.",
        "B": "Gutes Setup: sinnvoller Meridian Kandidat, Chartbestätigung bleibt wichtig.",
        "C": "Beobachtenswert: interessant, aber noch keine starke Vollbestätigung.",
        "D": "Nur Watchlist Kandidat: schwächere Woche oder uneinheitliche Faktoren.",
    }
    return f"{letter}  {label} | {explanations.get(letter, '')}"

def quality_short(score):
    return research_category(score)[0] + " " + research_category(score)[1]

def quality_stars(score):
    # Sterne bewusst nicht mehr genutzt, weil sie bei Research Scores psychologisch zu negativ wirken können.
    return ""

def confluence_label(supportive, total):
    if total <= 0:
        return "Keine Konfluenzdaten"
    ratio = supportive / total
    if ratio >= 0.75:
        return "starke Konfluenz"
    if ratio >= 0.55:
        return "solide Konfluenz"
    if ratio >= 0.40:
        return "gemischte Konfluenz"
    return "schwache Konfluenz"

def verdict_from_component(score):
    score = safe_float(score, 50)
    if score >= 68:
        return "stark unterstützend", COLORS["green"]
    if score >= 58:
        return "unterstützend", COLORS["green"]
    if score <= 32:
        return "starker Gegenwind", COLORS["red"]
    if score <= 42:
        return "Gegenwind", COLORS["red"]
    return "neutral", COLORS["yellow"]

def seasonality_color(verdict):
    if verdict in ("STARK_BESTÄTIGT", "BESTÄTIGT", "LEICHT_POSITIV"):
        return COLORS["green"]
    if verdict in ("STARK_KONFLIKT", "KONFLIKT", "LEICHT_NEGATIV"):
        return COLORS["red"]
    return COLORS["yellow"]


class WeeklyCotEngine:
    def __init__(self, progress):
        self.progress = progress
        self.records = {}
        self.years_loaded = []
        self.rows_loaded = 0
        self.report_date = "unbekannt"
        self.errors = []
        self.debug = []
        self.validation_warnings = []
        self.validation_errors = []
        self.used_usd_proxy = False
        self.source_files = []
        self.weekly_movers = []
        self.cftc_cache_status = "not_checked"
        self.cftc_cache_timestamp = None
        self.config = load_engine_config()
        self.weights = self.config["weights"].copy()
        self.lookback_weeks = self.config["lookback_weeks"]
        self.analysis_engine = DEFAULT_ANALYSIS_ENGINE


    def set_analysis_engine(self, engine_key):
        self.analysis_engine = engine_key if engine_key in ENGINE_LABELS else DEFAULT_ANALYSIS_ENGINE

    def calculate_analysis_profile(self, result, engine_key=None):
        """Berechnet alle drei Profile aus derselben validierten Währungsbasis.

        Classic und Flow behalten ihre bisherige Methodik. Hybrid ist eine
        eigenständige Kontextlogik: Die Commercial Position ist nur ein Faktor.
        Unabhängige Flow Komponenten dürfen die Richtung neutralisieren oder drehen.
        Open Interest und Modulübereinstimmung bestimmen die Hybrid Qualität.
        """
        engine_key = engine_key if engine_key in ENGINE_LABELS else self.analysis_engine
        classic_score = safe_float(result.get("classic_engine_score", result.get("strength", 50)), 50)
        flow_1w = safe_float(result.get("commercial_weekly_change", 50), 50)
        flow_4w = safe_float(result.get("commercial_4w_net_trend", 50), 50)
        acceleration = safe_float(result.get("flow_acceleration", 50), 50)
        oi_change = safe_float(result.get("oi_participation", 50), 50)
        spec_1w = safe_float(result.get("large_spec_weekly_change", 50), 50)
        commercial_change = clamp(flow_1w * 0.70 + spec_1w * 0.30)
        momentum_score = clamp(
            commercial_change * 0.30
            + flow_4w * 0.25
            + flow_1w * 0.20
            + acceleration * 0.15
            + oi_change * 0.10
        )

        components = result.get("components", {}) or {}
        position_context = safe_float(components.get("hybrid_commercial_position_context", result.get("commercial_position", 50)), 50)
        commercial_flow = safe_float(components.get("hybrid_commercial_flow", result.get("commercial_long_short_flow_absolute", flow_1w)), 50)
        spec_flow = safe_float(components.get("hybrid_large_spec_flow", result.get("large_spec_long_short_flow_absolute", spec_1w)), 50)
        acceleration_abs = safe_float(components.get("hybrid_flow_acceleration", result.get("flow_acceleration_absolute", acceleration)), 50)
        four_week_context = safe_float(components.get("hybrid_four_week_context", avg([
            result.get("commercial_4w_net_trend_absolute", flow_4w),
            result.get("large_spec_4w_net_trend_absolute", 50),
        ])), 50)

        hybrid_score = clamp(
            position_context * 0.20
            + commercial_flow * 0.30
            + spec_flow * 0.25
            + acceleration_abs * 0.15
            + four_week_context * 0.10
        )
        hybrid_side = 1 if hybrid_score >= 52 else -1 if hybrid_score <= 48 else 0
        directional_modules = [position_context, commercial_flow, spec_flow, acceleration_abs, four_week_context]
        module_weights = [0.20, 0.30, 0.25, 0.15, 0.10]
        if hybrid_side:
            aligned_weight = sum(
                weight for value, weight in zip(directional_modules, module_weights)
                if (value - 50.0) * hybrid_side >= 4.0
            )
            conflicting_weight = sum(
                weight for value, weight in zip(directional_modules, module_weights)
                if (value - 50.0) * hybrid_side <= -4.0
            )
            agreement_quality = clamp(50.0 + aligned_weight * 55.0 - conflicting_weight * 45.0)
        else:
            agreement_quality = clamp(100.0 - avg([abs(value - 50.0) for value in directional_modules]) * 2.0)
        raw = result.get("raw_audit", {}) or {}
        stability_quality = avg([
            safe_float(raw.get("commercial_4w_quality_pct", 50), 50),
            safe_float(raw.get("large_spec_4w_quality_pct", 50), 50),
        ])
        data_quality = safe_float(result.get("quality", 50), 50)
        hybrid_quality = clamp(
            agreement_quality * 0.35
            + oi_change * 0.30
            + stability_quality * 0.20
            + data_quality * 0.15
        )

        if engine_key == ENGINE_FLOW:
            selected_score = momentum_score
            selected_confidence = confidence_from_score(selected_score)
        elif engine_key == ENGINE_HYBRID:
            selected_score = hybrid_score
            selected_confidence = hybrid_quality
        else:
            selected_score = classic_score
            selected_confidence = confidence_from_score(selected_score)

        return {
            "classic_score": clamp(classic_score),
            "momentum_score": clamp(momentum_score),
            "hybrid_score": clamp(hybrid_score),
            "hybrid_quality": clamp(hybrid_quality),
            "hybrid_agreement_quality": clamp(agreement_quality),
            "hybrid_stability_quality": clamp(stability_quality),
            "selected_score": clamp(selected_score),
            "selected_confidence": clamp(selected_confidence),
            "engine_key": engine_key,
            "hybrid_components": {
                "commercial_position_context": round(position_context, 1),
                "commercial_flow": round(commercial_flow, 1),
                "large_spec_flow": round(spec_flow, 1),
                "flow_acceleration": round(acceleration_abs, 1),
                "four_week_context": round(four_week_context, 1),
                "open_interest_quality": round(oi_change, 1),
                "agreement_quality": round(agreement_quality, 1),
                "stability_quality": round(stability_quality, 1),
                "data_quality": round(data_quality, 1),
            },
        }

    def apply_analysis_profile(self, result):
        profile = self.calculate_analysis_profile(result, self.analysis_engine)
        selected_score = profile["selected_score"]
        result["classic_engine_score"] = round(profile["classic_score"], 1)
        result["momentum_engine_score"] = round(profile["momentum_score"], 1)
        result["hybrid_engine_score"] = round(profile["hybrid_score"], 1)
        result["hybrid_quality_score"] = round(profile["hybrid_quality"], 1)
        result["analysis_engine"] = self.analysis_engine
        result["analysis_engine_label"] = ENGINE_LABELS[self.analysis_engine]
        result["analysis_engine_weights"] = ENGINE_PROFILE_WEIGHTS[self.analysis_engine]
        result["analysis_engine_reason"] = ENGINE_REASONS[self.analysis_engine]
        result["strength"] = round(selected_score, 1)
        result["weekly_strength"] = round(selected_score, 1)
        result["confidence"] = round(profile["selected_confidence"], 1)
        result["probability"] = result["confidence"]
        result["signed_strength"] = round((selected_score - 50.0) * 2.0, 1)
        if self.analysis_engine != ENGINE_CLASSIC:
            result["bias"] = "BULLISH" if selected_score >= 58 else "BEARISH" if selected_score <= 42 else "NEUTRAL"
        result.setdefault("components", {})["classic_engine_score"] = round(profile["classic_score"], 1)
        result["components"]["momentum_engine_score"] = round(profile["momentum_score"], 1)
        result["components"]["hybrid_engine_score"] = round(profile["hybrid_score"], 1)
        result["components"]["hybrid_quality_score"] = round(profile["hybrid_quality"], 1)
        result["components"]["selected_engine_score"] = round(selected_score, 1)
        result["components"]["hybrid_profile"] = profile["hybrid_components"]
        result.setdefault("raw_audit", {})["analysis_engine"] = self.analysis_engine
        result["raw_audit"]["analysis_engine_label"] = ENGINE_LABELS[self.analysis_engine]
        result["raw_audit"]["analysis_engine_weights"] = ENGINE_PROFILE_WEIGHTS[self.analysis_engine]
        result["raw_audit"]["analysis_engine_reason"] = ENGINE_REASONS[self.analysis_engine]
        result["raw_audit"]["hybrid_method"] = "Independent Context 104W: Position 20, Commercial Flow 30, Large Spec Flow 25, Acceleration 15, Four Week Context 10. Open Interest contributes to quality, not direction."
        result["raw_audit"]["hybrid_profile"] = profile["hybrid_components"]
        return result

    def reset(self):
        self.records = {}
        self.years_loaded = []
        self.rows_loaded = 0
        self.report_date = "unbekannt"
        self.errors = []
        self.debug = []
        self.validation_warnings = []
        self.validation_errors = []
        self.used_usd_proxy = False
        self.source_files = []
        self.weekly_movers = []
        self.cftc_cache_status = "not_checked"
        self.cftc_cache_timestamp = None

    def load_year(self, year):
        # Strikter CFTC Legacy Modus mit Tagescache.
        # Für Rohdaten und Meridian Engine wird ausschließlich der offizielle historische
        # Report deacotYYYY.zip verwendet. Das aktuelle Jahr wird höchstens einmal
        # pro lokalem Kalendertag aktualisiert. Weitere Analysen desselben Tages
        # verwenden den geprüften lokalen Cache. Abgeschlossene Vorjahre bleiben
        # dauerhaft im Cache. Fehlende oder ungültige ZIP Dateien werden neu geladen.
        path = DATA_DIR / f"deacot{year}.zip"
        now = datetime.now()
        current_year = now.year
        is_current_year = year == current_year
        url = CFTC_HIST_URLS[0].format(year=year)

        cache_exists = path.exists()
        cache_is_valid = cache_exists and zipfile.is_zipfile(path)
        cache_date = datetime.fromtimestamp(path.stat().st_mtime).date() if cache_exists else None
        cache_is_from_today = cache_is_valid and cache_date == now.date()

        needs_download = not cache_is_valid
        if is_current_year and not cache_is_from_today:
            needs_download = True

        if needs_download:
            tmp_path = path.with_suffix(path.suffix + ".download")
            try:
                if tmp_path.exists():
                    tmp_path.unlink()
                download_url(url, tmp_path)
                if not zipfile.is_zipfile(tmp_path):
                    raise RuntimeError("CFTC Download ist keine gültige ZIP Datei")
                tmp_path.replace(path)
                if is_current_year:
                    self.cftc_cache_status = "downloaded_today"
                    self.cftc_cache_timestamp = datetime.fromtimestamp(path.stat().st_mtime)
                    self.debug.append(f"{year}: aktueller CFTC Legacy Report heute neu geladen")
                else:
                    self.debug.append(f"{year}: fehlender oder ungültiger CFTC Legacy Cache neu geladen")
            except Exception as exc:
                if tmp_path.exists():
                    try:
                        tmp_path.unlink()
                    except Exception:
                        pass
                if cache_is_valid:
                    if is_current_year:
                        self.cftc_cache_status = "cache_fallback"
                        self.cftc_cache_timestamp = datetime.fromtimestamp(path.stat().st_mtime)
                    self.validation_warnings.append(f"{year}: CFTC Download fehlgeschlagen, vorhandener lokaler Cache wurde verwendet: {type(exc).__name__}: {str(exc)}")
                else:
                    self.errors.append(f"{year} Legacy Quelle nicht geladen: {type(exc).__name__}: {str(exc)}")
                    return []
        elif is_current_year:
            self.cftc_cache_status = "cache_today"
            self.cftc_cache_timestamp = datetime.fromtimestamp(path.stat().st_mtime)
            self.debug.append(f"{year}: bereits heute aktualisiert, lokaler CFTC Cache verwendet")
        else:
            self.debug.append(f"{year}: abgeschlossener Jahresreport aus lokalem Cache verwendet")
        try:
            rows = read_zip_tables(path)
            if rows:
                file_hash = sha256_file(path)
                for idx, row in enumerate(rows, start=1):
                    row["_meridian_source_file"] = path.name
                    row["_meridian_source_sha256"] = file_hash
                    row["_meridian_source_row"] = idx
                    row["_meridian_source_url"] = CFTC_HIST_URLS[0].format(year=year)
                self.source_files.append({
                    "year": year,
                    "file": path.name,
                    "url": CFTC_HIST_URLS[0].format(year=year),
                    "sha256": file_hash,
                    "rows": len(rows),
                    "mode": "CFTC Legacy deacotYYYY.zip"
                })
                self.debug.append(f"{year}: CFTC Legacy Quelle {path.name} | SHA256 {file_hash[:12]} | {len(rows)} Zeilen")
                return rows
        except Exception as exc:
            self.errors.append(f"{year} Legacy Quelle fehlerhaft: {type(exc).__name__}: {str(exc)}")
        return []

    def prepare(self, years_back=2):
        self.reset()
        current_year = datetime.now().year
        years = list(range(current_year, current_year - years_back, -1))  # Meridian Engine braucht nur aktuelles und Vorjahr fuer die letzten Reports
        all_rows = []

        for i, year in enumerate(years):
            pct = 5 + int(28 * i / max(1, len(years)))
            self.progress(pct, f"CFTC Reports {year} laden")
            rows = self.load_year(year)
            if rows:
                all_rows.extend(rows)
                self.years_loaded.append(year)

        self.rows_loaded = len(all_rows)
        self.progress(38, "Forex COT Märkte filtern")

        records = {c: [] for c in list(MARKETS.keys()) + list(SINGLE_ASSET_MARKETS.keys())}
        for row in all_rows:
            market = row.get("Market_and_Exchange_Names") or row.get("Market and Exchange Names") or row.get("Market_and_Exchange_Name") or ""
            if not market:
                market = row_get_text(row, ["Market_and_Exchange_Names", "Market and Exchange Names", "Market_and_Exchange_Name"])
            if not market:
                for k, v in row.items():
                    if "market" in str(k).lower() and "exchange" in str(k).lower():
                        market = str(v)
                        break
            curr = match_currency(market) or match_single_asset(market)
            if not curr:
                continue
            rec = normalize_record(row, curr)
            if rec:
                records[curr].append(rec)

        self.progress(48, "Wochenänderungen normalisieren")
        for curr, series in records.items():
            dedup = {}
            for rec in series:
                dedup[rec["date"].strftime("%Y-%m-%d")] = rec
            s = sorted(dedup.values(), key=lambda x: x["date"])

            # Meridian Engine: Change Werte werden bewusst aus zwei direkt
            # aufeinanderfolgenden CFTC Reports neu berechnet. Dadurch ist klar:
            # 1W = aktueller Report minus Vorwochen Report.
            # Die originalen CFTC Change Felder bleiben im Audit als Rohhinweis erhalten,
            # steuern aber nicht die Engine. So vermeiden wir Spalten Mapping Fehler.
            if s:
                s[0]["raw_cftc_commercial_long_change"] = s[0].get("commercial_long_change", 0.0)
                s[0]["raw_cftc_commercial_short_change"] = s[0].get("commercial_short_change", 0.0)
                s[0]["raw_cftc_large_spec_long_change"] = s[0].get("large_spec_long_change", 0.0)
                s[0]["raw_cftc_large_spec_short_change"] = s[0].get("large_spec_short_change", 0.0)
                s[0]["raw_cftc_open_interest_change"] = s[0].get("open_interest_change", 0.0)
                s[0]["commercial_long_change"] = 0.0
                s[0]["commercial_short_change"] = 0.0
                s[0]["large_spec_long_change"] = 0.0
                s[0]["large_spec_short_change"] = 0.0
                s[0]["commercial_change"] = 0.0
                s[0]["spec_change"] = 0.0
                s[0]["open_interest_change"] = 0.0

            for i in range(1, len(s)):
                prev, cur = s[i - 1], s[i]
                cur["raw_cftc_commercial_long_change"] = cur.get("commercial_long_change", 0.0)
                cur["raw_cftc_commercial_short_change"] = cur.get("commercial_short_change", 0.0)
                cur["raw_cftc_large_spec_long_change"] = cur.get("large_spec_long_change", 0.0)
                cur["raw_cftc_large_spec_short_change"] = cur.get("large_spec_short_change", 0.0)
                cur["raw_cftc_open_interest_change"] = cur.get("open_interest_change", 0.0)

                cur["commercial_long_change"] = cur["commercial_long"] - prev["commercial_long"]
                cur["commercial_short_change"] = cur["commercial_short"] - prev["commercial_short"]
                cur["large_spec_long_change"] = cur["large_spec_long"] - prev["large_spec_long"]
                cur["large_spec_short_change"] = cur["large_spec_short"] - prev["large_spec_short"]
                cur["commercial_change"] = cur["commercial_net"] - prev["commercial_net"]
                cur["spec_change"] = cur["spec_net"] - prev["spec_net"]
                cur["open_interest_change"] = cur["open_interest"] - prev["open_interest"]
                oi = cur["open_interest"] if abs(cur["open_interest"]) > 0 else 1.0
                cur["commercial_change_oi"] = cur["commercial_change"] / oi
                cur["spec_change_oi"] = cur["spec_change"] / oi
                cur["open_interest_change_oi"] = cur["open_interest_change"] / oi

            records[curr] = s

        self.records = records
        latest_dates = [s[-1]["date"] for s in records.values() if s]
        if latest_dates:
            self.report_date = max(latest_dates).strftime("%Y-%m-%d")

        self.debug = [f"{c}: {len(v)} Wochen" for c, v in records.items()]
        return records

    def window(self, series, n, end=None):
        if end is None:
            end = len(series)
        return series[max(0, end - n):end]

    def sum_last(self, series, key, n, end=None):
        return sum(r.get(key, 0.0) for r in self.window(series, n, end))

    def rolling_sums(self, series, key, n, end=None):
        if end is None:
            end = len(series)
        vals = [r.get(key, 0.0) for r in series[:end]]
        return [sum(vals[i-n+1:i+1]) for i in range(n - 1, len(vals))]

    def compute_currency_at(self, curr, series, end_index):
        if end_index < max(5, self.lookback_weeks + 1):
            return None

        latest = series[end_index - 1]
        recent = self.window(series, self.lookback_weeks, end_index)
        first = recent[0]

        # Meridian Flow Engine 2.0
        # Ebene 1: Die Richtung kommt aus dem aktuellen Commercial Netto Überhang.
        # Ebene 2: Die Qualität kommt aus echten Positionsverschiebungen.
        # Dabei werden Long und Short Veränderungen getrennt gelesen:
        # Bullisch ist Commercial Long Aufbau plus Commercial Short Abbau.
        # Bearisch ist Commercial Short Aufbau plus Commercial Long Abbau.
        # Large Specs, Open Interest und Flow Beschleunigung bestätigen oder dämpfen
        # nur die Qualität. Sie drehen keinen klaren Commercial Bias um.
        oi_latest = max(abs(latest.get("open_interest", 0.0)), 1.0)
        comm_net_oi_values = [r.get("commercial_net_oi", 0.0) for r in recent]
        spec_net_oi_values = [r.get("spec_net_oi", 0.0) for r in recent]
        oi_values = [r.get("open_interest", 0.0) for r in recent]

        cot_index_values = []
        for j in range(end_index - len(recent), end_index):
            rec_j = series[j]
            cot_index_values.append(range_percentile_score(series, "commercial_net_oi", rec_j.get("commercial_net_oi", 0.0), j + 1, COT_INDEX_LOOKBACK_WEEKS))

        commercial_position = range_percentile_score(series, "commercial_net_oi", latest.get("commercial_net_oi", 0.0), end_index, COT_INDEX_LOOKBACK_WEEKS)
        commercial_net_score = directional_score(latest.get("commercial_net_oi", 0.0), scale=0.16)
        commercial_net_oi = latest.get("commercial_net_oi", 0.0)

        # Ebene 1: aktueller Commercial Netto Überhang. Mini Überhänge bleiben neutral.
        if commercial_net_oi >= 0.006:
            bias_side = 1
            bias = "BULLISH"
        elif commercial_net_oi <= -0.006:
            bias_side = -1
            bias = "BEARISH"
        else:
            bias_side = 0
            bias = "NEUTRAL"

        dominance_edge = clamp(abs(commercial_net_oi) / 0.20 * 36.0, 0.0, 36.0)
        institutional_bias_score = 50.0 + bias_side * dominance_edge if bias_side else commercial_net_score

        # Ebene 2: Long/Short Positionsverschiebungen separat messen.
        comm_long_1w = latest.get("commercial_long_change", 0.0)
        comm_short_1w = latest.get("commercial_short_change", 0.0)
        spec_long_1w = latest.get("large_spec_long_change", 0.0)
        spec_short_1w = latest.get("large_spec_short_change", 0.0)

        comm_long_4w = latest.get("commercial_long", 0.0) - first.get("commercial_long", 0.0)
        comm_short_4w = latest.get("commercial_short", 0.0) - first.get("commercial_short", 0.0)
        spec_long_4w = latest.get("large_spec_long", 0.0) - first.get("large_spec_long", 0.0)
        spec_short_4w = latest.get("large_spec_short", 0.0) - first.get("large_spec_short", 0.0)

        # Bullischer Rohflow: Long Aufbau und Short Abbau. Bearischer Rohflow ist das Vorzeichen davon.
        commercial_bull_flow_1w_oi = (comm_long_1w - comm_short_1w) / oi_latest
        commercial_bull_flow_4w_oi = (comm_long_4w - comm_short_4w) / oi_latest
        spec_bull_flow_1w_oi = (spec_long_1w - spec_short_1w) / oi_latest
        spec_bull_flow_4w_oi = (spec_long_4w - spec_short_4w) / oi_latest


        # Meridian Engine Modul 2/3 Audit Variablen:
        # Positive Werte bedeuten bullischen Long/Short Flow.
        # Negative Werte bedeuten bearischen Long/Short Flow.
        commercial_flow_1w_oi = commercial_bull_flow_1w_oi
        commercial_flow_4w_oi = commercial_bull_flow_4w_oi
        spec_flow_1w_oi = spec_bull_flow_1w_oi
        spec_flow_4w_oi = spec_bull_flow_4w_oi

        # Recency Gewichtung: aktuelle Woche 70 %, vier Wochen Kontext 30 %.
        commercial_bull_flow_weighted = commercial_bull_flow_1w_oi * 0.70 + commercial_bull_flow_4w_oi * 0.30
        spec_bull_flow_weighted = spec_bull_flow_1w_oi * 0.70 + spec_bull_flow_4w_oi * 0.30

        # Doppelte Aktion erkennen: bullisch = Longs hoch und Shorts runter, bearisch = Shorts hoch und Longs runter.
        commercial_double_bull = (max(comm_long_1w, 0.0) + max(-comm_short_1w, 0.0) + 0.45 * (max(comm_long_4w, 0.0) + max(-comm_short_4w, 0.0))) / oi_latest
        commercial_double_bear = (max(comm_short_1w, 0.0) + max(-comm_long_1w, 0.0) + 0.45 * (max(comm_short_4w, 0.0) + max(-comm_long_4w, 0.0))) / oi_latest
        spec_double_bull = (max(spec_long_1w, 0.0) + max(-spec_short_1w, 0.0) + 0.45 * (max(spec_long_4w, 0.0) + max(-spec_short_4w, 0.0))) / oi_latest
        spec_double_bear = (max(spec_short_1w, 0.0) + max(-spec_long_1w, 0.0) + 0.45 * (max(spec_short_4w, 0.0) + max(-spec_long_4w, 0.0))) / oi_latest

        if bias_side > 0:
            commercial_directional_flow = commercial_bull_flow_weighted
            spec_directional_flow = spec_bull_flow_weighted
            commercial_double_action = commercial_double_bull - commercial_double_bear * 0.65
            spec_double_action = spec_double_bull - spec_double_bear * 0.65
        elif bias_side < 0:
            commercial_directional_flow = -commercial_bull_flow_weighted
            spec_directional_flow = -spec_bull_flow_weighted
            commercial_double_action = commercial_double_bear - commercial_double_bull * 0.65
            spec_double_action = spec_double_bear - spec_double_bull * 0.65
        else:
            commercial_directional_flow = commercial_bull_flow_weighted
            spec_directional_flow = spec_bull_flow_weighted
            commercial_double_action = commercial_double_bull - commercial_double_bear
            spec_double_action = spec_double_bull - spec_double_bear

        commercial_flow_score = clamp(directional_score(commercial_directional_flow, scale=0.040) * 0.72 + directional_score(commercial_double_action, scale=0.060) * 0.28)
        large_spec_flow_score = clamp(directional_score(spec_directional_flow, scale=0.040) * 0.70 + directional_score(spec_double_action, scale=0.060) * 0.30)
        # Unabhängige bullisch bearisch Skalen für Hybrid. Anders als Classic
        # werden diese Werte nicht am zuvor gesetzten Commercial Bias gespiegelt.
        commercial_flow_score_absolute = clamp(
            directional_score(commercial_bull_flow_weighted, scale=0.040) * 0.72
            + directional_score(commercial_double_bull - commercial_double_bear, scale=0.060) * 0.28
        )
        large_spec_flow_score_absolute = clamp(
            directional_score(spec_bull_flow_weighted, scale=0.040) * 0.70
            + directional_score(spec_double_bull - spec_double_bear, scale=0.060) * 0.30
        )

        # Netto Trend bleibt Diagnose, Long/Short Verschiebungen sind aber entscheidender.
        comm_trend_quality = four_week_trend_quality(comm_net_oi_values, desired_direction=1)
        spec_trend_quality = four_week_trend_quality(spec_net_oi_values, desired_direction=1)
        cot_index_quality = four_week_trend_quality(cot_index_values, desired_direction=1)
        oi_trend_quality = four_week_trend_quality(oi_values, desired_direction=1)
        commercial_net_trend_bull = recency_weighted_trend_score(comm_net_oi_values, desired_direction=1, scale=0.055)
        large_spec_net_trend_bull = recency_weighted_trend_score(spec_net_oi_values, desired_direction=1, scale=0.055)

        commercial_acceleration_bull = acceleration_score(comm_net_oi_values, desired_direction=1, scale=0.030)
        large_spec_acceleration_bull = acceleration_score(spec_net_oi_values, desired_direction=1, scale=0.030)
        if bias_side < 0:
            commercial_trend = 100.0 - commercial_net_trend_bull
            large_spec_trend = 100.0 - large_spec_net_trend_bull
            flow_acceleration = 100.0 - clamp(commercial_acceleration_bull * 0.45 + large_spec_acceleration_bull * 0.55)
        elif bias_side > 0:
            commercial_trend = commercial_net_trend_bull
            large_spec_trend = large_spec_net_trend_bull
            flow_acceleration = clamp(commercial_acceleration_bull * 0.45 + large_spec_acceleration_bull * 0.55)
        else:
            commercial_trend = commercial_net_trend_bull
            large_spec_trend = large_spec_net_trend_bull
            flow_acceleration = clamp(commercial_acceleration_bull * 0.45 + large_spec_acceleration_bull * 0.55)

        commercial_trend_absolute = commercial_net_trend_bull
        large_spec_trend_absolute = large_spec_net_trend_bull
        flow_acceleration_absolute = clamp(commercial_acceleration_bull * 0.45 + large_spec_acceleration_bull * 0.55)
        four_week_context_absolute = clamp(commercial_trend_absolute * 0.55 + large_spec_trend_absolute * 0.45)

        cot_index_trend = recency_weighted_trend_score(cot_index_values, desired_direction=1, scale=35.0)
        if bias_side < 0:
            cot_index_context = 100.0 - commercial_position
        elif bias_side > 0:
            cot_index_context = commercial_position
        else:
            cot_index_context = 50.0

        fresh_flow = clamp(commercial_flow_score * 0.55 + large_spec_flow_score * 0.45)
        oi_participation = oi_participation_score(oi_values, fresh_flow)
        oi_falling = oi_falling_score(oi_values)

        # Meridian Engine Clean Flow: Kein verstecktes Prozent Mischsignal.
        # Jedes Modul liefert ein eigenes Urteil. Die Commercial Richtung bleibt der Anker.
        commercial_module = commercial_flow_score
        spec_module = large_spec_flow_score
        oi_module = oi_participation
        acceleration_module = flow_acceleration

        confirmations = 0
        conflicts = 0
        for module_score in (commercial_module, spec_module, oi_module, acceleration_module):
            if module_score >= 57:
                confirmations += 1
            elif module_score <= 43:
                conflicts += 1

        # Qualität wird aus Modulen gebildet, nicht aus einem neuen Richtungsgeber.
        confirmation_score = clamp(
            50.0
            + confirmations * 9.5
            - conflicts * 7.0
            + (commercial_module - 50.0) * 0.22
            + (spec_module - 50.0) * 0.18
            + (oi_module - 50.0) * 0.10
        )

        # Finale Stärke: Commercial Netto bestimmt Richtung, Module bestimmen nur Abstand von 50.
        quality_edge = clamp((confirmation_score - 50.0) * 0.38, -12.0, 20.0)
        final_edge = clamp(dominance_edge + quality_edge, 4.0 if bias_side else 0.0, 46.0)
        if bias_side > 0:
            weekly_strength = clamp(50.0 + final_edge)
        elif bias_side < 0:
            weekly_strength = clamp(50.0 - final_edge)
        else:
            # Ohne klaren Commercial Überhang bleibt der Markt grundsätzlich neutral.
            weekly_strength = clamp(50.0 + (fresh_flow - 50.0) * 0.18)

        quality = clamp(min(100, end_index / 52 * 100))
        confidence = confidence_from_score(weekly_strength)

        large_spec_position = range_percentile_score(series, "spec_net_oi", latest.get("spec_net_oi", 0.0), end_index, 156)
        commercial_weekly_change = commercial_flow_score if bias_side >= 0 else 100.0 - commercial_flow_score
        large_spec_weekly_change = large_spec_flow_score if bias_side >= 0 else 100.0 - large_spec_flow_score
        open_interest_confirmation = oi_participation
        flow_trend_filter = fresh_flow
        cot_freshness = clamp(flow_acceleration * 0.45 + fresh_flow * 0.35 + cot_index_context * 0.20)

        bias_score = weekly_strength
        flow_score = clamp(50.0 + bias_side * (fresh_flow - 50.0)) if bias_side else fresh_flow
        momentum_score = clamp(50.0 + bias_side * (flow_acceleration - 50.0)) if bias_side else flow_acceleration
        participation_score = open_interest_confirmation

        components = {
            "commercial_position": round(commercial_position, 1),
            "commercial_net_score": round(commercial_net_score, 1),
            "institutional_bias_score": round(institutional_bias_score, 1),
            "commercial_weekly_change": round(commercial_weekly_change, 1),
            "large_spec_position": round(large_spec_position, 1),
            "large_spec_weekly_change": round(large_spec_weekly_change, 1),
            "open_interest_confirmation": round(open_interest_confirmation, 1),
            "flow_trend_filter": round(flow_trend_filter, 1),
            "cot_freshness": round(cot_freshness, 1),
            "bias_score": round(bias_score, 1),
            "confirmation_score": round(confirmation_score, 1),
            "flow_score": round(flow_score, 1),
            "momentum_score": round(momentum_score, 1),
            "participation_score": round(participation_score, 1),
            "commercial_4w_net_trend": round(commercial_trend, 1),
            "large_spec_4w_net_trend": round(large_spec_trend, 1),
            "cot_index_4w_trend": round(cot_index_trend, 1),
            "cot_index_context": round(cot_index_context, 1),
            "commercial_long_short_flow": round(commercial_flow_score, 1),
            "large_spec_long_short_flow": round(large_spec_flow_score, 1),
            "oi_4w_falling_filter": round(oi_falling, 1),
            "flow_acceleration": round(flow_acceleration, 1),
            "oi_participation": round(oi_participation, 1),
            "hybrid_commercial_position_context": round(commercial_position, 1),
            "hybrid_commercial_flow": round(commercial_flow_score_absolute, 1),
            "hybrid_large_spec_flow": round(large_spec_flow_score_absolute, 1),
            "hybrid_flow_acceleration": round(flow_acceleration_absolute, 1),
            "hybrid_four_week_context": round(four_week_context_absolute, 1),
        }
        weighted_points = {
            "commercial_current_bias": round((institutional_bias_score - 50) * 0.52, 2),
            "commercial_long_short_flow": round((commercial_flow_score - 50) * 0.20, 2),
            "large_spec_long_short_flow": round((large_spec_flow_score - 50) * 0.18, 2),
            "flow_acceleration": round((flow_acceleration - 50) * 0.06, 2),
            "oi_participation": round((oi_participation - 50) * 0.04, 2),
        }

        large_spec_momentum = large_spec_flow_score if bias_side >= 0 else 100.0 - large_spec_flow_score
        commercial_flow = commercial_flow_score if bias_side >= 0 else 100.0 - commercial_flow_score
        alignment = clamp(commercial_flow_score * 0.50 + large_spec_flow_score * 0.50)
        flow_consistency = flow_trend_filter
        market_participation = open_interest_confirmation

        result = {
            "currency": curr,
            "weekly_strength": round(weekly_strength, 1),
            "strength": round(weekly_strength, 1),
            "confidence": round(confidence, 1),
            "probability": round(confidence, 1),
            "bias": bias,
            "weekly_impulse": round(large_spec_momentum, 1),
            "fresh_impulse": round(large_spec_momentum, 1),
            "four_week_confirmation": round(flow_consistency, 1),
            "commercial_change": round(commercial_flow, 1),
            "large_spec_flow": round(large_spec_momentum, 1),
            "spec_flow": round(large_spec_momentum, 1),
            "market_quality": round(market_participation, 1),
            "open_interest": round(market_participation, 1),
            "large_spec_momentum": round(large_spec_momentum, 1),
            "commercial_flow": round(commercial_flow, 1),
            "alignment": round(alignment, 1),
            "flow_consistency": round(flow_consistency, 1),
            "market_participation": round(market_participation, 1),
            "commercial_position": round(commercial_position, 1),
            "commercial_net_score": round(commercial_net_score, 1),
            "institutional_bias_score": round(institutional_bias_score, 1),
            "commercial_weekly_change": round(commercial_weekly_change, 1),
            "large_spec_position": round(large_spec_position, 1),
            "large_spec_weekly_change": round(large_spec_weekly_change, 1),
            "open_interest_confirmation": round(open_interest_confirmation, 1),
            "flow_trend_filter": round(flow_trend_filter, 1),
            "cot_freshness": round(cot_freshness, 1),
            "bias_score": round(bias_score, 1),
            "confirmation_score": round(confirmation_score, 1),
            "flow_score": round(flow_score, 1),
            "momentum_score": round(momentum_score, 1),
            "participation_score": round(participation_score, 1),
            "commercial_4w_net_trend": round(commercial_trend, 1),
            "large_spec_4w_net_trend": round(large_spec_trend, 1),
            "cot_index_4w_trend": round(cot_index_trend, 1),
            "cot_index_context": round(cot_index_context, 1),
            "commercial_long_short_flow": round(commercial_flow_score, 1),
            "large_spec_long_short_flow": round(large_spec_flow_score, 1),
            "oi_4w_falling_filter": round(oi_falling, 1),
            "flow_acceleration": round(flow_acceleration, 1),
            "oi_participation": round(oi_participation, 1),
            "commercial_long_short_flow_absolute": round(commercial_flow_score_absolute, 1),
            "large_spec_long_short_flow_absolute": round(large_spec_flow_score_absolute, 1),
            "flow_acceleration_absolute": round(flow_acceleration_absolute, 1),
            "commercial_4w_net_trend_absolute": round(commercial_trend_absolute, 1),
            "large_spec_4w_net_trend_absolute": round(large_spec_trend_absolute, 1),
            "hybrid_four_week_context": round(four_week_context_absolute, 1),
            "quality": round(quality, 1),
            "components": components,
            "weighted_points": weighted_points,
            "weeks": end_index,
            "latest_date": latest["date"].strftime("%Y-%m-%d"),
            "raw_audit": {
                "market": latest.get("market", ""),
                "source_file": latest.get("source_file", ""),
                "source_url": latest.get("source_url", ""),
                "source_sha256": latest.get("source_sha256", ""),
                "source_row": latest.get("source_row", ""),
                "cftc_contract_market_code": latest.get("cftc_contract_market_code", ""),
                "cftc_market_code": latest.get("cftc_market_code", ""),
                "cftc_commodity_code": latest.get("cftc_commodity_code", ""),
                "open_interest": round(latest.get("open_interest", 0.0)),
                "open_interest_change": round(latest.get("open_interest_change", 0.0)),
                "open_interest_change_4w": round(recent[-1].get("open_interest", 0.0) - recent[0].get("open_interest", 0.0)),
                "commercial_long": round(latest.get("commercial_long", 0.0)),
                "commercial_short": round(latest.get("commercial_short", 0.0)),
                "commercial_long_change": round(latest.get("commercial_long_change", 0.0)),
                "commercial_short_change": round(latest.get("commercial_short_change", 0.0)),
                "commercial_long_change_4w": round(comm_long_4w),
                "commercial_short_change_4w": round(comm_short_4w),
                "large_spec_long": round(latest.get("large_spec_long", 0.0)),
                "large_spec_short": round(latest.get("large_spec_short", 0.0)),
                "large_spec_long_change": round(latest.get("large_spec_long_change", 0.0)),
                "large_spec_short_change": round(latest.get("large_spec_short_change", 0.0)),
                "large_spec_long_change_4w": round(spec_long_4w),
                "large_spec_short_change_4w": round(spec_short_4w),
                "commercial_long_short_flow_1w_oi": round(commercial_flow_1w_oi, 6),
                "commercial_long_short_flow_4w_oi": round(commercial_flow_4w_oi, 6),
                "large_spec_long_short_flow_1w_oi": round(spec_flow_1w_oi, 6),
                "large_spec_long_short_flow_4w_oi": round(spec_flow_4w_oi, 6),
                "large_spec_net": round(latest.get("spec_net", 0.0)),
                "large_spec_change_1w": round(latest.get("spec_change", 0.0)),
                "large_spec_change_4w": round(recent[-1].get("spec_net", 0.0) - recent[0].get("spec_net", 0.0)),
                "commercial_net": round(latest.get("commercial_net", 0.0)),
                "commercial_change_1w": round(latest.get("commercial_change", 0.0)),
                "commercial_change_4w": round(recent[-1].get("commercial_net", 0.0) - recent[0].get("commercial_net", 0.0)),
                "spec_change_oi": round(latest.get("spec_change_oi", 0.0), 6),
                "commercial_change_oi": round(latest.get("commercial_change_oi", 0.0), 6),
                "open_interest_change_oi": round(latest.get("open_interest_change_oi", 0.0), 6),
                "change_basis": "Meridian Engine berechnet 1W Changes selbst: aktueller Report minus direkter Vorwochen Report",
                "raw_cftc_commercial_long_change": round(latest.get("raw_cftc_commercial_long_change", 0.0)),
                "raw_cftc_commercial_short_change": round(latest.get("raw_cftc_commercial_short_change", 0.0)),
                "raw_cftc_large_spec_long_change": round(latest.get("raw_cftc_large_spec_long_change", 0.0)),
                "raw_cftc_large_spec_short_change": round(latest.get("raw_cftc_large_spec_short_change", 0.0)),
                "raw_cftc_open_interest_change": round(latest.get("raw_cftc_open_interest_change", 0.0)),
                "commercial_percentile_3y": round(commercial_position, 1),
                "commercial_cot_index_5y": round(commercial_position, 1),
                "commercial_net_score": round(commercial_net_score, 1),
                "institutional_bias_score": round(institutional_bias_score, 1),
                "large_spec_percentile_3y": round(large_spec_position, 1),
                "cot_report_4w_dates": [r.get("date").strftime("%Y-%m-%d") for r in recent if r.get("date")],
                "cot_index_4w_values": [round(v, 1) for v in cot_index_values],
                "commercial_net_4w_values": [round(r.get("commercial_net", 0.0)) for r in recent],
                "large_spec_net_4w_values": [round(r.get("spec_net", 0.0)) for r in recent],
                "commercial_net_4w_deltas": [round(recent[i].get("commercial_net", 0.0) - recent[i-1].get("commercial_net", 0.0)) for i in range(1, len(recent))],
                "large_spec_net_4w_deltas": [round(recent[i].get("spec_net", 0.0) - recent[i-1].get("spec_net", 0.0)) for i in range(1, len(recent))],
                "commercial_net_oi_4w_deltas": [round(v, 8) for v in comm_trend_quality.get("deltas", [])],
                "large_spec_net_oi_4w_deltas": [round(v, 8) for v in spec_trend_quality.get("deltas", [])],
                "open_interest_4w_deltas": [round(v) for v in oi_trend_quality.get("deltas", [])],
                "commercial_net_oi_4w_values": [round(r.get("commercial_net_oi", 0.0), 6) for r in recent],
                "large_spec_net_oi_4w_values": [round(r.get("spec_net_oi", 0.0), 6) for r in recent],
                "open_interest_4w_values": [round(v) for v in oi_values],
                "commercial_4w_alignment_pct": round(comm_trend_quality.get("alignment_pct", 0), 1),
                "commercial_4w_consistency_pct": round(comm_trend_quality.get("consistency_pct", 0), 1),
                "commercial_4w_quality_pct": round(comm_trend_quality.get("quality_pct", 0), 1),
                "large_spec_4w_alignment_pct": round(spec_trend_quality.get("alignment_pct", 0), 1),
                "large_spec_4w_consistency_pct": round(spec_trend_quality.get("consistency_pct", 0), 1),
                "large_spec_4w_quality_pct": round(spec_trend_quality.get("quality_pct", 0), 1),
                "cot_index_4w_alignment_pct": round(cot_index_quality.get("alignment_pct", 0), 1),
                "cot_index_4w_consistency_pct": round(cot_index_quality.get("consistency_pct", 0), 1),
                "oi_4w_alignment_pct": round(oi_trend_quality.get("alignment_pct", 0), 1),
                "oi_4w_consistency_pct": round(oi_trend_quality.get("consistency_pct", 0), 1),
                "cot_freshness": round(cot_freshness, 1),
                "flow_acceleration": round(flow_acceleration, 1),
                "oi_participation": round(oi_participation, 1),
                "hybrid_commercial_position_context": round(commercial_position, 1),
                "hybrid_commercial_flow": round(commercial_flow_score_absolute, 1),
                "hybrid_large_spec_flow": round(large_spec_flow_score_absolute, 1),
                "hybrid_flow_acceleration": round(flow_acceleration_absolute, 1),
                "hybrid_four_week_context": round(four_week_context_absolute, 1),
                "engine_method": "Meridian Classic Commercial Bias plus Clean Flow; Hybrid Independent Context 104W",
            },
            "commercial_net": round(latest["commercial_net"]),
            "spec_net": round(latest["spec_net"]),
            "commercial_change_1w": round(latest.get("commercial_change", 0.0)),
            "spec_change_1w": round(latest.get("spec_change", 0.0)),
            "commercial_change_4w": round(recent[-1].get("commercial_net", 0.0) - recent[0].get("commercial_net", 0.0)),
            "spec_change_4w": round(recent[-1].get("spec_net", 0.0) - recent[0].get("spec_net", 0.0)),
            "explanation": self.explain_v2(commercial_position, commercial_weekly_change, large_spec_position, large_spec_weekly_change, open_interest_confirmation, flow_trend_filter),
        }
        return self.apply_analysis_profile(result)

    def make_usd_proxy(self, strengths):
        # Der USD wird nur dann synthetisch gebaut, wenn kein valider aktueller Dollar Index Datensatz vorhanden ist.
        # Wichtig: Das ist kein Fantasiewert, sondern eine klar markierte Ableitung aus den aktuellen Meridian Qualitätswerten
        # der übrigen Währungen. Der Audit weist diesen Zustand ausdrücklich aus.
        vals = [v["strength"] for c, v in strengths.items() if c != "USD" and v.get("latest_date") == self.report_date]
        if not vals:
            return None
        usd = clamp(100 - avg(vals))
        return {
            "currency": "USD",
            "weekly_strength": round(usd, 1),
            "strength": round(usd, 1),
            "confidence": round(confidence_from_score(usd), 1),
            "probability": round(confidence_from_score(usd), 1),
            "bias": "BULLISH" if usd >= 58 else "BEARISH" if usd <= 42 else "NEUTRAL",
            "weekly_impulse": round(usd, 1),
            "fresh_impulse": round(usd, 1),
            "four_week_confirmation": round(usd, 1),
            "commercial_change": round(usd, 1),
            "large_spec_flow": round(usd, 1),
            "spec_flow": round(usd, 1),
            "market_quality": 50,
            "open_interest": 50,
            "quality": 50,
            "components": {k: round(usd, 1) for k in SCORE_COMPONENT_LABELS},
            "weighted_points": {k: round((usd - 50) * self.weights.get(k, 0.0), 2) for k in SCORE_COMPONENT_LABELS},
            "is_proxy": True,
            "weeks": 0,
            "latest_date": self.report_date,
            "raw_audit": {
                "market": "SYNTHETIC USD PROXY FROM CURRENT NON USD Meridian QUALITÄTS",
                "source_file": "PROXY",
                "source_url": "PROXY",
                "source_sha256": "PROXY",
                "source_row": "PROXY",
                "cftc_contract_market_code": "PROXY",
                "cftc_market_code": "PROXY",
                "cftc_commodity_code": "PROXY",
                "open_interest": "PROXY",
                "open_interest_change": "PROXY",
                "commercial_long": "PROXY",
                "commercial_short": "PROXY",
                "commercial_long_change": "PROXY",
                "commercial_short_change": "PROXY",
                "large_spec_long": "PROXY",
                "large_spec_short": "PROXY",
                "large_spec_long_change": "PROXY",
                "large_spec_short_change": "PROXY",
                "large_spec_net": "PROXY",
                "large_spec_change_1w": "PROXY",
                "large_spec_change_4w": "PROXY",
                "commercial_net": "PROXY",
                "commercial_change_1w": "PROXY",
                "commercial_change_4w": "PROXY",
                "open_interest_change_4w": "PROXY",
                "spec_change_oi": "PROXY",
                "commercial_change_oi": "PROXY",
                "open_interest_change_oi": "PROXY",
            },
            "explanation": "USD ist in diesem Lauf ein klar markierter Proxy aus aktuellen Nicht USD Meridian Qualitätswerten, weil kein aktueller Dollar Index Datensatz im CFTC Import validiert wurde.",
        }

    def compute_current_strengths(self):
        strengths = {}
        stale = []
        for curr, series in self.records.items():
            if len(series) >= 5:
                result = self.compute_currency_at(curr, series, len(series))
                if result:
                    if result.get("latest_date") == self.report_date:
                        strengths[curr] = result
                    else:
                        stale.append((curr, result.get("latest_date", "unbekannt")))

        for curr, date in stale:
            msg = f"{curr} wurde nicht direkt verwendet, weil letzter Datensatz {date} statt {self.report_date} ist."
            self.validation_warnings.append(msg)

        if "USD" not in strengths:
            proxy = self.make_usd_proxy(strengths)
            if proxy:
                strengths["USD"] = proxy
                self.used_usd_proxy = True
                self.validation_warnings.append("USD Dollar Index nicht aktuell validiert. USD wurde als ausdrücklich markierter Proxy aus aktuellen Nicht USD Meridian Qualitätswerten berechnet.")
            else:
                self.validation_errors.append("USD konnte weder aktuell validiert noch als Proxy berechnet werden.")

        return strengths


    def compute_weekly_movers(self, strengths):
        """Ermittelt Gewinner und Verlierer der Woche aus der Veränderung des Meridian Strength Scores.

        Die Berechnung vergleicht den aktuellen vollständigen Engine Score mit dem Score des
        direkten Vorwochen Reports. Dadurch wird kein neues Signal erfunden, sondern nur sichtbar
        gemacht, welche Währung sich durch die neuen COT Changes am stärksten bewegt hat.
        """
        movers = []
        previous_strengths = {}

        for curr, current in strengths.items():
            # Die Wochengewinner Anzeige bezieht sich bewusst auf Währungen.
            # Zusatzmärkte wie Gold, Silber, Nasdaq und S&P 500 bleiben in ihrem eigenen Bereich.
            if curr not in MARKETS:
                continue
            if current.get("is_proxy"):
                continue
            series = self.records.get(curr, [])
            if len(series) < max(6, self.lookback_weeks + 2):
                continue
            previous = self.compute_currency_at(curr, series, len(series) - 1)
            if not previous:
                continue

            current_strength = safe_float(current.get("strength", 50.0), 50.0)
            previous_strength = safe_float(previous.get("strength", 50.0), 50.0)
            delta = current_strength - previous_strength
            previous_strengths[curr] = previous

            movers.append({
                "currency": curr,
                "current_strength": round(current_strength, 1),
                "previous_strength": round(previous_strength, 1),
                "change": round(delta, 1),
                "abs_change": round(abs(delta), 1),
                "current_bias": current.get("bias", "NEUTRAL"),
                "previous_bias": previous.get("bias", "NEUTRAL"),
                "commercial_flow": round(safe_float(current.get("commercial_long_short_flow", current.get("commercial_change", 50.0)), 50.0), 1),
                "large_spec_flow": round(safe_float(current.get("large_spec_long_short_flow", current.get("large_spec_flow", 50.0)), 50.0), 1),
                "flow_acceleration": round(safe_float(current.get("flow_acceleration", 50.0), 50.0), 1),
                "oi_participation": round(safe_float(current.get("oi_participation", current.get("open_interest", 50.0)), 50.0), 1),
                "latest_date": current.get("latest_date", self.report_date),
                "previous_date": previous.get("latest_date", "Vorwoche"),
            })

        # Wenn USD nur als Proxy berechnet wurde, bekommt auch er einen transparenten Proxy Delta.
        current_usd = strengths.get("USD")
        if current_usd and current_usd.get("is_proxy") and previous_strengths:
            prev_vals = [v["strength"] for c, v in previous_strengths.items() if c != "USD"]
            if prev_vals:
                current_strength = safe_float(current_usd.get("strength", 50.0), 50.0)
                previous_strength = clamp(100.0 - avg(prev_vals))
                delta = current_strength - previous_strength
                movers.append({
                    "currency": "USD",
                    "current_strength": round(current_strength, 1),
                    "previous_strength": round(previous_strength, 1),
                    "change": round(delta, 1),
                    "abs_change": round(abs(delta), 1),
                    "current_bias": current_usd.get("bias", "NEUTRAL"),
                    "previous_bias": "PROXY",
                    "commercial_flow": round(current_strength, 1),
                    "large_spec_flow": round(current_strength, 1),
                    "flow_acceleration": round(current_strength, 1),
                    "oi_participation": 50.0,
                    "latest_date": current_usd.get("latest_date", self.report_date),
                    "previous_date": "USD Proxy Vorwoche",
                    "is_proxy": True,
                })

        movers.sort(key=lambda x: x.get("change", 0.0), reverse=True)
        winner = movers[0] if movers else None
        loser = movers[-1] if movers else None
        return {
            "winner": winner,
            "loser": loser,
            "all": movers,
            "method": "Aktueller Meridian Strength Score minus direkter Vorwochen Score. Zeigt die stärkste Veränderung durch den neuen COT Report.",
        }

    def compute_single_assets(self, strengths):
        assets = []
        for asset, cfg in SINGLE_ASSET_MARKETS.items():
            data = strengths.get(asset)
            if not data:
                continue
            signed = clamp((safe_float(data.get("strength", 50), 50) - 50.0) * 2.0, -100, 100)
            data["signed_strength"] = round(signed, 1)
            direction = "LONG" if signed >= 0 else "SHORT"
            abs_signed = abs(signed)

            position_score = data.get("bias_score", avg([
                data.get("commercial_position", 50),
                data.get("large_spec_position", 50),
            ]))
            flow_score = data.get("flow_score", data.get("large_spec_weekly_change", 50) * 0.55 + data.get("commercial_weekly_change", 50) * 0.45)
            momentum_score = data.get("momentum_score", data.get("flow_trend_filter", data.get("flow_consistency", 50)))
            participation_score = data.get("participation_score", data.get("open_interest_confirmation", data.get("market_participation", 50)))

            directional_position = position_score if direction == "LONG" else 100.0 - position_score
            directional_flow = flow_score if direction == "LONG" else 100.0 - flow_score
            directional_momentum = momentum_score if direction == "LONG" else 100.0 - momentum_score
            directional_participation = participation_score

            supportive = 0
            conflicts = 0
            confluence_bonus = 0.0
            for value in (directional_position, directional_flow, directional_momentum):
                if value >= 58:
                    supportive += 1
                    confluence_bonus += 2.0
                elif value <= 42:
                    conflicts += 1
                    confluence_bonus -= 3.0
            if directional_participation >= 58:
                supportive += 1
                confluence_bonus += 0.8
            elif directional_participation <= 42:
                conflicts += 1
                confluence_bonus -= 1.2

            raw_selection = abs_signed + confluence_bonus
            confidence = clamp(50.0 + raw_selection * 0.23, 50, 95)
            label = cfg.get("label", asset)
            pair = cfg.get("pair", asset)
            assets.append({
                "pair": pair,
                "display_name": label,
                "asset": asset,
                "is_single_asset": True,
                "direction": direction,
                "score": round(confidence, 1),
                "confidence": round(confidence, 1),
                "probability": round(confidence, 1),
                "diff": round(signed, 1),
                "signed_pair_spread": round(abs_signed, 1),
                "base_signed_strength": round(signed, 1),
                "quote_signed_strength": 0.0,
                "strong_signed_strength": round(max(signed, 0.0), 1),
                "weak_signed_strength": round(min(signed, 0.0), 1),
                "polarity_note": "Single Asset COT Bias ohne Forex Gegenwährung",
                "impulse_gap": round(abs(directional_momentum - 50.0), 1),
                "momentum_gap": round(abs(directional_momentum - 50.0), 1),
                "commercial_gap": round(abs(directional_flow - 50.0), 1),
                "alignment_gap": round(abs(data.get("alignment", 50) - 50.0), 1),
                "consistency_gap": round(abs(data.get("flow_trend_filter", data.get("flow_consistency", 50)) - 50.0), 1),
                "participation_gap": round(abs(directional_participation - 50.0), 1),
                "strong": label if direction == "LONG" else "Short Bias",
                "weak": "Short Bias" if direction == "LONG" else label,
                "quality": round(data.get("quality", 50), 1),
                "matrix_relative_strength": round(clamp(50 + abs_signed * 0.24, 50, 95), 1),
                "matrix_position": round(directional_position, 1),
                "matrix_flow": round(directional_flow, 1),
                "matrix_momentum": round(directional_momentum, 1),
                "matrix_market_activity": round(directional_participation, 1),
                "matrix_supportive_factors": supportive,
                "matrix_conflict_factors": conflicts,
                "spread_score": round(abs_signed, 1),
                "weekly_filter_confidence": round(confidence, 1),
                "position_edge": round(directional_position - 50.0, 1),
                "flow_edge": round(directional_flow - 50.0, 1),
                "momentum_edge": round(directional_momentum - 50.0, 1),
                "oi_edge": round(directional_participation - 50.0, 1),
                "base_components": data.get("components", {}),
                "quote_components": {},
                "base_weighted_points": data.get("weighted_points", {}),
                "quote_weighted_points": {},
                "confidence_formula": {
                    "engine": f"V{APP_VERSION} Meridian Engine Clean Flow",
                    "signed_asset_strength": round(signed, 1),
                    "confluence_bonus": round(confluence_bonus, 1),
                    "position_score": round(directional_position, 1),
                    "flow_score": round(directional_flow, 1),
                    "momentum_score": round(directional_momentum, 1),
                    "market_activity_score": round(directional_participation, 1),
                    "supportive_factors": supportive,
                    "conflict_factors": conflicts,
                    "cap": 95,
                },
                "base_raw_audit": data.get("raw_audit", {}),
                "quote_raw_audit": {},
                "why": (
                    f"{label} {direction}: Der Markt wird als einzelner COT Basiswert bewertet. "
                    f"Signed Asset Strength: {signed:+.1f}. "
                    f"Position: {directional_position:.1f}, Flow: {directional_flow:.1f}, Momentum: {directional_momentum:.1f}, Open Interest: {directional_participation:.1f}. "
                    "Der Wert ist eine Meridian Qualitätsbewertung, keine garantierte Trefferwahrscheinlichkeit."
                ),
            })
        return assets

    def compute_pairs(self, strengths):
        # FINAL Engine: Erst einzelne Währungen bewerten, dann stärkste gegen schwächste stellen.
        # Jede Währung bekommt aus der Meridian Flow Engine einen Signed Strength Score
        # von -100 bis +100. Positive Werte bedeuten institutionelle Stärke, negative Werte
        # institutionelle Schwäche. Die Top 3 entstehen aus dem größten Abstand zwischen
        # starker und schwacher Währung, nicht aus einer direkten Einzelpaar-Optimierung.
        pairs = []
        signed_strengths = {}
        for curr, data in strengths.items():
            signed = clamp((safe_float(data.get("strength", 50), 50) - 50.0) * 2.0, -100, 100)
            data["signed_strength"] = round(signed, 1)
            signed_strengths[curr] = signed

        for pair in MAJOR_PAIRS:
            base, quote = pair.split("/")
            if base not in strengths or quote not in strengths:
                continue

            b, q = strengths[base], strengths[quote]
            base_signed = signed_strengths.get(base, 0.0)
            quote_signed = signed_strengths.get(quote, 0.0)
            signed_diff = base_signed - quote_signed

            if signed_diff >= 0:
                direction, strong, weak = "LONG", base, quote
                strong_data, weak_data = b, q
                strong_signed, weak_signed = base_signed, quote_signed
            else:
                direction, strong, weak = "SHORT", quote, base
                strong_data, weak_data = q, b
                strong_signed, weak_signed = quote_signed, base_signed

            abs_signed_diff = abs(signed_diff)
            abs_diff = abs(safe_float(b.get("strength", 50), 50) - safe_float(q.get("strength", 50), 50))

            # Bestes Setup ist: eine Währung klar positiv, die andere klar negativ.
            # Sind beide Währungen auf derselben Seite, wird das Paar bewusst abgewertet.
            strong_is_positive = strong_signed > 0
            weak_is_negative = weak_signed < 0
            polarity_bonus = 0.0
            polarity_note = "Starke Währung gegen schwache Währung"
            if strong_is_positive and weak_is_negative:
                polarity_bonus = 8.0
            elif strong_signed > 0 and weak_signed >= 0:
                polarity_bonus = -12.0
                polarity_note = "Beide Währungen sind institutionell eher stark"
            elif strong_signed <= 0 and weak_signed < 0:
                polarity_bonus = -12.0
                polarity_note = "Beide Währungen sind institutionell eher schwach"
            else:
                polarity_bonus = -18.0
                polarity_note = "Kein sauberer Stärke gegen Schwäche Aufbau"

            strong_position = strong_data.get("bias_score", avg([
                strong_data.get("commercial_position", 50),
                strong_data.get("large_spec_position", 50),
            ]))
            weak_position = weak_data.get("bias_score", avg([
                weak_data.get("commercial_position", 50),
                weak_data.get("large_spec_position", 50),
            ]))
            position_edge = strong_position - weak_position

            strong_flow = strong_data.get("flow_score", strong_data.get("large_spec_weekly_change", 50) * 0.55 + strong_data.get("commercial_weekly_change", 50) * 0.45)
            weak_flow = weak_data.get("flow_score", weak_data.get("large_spec_weekly_change", 50) * 0.55 + weak_data.get("commercial_weekly_change", 50) * 0.45)
            flow_edge = strong_flow - weak_flow

            strong_momentum = strong_data.get("momentum_score", strong_data.get("flow_trend_filter", strong_data.get("flow_consistency", 50)))
            weak_momentum = weak_data.get("momentum_score", weak_data.get("flow_trend_filter", weak_data.get("flow_consistency", 50)))
            momentum_edge = strong_momentum - weak_momentum

            oi_edge = strong_data.get("participation_score", strong_data.get("open_interest_confirmation", strong_data.get("market_participation", 50))) - weak_data.get("participation_score", weak_data.get("open_interest_confirmation", weak_data.get("market_participation", 50)))

            quality = min(b.get("quality", 50), q.get("quality", 50))

            # Pair Confidence ist nur eine übersetzte Lesbarkeitszahl. Die Auswahl basiert auf
            # signed_pair_spread plus Polarität und kleiner Konfluenzbestätigung.
            confluence_bonus = 0.0
            supportive = 0
            conflicts = 0
            for edge in (position_edge, flow_edge, momentum_edge):
                if edge >= 8:
                    supportive += 1
                    confluence_bonus += 2.0
                elif edge <= -8:
                    conflicts += 1
                    confluence_bonus -= 3.0
            if oi_edge >= 6:
                supportive += 1
                confluence_bonus += 0.8
            elif oi_edge <= -6:
                conflicts += 1
                confluence_bonus -= 1.2

            proxy_penalty = 0.0
            proxy_cap = 95.0
            if b.get("is_proxy") or q.get("is_proxy"):
                # Wenn der USD nur synthetisch berechnet wurde, darf er die Top 3 nicht dominieren.
                # Direkte CFTC Dollar Index Daten werden weiterhin normal behandelt.
                proxy_penalty = 18.0
                proxy_cap = 82.0

            raw_selection = abs_signed_diff + polarity_bonus + confluence_bonus - proxy_penalty
            confidence = clamp(50.0 + raw_selection * 0.23, 50, proxy_cap)
            matrix = {
                "relative_strength_score": round(clamp(50 + abs_signed_diff * 0.24, 50, 95), 1),
                "position_score": round(clamp(50 + position_edge * 0.58, 0, 100), 1),
                "flow_score": round(clamp(50 + flow_edge * 0.70, 0, 100), 1),
                "momentum_score": round(clamp(50 + momentum_edge * 0.56, 0, 100), 1),
                "market_activity_score": round(clamp(50 + oi_edge * 0.45, 0, 100), 1),
                "supportive_factors": supportive,
                "conflict_factors": conflicts,
            }

            momentum_gap = abs(strong_momentum - weak_momentum)
            commercial_gap = abs(strong_data.get("commercial_weekly_change", strong_data.get("commercial_flow", 50)) - weak_data.get("commercial_weekly_change", weak_data.get("commercial_flow", 50)))
            alignment_gap = abs(strong_data.get("alignment", 50) - weak_data.get("alignment", 50))
            consistency_gap = abs(strong_data.get("flow_trend_filter", strong_data.get("flow_consistency", 50)) - weak_data.get("flow_trend_filter", weak_data.get("flow_consistency", 50)))
            participation_gap = abs(strong_data.get("open_interest_confirmation", strong_data.get("market_participation", 50)) - weak_data.get("open_interest_confirmation", weak_data.get("market_participation", 50)))

            pairs.append({
                "pair": pair,
                "direction": direction,
                "score": round(confidence, 1),
                "confidence": round(confidence, 1),
                "probability": round(confidence, 1),
                "diff": round(signed_diff, 1),
                "signed_pair_spread": round(abs_signed_diff, 1),
                "base_signed_strength": round(base_signed, 1),
                "quote_signed_strength": round(quote_signed, 1),
                "strong_signed_strength": round(strong_signed, 1),
                "weak_signed_strength": round(weak_signed, 1),
                "polarity_note": polarity_note,
                "impulse_gap": round(momentum_gap, 1),
                "momentum_gap": round(momentum_gap, 1),
                "commercial_gap": round(commercial_gap, 1),
                "alignment_gap": round(alignment_gap, 1),
                "consistency_gap": round(consistency_gap, 1),
                "participation_gap": round(participation_gap, 1),
                "strong": strong,
                "weak": weak,
                "quality": round(quality, 1),
                "matrix_relative_strength": matrix["relative_strength_score"],
                "matrix_position": matrix["position_score"],
                "matrix_flow": matrix["flow_score"],
                "matrix_momentum": matrix["momentum_score"],
                "matrix_market_activity": matrix["market_activity_score"],
                "matrix_supportive_factors": matrix["supportive_factors"],
                "matrix_conflict_factors": matrix["conflict_factors"],
                "spread_score": round(abs_signed_diff, 1),
                "weekly_filter_confidence": round(confidence, 1),
                "position_edge": round(position_edge, 1),
                "flow_edge": round(flow_edge, 1),
                "momentum_edge": round(momentum_edge, 1),
                "oi_edge": round(oi_edge, 1),
                "base_components": b.get("components", {}),
                "quote_components": q.get("components", {}),
                "base_weighted_points": b.get("weighted_points", {}),
                "quote_weighted_points": q.get("weighted_points", {}),
                "confidence_formula": {
                    "engine": f"V{APP_VERSION} Meridian Engine Clean Flow",
                    "signed_pair_spread": round(abs_signed_diff, 1),
                    "base_signed_strength": round(base_signed, 1),
                    "quote_signed_strength": round(quote_signed, 1),
                    "polarity_bonus": round(polarity_bonus, 1),
                    "proxy_penalty": round(proxy_penalty, 1),
                    "proxy_cap": round(proxy_cap, 1),
                    "confluence_bonus": round(confluence_bonus, 1),
                    "relative_strength_score": matrix["relative_strength_score"],
                    "position_score": matrix["position_score"],
                    "flow_score": matrix["flow_score"],
                    "momentum_score": matrix["momentum_score"],
                    "market_activity_score": matrix["market_activity_score"],
                    "supportive_factors": matrix["supportive_factors"],
                    "conflict_factors": matrix["conflict_factors"],
                    "cap": 95,
                },
                "base_raw_audit": b.get("raw_audit", {}),
                "quote_raw_audit": q.get("raw_audit", {}),
                "why": self.explain_pair(pair, direction, strong, weak, b, q, abs_diff, momentum_gap, commercial_gap, alignment_gap) + " " + polarity_note + ".",
            })

        # Die finale Hauptwatchlist ist strikt auf Forex begrenzt.
        # Zusatzmärkte werden weiterhin vollständig berechnet und im Gesamtranking geführt,
        # dürfen aber niemals einen Platz in der Forex Top 3 belegen.
        #
        # NEU in 0.0.3, USD Proxy Hardening: Ist eine Währung nur ein synthetischer
        # Proxy (kein echter Dollar Index Datensatz gefunden), ist ihre "Richtung"
        # mathematisch nur der gespiegelte Durchschnitt der übrigen Währungen -
        # keine unabhängige COT Information. Ein reiner Penalty/Cap (weiterhin
        # unten für die Gesamtranking Transparenz sichtbar) reicht nicht aus, um
        # das zu verhindern. Deshalb werden Paare mit Proxy Beteiligung hart aus
        # der Forex Top 3 Kandidatenmenge ausgeschlossen. Sie bleiben im
        # Gesamtranking (pairs / all_pairs) für Audit und Nachvollziehbarkeit
        # weiterhin sichtbar, inklusive is_proxy_excluded Flag.
        proxy_currencies = {curr for curr, data in strengths.items() if data.get("is_proxy")}
        for p in pairs:
            base_c, _, quote_c = p.get("pair", "//").partition("/")
            p["is_proxy_excluded"] = bool(proxy_currencies) and (base_c in proxy_currencies or quote_c in proxy_currencies)

        forex_pairs = [p for p in pairs if not p.get("is_proxy_excluded")]
        single_assets = self.compute_single_assets(strengths)
        pairs.extend(single_assets)

        # Gesamtranking für Audit, Zusatzmarkt Anzeige und Transparenz.
        pairs.sort(key=lambda p: (p.get("confidence", 0), p.get("signed_pair_spread", 0)), reverse=True)
        forex_pairs.sort(key=lambda p: (p.get("confidence", 0), p.get("signed_pair_spread", 0)), reverse=True)

        for rank, p in enumerate(pairs, 1):
            p["original_rank"] = rank
            p["diversity_penalty"] = 0.0
            p["selection_score"] = p["confidence"]
            p["diversity_note"] = "Final Ranking nach Signed Currency Strength Spread"

        for rank, p in enumerate(forex_pairs, 1):
            p["forex_rank"] = rank

        # Hybrid Top 3 Modell:
        # 1. stärkste gegen schwächste Währung
        # 2. zweitstärkste gegen zweitschwächste Währung
        # 3. drittstärkste gegen drittschwächste Währung
        # Die Zielpaarung wird nur übernommen, wenn sie mindestens 90 Prozent der
        # Qualität des besten noch verfügbaren Kandidaten erreicht. So wird das
        # Währungsexposure diversifiziert, ohne ein deutlich schwächeres Setup zu erzwingen.
        forex_currency_universe = ("AUD", "CAD", "CHF", "EUR", "GBP", "JPY", "NZD", "USD")
        ranked_currencies = sorted(
            (
                currency for currency in forex_currency_universe
                if currency in signed_strengths and currency not in proxy_currencies
            ),
            key=lambda currency: signed_strengths.get(currency, 0.0),
            reverse=True,
        )
        hybrid_targets = []
        for slot in range(min(3, len(ranked_currencies) // 2)):
            hybrid_targets.append((ranked_currencies[slot], ranked_currencies[-(slot + 1)]))

        top = []
        selected_pairs = set()
        selected_currency_counts = {}
        minimum_quality = 55.0
        relative_quality_floor = 0.90

        def candidate_currencies(candidate):
            if candidate.get("is_single_asset"):
                asset = candidate.get("asset", candidate.get("pair", ""))
                return [asset] if asset else []
            return candidate.get("pair", "").split("/", 1)

        def exposure_allowed(candidate):
            currencies = candidate_currencies(candidate)
            return all(selected_currency_counts.get(currency, 0) < 2 for currency in currencies)

        def target_match(candidate, target):
            if candidate.get("is_single_asset") or not target:
                return False
            return candidate.get("strong") == target[0] and candidate.get("weak") == target[1]

        for slot in range(3):
            available = [p for p in forex_pairs if p.get("pair") not in selected_pairs]
            if not available:
                break

            exposure_candidates = [p for p in available if exposure_allowed(p)]
            if not exposure_candidates:
                exposure_candidates = available

            best_available = max(
                available,
                key=lambda p: (p.get("confidence", 0), p.get("signed_pair_spread", 0)),
            )
            best_available_confidence = safe_float(best_available.get("confidence", 0), 0)

            raw_best = max(
                exposure_candidates,
                key=lambda p: (p.get("confidence", 0), p.get("signed_pair_spread", 0)),
            )
            raw_best_confidence = safe_float(raw_best.get("confidence", 0), 0)
            quality_threshold = max(minimum_quality, best_available_confidence * relative_quality_floor)
            target = hybrid_targets[slot] if slot < len(hybrid_targets) else None

            preferred = [
                p for p in exposure_candidates
                if target_match(p, target)
                and safe_float(p.get("confidence", 0), 0) >= quality_threshold
            ]

            if preferred:
                chosen = max(
                    preferred,
                    key=lambda p: (p.get("confidence", 0), p.get("signed_pair_spread", 0)),
                )
                quality_ratio = (
                    safe_float(chosen.get("confidence", 0), 0) / best_available_confidence
                    if best_available_confidence > 0 else 1.0
                )
                chosen["diversity_penalty"] = round(max(0.0, raw_best_confidence - safe_float(chosen.get("confidence", 0), 0)), 1)
                chosen["selection_score"] = round(safe_float(chosen.get("confidence", 0), 0), 1)
                chosen["hybrid_slot"] = slot + 1
                chosen["hybrid_target"] = f"{target[0]} gegen {target[1]}"
                chosen["hybrid_quality_ratio"] = round(quality_ratio * 100.0, 1)
                chosen["diversity_note"] = (
                    f"Hybrid Rang {slot + 1}: {target[0]} gegen {target[1]}; "
                    f"Qualität {quality_ratio * 100.0:.1f} Prozent des besten verfügbaren Setups"
                )
            else:
                chosen = raw_best
                chosen["diversity_penalty"] = 0.0
                chosen["selection_score"] = round(safe_float(chosen.get("confidence", 0), 0), 1)
                chosen["hybrid_slot"] = slot + 1
                chosen["hybrid_target"] = f"{target[0]} gegen {target[1]}" if target else "Kein Ziel"
                fallback_quality_ratio = (
                    safe_float(chosen.get("confidence", 0), 0) / best_available_confidence
                    if best_available_confidence > 0 else 1.0
                )
                chosen["hybrid_quality_ratio"] = round(fallback_quality_ratio * 100.0, 1)
                if target:
                    chosen["diversity_note"] = (
                        f"Hybrid Rang {slot + 1} Fallback: Ziel {target[0]} gegen {target[1]} "
                        f"lag unter der Qualitätsgrenze von {quality_threshold:.1f}; "
                        f"Fallback Qualität {fallback_quality_ratio * 100.0:.1f} Prozent "
                        f"des besten noch verfügbaren Setups"
                    )
                else:
                    chosen["diversity_note"] = "Hybrid Fallback auf bestes verfügbares Setup"

            top.append(chosen)
            selected_pairs.add(chosen.get("pair"))
            for currency in candidate_currencies(chosen):
                selected_currency_counts[currency] = selected_currency_counts.get(currency, 0) + 1

        return top, pairs

    def explain_v2(self, commercial_position, commercial_weekly_change, large_spec_position, large_spec_weekly_change, open_interest_confirmation, flow_trend_filter):
        parts = []
        if large_spec_weekly_change >= 65:
            parts.append("Large Specs bauen frischen bullischen Wochenflow auf")
        elif large_spec_weekly_change <= 35:
            parts.append("Large Specs bauen frischen bearischen Wochenflow auf")
        else:
            parts.append("Large Spec Wochenflow ist neutral")

        if commercial_weekly_change >= 65:
            parts.append("Commercial Wochenänderung wirkt bullisch")
        elif commercial_weekly_change <= 35:
            parts.append("Commercial Wochenänderung wirkt bearisch")
        else:
            parts.append("Commercial Wochenänderung ist gemischt")

        if commercial_position >= 65:
            parts.append("Commercial COT Index (104 Wochen Kontext) und Netto Positionierung unterstützen die bullische Seite")
        elif commercial_position <= 35:
            parts.append("Commercial COT Index (104 Wochen Kontext) und Netto Positionierung unterstützen die bearische Seite")
        elif large_spec_position >= 65:
            parts.append("Large Specs sind netto auffällig bullisch positioniert")
        elif large_spec_position <= 35:
            parts.append("Large Specs sind netto auffällig bearisch positioniert")
        else:
            parts.append("Netto Positionierung ist nicht extrem")

        if open_interest_confirmation >= 60:
            parts.append("Open Interest bestätigt den aktuellen Flow")
        elif open_interest_confirmation <= 40:
            parts.append("Open Interest bestätigt die Gegenseite oder mahnt zur Vorsicht")
        else:
            parts.append("Open Interest ist neutral")

        if flow_trend_filter >= 62:
            parts.append("vier Wochen Flow zeigen zunehmende Stärke")
        elif flow_trend_filter <= 38:
            parts.append("vier Wochen Flow zeigen zunehmende Schwäche")

        return ", ".join(parts) + "."

    def explain(self, large_spec_momentum, commercial_flow, alignment, flow_consistency, market_participation, spec_1, comm_1):
        parts = []
        if large_spec_momentum >= 65:
            parts.append("Large Specs bauen kurzfristig bullisches Momentum auf")
        elif large_spec_momentum <= 35:
            parts.append("Large Specs bauen kurzfristig bearisches Momentum auf")
        else:
            parts.append("Large Specs Wochenflow ist neutral")

        if commercial_flow >= 65:
            parts.append("Commercial Kapitalfluss wirkt bullisch")
        elif commercial_flow <= 35:
            parts.append("Commercial Kapitalfluss wirkt bearisch")
        else:
            parts.append("Commercial Kapitalfluss ist gemischt")

        if alignment >= 65:
            parts.append("Commercials und Specs bestätigen den Flow")
        elif alignment <= 35:
            parts.append("Commercials und Specs laufen gegeneinander")
        else:
            parts.append("Alignment ist neutral")

        if flow_consistency >= 65:
            parts.append("der mehrwöchige Positionsaufbau bestätigt die Richtung")
        elif flow_consistency <= 35:
            parts.append("der mehrwöchige Positionsaufbau ist schwach")

        if market_participation >= 60:
            parts.append("Open Interest unterstützt die Bewegung")
        elif market_participation <= 40:
            parts.append("Open Interest mahnt zur Vorsicht")

        return ", ".join(parts) + "."

    def explain_pair(self, pair, direction, strong, weak, base_data, quote_data, abs_diff, momentum_gap, commercial_gap, alignment_gap):
        base, quote = pair.split("/")
        direction_text = "Long" if direction == "LONG" else "Short"
        strong_data = base_data if strong == base else quote_data
        weak_data = quote_data if weak == quote else base_data
        return (
            f"{pair} {direction_text}: {strong} wird in der Relative Strength Matrix stärker bewertet als {weak}. "
            f"Der Abstand der Währungsstärke beträgt {abs_diff:.1f} Punkte. "
            f"Kapitalfluss Gap: {momentum_gap:.1f}, Commercial Gap: {commercial_gap:.1f}. "
            f"{strong}: {strong_data.get('explanation', 'institutioneller Flow positiv')} "
            f"{weak}: {weak_data.get('explanation', 'institutioneller Flow schwächer')} "
            "Der Wert ist eine Meridian Qualitätsbewertung, keine garantierte Trefferwahrscheinlichkeit."
        )

    def run(self):
        self.prepare(2)
        self.progress(62, "Aktuellen Wochenimpuls berechnen")
        strengths = self.compute_current_strengths()
        self.weekly_movers = self.compute_weekly_movers(strengths)
        self.progress(80, "Stark gegen schwach kombinieren")
        top3, all_pairs = self.compute_pairs(strengths)
        return strengths, top3, all_pairs


class SeasonalityEngine:
    CACHE_MAX_AGE_HOURS = 24

    def __init__(self, progress=None):
        self.progress = progress or (lambda pct, text: None)
        self.errors = []
        self.source = "Yahoo Finance Wochenkurse"
        self.yahoo_paused = False

    def yahoo_symbols(self, pair):
        symbols = YAHOO_PAIR_SYMBOLS.get(pair, pair.replace("/", "") + "=X")
        if isinstance(symbols, (tuple, list)):
            return tuple(str(symbol) for symbol in symbols if symbol)
        return (str(symbols),)

    def yahoo_symbol(self, pair):
        # Kompatibilitätsmethode für bestehende Aufrufer.
        return self.yahoo_symbols(pair)[0]

    def cache_path(self, pair):
        safe = pair.replace("/", "")
        return SEASONALITY_DIR / f"{safe}_weekly_yahoo.csv"

    def download_weekly_prices(self, pair):
        path = self.cache_path(pair)
        try:
            cache_age_seconds = time.time() - path.stat().st_mtime
            if path.stat().st_size > 200 and cache_age_seconds < self.CACHE_MAX_AGE_HOURS * 3600:
                return path, "cache"
        except (FileNotFoundError, OSError):
            pass

        if self.yahoo_paused:
            if path.exists() and path.stat().st_size > 200:
                return path, "cache"
            raise RuntimeError(f"Yahoo Abrufe pausiert und kein lokaler Cache für {pair} vorhanden")

        now = int(time.time())
        start = int(datetime(2000, 1, 1).timestamp())
        download_errors = []

        # Einzelmärkte besitzen bewusst mehrere echte Yahoo Symbole. Zuerst wird
        # Spot beziehungsweise Index versucht, danach der vorhandene Future Fallback.
        for symbol in self.yahoo_symbols(pair):
            encoded_symbol = urllib.parse.quote(symbol, safe="")
            chart_url = (
                f"https://query1.finance.yahoo.com/v8/finance/chart/{encoded_symbol}"
                f"?period1={start}&period2={now}&interval=1wk&events=history"
            )
            req = urllib.request.Request(chart_url, headers={"User-Agent": "Mozilla/5.0 Meridian Analyzer"})
            try:
                with urllib.request.urlopen(req, timeout=10) as response:
                    content = response.read().decode("utf-8", errors="ignore")
                payload = json.loads(content)
                result = payload.get("chart", {}).get("result", [])
                if not result:
                    raise RuntimeError("Yahoo Chart Antwort enthält keine Daten")
                item = result[0]
                timestamps = item.get("timestamp", [])
                quote = item.get("indicators", {}).get("quote", [{}])[0]
                closes = quote.get("close", [])
                lines = ["Date,Close,Adj Close"]
                for ts, close in zip(timestamps, closes):
                    if close is None:
                        continue
                    dt = datetime.utcfromtimestamp(int(ts)).strftime("%Y-%m-%d")
                    lines.append(f"{dt},{close},{close}")
                if len(lines) < 120:
                    raise RuntimeError("Yahoo Chart Antwort enthält zu wenig Kursdaten")
                path.write_text("\n".join(lines), encoding="utf-8")
                return path, "online"
            except Exception as exc:
                download_errors.append(f"{symbol}: {type(exc).__name__}")
                if isinstance(exc, urllib.error.HTTPError) and exc.code in (401, 403, 429):
                    self.yahoo_paused = True
                    break

        detail = ", ".join(download_errors) if download_errors else "kein Yahoo Symbol verfügbar"
        self.errors.append(f"{pair}: Online Download fehlgeschlagen ({detail})")
        if path.exists() and path.stat().st_size > 200:
            return path, "cache"
        raise RuntimeError(
            f"Keine Seasonality Daten für {pair}. Yahoo Datenabruf fehlgeschlagen und es ist noch kein lokaler Cache vorhanden."
        )

    def read_prices(self, pair):
        path, mode = self.download_weekly_prices(pair)
        rows = []
        with path.open("r", encoding="utf-8", errors="ignore") as f:
            reader = csv.DictReader(f)
            for row in reader:
                try:
                    date = datetime.strptime(row.get("Date", ""), "%Y-%m-%d")
                    close_raw = row.get("Adj Close") or row.get("Close")
                    if close_raw in (None, "", "null"):
                        continue
                    close = safe_float(close_raw, None)
                    if close is None or close <= 0:
                        continue
                    rows.append({"date": date, "close": close})
                except Exception:
                    continue
        rows.sort(key=lambda r: r["date"])
        if len(rows) < 120:
            raise RuntimeError(f"Zu wenig historische Wochenkurse für {pair}")
        return rows, path, mode

    def nearest_after(self, rows, target_date):
        for r in rows:
            if r["date"] >= target_date:
                return r
        return None

    def seasonal_windows(self, rows, analysis_date, direction):
        # Die Seasonality beantwortet die Frage: Wie entwickelte sich der Markt
        # historisch ab dem heutigen Analysezeitpunkt in den kommenden vier Wochen?
        # Das COT Reportdatum bleibt Kontext, bestimmt aber nicht das Saisonfenster.
        target_week = analysis_date.isocalendar()[1]
        target_year = analysis_date.year
        windows = []
        by_year = {}
        for r in rows:
            by_year.setdefault(r["date"].year, []).append(r)

        for year, yr_rows in sorted(by_year.items()):
            if year >= target_year:
                continue
            candidates = [r for r in yr_rows if r["date"].isocalendar()[1] == target_week]
            if not candidates:
                continue
            start = candidates[0]
            end = self.nearest_after(rows, start["date"] + timedelta(days=7 * SEASONALITY_LOOKAHEAD_WEEKS))
            if not end or end["date"].year != year:
                continue
            raw_return = (end["close"] / start["close"] - 1.0) * 100.0
            directional_return = raw_return if direction == "LONG" else -raw_return
            windows.append({
                "year": year,
                "start_date": start["date"].strftime("%Y-%m-%d"),
                "end_date": end["date"].strftime("%Y-%m-%d"),
                "raw_return_pct": round(raw_return, 3),
                "directional_return_pct": round(directional_return, 3),
                "hit": directional_return > 0,
            })
        return windows

    def seasonality_score(self, directional_returns):
        n = len(directional_returns)
        if n == 0:
            return 50.0
        wins = [r for r in directional_returns if r > 0]
        hit_rate = len(wins) / n * 100.0
        avg_ret = sum(directional_returns) / n
        sorted_rets = sorted(directional_returns)
        mid = n // 2
        median_ret = sorted_rets[mid] if n % 2 else (sorted_rets[mid - 1] + sorted_rets[mid]) / 2
        if n > 1:
            variance = sum((r - avg_ret) ** 2 for r in directional_returns) / (n - 1)
            stdev = math.sqrt(variance)
        else:
            stdev = 0.0
        reliability = clamp((n - SEASONALITY_MIN_YEARS) / 10 * 100, 0, 100)
        hit_component = 50 + (hit_rate - 50) * 0.85
        avg_component = 50 + math.tanh(avg_ret / 2.5) * 28
        median_component = 50 + math.tanh(median_ret / 2.0) * 22
        # Streuung ist vor allem ein Zuverlässigkeitsmerkmal und kein eigenes
        # Richtungssignal. Deshalb bleibt der Abschlag bewusst klein und gedeckelt.
        volatility_penalty = clamp((stdev - abs(avg_ret) * 1.4) * 0.60, 0, 4)
        score = hit_component * 0.45 + avg_component * 0.25 + median_component * 0.20 + reliability * 0.10 - volatility_penalty
        return clamp(score, 0, 100)

    def analyze_pair(self, pair_setup, report_date, analysis_date=None):
        pair = pair_setup["pair"]
        direction = pair_setup["direction"]
        analysis_date = analysis_date or datetime.now()
        rows, path, mode = self.read_prices(pair)
        windows = self.seasonal_windows(rows, analysis_date, direction)
        returns = [w["directional_return_pct"] for w in windows]
        raw_returns = [w["raw_return_pct"] for w in windows]
        if len(returns) < SEASONALITY_MIN_YEARS:
            raise RuntimeError(f"Nur {len(returns)} saisonale Vergleichsjahre für {pair} gefunden")
        n = len(returns)
        wins = sum(1 for r in returns if r > 0)
        hit_rate = wins / n * 100.0
        avg_ret = sum(returns) / n
        avg_raw_ret = sum(raw_returns) / n if raw_returns else 0.0
        sorted_rets = sorted(returns)
        mid = n // 2
        median_ret = sorted_rets[mid] if n % 2 else (sorted_rets[mid - 1] + sorted_rets[mid]) / 2
        sorted_raw_rets = sorted(raw_returns)
        median_raw_ret = sorted_raw_rets[mid] if n % 2 else (sorted_raw_rets[mid - 1] + sorted_raw_rets[mid]) / 2
        stdev = math.sqrt(sum((r - avg_ret) ** 2 for r in returns) / max(1, n - 1))
        score = self.seasonality_score(returns)
        # Engine 3.0.1: Seasonality wird immer richtungsbezogen bewertet.
        # Bei SHORT bedeutet ein positiver Wert: Das Paar ist historisch in Short Richtung gefallen.
        # Daher wird nicht mehr von Rendite gesprochen, sondern von historischer Statistik zum COT Bias.
        if score >= 72:
            verdict = "STARK_BESTÄTIGT"
        elif score >= 62:
            verdict = "BESTÄTIGT"
        elif score >= 55:
            verdict = "LEICHT_POSITIV"
        elif score <= 34:
            verdict = "STARK_KONFLIKT"
        elif score <= 42:
            verdict = "KONFLIKT"
        elif score <= 45:
            verdict = "LEICHT_NEGATIV"
        else:
            verdict = "NEUTRAL"
        # COT bleibt die Basis. Seasonality verfeinert die Qualität dynamisch,
        # kann den Wert aber höchstens um acht Punkte verändern.
        cot_score = safe_float(pair_setup.get("confidence", 50), 50)
        seasonality_delta = seasonality_quality_adjustment(score)
        final_score = clamp(cot_score + seasonality_delta)
        return {
            "pair": pair,
            "display_name": pair_setup.get("display_name", pair),
            "asset": pair_setup.get("asset", ""),
            "is_single_asset": bool(pair_setup.get("is_single_asset", False)),
            "original_rank": pair_setup.get("original_rank", ""),
            "direction": direction,
            "cot_confidence": pair_setup.get("confidence", 50),
            "seasonality_score": round(score, 1),
            "seasonality_adjustment": seasonality_delta,
            "final_score": round(final_score, 1),
            "verdict": verdict,
            "calendar_week": analysis_date.isocalendar()[1],
            "analysis_date": analysis_date.strftime("%Y-%m-%d"),
            "analysis_end_date": (analysis_date + timedelta(days=7 * SEASONALITY_LOOKAHEAD_WEEKS)).strftime("%Y-%m-%d"),
            "cot_report_date": report_date.strftime("%Y-%m-%d"),
            "lookahead_weeks": SEASONALITY_LOOKAHEAD_WEEKS,
            "years": n,
            "positive_years": wins,
            "negative_years": n - wins,
            "hit_rate": round(hit_rate, 1),
            "average_return_pct": round(avg_ret, 2),
            "median_return_pct": round(median_ret, 2),
            "average_raw_return_pct": round(avg_raw_ret, 2),
            "median_raw_return_pct": round(median_raw_ret, 2),
            "stdev_return_pct": round(stdev, 2),
            "reliability_label": "HOCH" if n >= 18 and stdev <= max(2.5, abs(avg_ret) * 2.5) else "MITTEL" if n >= 12 else "NIEDRIG",
            "source": self.source,
            "data_mode": mode,
            "cache_file": str(path),
            "windows": windows,
        }

    def analyze_top3(self, top3, report_date_text):
        try:
            report_date = datetime.strptime(str(report_date_text), "%Y-%m-%d")
        except Exception:
            report_date = datetime.now()
        analysis_date = datetime.now()
        results = []
        total = max(1, len(top3))
        for i, pair_setup in enumerate(top3, 1):
            pct = 65 + int((i / total) * 30)
            self.progress(clamp(pct, 65, 95), f"Seasonality {pair_setup['pair']} prüfen")
            results.append(self.analyze_pair(pair_setup, report_date, analysis_date))
        results.sort(key=lambda r: r["final_score"], reverse=True)
        return results


BOND_COUNTRY_SLUGS = {
    "USD": "united-states",
    "EUR": "germany",
    "GBP": "united-kingdom",
    "JPY": "japan",
    "CHF": "switzerland",
    "CAD": "canada",
    "AUD": "australia",
    "NZD": "new-zealand",
}

BOND_COUNTRY_NAMES = {
    "USD": "United States",
    "EUR": "Germany",
    "GBP": "United Kingdom",
    "JPY": "Japan",
    "CHF": "Switzerland",
    "CAD": "Canada",
    "AUD": "Australia",
    "NZD": "New Zealand",
}

# Sekundäre Tageshistorie ausschließlich für den Zinsimpuls. Die aktuellen
# 2Y und 10Y Niveaus werden weiterhin aus den bereits priorisierten Behörden
# und Reservequellen geladen. Diese Reihe wird nur verwendet, wenn eine
# Primärquelle keine mindestens 20 Handelstage lange Historie bereitstellt.
MARKETWATCH_BOND_TICKERS = {
    "USD": {2: "tmubmusd02y", 10: "tmubmusd10y"},
    "EUR": {2: "tmbmkde-02y", 10: "tmbmkde-10y"},
    "GBP": {2: "tmbmkgb-02y", 10: "tmbmkgb-10y"},
    "JPY": {2: "tmbmkjp-02y", 10: "tmbmkjp-10y"},
    "CAD": {2: "tmbmkca-02y", 10: "tmbmkca-10y"},
    "AUD": {2: "tmbmkau-02y", 10: "tmbmkau-10y"},
    "NZD": {2: "tmbmknz-02y", 10: "tmbmknz-10y"},
}

EVENT_COUNTRIES = {
    "USD": "united states",
    "EUR": "euro area",
    "GBP": "united kingdom",
    "JPY": "japan",
    "CHF": "switzerland",
    "CAD": "canada",
    "AUD": "australia",
    "NZD": "new zealand",
}

HIGH_IMPACT_KEYWORDS = (
    "interest rate", "rate decision", "central bank", "monetary policy", "fomc", "fed", "ecb", "boe", "boj", "snb", "boc", "rba", "rbnz",
    "inflation", "cpi", "consumer price", "non farm", "nonfarm", "payroll", "employment", "unemployment", "gdp", "retail sales", "pmi",
)

EVENT_TRANSLATIONS = {
    "Average Hourly Earnings m/m": "Durchschnittliche Stundenlöhne, m/m",
    "Non-Farm Employment Change": "US Arbeitsmarktbericht, neue Stellen außerhalb der Landwirtschaft",
    "Nonfarm Payrolls": "US Arbeitsmarktbericht, neue Stellen außerhalb der Landwirtschaft",
    "Unemployment Rate": "Arbeitslosenquote",
    "CPI m/m": "Verbraucherpreise, m/m",
    "CPI y/y": "Verbraucherpreise, y/y",
    "Core CPI m/m": "Kernverbraucherpreise, m/m",
    "PPI m/m": "Erzeugerpreise, m/m",
    "GDP q/q": "Bruttoinlandsprodukt, q/q",
    "Retail Sales m/m": "Einzelhandelsumsätze, m/m",
    "Manufacturing PMI": "Einkaufsmanagerindex Industrie",
    "Services PMI": "Einkaufsmanagerindex Dienstleistungen",
    "FOMC Member": "Rede eines Fed Mitglieds",
    "FOMC Statement": "Fed Zinsstatement",
    "Federal Funds Rate": "Fed Zinsentscheid",
    "BOE Credit Conditions Survey": "BoE Kreditbedingungen Umfrage",
    "Official Bank Rate": "BoE Zinsentscheid",
    "BOC Rate Statement": "BoC Zinsstatement",
    "Overnight Rate": "BoC Zinsentscheid",
    "RBNZ Rate Statement": "RBNZ Zinsstatement",
    "Official Cash Rate": "RBNZ Zinsentscheid",
}


def translate_event_title(title):
    text = str(title or "Wirtschaftstermin").strip()
    low = text.lower()
    for key, val in EVENT_TRANSLATIONS.items():
        if key.lower() in low:
            if "speaks" in low and "Rede" in val:
                return val
            return val
    # Ein paar robuste Fallbacks, damit die Oberfläche deutsch bleibt, auch wenn die Quelle englische Titel liefert.
    replacements = [
        ("average hourly earnings", "Durchschnittliche Stundenlöhne"),
        ("non-farm employment change", "US Arbeitsmarktbericht"),
        ("non farm employment change", "US Arbeitsmarktbericht"),
        ("nonfarm payroll", "US Arbeitsmarktbericht"),
        ("unemployment rate", "Arbeitslosenquote"),
        ("consumer price", "Verbraucherpreise"),
        ("core cpi", "Kernverbraucherpreise"),
        ("cpi", "Verbraucherpreise"),
        ("producer price", "Erzeugerpreise"),
        ("ppi", "Erzeugerpreise"),
        ("retail sales", "Einzelhandelsumsätze"),
        ("manufacturing pmi", "Einkaufsmanagerindex Industrie"),
        ("services pmi", "Einkaufsmanagerindex Dienstleistungen"),
        ("gdp", "Bruttoinlandsprodukt"),
        ("rate decision", "Zinsentscheid"),
        ("interest rate", "Zinsentscheid"),
        ("fomc", "Fed Termin"),
        ("speaks", "Rede"),
    ]
    out = text
    for eng, ger in replacements:
        out = re.sub(re.escape(eng), ger, out, flags=re.IGNORECASE)
    return out


def star_text(score):
    score = clamp(safe_float(score, 50), 0, 100)
    stars = int(round(score / 20.0))
    stars = max(1, min(5, stars))
    return "★" * stars + "☆" * (5 - stars)


def sanitize_audit_payload(value):
    """Entfernt absolute lokale Pfade aus Audit Dateien.
    URLs bleiben erhalten, Dateipfade werden auf Dateinamen oder relative Pfade gekürzt.
    """
    if isinstance(value, dict):
        return {k: sanitize_audit_payload(v) for k, v in value.items()}
    if isinstance(value, list):
        return [sanitize_audit_payload(v) for v in value]
    if isinstance(value, tuple):
        return tuple(sanitize_audit_payload(v) for v in value)
    if isinstance(value, str):
        if value.startswith(("http://", "https://")):
            return value
        app = str(APP_DIR)
        if app and value.startswith(app):
            try:
                return str(Path(value).relative_to(APP_DIR))
            except Exception:
                return Path(value).name
        if re.match(r"^[A-Za-z]:\\", value) or value.startswith("/"):
            return Path(value).name
        return value
    return value


class MacroEngine:
    """
    Eigenständiger Makro Check.
    Sie verändert keine COT oder Seasonality Berechnung, sondern ergänzt nur eine finale Marktprüfung.
    """
    def __init__(self, progress=None):
        self.progress = progress or (lambda pct, text: None)
        self.errors = []
        self.cache_dir = MACRO_DIR
        self.cache_dir.mkdir(exist_ok=True)
        self.yields = {}
        self.sources_used = {}
        self.event_audits = []
        self.bond_audits = []
        # Laufzeit Caches verhindern identische Netzwerkaufrufe innerhalb einer Analyse.
        self._event_cache = {}
        self._forexfactory_cache = {}
        self._bond_api_rows = {}
        self._bond_api_errors = {}
        self._bond_api_lock = threading.Lock()
        self._boe_curve_cache = None
        self._boe_archive_curve_cache = None
        self._raw_text_cache = {}
        self._raw_bytes_cache = {}
        self._bond_history_memory = {}
        self._impulse_history_cache = {}
        self._impulse_history_sources = {}
        self._impulse_history_errors = {}
        self._snb_curve_cache = None
        self._forexfactory_lock = threading.Lock()

    def _fetch_windows_tls_bytes(self, url, timeout, headers):
        """Sicherer Windows TLS Fallback ohne Abschalten der Zertifikatsprüfung."""
        errors = []
        creation_flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        curl = shutil.which("curl.exe") or (shutil.which("curl") if os.name == "nt" else None)
        if curl:
            command = [
                curl, "--fail", "--location", "--silent", "--show-error",
                "--connect-timeout", str(max(4, int(timeout))),
                "--max-time", str(max(10, int(timeout) + 8)),
            ]
            for name, value in dict(headers or {}).items():
                command.extend(["-H", f"{name}: {value}"])
            command.append(url)
            try:
                completed = subprocess.run(
                    command, capture_output=True,
                    timeout=max(15, int(timeout) + 12),
                    creationflags=creation_flags,
                )
                if completed.returncode == 0 and completed.stdout:
                    return completed.stdout
                detail = completed.stderr.decode("utf-8", errors="replace").strip()
                errors.append("Windows curl: " + (detail or f"Fehlercode {completed.returncode}"))
            except Exception as exc:
                errors.append(f"Windows curl: {exc}")

        powershell = (
            shutil.which("powershell.exe") or shutil.which("powershell") or
            shutil.which("pwsh.exe") or shutil.which("pwsh")
        )
        if powershell:
            descriptor, temporary_name = tempfile.mkstemp(prefix="meridian_tls_", suffix=".bin")
            os.close(descriptor)
            temporary_path = Path(temporary_name)
            try:
                # URL und Header werden bewusst über die Prozessumgebung übergeben.
                # Hinter ``-Command`` wertet Windows PowerShell Zeichen wie ``&``
                # andernfalls als Operator aus. Dadurch wurden URLs mit mehreren
                # Query Parametern auf einzelnen Kundensystemen abgeschnitten.
                powershell_env = os.environ.copy()
                powershell_env["FIVEMG_TLS_URL"] = str(url)
                powershell_env["FIVEMG_TLS_OUTPUT"] = str(temporary_path)
                powershell_env["FIVEMG_TLS_HEADERS"] = json.dumps(
                    {str(name): str(value) for name, value in dict(headers or {}).items()},
                    ensure_ascii=False,
                )
                script = (
                    "$ErrorActionPreference='Stop'; "
                    "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; "
                    "$ProgressPreference='SilentlyContinue'; "
                    "$uri=[Environment]::GetEnvironmentVariable('FIVEMG_TLS_URL'); "
                    "$output=[Environment]::GetEnvironmentVariable('FIVEMG_TLS_OUTPUT'); "
                    "$headersJson=[Environment]::GetEnvironmentVariable('FIVEMG_TLS_HEADERS'); "
                    "$headers=@{}; "
                    "if($headersJson){$headerObject=ConvertFrom-Json -InputObject $headersJson; "
                    "$headerObject.PSObject.Properties|ForEach-Object{$headers[$_.Name]=[string]$_.Value}}; "
                    f"Invoke-WebRequest -UseBasicParsing -MaximumRedirection 5 -TimeoutSec {max(10, int(timeout) + 5)} "
                    "-Headers $headers -Uri $uri -OutFile $output"
                )
                completed = subprocess.run(
                    [
                        powershell, "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
                        "-Command", script,
                    ],
                    capture_output=True,
                    timeout=max(20, int(timeout) + 15),
                    creationflags=creation_flags,
                    env=powershell_env,
                )
                if completed.returncode == 0 and temporary_path.exists() and temporary_path.stat().st_size:
                    return temporary_path.read_bytes()
                detail = completed.stderr.decode("utf-8", errors="replace").strip()
                errors.append("Windows TLS: " + (detail or f"Fehlercode {completed.returncode}"))
            except Exception as exc:
                errors.append(f"Windows TLS: {exc}")
            finally:
                try:
                    temporary_path.unlink(missing_ok=True)
                except Exception:
                    pass
        raise RuntimeError("; ".join(errors) if errors else "Kein Windows TLS Fallback verfügbar")

    def _fetch_secure_bytes(self, url, timeout, headers):
        errors = []
        contexts = []
        try:
            import certifi  # type: ignore
            contexts.append(("Python Zertifikatsspeicher", ssl.create_default_context(cafile=certifi.where())))
        except Exception:
            pass
        contexts.append(("Python TLS", ssl.create_default_context()))
        for label, context in contexts:
            try:
                request = urllib.request.Request(url, headers=headers)
                with urllib.request.urlopen(request, timeout=timeout, context=context) as response:
                    raw = response.read()
                if raw:
                    return raw
                errors.append(f"{label}: leere Antwort")
            except Exception as exc:
                errors.append(f"{label}: {exc}")
        if os.name == "nt":
            try:
                return self._fetch_windows_tls_bytes(url, timeout, headers)
            except Exception as exc:
                errors.append(str(exc))
        raise RuntimeError(" | ".join(errors))

    def fetch_url(self, url, timeout=8):
        if url in self._raw_text_cache:
            return self._raw_text_cache[url]
        headers = {
            "User-Agent": f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) MeridianAnalyzerPro/{APP_VERSION}",
            "Accept": "text/html,application/json,text/plain,*/*",
        }
        text = self._fetch_secure_bytes(url, timeout, headers).decode("utf-8", errors="ignore")
        self._raw_text_cache[url] = text
        return text

    def fetch_bytes(self, url, timeout=10, extra_headers=None):
        """Binärer Download für offizielle CSV Dateien mit abweichender Kodierung."""
        if url in self._raw_bytes_cache:
            return self._raw_bytes_cache[url]
        headers = {
            "User-Agent": f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) MeridianAnalyzerPro/{APP_VERSION}",
            "Accept": "text/csv,application/xml,application/json,application/zip,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/plain,*/*",
        }
        headers.update(dict(extra_headers or {}))
        raw = self._fetch_secure_bytes(url, timeout, headers)
        self._raw_bytes_cache[url] = raw
        return raw

    def fetch_byte_range(self, url, start=None, end=None, suffix=None, timeout=12):
        """Lädt einen klar begrenzten Bereich einer großen offiziellen Datei.

        Große Behördenarchive werden dadurch nicht vollständig übertragen, wenn
        nur die aktuelle Arbeitsmappe benötigt wird. Ignoriert ein Server die
        Range Anforderung, wird die vollständige Antwort weiterhin akzeptiert.
        """
        if suffix is not None:
            range_value = f"bytes=-{max(1024, int(suffix))}"
        else:
            if start is None:
                raise ValueError("Für den Bytebereich fehlt der Startwert")
            range_value = f"bytes={max(0, int(start))}-{'' if end is None else max(int(start), int(end))}"
        cache_key = f"{url}#range={range_value}"
        if cache_key in self._raw_bytes_cache:
            return self._raw_bytes_cache[cache_key]
        headers = {
            "User-Agent": f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) MeridianAnalyzerPro/{APP_VERSION}",
            "Accept": "application/zip,application/x-zip-compressed,application/octet-stream,*/*",
            "Range": range_value,
        }
        raw = self._fetch_secure_bytes(url, timeout, headers)
        if not raw:
            raise RuntimeError("Offizielles Archiv lieferte einen leeren Bytebereich")
        self._raw_bytes_cache[cache_key] = raw
        return raw

    def extract_selected_zip_member(self, archive, member_selector):
        """Extrahiert die passendste Datei aus einem vollständig geladenen ZIP."""
        with zipfile.ZipFile(io.BytesIO(archive), "r") as bundle:
            matches = [name for name in bundle.namelist() if member_selector(name)]
            if not matches:
                raise RuntimeError("Gesuchte Arbeitsmappe fehlt im offiziellen Archiv")
            matches.sort(key=self.remote_zip_member_rank)
            return bundle.read(matches[-1]), matches[-1]

    @staticmethod
    def remote_zip_member_rank(name):
        text = str(name or "").lower()
        years = [int(value) for value in re.findall(r"(?:19|20)\d{2}", text)]
        return (1 if "present" in text else 0, max(years) if years else 0, text)

    def fetch_remote_zip_member(self, url, member_selector, timeout=15):
        """Liest gezielt ein Mitglied aus einem großen entfernten ZIP Archiv.

        Zuerst werden nur ZIP Verzeichnis und der komprimierte Bereich der
        benötigten Datei geladen. Falls ein Server keine Bytebereiche unterstützt,
        bleibt ein vollständiger Download als robuste letzte Ausweichmöglichkeit.
        """
        def from_complete_archive(raw):
            try:
                if not zipfile.is_zipfile(io.BytesIO(raw)):
                    return None
                return self.extract_selected_zip_member(raw, member_selector)
            except (OSError, ValueError, zipfile.BadZipFile):
                # Ein Bytebereich kann zufällig den ZIP Abschluss enthalten,
                # ist aber noch kein vollständiges Archiv. Dann normal mit dem
                # zentralen Verzeichnis fortfahren.
                return None

        try:
            # Die aktuelle BoE Arbeitsmappe liegt am Ende des Archivs. Ein etwas
            # größerer Endbereich enthält normalerweise Verzeichnis, Dateikopf
            # und komprimierte Arbeitsmappe in einer einzigen HTTP Antwort.
            tail = self.fetch_byte_range(url, suffix=3 * 1024 * 1024, timeout=timeout)
            complete = from_complete_archive(tail)
            if complete is not None:
                return complete

            signature = b"PK\x05\x06"
            eocd_position = tail.rfind(signature)
            if eocd_position < 0 or eocd_position + 22 > len(tail):
                raise RuntimeError("ZIP Abschlussverzeichnis fehlt im Bytebereich")
            fields = struct.unpack_from("<4s4H2IH", tail, eocd_position)
            disk_number, directory_disk = fields[1], fields[2]
            entry_count, directory_size, directory_offset, comment_length = (
                fields[4], fields[5], fields[6], fields[7]
            )
            if disk_number or directory_disk:
                raise RuntimeError("Mehrteiliges ZIP Archiv wird nicht unterstützt")
            total_size = directory_offset + directory_size + 22 + comment_length
            tail_offset = total_size - len(tail)
            if directory_offset >= tail_offset and directory_offset + directory_size <= total_size:
                start = directory_offset - tail_offset
                directory = tail[start:start + directory_size]
            else:
                directory = self.fetch_byte_range(
                    url, directory_offset, directory_offset + directory_size - 1, timeout=timeout
                )
                complete = from_complete_archive(directory)
                if complete is not None:
                    return complete
            if len(directory) < directory_size:
                raise RuntimeError("ZIP Verzeichnis wurde unvollständig übertragen")

            entries = []
            cursor = 0
            for _ in range(entry_count):
                if cursor + 46 > len(directory) or directory[cursor:cursor + 4] != b"PK\x01\x02":
                    raise RuntimeError("ZIP Verzeichniseintrag ist unvollständig")
                values = struct.unpack_from("<4s6H3I5H2I", directory, cursor)
                flags, compression = values[3], values[4]
                crc_value, compressed_size, uncompressed_size = values[7], values[8], values[9]
                name_length, extra_length, entry_comment_length = values[10], values[11], values[12]
                local_offset = values[16]
                name_start = cursor + 46
                name_end = name_start + name_length
                encoding = "utf-8" if flags & 0x800 else "cp437"
                name = directory[name_start:name_end].decode(encoding, errors="replace")
                if member_selector(name):
                    entries.append({
                        "name": name,
                        "flags": flags,
                        "compression": compression,
                        "crc": crc_value,
                        "compressed_size": compressed_size,
                        "uncompressed_size": uncompressed_size,
                        "local_offset": local_offset,
                    })
                cursor = name_end + extra_length + entry_comment_length
            if not entries:
                raise RuntimeError("Gesuchte Arbeitsmappe fehlt im ZIP Verzeichnis")
            entries.sort(key=lambda item: self.remote_zip_member_rank(item["name"]))
            selected = entries[-1]

            if selected["local_offset"] >= tail_offset:
                header_start = selected["local_offset"] - tail_offset
                header = tail[header_start:header_start + 4096]
            else:
                header = self.fetch_byte_range(
                    url, selected["local_offset"], selected["local_offset"] + 4095, timeout=timeout
                )
            complete = from_complete_archive(header)
            if complete is not None:
                return complete
            if len(header) < 30 or header[:4] != b"PK\x03\x04":
                raise RuntimeError("Lokaler ZIP Dateikopf ist unvollständig")
            local_values = struct.unpack_from("<4s5H3I2H", header, 0)
            file_name_length, local_extra_length = local_values[9], local_values[10]
            data_start = selected["local_offset"] + 30 + file_name_length + local_extra_length
            data_end = data_start + selected["compressed_size"] - 1
            if data_start >= tail_offset and data_end < total_size:
                compressed_start = data_start - tail_offset
                compressed = tail[compressed_start:compressed_start + selected["compressed_size"]]
            else:
                compressed = self.fetch_byte_range(url, data_start, data_end, timeout=max(timeout, 18))
            complete = from_complete_archive(compressed)
            if complete is not None:
                return complete
            if len(compressed) != selected["compressed_size"]:
                raise RuntimeError("Komprimierte Arbeitsmappe wurde unvollständig übertragen")
            if selected["flags"] & 0x1:
                raise RuntimeError("Verschlüsseltes ZIP Mitglied wird nicht unterstützt")
            if selected["compression"] == zipfile.ZIP_STORED:
                workbook = compressed
            elif selected["compression"] == zipfile.ZIP_DEFLATED:
                workbook = zlib.decompress(compressed, -zlib.MAX_WBITS)
            else:
                raise RuntimeError(f"ZIP Kompressionsmethode {selected['compression']} wird nicht unterstützt")
            if len(workbook) != selected["uncompressed_size"]:
                raise RuntimeError("Entpackte Arbeitsmappe besitzt eine unerwartete Größe")
            if (zlib.crc32(workbook) & 0xFFFFFFFF) != selected["crc"]:
                raise RuntimeError("Prüfsumme der offiziellen Arbeitsmappe stimmt nicht")
            return workbook, selected["name"]
        except Exception as range_error:
            try:
                archive = self.fetch_bytes(url, timeout=max(45, timeout * 3))
                return self.extract_selected_zip_member(archive, member_selector)
            except Exception as full_error:
                raise RuntimeError(
                    f"Offizielles ZIP Archiv nicht lesbar: Bytebereich {range_error}; Vollabruf {full_error}"
                ) from full_error

    def decode_official_text(self, raw):
        if isinstance(raw, str):
            return raw
        for encoding in ("utf-8-sig", "utf-8", "cp1252", "latin-1"):
            try:
                return raw.decode(encoding)
            except UnicodeDecodeError:
                continue
        return raw.decode("utf-8", errors="ignore")

    def is_official_bond_source(self, source):
        text = str(source or "").lower()
        markers = (
            "us treasury", "ezb", "bank of england", "japan ministry of finance",
            "snb", "bank of canada", "reserve bank of australia",
            "reserve bank of new zealand",
        )
        return any(marker in text for marker in markers)

    def normalize_observation_date(self, value):
        """Normalisiert Behördenzeitstempel und Excel Datumswerte auf YYYY-MM-DD."""
        raw = str(value or "").strip()
        numeric = safe_float(raw, None)
        if numeric is not None and 20000 <= numeric <= 80000:
            try:
                return (datetime(1899, 12, 30) + timedelta(days=float(numeric))).strftime("%Y-%m-%d")
            except Exception:
                return ""
        raw = raw[:19]
        for date_format in (
            "%Y-%m-%d", "%Y/%m/%d", "%d-%b-%Y", "%d %b %Y",
            "%d-%B-%Y", "%d %B %Y", "%b %d %Y", "%B %d %Y",
            "%d.%m.%Y", "%m/%d/%Y", "%Y-%m-%dT%H:%M:%S",
        ):
            try:
                return datetime.strptime(raw, date_format).strftime("%Y-%m-%d")
            except ValueError:
                continue
        match = re.match(r"(\d{4}-\d{2}-\d{2})", raw)
        return match.group(1) if match else ""

    def normalize_history_points(self, points, default_source=""):
        by_date = {}
        for point in list(points or []):
            if not isinstance(point, dict):
                continue
            date_text = self.normalize_observation_date(point.get("date"))
            value = safe_float(point.get("yield", point.get("value")), None)
            if not date_text or not self.valid_bond_value(value):
                continue
            by_date[date_text] = {
                "date": date_text,
                "yield": round(float(value), 6),
                "source": str(point.get("source") or default_source),
            }
        return [by_date[key] for key in sorted(by_date)][-400:]

    def history_from_csv(self, text, column_tokens):
        """Liest Datum und Laufzeitwert aus üblichen Behörden CSV Formaten."""
        text = self.decode_official_text(text).replace("\x00", "")
        try:
            delimiter = csv.Sniffer().sniff(text[:8192], delimiters=",;\t").delimiter
        except Exception:
            delimiter = ","
        rows = list(csv.reader(io.StringIO(text), delimiter=delimiter))
        tokens = [re.sub(r"\s+", "", str(token).lower()) for token in column_tokens]
        for header_no, row in enumerate(rows[:100]):
            normalized = [re.sub(r"\s+", "", str(cell).lower()) for cell in row]
            value_index = next((index for index, cell in enumerate(normalized)
                                if any(token in cell for token in tokens)), None)
            if value_index is None:
                continue
            date_index = next((index for index, cell in enumerate(normalized)
                               if cell in ("date", "timeperiod", "time_period", "datum")), 0)
            points = []
            for data_row in rows[header_no + 1:]:
                if max(value_index, date_index) >= len(data_row):
                    continue
                date_text = self.normalize_observation_date(data_row[date_index])
                raw_value = str(data_row[value_index]).strip().replace("%", "").replace("\u2212", "-")
                if raw_value.count(",") == 1 and "." not in raw_value:
                    raw_value = raw_value.replace(",", ".")
                value = safe_float(raw_value, None)
                if date_text and self.valid_bond_value(value):
                    points.append({"date": date_text, "yield": float(value)})
            normalized_points = self.normalize_history_points(points)
            if normalized_points:
                return normalized_points
        raise RuntimeError("Offizielle Zeitreihe enthält keine datierten Renditewerte")

    def ensure_history_fresh(self, points, source, max_age_days=10):
        normalized = self.normalize_history_points(points, source)
        if not normalized:
            raise RuntimeError(f"{source} enthält keine belastbare Renditehistorie")
        latest = datetime.strptime(normalized[-1]["date"], "%Y-%m-%d").date()
        age_days = (datetime.now().date() - latest).days
        if age_days > max_age_days:
            raise RuntimeError(f"{source} ist mit Datenstand {normalized[-1]['date']} nicht aktuell genug")
        return normalized

    def bond_history_path(self, currency, maturity):
        return self.cache_path(f"bond_history_{currency.upper()}_{int(maturity)}y.json")

    def fallback_market_date(self):
        """Verhindert künstliche Wochenendpunkte in Reservehistorien."""
        current = datetime.now().date()
        while current.weekday() >= 5:
            current -= timedelta(days=1)
        return current.strftime("%Y-%m-%d")

    def store_bond_history(self, currency, maturity, points, source, url=""):
        currency = currency.upper()
        maturity = 2 if int(maturity) == 2 else 10
        path = self.bond_history_path(currency, maturity)
        existing = self.load_cached_json(path, 24 * 3650) or {}
        merged = list(existing.get("points", [])) + list(points or [])
        normalized = self.normalize_history_points(merged, source)
        payload = {
            "schema_version": BOND_HISTORY_SCHEMA_VERSION,
            "currency": currency,
            "maturity": maturity,
            "source": source,
            "url": url,
            "updated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "points": normalized,
        }
        self.save_cached_json(path, payload)
        self._bond_history_memory[(currency, maturity)] = payload
        return payload

    def load_bond_history(self, currency, maturity, current_payload=None):
        currency = currency.upper()
        maturity = 2 if int(maturity) == 2 else 10
        key = (currency, maturity)
        payload = self._bond_history_memory.get(key)
        if payload is None:
            payload = self.load_cached_json(self.bond_history_path(currency, maturity), 24 * 3650) or {}
        points = list(payload.get("points", []))
        if current_payload and self.valid_bond_value(current_payload.get("yield")):
            observation_date = current_payload.get("observation_date") or self.fallback_market_date()
            points.append({
                "date": observation_date,
                "yield": current_payload.get("yield"),
                "source": current_payload.get("source", ""),
            })
            payload = self.store_bond_history(
                currency, maturity, points,
                current_payload.get("source", payload.get("source", "")),
                current_payload.get("url", payload.get("url", "")),
            )
        return payload

    def latest_history_observation(self, currency, maturity, source):
        payload = self._bond_history_memory.get((currency.upper(), 2 if int(maturity) == 2 else 10), {})
        matching = [point for point in payload.get("points", []) if str(point.get("source")) == str(source)]
        return matching[-1]["date"] if matching else ""

    def latest_numeric_from_csv(self, text, column_tokens, min_value=-2.0, max_value=25.0):
        """Liest den neuesten plausiblen Wert aus unterschiedlich aufgebauten Behörden CSVs."""
        text = self.decode_official_text(text).replace("\x00", "")
        sample = text[:8192]
        try:
            dialect = csv.Sniffer().sniff(sample, delimiters=",;\t")
            delimiter = dialect.delimiter
        except Exception:
            delimiter = ","
        rows = list(csv.reader(io.StringIO(text), delimiter=delimiter))
        if not rows:
            raise RuntimeError("Offizielle CSV enthält keine Zeilen")
        tokens = [str(token).lower().replace(" ", "") for token in column_tokens]
        header_index = None
        value_index = None
        for row_no, row in enumerate(rows[:30]):
            normalized = [re.sub(r"\s+", "", str(cell).lower()) for cell in row]
            for col_no, cell in enumerate(normalized):
                if any(token in cell for token in tokens):
                    header_index, value_index = row_no, col_no
                    break
            if value_index is not None:
                break
        if value_index is None:
            raise RuntimeError("Gesuchte Laufzeit fehlt in offizieller CSV")
        values = []
        for row in rows[header_index + 1:]:
            if value_index >= len(row):
                continue
            raw_value = str(row[value_index]).strip().replace("%", "").replace("\u2212", "-")
            if raw_value.count(",") == 1 and "." not in raw_value:
                raw_value = raw_value.replace(",", ".")
            value = safe_float(raw_value, None)
            if value is not None and min_value <= value <= max_value:
                values.append(value)
        if not values:
            raise RuntimeError("Offizielle CSV enthält keinen aktuellen Renditewert")
        return float(values[-1])

    def latest_numeric_from_xlsx(self, raw, column_tokens, min_value=-2.0, max_value=25.0):
        """Kleine, abhängigkeitsfreie XLSX Auswertung für offizielle Statistikdateien."""
        with zipfile.ZipFile(io.BytesIO(raw), "r") as book:
            shared = []
            if "xl/sharedStrings.xml" in book.namelist():
                root = ET.fromstring(book.read("xl/sharedStrings.xml"))
                for item in root.findall("{*}si"):
                    shared.append("".join(node.text or "" for node in item.findall(".//{*}t")))
            tokens = [str(token).lower().replace(" ", "") for token in column_tokens]
            candidates = []
            for sheet_name in sorted(name for name in book.namelist() if re.match(r"xl/worksheets/sheet\d+\.xml$", name)):
                root = ET.fromstring(book.read(sheet_name))
                rows = []
                for row_node in root.findall(".//{*}row"):
                    row = {}
                    for cell in row_node.findall("{*}c"):
                        ref = cell.attrib.get("r", "A1")
                        letters = re.match(r"[A-Z]+", ref)
                        if not letters:
                            continue
                        col = 0
                        for char in letters.group(0):
                            col = col * 26 + ord(char) - 64
                        value_node = cell.find("{*}v")
                        inline = cell.find(".//{*}t")
                        value = inline.text if inline is not None else (value_node.text if value_node is not None else "")
                        if cell.attrib.get("t") == "s" and str(value).isdigit():
                            index = int(value)
                            value = shared[index] if index < len(shared) else ""
                        row[col - 1] = value
                    if row:
                        width = max(row) + 1
                        rows.append([row.get(i, "") for i in range(width)])
                for header_no, row in enumerate(rows[:80]):
                    normalized = [re.sub(r"\s+", "", str(cell).lower()) for cell in row]
                    for value_index, cell in enumerate(normalized):
                        if not any(token in cell for token in tokens):
                            continue
                        values = []
                        for data_row in rows[header_no + 1:]:
                            if value_index >= len(data_row):
                                continue
                            value = safe_float(str(data_row[value_index]).replace(",", "."), None)
                            if value is not None and min_value <= value <= max_value:
                                values.append(value)
                        if values:
                            candidates.append(float(values[-1]))
            if not candidates:
                raise RuntimeError("Gesuchte Laufzeit fehlt in offizieller XLSX Datei")
            return candidates[-1]

    def history_from_xlsx(self, raw, column_tokens, min_value=-2.0, max_value=25.0):
        """Liest eine datierte Renditespalte aus einer Behörden XLSX Datei."""
        with zipfile.ZipFile(io.BytesIO(raw), "r") as book:
            shared = []
            if "xl/sharedStrings.xml" in book.namelist():
                root = ET.fromstring(book.read("xl/sharedStrings.xml"))
                for item in root.findall("{*}si"):
                    shared.append("".join(node.text or "" for node in item.findall(".//{*}t")))
            tokens = [str(token).lower().replace(" ", "") for token in column_tokens]
            best = []
            for sheet_name in sorted(name for name in book.namelist() if re.match(r"xl/worksheets/sheet\d+\.xml$", name)):
                root = ET.fromstring(book.read(sheet_name))
                rows = []
                for row_node in root.findall(".//{*}row"):
                    row = {}
                    for cell in row_node.findall("{*}c"):
                        ref = cell.attrib.get("r", "A1")
                        letters = re.match(r"[A-Z]+", ref)
                        if not letters:
                            continue
                        column = 0
                        for char in letters.group(0):
                            column = column * 26 + ord(char) - 64
                        value_node = cell.find("{*}v")
                        inline = cell.find(".//{*}t")
                        value = inline.text if inline is not None else (value_node.text if value_node is not None else "")
                        if cell.attrib.get("t") == "s" and str(value).isdigit():
                            index = int(value)
                            value = shared[index] if index < len(shared) else ""
                        row[column - 1] = value
                    if row:
                        rows.append(row)

                for header_no, row in enumerate(rows[:100]):
                    normalized = {column: re.sub(r"\s+", "", str(value).lower()) for column, value in row.items()}
                    value_index = next((column for column, cell in normalized.items()
                                        if any(token in cell for token in tokens)), None)
                    if value_index is None:
                        continue
                    points = []
                    for data_row in rows[header_no + 1:]:
                        value = safe_float(str(data_row.get(value_index, "")).replace(",", "."), None)
                        if value is None or not min_value <= value <= max_value:
                            continue
                        date_text = ""
                        for column in sorted(data_row):
                            if column == value_index:
                                continue
                            date_text = self.normalize_observation_date(data_row.get(column))
                            if date_text:
                                break
                        if date_text:
                            points.append({"date": date_text, "yield": value})
                    points = self.normalize_history_points(points)
                    if len(points) > len(best):
                        best = points
            if not best:
                raise RuntimeError("Offizielle XLSX enthält keine datierte Renditehistorie")
            return best

    def fetch_us_treasury_yield(self, maturity=10):
        maturity = 2 if int(maturity) == 2 else 10
        year = time.strftime("%Y")
        url = ("https://home.treasury.gov/resource-center/data-chart-center/interest-rates/"
               f"pages/xml?data=daily_treasury_yield_curve&field_tdr_date_value={year}")
        xml = self.fetch_url(url, timeout=10)
        field = "BC_2YEAR" if maturity == 2 else "BC_10YEAR"
        points = []
        for block in re.findall(r"<entry>.*?</entry>", xml, re.IGNORECASE | re.DOTALL):
            date_match = re.search(r"<(?:\w+:)?NEW_DATE[^>]*>([^<]+)</(?:\w+:)?NEW_DATE>", block, re.IGNORECASE)
            value_match = re.search(rf"<(?:\w+:)?{field}[^>]*>(-?\d+(?:\.\d+)?)</(?:\w+:)?{field}>", block, re.IGNORECASE)
            if date_match and value_match:
                points.append({"date": date_match.group(1), "yield": float(value_match.group(1))})
        source = f"US Treasury Daily Par Yield Curve {maturity}Y"
        points = self.ensure_history_fresh(points, source)
        self.store_bond_history("USD", maturity, points, source, url)
        if not points:
            raise RuntimeError(f"US Treasury Feld {field} fehlt")
        value = float(points[-1]["yield"])
        if not -2.0 <= value <= 25.0:
            raise RuntimeError("US Treasury Rendite außerhalb Plausibilität")
        return value, source, url

    def fetch_ecb_yield(self, maturity=10):
        maturity = 2 if int(maturity) == 2 else 10
        series = f"B.U2.EUR.4F.G_N_A.SV_C_YM.SR_{maturity}Y"
        url = f"https://data-api.ecb.europa.eu/service/data/YC/{series}?format=csvdata&lastNObservations=45"
        text = self.fetch_url(url, timeout=10)
        source = f"EZB AAA Staatsanleihen Spotkurve {maturity}Y"
        points = self.ensure_history_fresh(self.history_from_csv(text, ("OBS_VALUE", "obsvalue", "value")), source)
        self.store_bond_history("EUR", maturity, points, source, url)
        return points[-1]["yield"], source, url

    def fetch_bank_of_canada_yield(self, maturity=10):
        maturity = 2 if int(maturity) == 2 else 10
        series = f"BD.CDN.{maturity}YR.DQ.YLD"
        url = f"https://www.bankofcanada.ca/valet/observations/{series}/json?recent=45"
        data = json.loads(self.fetch_url(url, timeout=10))
        points = []
        for row in data.get("observations", []):
            value = safe_float((row.get(series) or {}).get("v"), None)
            if value is not None and -2.0 <= value <= 25.0:
                points.append({"date": row.get("d"), "yield": value})
        source = f"Bank of Canada Benchmark Bond {maturity}Y"
        points = self.ensure_history_fresh(points, source)
        self.store_bond_history("CAD", maturity, points, source, url)
        return float(points[-1]["yield"]), source, url

    def fetch_rba_yield(self, maturity=10):
        maturity = 2 if int(maturity) == 2 else 10
        url = "https://www.rba.gov.au/statistics/tables/csv/f2-data.csv"
        text = self.decode_official_text(self.fetch_bytes(url, timeout=10))
        tokens = (f"AustralianGovernment{maturity}yearbond", f"government{maturity}yearbond", f"{maturity}yearbond")
        source = f"Reserve Bank of Australia Government Bond {maturity}Y"
        points = self.ensure_history_fresh(self.history_from_csv(text, tokens), source)
        self.store_bond_history("AUD", maturity, points, source, url)
        return points[-1]["yield"], source, url

    def fetch_mof_japan_yield(self, maturity=10):
        maturity = 2 if int(maturity) == 2 else 10
        # Die Current Data Datei wird täglich aktualisiert. Das bisherige historische
        # Archiv kann am Monatswechsel deutlich älter sein und dient deshalb nicht
        # mehr als Primärwert.
        url = "https://www.mof.go.jp/english/policy/jgbs/reference/interest_rate/jgbcme.csv"
        text = self.decode_official_text(self.fetch_bytes(url, timeout=12))
        source = f"Japan Ministry of Finance JGB {maturity}Y"
        points = self.ensure_history_fresh(
            self.history_from_csv(text, (f"{maturity}-year", f"{maturity}year", f"{maturity}y")),
            source,
        )
        self.store_bond_history("JPY", maturity, points, source, url)
        return points[-1]["yield"], source, url

    def fetch_snb_current_curve(self):
        """Lädt die täglich gepflegte 2Y und 10Y Schweizer Spotkurve.

        Der frühere SNB Cube ``rendoblid`` wurde 2025 eingefroren. Das aktuelle
        Datenportal stellt dieselben Laufzeiten in der offiziellen Chart Reihe
        ``rendeidglfzch`` bereit. Der kurze Properties Aufruf liefert die von der
        SNB geforderten Sitzungsparameter für den anschließenden Datenabruf.
        """
        if self._snb_curve_cache is not None:
            return self._snb_curve_cache

        base_url = "https://data.snb.ch/"
        chart_id = "rendeidglfzch"
        cookie_jar = http.cookiejar.CookieJar()
        opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cookie_jar))
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/138.0.0.0 Safari/537.36",
            "Accept": "application/json,text/plain,*/*",
        }
        properties_request = urllib.request.Request(
            base_url + "json/application/properties?lang=en", headers=headers,
        )
        with opener.open(properties_request, timeout=12) as response:
            properties = json.loads(response.read().decode("utf-8", errors="ignore"))
        params = {
            "lang": "en",
            "pageViewTime": properties.get("pageViewTime", ""),
            "applicationId": properties.get("applicationId", "epb-public"),
            "environmentId": properties.get("environmentId", "prod"),
            "snbWebsiteUrl": properties.get("snbWebsiteUrl", "https://www.snb.ch"),
            "userName": properties.get("userName", "dummy"),
        }
        data_url = base_url + "json/chart/getAirchartConfigAndData?" + urllib.parse.urlencode(params)
        request = urllib.request.Request(
            data_url,
            data=json.dumps({"chartId": chart_id, "maxZoomOut": False}).encode("utf-8"),
            headers={**headers, "Content-Type": "application/json"},
        )
        with opener.open(request, timeout=18) as response:
            payload = json.loads(response.read().decode("utf-8", errors="ignore"))

        series_keys = {2: "pk1", 10: "pk3"}
        curve = {"url": f"https://data.snb.ch/en/topics/ziredev/chart/{chart_id}"}
        for maturity, series_key in series_keys.items():
            source = f"SNB Swiss Confederation Spot Rate {maturity}Y"
            points = []
            for row in (payload.get("data", {}) or {}).get("data", []):
                if not isinstance(row, list) or len(row) < 3 or str(row[1]) != series_key:
                    continue
                value = safe_float(row[2], None)
                if self.valid_bond_value(value):
                    points.append({"date": row[0], "yield": value})
            points = self.ensure_history_fresh(points, source)
            self.store_bond_history("CHF", maturity, points, source, curve["url"])
            curve[maturity] = float(points[-1]["yield"])
        self._snb_curve_cache = curve
        return curve

    def fetch_snb_yield(self, maturity=10):
        maturity = 2 if int(maturity) == 2 else 10
        try:
            curve = self.fetch_snb_current_curve()
            return (
                curve[maturity],
                f"SNB Swiss Confederation Spot Rate {maturity}Y",
                curve["url"],
            )
        except Exception as current_error:
            self.errors.append(f"SNB aktuelle Spotkurve {maturity}Y: {current_error}")

        # data-api.snb.ch liefert zeitweise Gateway Fehler. Die SNB dokumentiert
        # den historischen Altbestand weiterhin unter data.snb.ch. Er ist nur
        # eine technische Rückfallebene und muss den Frischetest bestehen.
        url = "https://data.snb.ch/api/cube/rendoblid/data/csv/en"
        text = self.decode_official_text(self.fetch_bytes(url, timeout=10))
        try:
            delimiter = csv.Sniffer().sniff(text[:8192], delimiters=",;\t").delimiter
        except Exception:
            delimiter = ";"
        target_code = "2J" if maturity == 2 else "10J0"
        points = []
        for row in csv.reader(io.StringIO(text), delimiter=delimiter):
            if len(row) < 3 or str(row[1]).strip().upper() != target_code:
                continue
            value = safe_float(row[2], None)
            if self.valid_bond_value(value):
                points.append({"date": row[0], "yield": value})
        source = f"SNB Swiss Confederation Spot Rate {maturity}Y"
        try:
            points = self.ensure_history_fresh(points, source)
            self.store_bond_history("CHF", maturity, points, source, url)
            return points[-1]["yield"], source, url
        except Exception:
            if maturity != 10:
                raise

        # Die tägliche 10Y Übersicht der SNB wird aktuell weitergeführt, auch wenn
        # der historische Renditecube zeitweise keinen frischen Stand liefert.
        # Sie verbessert die offizielle Abdeckung, ohne einen 2Y Wert zu erfinden.
        current_url = "https://www.snb.ch/en/the-snb/mandates-goals/statistics/statistics-pub/current_interest_exchange_rates"
        page = self.fetch_url(current_url, timeout=10)
        plain = html_lib.unescape(re.sub(r"<[^>]+>", " ", page))
        plain = re.sub(r"\s+", " ", plain)
        match = re.search(
            r"Yield on Swiss Confederation bonds\s+(-?\d+(?:\.\d+)?)\s*%\s+(\d{2}\.\d{2}\.\d{4})",
            plain,
            re.IGNORECASE,
        )
        if not match:
            raise RuntimeError("SNB aktuelle 10Y Übersicht enthält keinen eindeutigen Renditewert")
        value = safe_float(match.group(1), None)
        date_text = self.normalize_observation_date(match.group(2))
        current_source = "SNB Current Swiss Confederation Bond 10Y"
        current_points = self.ensure_history_fresh([{"date": date_text, "yield": value}], current_source)
        self.store_bond_history("CHF", 10, current_points, current_source, current_url)
        return current_points[-1]["yield"], current_source, current_url

    def fetch_boe_yield(self, maturity=10):
        """Bank of England, tägliche nominale Gilt Spotkurve."""
        maturity = 2 if int(maturity) == 2 else 10
        if self._boe_curve_cache is not None:
            value = self._boe_curve_cache[maturity]
            return value, f"Bank of England nominale Gilt Spotkurve {maturity}Y", self._boe_curve_cache["url"]

        url = "https://www.bankofengland.co.uk/-/media/boe/files/statistics/yield-curves/latest-yield-curve-data.zip"
        archive = self.fetch_bytes(url, timeout=15)
        with zipfile.ZipFile(io.BytesIO(archive), "r") as bundle:
            names = [name for name in bundle.namelist() if name.lower().endswith(".xlsx") and "nominal" in name.lower()]
            if not names:
                names = [name for name in bundle.namelist() if name.lower().endswith(".xlsx")]
            if not names:
                raise RuntimeError("Bank of England ZIP ohne XLSX Datei")
            workbook = bundle.read(names[0])
        curve = self.latest_boe_spot_curve(workbook)
        curve["url"] = url
        for term in (2, 10):
            source = f"Bank of England nominale Gilt Spotkurve {term}Y"
            points = self.ensure_history_fresh(curve.get("history", {}).get(term, []), source)
            self.store_bond_history("GBP", term, points, source, url)
        self._boe_curve_cache = curve
        value = curve[maturity]
        return value, f"Bank of England nominale Gilt Spotkurve {maturity}Y", url

    def fetch_boe_archive_history(self, maturity=10):
        """Lädt nur die aktuelle Arbeitsmappe aus dem offiziellen Tagesarchiv.

        Das normale BoE Monatsblatt kann am Monatsanfang erst einen einzigen
        Handelstag enthalten. Das Tagesarchiv ergänzt dann die vorherigen Monate,
        ohne dass das rund 39 MB große Gesamtarchiv vollständig geladen werden muss.
        """
        maturity = 2 if int(maturity) == 2 else 10
        if self._boe_archive_curve_cache is None:
            workbook, member_name = self.fetch_remote_zip_member(
                BOE_DAILY_ARCHIVE_URL,
                lambda name: (
                    str(name).lower().endswith(".xlsx") and
                    "glc nominal daily data" in str(name).lower() and
                    ("present" in str(name).lower() or "202" in str(name).lower())
                ),
                timeout=15,
            )
            curve = self.latest_boe_spot_curve(workbook)
            curve["url"] = BOE_DAILY_ARCHIVE_URL
            curve["member_name"] = member_name
            for term in (2, 10):
                source = f"Bank of England nominale Gilt Spotkurve {term}Y"
                points = self.ensure_history_fresh(curve.get("history", {}).get(term, []), source)
                if len(points) < YIELD_IMPULSE_MIN_HISTORY_POINTS:
                    raise RuntimeError(
                        f"Bank of England Tagesarchiv enthält für {term}Y weniger als "
                        f"{YIELD_IMPULSE_MIN_HISTORY_POINTS} Handelstage"
                    )
                self.store_bond_history(
                    "GBP", term, points, source,
                    f"{BOE_DAILY_ARCHIVE_URL}#{urllib.parse.quote(member_name)}",
                )
                curve["history"][term] = points
            self._boe_archive_curve_cache = curve
        source = f"Bank of England nominale Gilt Spotkurve {maturity}Y"
        points = list(self._boe_archive_curve_cache.get("history", {}).get(maturity, []))
        if len(points) < YIELD_IMPULSE_MIN_HISTORY_POINTS:
            raise RuntimeError(f"Bank of England Tageshistorie {maturity}Y ist unvollständig")
        return points, source, self._boe_archive_curve_cache.get("url", BOE_DAILY_ARCHIVE_URL)

    def latest_boe_spot_curve(self, raw, min_value=-2.0, max_value=25.0):
        """Liest 2Y und 10Y aus derselben nominalen Spotkurve und aus getrennten Spalten.

        Die Laufzeiten werden exakt abgeglichen. Dadurch kann die Ziffer 2 nicht mehr
        versehentlich ein Datum, einen anderen Zahlenwert oder die 10Y Spalte treffen.
        """
        with zipfile.ZipFile(io.BytesIO(raw), "r") as book:
            names = set(book.namelist())
            shared = []
            if "xl/sharedStrings.xml" in names:
                root = ET.fromstring(book.read("xl/sharedStrings.xml"))
                for item in root.findall("{*}si"):
                    shared.append("".join(node.text or "" for node in item.findall(".//{*}t")))

            rel_targets = {}
            rel_path = "xl/_rels/workbook.xml.rels"
            if rel_path in names:
                rel_root = ET.fromstring(book.read(rel_path))
                for rel in rel_root.findall("{*}Relationship"):
                    target = rel.attrib.get("Target", "").replace("\\", "/")
                    if target.startswith("/"):
                        target = target.lstrip("/")
                    elif not target.startswith("xl/"):
                        target = "xl/" + target.lstrip("./")
                    rel_targets[rel.attrib.get("Id", "")] = target

            sheets = []
            workbook_path = "xl/workbook.xml"
            if workbook_path in names:
                workbook_root = ET.fromstring(book.read(workbook_path))
                rel_key = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id"
                for sheet in workbook_root.findall(".//{*}sheet"):
                    target = rel_targets.get(sheet.attrib.get(rel_key, ""), "")
                    if target in names:
                        sheets.append((sheet.attrib.get("name", ""), target))
            if not sheets:
                sheets = [(name, name) for name in sorted(names) if re.match(r"xl/worksheets/sheet\d+\.xml$", name)]

            def sheet_rank(item):
                label = re.sub(r"\s+", " ", item[0].strip().lower())
                full_spot_curve = "spot curve" in label and "short end" not in label
                return (0 if full_spot_curve else 1,
                        1 if "short end" in label else 0,
                        1 if "forward" in label else 0,
                        1 if any(word in label for word in ("real", "inflation")) else 0)

            def cell_text(cell):
                value_node = cell.find("{*}v")
                inline = cell.find(".//{*}t")
                value = inline.text if inline is not None else (value_node.text if value_node is not None else "")
                if cell.attrib.get("t") == "s" and str(value).isdigit():
                    index = int(value)
                    value = shared[index] if index < len(shared) else ""
                return value

            def maturity_of(value):
                text = re.sub(r"\s+", "", str(value).strip().lower()).replace(",", ".")
                match = re.fullmatch(r"(2|10)(?:\.0+)?(?:y|yr|yrs|year|years)?", text)
                return int(match.group(1)) if match else None

            def is_excel_date(value):
                text = str(value or "").strip()
                numeric = safe_float(text, None)
                if numeric is not None and 20000 <= numeric <= 80000:
                    return True
                return bool(re.fullmatch(r"\d{4}-\d{2}-\d{2}(?:[T ][^ ]+)?", text))

            for sheet_label, sheet_path in sorted(sheets, key=sheet_rank):
                label = re.sub(r"\s+", " ", sheet_label.strip().lower())
                if ("spot curve" not in label or "short end" in label or
                        "forward" in label or "inflation" in label or "real" in label):
                    continue
                root = ET.fromstring(book.read(sheet_path))
                rows = []
                for row_node in root.findall(".//{*}row"):
                    row = {}
                    for cell in row_node.findall("{*}c"):
                        ref = cell.attrib.get("r", "A1")
                        letters = re.match(r"[A-Z]+", ref)
                        if not letters:
                            continue
                        column = 0
                        for char in letters.group(0):
                            column = column * 26 + ord(char) - 64
                        row[column - 1] = cell_text(cell)
                    if row:
                        rows.append(row)

                for header_no, row in enumerate(rows[:100]):
                    # Die BoE Datei enthält zusätzlich eine Monatszeile. Werte wie
                    # 2 und 10 bedeuten dort Monate und dürfen niemals als Renditen
                    # oder Jahreslaufzeiten interpretiert werden.
                    header_label = re.sub(r"\s+", "", str(row.get(0, "")).strip().lower())
                    if header_label not in ("years:", "years", "year:", "year"):
                        continue
                    columns = {}
                    for column, value in row.items():
                        detected = maturity_of(value)
                        if detected in (2, 10) and detected not in columns:
                            columns[detected] = column
                    if set(columns) != {2, 10} or columns[2] == columns[10]:
                        continue
                    latest = None
                    history = {2: [], 10: []}
                    for data_row in rows[header_no + 1:]:
                        raw_date = data_row.get(0, "")
                        if not is_excel_date(raw_date):
                            continue
                        date_text = self.normalize_observation_date(raw_date)
                        if not date_text:
                            continue
                        values = {}
                        for term in (2, 10):
                            raw_value = str(data_row.get(columns[term], "")).strip().replace("%", "").replace("\u2212", "-")
                            if raw_value.count(",") == 1 and "." not in raw_value:
                                raw_value = raw_value.replace(",", ".")
                            value = safe_float(raw_value, None)
                            if value is not None and min_value <= value <= max_value:
                                values[term] = float(value)
                        if set(values) == {2, 10}:
                            latest = values
                            for term in (2, 10):
                                history[term].append({"date": date_text, "yield": values[term]})
                    if latest is not None:
                        latest["history"] = history
                        return latest
        raise RuntimeError("Bank of England Spotkurve enthält keine getrennten 2Y und 10Y Spalten")

    def fetch_rbnz_bond_history(self, maturity=10):
        """Lädt die vollständige offizielle B2 Tageshistorie der RBNZ.

        Die sichtbare RBNZ Tabelle enthält nur die jüngsten Beobachtungen. Für
        den 20 Handelstage Impuls wird deshalb ausdrücklich die veröffentlichte
        B2 Arbeitsmappe geladen. Beide offiziellen Hostvarianten werden genutzt,
        da deren Zertifikatsketten regional unterschiedlich ausgeliefert werden.
        """
        maturity = 2 if int(maturity) == 2 else 10
        source = f"Reserve Bank of New Zealand Government Bond {maturity}Y"
        page_url = "https://www.rbnz.govt.nz/statistics/series/exchange-and-interest-rates/wholesale-interest-rates"
        urls = (
            "https://www.rbnz.govt.nz/-/media/project/sites/rbnz/files/statistics/series/b/b2/hb2-daily-close.xlsx",
            "https://rbnz.govt.nz/-/media/project/sites/rbnz/files/statistics/series/b/b2/hb2-daily-close.xlsx",
        )
        tokens = (
            f"governmentbond{maturity}year", f"{maturity}yeargovernmentbond",
            f"govt{maturity}y", f"government{maturity}year", f"{maturity}year",
        )
        errors = []
        for url in urls:
            try:
                raw = self.fetch_bytes(url, timeout=18, extra_headers={
                    "Referer": page_url,
                    "Accept": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,*/*",
                })
                points = self.ensure_history_fresh(self.history_from_xlsx(raw, tokens), source)
                if len(points) < YIELD_IMPULSE_MIN_HISTORY_POINTS:
                    raise RuntimeError(
                        f"RBNZ B2 enthält weniger als {YIELD_IMPULSE_MIN_HISTORY_POINTS} Handelstage"
                    )
                self.store_bond_history("NZD", maturity, points, source, url)
                return points, source, url
            except Exception as exc:
                errors.append(str(exc))
        raise RuntimeError("RBNZ B2 Tageshistorie derzeit nicht erreichbar: " + " | ".join(errors[-2:]))

    def fetch_rbnz_yield(self, maturity=10):
        maturity = 2 if int(maturity) == 2 else 10
        source = f"Reserve Bank of New Zealand Government Bond {maturity}Y"
        page_url = "https://www.rbnz.govt.nz/statistics/series/exchange-and-interest-rates/wholesale-interest-rates"
        errors = []

        # Die öffentliche B2 Seite enthält eine aktuelle Tagestabelle. Sie ist der
        # bevorzugte Weg, weil der separate Excel Download regional mit 403 blockiert
        # werden kann.
        try:
            page = self.fetch_url(page_url, timeout=12)
            points = []
            for table_row in re.findall(r"<tr[^>]*>(.*?)</tr>", page, re.IGNORECASE | re.DOTALL):
                cells = []
                for cell in re.findall(r"<t[dh][^>]*>(.*?)</t[dh]>", table_row, re.IGNORECASE | re.DOTALL):
                    clean = html_lib.unescape(re.sub(r"<[^>]+>", " ", cell))
                    cells.append(re.sub(r"\s+", " ", clean).strip())
                value_index = 9 if maturity == 2 else 11
                if len(cells) <= value_index:
                    continue
                date_text = self.normalize_observation_date(cells[0])
                value = safe_float(cells[value_index], None)
                if date_text and self.valid_bond_value(value):
                    points.append({"date": date_text, "yield": value})
            points = self.ensure_history_fresh(points, source)
            self.store_bond_history("NZD", maturity, points, source, page_url)
            return points[-1]["yield"], source, page_url
        except Exception as exc:
            errors.append(str(exc))

        # Zweiter offizieller Weg: die vollständige veröffentlichte B2 Datei.
        try:
            points, source, url = self.fetch_rbnz_bond_history(maturity)
            return points[-1]["yield"], source, url
        except Exception as exc:
            errors.append(str(exc))
        raise RuntimeError("RBNZ Primärwege derzeit nicht erreichbar: " + " | ".join(errors[-2:]))

    def official_bond_sources(self, currency, maturity):
        providers = {
            "USD": self.fetch_us_treasury_yield,
            "EUR": self.fetch_ecb_yield,
            "GBP": self.fetch_boe_yield,
            "JPY": self.fetch_mof_japan_yield,
            "CHF": self.fetch_snb_yield,
            "CAD": self.fetch_bank_of_canada_yield,
            "AUD": self.fetch_rba_yield,
            "NZD": self.fetch_rbnz_yield,
        }
        provider = providers.get(currency)
        return [lambda p=provider, m=maturity: p(m)] if provider else []

    def cache_path(self, name):
        safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", name)
        return self.cache_dir / safe

    def load_cached_json(self, path, max_age_hours=24):
        try:
            if path.exists() and (time.time() - path.stat().st_mtime) <= max_age_hours * 3600:
                return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return None
        return None

    def save_cached_json(self, path, payload):
        try:
            path.write_text(json.dumps(sanitize_audit_payload(payload), indent=2, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass

    def parse_percent_candidates(self, html, maturity=10):
        """Extrahiert plausible Renditen und priorisiert die gewünschte Laufzeit."""
        text = re.sub(r"<[^>]+>", " ", html)
        text = re.sub(r"\s+", " ", text)
        candidates = []
        maturity = int(maturity)
        maturity_tokens = (f"{maturity} year", f"{maturity}-year", f"{maturity}y", f"{maturity} yr")
        for m in re.finditer(r"(-?\d{1,2}[\.,]\d{1,4})\s*%?", text):
            value = safe_float(m.group(1).replace(",", "."), None)
            if value is None or not (-2.0 <= value <= 25.0):
                continue
            start = max(0, m.start() - 150)
            end = min(len(text), m.end() + 150)
            context = text[start:end].lower()
            weight = 0
            if any(token in context for token in maturity_tokens):
                weight += 8
            if maturity == 10 and ("government bond yield" in context or "10y" in context):
                weight += 4
            if maturity == 2 and ("2 year note" in context or "2y" in context or "schatz" in context):
                weight += 4
            if "bond" in context or "government" in context or "yield" in context:
                weight += 3
            if "last" in context or "current" in context or "actual" in context or "traded at" in context:
                weight += 2
            candidates.append((weight, value, context[:200]))
        candidates.sort(key=lambda x: x[0], reverse=True)
        return candidates

    def fetch_tradingeconomics_bond_api_rows(self, maturity=10):
        """Lädt die Bond Liste für 2Y oder 10Y höchstens einmal pro Analyse."""
        maturity = 2 if int(maturity) == 2 else 10
        key = f"{maturity}Y"
        url = f"https://api.tradingeconomics.com/markets/bond?c=guest:guest&type={key}"
        with self._bond_api_lock:
            if key in self._bond_api_rows:
                return self._bond_api_rows[key], url
            if key in self._bond_api_errors:
                raise RuntimeError(self._bond_api_errors[key])
            cache = self.cache_path(f"bond_tradingeconomics_{maturity}y_all.json")
            cached = self.load_cached_json(cache, 6)
            if isinstance(cached, list) and cached:
                self._bond_api_rows[key] = cached
                return cached, url
            try:
                raw = self.fetch_url(url, timeout=8)
                data = json.loads(raw)
                if isinstance(data, dict):
                    data = data.get("data", []) or data.get("markets", []) or data.get("Bonds", []) or []
                if not isinstance(data, list):
                    raise RuntimeError("Unerwartetes Bond API Format")
                self._bond_api_rows[key] = data
                if data:
                    self.save_cached_json(cache, data)
                return data, url
            except Exception as exc:
                self._bond_api_errors[key] = str(exc)
                raise

    def fetch_tradingeconomics_bond_api_yield(self, currency, maturity=10):
        target_country = BOND_COUNTRY_NAMES.get(currency, "").lower()
        if not target_country:
            raise RuntimeError(f"Keine Bond Quelle für {currency}")
        maturity = 2 if int(maturity) == 2 else 10
        data, url = self.fetch_tradingeconomics_bond_api_rows(maturity)
        matches = []
        for row in data:
            if not isinstance(row, dict):
                continue
            text = " ".join(str(row.get(k, "")) for k in ("Country", "country", "Name", "name", "Symbol", "symbol", "Ticker", "ticker")).lower()
            if target_country not in text:
                continue
            compact = re.sub(r"\s+", "", text)
            maturity_ok = bool(re.search(
                rf"(?<!\d){maturity}(?:y|yr|yrs|year|years)(?!\d)", compact
            ))
            if not maturity_ok:
                continue
            value = None
            for field in ("Last", "last", "Price", "price", "Close", "close", "Value", "value"):
                if row.get(field) is not None:
                    value = safe_float(row.get(field), None)
                    if value is not None:
                        break
            if value is not None and -2.0 <= value <= 25.0:
                matches.append(value)
        if not matches:
            raise RuntimeError(f"Kein passender {maturity}Y Bond Wert in API")
        return matches[0], f"TradingEconomics Bond API {maturity}Y", url

    def fetch_tradingeconomics_yield(self, currency, maturity=10):
        slug = BOND_COUNTRY_SLUGS.get(currency)
        if not slug:
            raise RuntimeError(f"Keine Bond Quelle für {currency}")
        maturity = 2 if int(maturity) == 2 else 10
        suffix = "2-year-note-yield" if maturity == 2 else "government-bond-yield"
        url = f"https://tradingeconomics.com/{slug}/{suffix}"
        html = self.fetch_url(url)
        candidates = self.parse_percent_candidates(html, maturity)
        if not candidates or candidates[0][0] < 5:
            raise RuntimeError(f"Keine belastbare {maturity}Y Rendite gefunden")
        return candidates[0][1], f"TradingEconomics {maturity}Y", url

    def fetch_worldgovernmentbonds_yield(self, currency):
        slug = BOND_COUNTRY_SLUGS.get(currency)
        if not slug:
            raise RuntimeError(f"Keine Bond Quelle für {currency}")
        url = f"https://www.worldgovernmentbonds.com/country/{slug}/"
        html = self.fetch_url(url)
        candidates = self.parse_percent_candidates(html, 10)
        if not candidates:
            raise RuntimeError("Keine Prozentwerte gefunden")
        return candidates[0][1], "WorldGovernmentBonds 10Y", url

    def fetch_yahoo_us10y(self):
        url = "https://query1.finance.yahoo.com/v8/finance/chart/%5ETNX?range=5d&interval=1d"
        raw = self.fetch_url(url)
        data = json.loads(raw)
        result = data.get("chart", {}).get("result", [{}])[0]
        closes = result.get("indicators", {}).get("quote", [{}])[0].get("close", [])
        values = [safe_float(x, None) for x in closes if x is not None]
        if not values:
            raise RuntimeError("Yahoo ^TNX ohne Close")
        value = values[-1]
        if value > 20:
            value = value / 10.0
        return value, "Yahoo Finance ^TNX 10Y", url

    def get_yield(self, currency, maturity=10):
        currency = currency.upper()
        maturity = 2 if int(maturity) == 2 else 10
        memory_key = f"{currency}_{maturity}Y"
        if memory_key in self.yields:
            return self.yields[memory_key]
        cache = self.cache_path(f"bond_{currency}_{maturity}y.json")
        cached = self.load_cached_json(cache, BOND_OFFICIAL_CACHE_HOURS)
        if cached and not self.is_official_bond_source(cached.get("source")):
            try:
                cache_age_hours = (time.time() - cache.stat().st_mtime) / 3600.0
            except Exception:
                cache_age_hours = BOND_RESERVE_CACHE_HOURS + 1
            if cache_age_hours > BOND_RESERVE_CACHE_HOURS:
                cached = None
        if (cached and cached.get("schema_version") == BOND_CACHE_SCHEMA_VERSION and
                cached.get("currency") == currency and cached.get("maturity") == maturity and
                self.valid_bond_value(cached.get("yield"))):
            self.yields[memory_key] = cached
            return cached
        negative_cache = self.cache_path(f"bond_{currency}_{maturity}y_unavailable.json")
        negative = self.load_cached_json(negative_cache, 0.25)
        if (isinstance(negative, dict) and
                negative.get("schema_version") == BOND_CACHE_SCHEMA_VERSION and
                negative.get("currency") == currency and negative.get("maturity") == maturity and
                negative.get("yield") is None):
            self.yields[memory_key] = negative
            return negative
        # Offizielle, kostenfreie Primärquelle der jeweiligen Institution zuerst.
        # Bestehende Quellen bleiben ausschließlich als Ausfallsicherung erhalten.
        sources = self.official_bond_sources(currency, maturity)
        if currency == "NZD":
            sources.append(lambda c=currency, m=maturity: self.fetch_marketwatch_bond_yield(c, m))
        sources.append(lambda c=currency, m=maturity: self.fetch_tradingeconomics_bond_api_yield(c, m))
        if maturity == 10 and currency == "USD":
            sources.append(self.fetch_yahoo_us10y)
        sources.append(lambda c=currency, m=maturity: self.fetch_tradingeconomics_yield(c, m))
        if maturity == 10:
            sources.append(lambda c=currency: self.fetch_worldgovernmentbonds_yield(c))
        last_err = None
        attempts = []
        for fn in sources:
            try:
                value, source, url = fn()
                if not self.valid_bond_value(value):
                    raise RuntimeError(f"Unplausibler Renditewert {value!r}")
                attempts.append({"source": source, "status": "OK", "value": round(float(value), 3)})
                observation_date = self.latest_history_observation(currency, maturity, source) or self.fallback_market_date()
                payload = {
                    "schema_version": BOND_CACHE_SCHEMA_VERSION,
                    "currency": currency, "maturity": maturity, "yield": round(float(value), 3),
                    "source": source, "url": url, "fetched_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                    "observation_date": observation_date,
                    "attempts": attempts,
                }
                self.save_cached_json(cache, payload)
                self.load_bond_history(currency, maturity, payload)
                try:
                    negative_cache.unlink(missing_ok=True)
                except Exception:
                    pass
                self.yields[memory_key] = payload
                self.bond_audits.append({"currency": currency, "maturity": maturity, "status": "OK", "source": source, "yield": payload["yield"], "attempts": attempts})
                return payload
            except Exception as exc:
                last_err = exc
                name = getattr(fn, "__name__", "Quelle")
                attempts.append({"source": name, "status": "FEHLER", "error": str(exc)[:180]})
                self.errors.append(f"Bond Quelle {currency} {maturity}Y: {exc}")
        self.bond_audits.append({"currency": currency, "maturity": maturity, "status": "FEHLER", "attempts": attempts})
        payload = {"schema_version": BOND_CACHE_SCHEMA_VERSION, "currency": currency, "maturity": maturity, "yield": None, "source": "nicht verfügbar", "url": "", "error": str(last_err) if last_err else "unbekannt", "attempts": attempts, "fetched_at": time.strftime("%Y-%m-%d %H:%M:%S")}
        self.save_cached_json(negative_cache, payload)
        self.yields[memory_key] = payload
        return payload

    def valid_bond_value(self, value):
        """Letzte Schranke gegen leere, nicht endliche oder unmögliche Renditewerte."""
        parsed = safe_float(value, None)
        return parsed is not None and math.isfinite(parsed) and -5.0 <= parsed <= 25.0

    def spread_supports_direction(self, pair, direction, spread):
        if abs(spread) < 0.08:
            return "NEUTRAL"
        favours_base = spread > 0
        if direction == "LONG":
            return "SUPPORT" if favours_base else "HEADWIND"
        return "SUPPORT" if not favours_base else "HEADWIND"

    def macro_score(self, spread, support_state):
        """Sanfte kontinuierliche Bewertung, bewusst auf 20 bis 80 begrenzt."""
        abs_spread = abs(safe_float(spread, 0))
        if abs_spread < 0.08 or support_state == "NEUTRAL":
            return 50.0
        magnitude = 30.0 * math.tanh(max(0.0, abs_spread - 0.08) / 0.65)
        if support_state == "SUPPORT":
            return round(clamp(50.0 + magnitude, 20, 80), 1)
        if support_state == "HEADWIND":
            return round(clamp(50.0 - magnitude, 20, 80), 1)
        return 50.0

    def curve_score(self, curve_spread, support_state):
        """Moderater Yield-Curve-Impuls. Die Kurve ergänzt, dominiert aber nie 2Y/10Y."""
        abs_spread = abs(safe_float(curve_spread, 0))
        if abs_spread < 0.05 or support_state == "NEUTRAL":
            return 50.0
        magnitude = 15.0 * math.tanh(max(0.0, abs_spread - 0.05) / 0.55)
        if support_state == "SUPPORT":
            return round(clamp(50.0 + magnitude, 35, 65), 1)
        if support_state == "HEADWIND":
            return round(clamp(50.0 - magnitude, 35, 65), 1)
        return 50.0

    def fetch_marketwatch_bond_history(self, currency, maturity):
        """Sekundäre Tageshistorie und technische NZD Reserve nach der RBNZ."""
        currency = str(currency or "").upper()
        maturity = 2 if int(maturity) == 2 else 10
        ticker = (MARKETWATCH_BOND_TICKERS.get(currency) or {}).get(maturity)
        if not ticker:
            raise RuntimeError(f"Keine sekundäre Impulshistorie für {currency} {maturity}Y")

        end_date = datetime.now().date() + timedelta(days=1)
        start_date = end_date - timedelta(days=85)
        query = urllib.parse.urlencode({
            "startdate": start_date.strftime("%m/%d/%Y 00:00:00"),
            "enddate": end_date.strftime("%m/%d/%Y 23:59:59"),
            "daterange": "d90",
            "frequency": "p1d",
            "csvdownload": "true",
            "downloadpartial": "false",
            "newdates": "false",
            "countrycode": "bx",
        })
        url = f"https://www.marketwatch.com/investing/bond/{ticker}/downloaddatapartial?{query}"
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/138.0.0.0 Safari/537.36",
            "Accept": "text/csv,*/*;q=0.8",
            "Referer": f"https://www.marketwatch.com/investing/bond/{ticker}/download-data?countrycode=bx",
        }
        text = self.fetch_bytes(url, timeout=18, extra_headers=headers).decode("utf-8-sig", errors="ignore")
        points = []
        for row in csv.DictReader(io.StringIO(text)):
            raw_value = str(row.get("Close") or "").replace("%", "").replace(",", "").strip()
            value = safe_float(raw_value, None)
            date_text = self.normalize_observation_date(row.get("Date"))
            if date_text and self.valid_bond_value(value):
                points.append({"date": date_text, "yield": value})
        source = f"MarketWatch Bondhistorie {currency} {maturity}Y"
        points = self.ensure_history_fresh(points, source)
        if len(points) < YIELD_IMPULSE_MIN_HISTORY_POINTS:
            raise RuntimeError(
                f"{source} enthält weniger als {YIELD_IMPULSE_MIN_HISTORY_POINTS} Handelstage"
            )
        self.store_bond_history(currency, maturity, points, source, url)
        return points, source

    def fetch_marketwatch_bond_yield(self, currency, maturity):
        """Technische NZD Reserve, deren Tageswert und Historie zusammenpassen."""
        points, source = self.fetch_marketwatch_bond_history(currency, maturity)
        ticker = (MARKETWATCH_BOND_TICKERS.get(str(currency or "").upper()) or {}).get(
            2 if int(maturity) == 2 else 10
        )
        url = f"https://www.marketwatch.com/investing/bond/{ticker}" if ticker else ""
        return float(points[-1]["yield"]), source, url

    def history_for_impulse(self, currency, maturity, current_payload):
        """Wählt die beste frische Historie unabhängig von der heutigen Levelquelle.

        Dadurch kann ein offizieller oder reservierter Tageswert mit einer separaten
        konsistenten Zeitreihe kombiniert werden. Verglichen werden ausschließlich
        Veränderungen innerhalb derselben Historienquelle, niemals absolute Niveaus
        aus zwei verschiedenen Anbietern.
        """
        currency = str(currency or "").upper()
        maturity = 2 if int(maturity) == 2 else 10
        key = (currency, maturity)
        if key in self._impulse_history_cache:
            return list(self._impulse_history_cache[key])

        history = self.load_bond_history(currency, maturity, current_payload)
        current_source = str((current_payload or {}).get("source") or "")

        def grouped_candidates(payload):
            groups = {}
            for point in payload.get("points", []):
                source = str(point.get("source") or "")
                groups.setdefault(source, []).append(point)
            candidates = []
            for source, raw_points in groups.items():
                points = self.normalize_history_points(raw_points, source)
                if not points:
                    continue
                try:
                    latest = datetime.strptime(points[-1]["date"], "%Y-%m-%d").date()
                    fresh = (datetime.now().date() - latest).days <= 10
                except Exception:
                    fresh = False
                if not fresh:
                    continue
                priority = (
                    1 if source == current_source else 0,
                    1 if self.is_official_bond_source(source) else 0,
                    len(points),
                )
                candidates.append((priority, source, points))
            return sorted(candidates, key=lambda item: item[0], reverse=True)

        candidates = grouped_candidates(history)
        complete = next(
            (item for item in candidates if len(item[2]) >= YIELD_IMPULSE_MIN_HISTORY_POINTS),
            None,
        )
        history_errors = []
        if complete is None and currency == "GBP":
            try:
                self.fetch_boe_archive_history(maturity)
            except Exception as exc:
                history_errors.append("Bank of England Tagesarchiv: " + str(exc))
            history = self.load_bond_history(currency, maturity)
            candidates = grouped_candidates(history)
            complete = next(
                (item for item in candidates if len(item[2]) >= YIELD_IMPULSE_MIN_HISTORY_POINTS),
                None,
            )

        if complete is None and currency == "NZD":
            try:
                self.fetch_rbnz_bond_history(maturity)
            except Exception as exc:
                history_errors.append("RBNZ: " + str(exc))
            history = self.load_bond_history(currency, maturity)
            candidates = grouped_candidates(history)
            complete = next(
                (item for item in candidates if len(item[2]) >= YIELD_IMPULSE_MIN_HISTORY_POINTS),
                None,
            )

        if complete is None:
            try:
                self.fetch_marketwatch_bond_history(currency, maturity)
            except Exception as exc:
                self.errors.append(f"Impulshistorie {currency} {maturity}Y: {exc}")
                history_errors.append("Reserve: " + str(exc))
            history = self.load_bond_history(currency, maturity)
            candidates = grouped_candidates(history)
            complete = next(
                (item for item in candidates if len(item[2]) >= YIELD_IMPULSE_MIN_HISTORY_POINTS),
                None,
            )

        if history_errors and complete is None:
            self._impulse_history_errors[key] = " | ".join(history_errors)[:1200]
        else:
            self._impulse_history_errors.pop(key, None)

        selected = complete or (candidates[0] if candidates else None)
        points = list(selected[2]) if selected else []
        source = selected[1] if selected else "nicht verfügbar"
        self._impulse_history_cache[key] = points
        self._impulse_history_sources[key] = source
        return list(points)

    def history_for_current_source(self, currency, maturity, current_payload):
        """Kompatibilitätsalias für bestehende Tests und ältere Audit Aufrufer."""
        return self.history_for_impulse(currency, maturity, current_payload)

    def spread_history(self, base_points, quote_points):
        base_by_date = {point["date"]: point["yield"] for point in base_points}
        quote_by_date = {point["date"]: point["yield"] for point in quote_points}
        common_dates = sorted(set(base_by_date).intersection(quote_by_date))
        return [{
            "date": date_text,
            "spread": round(base_by_date[date_text] - quote_by_date[date_text], 6),
        } for date_text in common_dates]

    def impulse_horizon_change(self, series, trading_days):
        if len(series) < int(trading_days) + 1:
            return None
        return round(series[-1]["spread"] - series[-int(trading_days) - 1]["spread"], 6)

    def impulse_score(self, directional_change):
        """Sanfter Impulsscore mit kleiner Neutralzone und gedeckelter Wirkung."""
        change = safe_float(directional_change, 0.0)
        if abs(change) < 0.03:
            return 50.0
        magnitude = 30.0 * math.tanh(max(0.0, abs(change) - 0.03) / 0.22)
        return round(clamp(50.0 + magnitude if change > 0 else 50.0 - magnitude, 20.0, 80.0), 1)

    def calculate_yield_impulse(self, pair, direction, histories):
        """Misst die Veränderung des relativen 2Y und 10Y Renditevorteils.

        2Y erhält innerhalb des Impulses 70 Prozent, 10Y 30 Prozent.
        Fünf Handelstage erhalten 70 Prozent, zwanzig Handelstage 30 Prozent.
        Fehlende Horizonte werden neutral übersprungen und nie geschätzt.
        """
        maturity_weights = {2: 70.0, 10: 30.0}
        horizon_weights = {YIELD_IMPULSE_SHORT_DAYS: 70.0, YIELD_IMPULSE_LONG_DAYS: 30.0}
        changes = {}
        weighted_parts = []
        horizon_totals = {}
        horizon_weights_available = {}
        latest_dates = []
        for maturity, maturity_weight in maturity_weights.items():
            base_points, quote_points = histories.get(maturity, ([], []))
            series = self.spread_history(base_points, quote_points)
            if series:
                latest_dates.append(series[-1]["date"])
            changes[maturity] = {}
            for horizon, horizon_weight in horizon_weights.items():
                change = self.impulse_horizon_change(series, horizon)
                changes[maturity][horizon] = change
                if change is None:
                    continue
                combined_weight = maturity_weight * horizon_weight
                weighted_parts.append((change, combined_weight))
                horizon_totals[horizon] = horizon_totals.get(horizon, 0.0) + change * maturity_weight
                horizon_weights_available[horizon] = horizon_weights_available.get(horizon, 0.0) + maturity_weight

        direction_factor = 1.0 if str(direction).upper() == "LONG" else -1.0
        if weighted_parts:
            raw_change = sum(value * weight for value, weight in weighted_parts) / sum(weight for _, weight in weighted_parts)
            directional_change = raw_change * direction_factor
            score = self.impulse_score(directional_change)
            # Die visuelle Aussage folgt dem tatsächlich wirksamen Score. Kleine
            # Bewegungen knapp außerhalb der mathematischen Neutralzone werden
            # nicht mehr vorschnell als klar grün oder rot bezeichnet.
            state = "SUPPORT" if score >= 52.0 else "HEADWIND" if score <= 48.0 else "NEUTRAL"
            if score >= 56.0:
                label = "VERBESSERT SICH"
            elif score >= 52.0:
                label = "LEICHT VERBESSERT"
            elif score <= 44.0:
                label = "SCHWÄCHT SICH AB"
            elif score <= 48.0:
                label = "LEICHT SCHWÄCHER"
            else:
                label = "STABIL"
            available = True
        else:
            raw_change = 0.0
            directional_change = 0.0
            score = 50.0
            state = "NEUTRAL"
            label = "HISTORIE BAUT SICH AUF"
            available = False

        horizon_changes = {}
        for horizon in horizon_weights:
            total_weight = horizon_weights_available.get(horizon, 0.0)
            horizon_changes[horizon] = round(
                (horizon_totals[horizon] / total_weight) * direction_factor, 6
            ) if total_weight else None

        if state == "SUPPORT":
            interpretation = "Der relative Renditevorteil entwickelt sich zugunsten des Analyzer Bias."
        elif state == "HEADWIND":
            interpretation = "Der relative Renditevorteil schwächt sich entgegen dem Analyzer Bias ab."
        elif available:
            interpretation = "Der relative Renditevorteil verändert sich derzeit nur geringfügig."
        else:
            interpretation = "Für einen belastbaren Zinsimpuls liegt noch keine ausreichende gemeinsame Historie vor."

        return {
            "available": available,
            "pair": pair,
            "direction": direction,
            "score": score,
            "state": state,
            "label": label,
            "raw_change": round(raw_change, 6),
            "directional_change": round(directional_change, 6),
            "change_5d": horizon_changes.get(YIELD_IMPULSE_SHORT_DAYS),
            "change_20d": horizon_changes.get(YIELD_IMPULSE_LONG_DAYS),
            "component_changes": changes,
            "latest_date": min(latest_dates) if latest_dates else "",
            "interpretation": interpretation,
        }

    def combine_maturity_scores(self, score_2y, score_10y, score_curve=50.0, score_impulse=50.0,
                                available_2y=True, available_10y=True, available_curve=True,
                                available_impulse=False):
        """Feste Gewichte. Nicht verfügbare Bausteine tragen neutral 50 bei."""
        parts = [
            (safe_float(score_2y, 50) if available_2y else 50.0, 35.0),
            (safe_float(score_10y, 50) if available_10y else 50.0, 20.0),
            (safe_float(score_curve, 50) if available_curve else 50.0, 15.0),
            (safe_float(score_impulse, 50) if available_impulse else 50.0, YIELD_IMPULSE_WEIGHT),
        ]
        total = sum(weight for _, weight in parts)
        return round(sum(score * weight for score, weight in parts) / total, 1)

    def macro_label(self, state, score):
        if score >= 68:
            return "stark unterstützend"
        if score >= 56:
            return "unterstützend"
        if score <= 32:
            return "deutlicher Gegenwind"
        if score <= 44:
            return "Gegenwind"
        return "neutral"

    def event_risk_penalty(self, event_risk):
        if event_risk == "sehr hoch":
            return 4.0
        if event_risk == "erhöht":
            return 2.5
        if event_risk == "beobachten":
            return 1.0
        return 0.0

    def expected_volatility_score(self, event_risk):
        if event_risk == "sehr hoch":
            return 8
        if event_risk == "erhöht":
            return 6
        if event_risk == "beobachten":
            return 3
        return 1

    def final_quality_score(self, season_row, macro_row):
        cot = safe_float(season_row.get("cot_confidence", season_row.get("confidence", 50)), 50)
        season = safe_float(season_row.get("seasonality_score", 50), 50)
        macro = safe_float(macro_row.get("macro_score", 50), 50) if macro_row else 50
        penalty = safe_float(macro_row.get("event_penalty", 0), 0) if macro_row else 0
        return final_watchlist_quality_breakdown(cot, season, macro, penalty)["final_quality"]

    def interpret_bond(self, pair, direction, two, ten, curve, impulse, score):
        available = [x for x in (two, ten) if x and x.get("available")]
        if not available:
            return "2Y und 10Y Bonddaten konnten nicht zuverlässig geladen werden. Die Makro Prüfung bleibt neutral."
        details = []
        for item in available:
            fav = item["base"] if item["spread"] > 0 else item["quote"] if item["spread"] < 0 else "keine Seite"
            label = "Kurzfristige Zinserwartung" if item["maturity"] == 2 else "Langfristiger Renditevorteil"
            details.append(f"{label}: {item['spread']:+.2f} PP, Vorteil {fav}")
        if curve and curve.get("available"):
            curve_fav = curve["base"] if curve["spread"] > 0 else curve["quote"] if curve["spread"] < 0 else "keine Seite"
            details.append(f"Yield Curve: {curve['spread']:+.2f} PP, Vorteil {curve_fav}")
        if impulse:
            details.append(f"Zinsimpuls: {impulse.get('interpretation')}")
        if score >= 56:
            conclusion = "Makro Urteil: Die kombinierte Zinsstruktur unterstützt das Setup."
        elif score <= 44:
            conclusion = "Makro Urteil: Die kombinierte Zinsstruktur liefert Gegenwind, ohne das COT Signal allein aufzuheben."
        else:
            conclusion = "Makro Urteil: Die kombinierte Zinsstruktur ist weitgehend neutral."
        return "; ".join(details) + ". " + conclusion

    def fetch_tradingeconomics_events_for_country(self, country, start_date, end_date):
        # TradingEconomics liefert je nach Endpoint entweder alle Termine oder nur gefilterte Treffer.
        # Deshalb werden mehrere dokumentierte bzw. in der Praxis übliche Varianten versucht.
        q_country = urllib.request.quote(country)
        d1 = start_date.strftime("%Y-%m-%d")
        d2 = end_date.strftime("%Y-%m-%d")
        urls = [
            f"https://api.tradingeconomics.com/calendar/country/{q_country}/{d1}/{d2}?c=guest:guest",
            f"https://api.tradingeconomics.com/calendar/country/{q_country}?d1={d1}&d2={d2}&c=guest:guest",
            f"https://api.tradingeconomics.com/calendar/country/{q_country}?importance=3&d1={d1}&d2={d2}&c=guest:guest",
            f"https://api.tradingeconomics.com/calendar?country={q_country}&d1={d1}&d2={d2}&c=guest:guest",
        ]
        # Varianten sind Fallbacks, keine Quellen, die alle vollständig abgefragt werden müssen.
        # Sobald eine Variante valide Daten liefert, wird direkt zurückgegeben.
        for url in urls:
            try:
                raw = self.fetch_url(url, timeout=8)
                data = json.loads(raw)
                if isinstance(data, dict):
                    data = data.get("Calendar", []) or data.get("data", []) or data.get("events", []) or []
                if isinstance(data, list) and data:
                    events = []
                    for ev in data:
                        if isinstance(ev, dict):
                            ev = dict(ev)
                            ev.setdefault("_source", "TradingEconomics")
                            events.append(ev)
                    if events:
                        return events
            except Exception as exc:
                self.errors.append(f"Event Quelle TradingEconomics {country}: {exc}")
        return []

    def fetch_forexfactory_events(self, start_date, end_date):
        # ForexFactory stellt frei abrufbare Wochen CSVs bereit. Das ist als Fallback sehr nützlich,
        # weil dort Impact und Währung bereits sauber strukturiert sind.
        memory_key = (start_date.date().isoformat(), end_date.date().isoformat())
        if memory_key in self._forexfactory_cache:
            return self._forexfactory_cache[memory_key]
        with self._forexfactory_lock:
            # Mehrere parallel vorbereitete Währungen benötigen dieselben zwei
            # Kalenderdateien. Innerhalb der Sperre wird nochmals geprüft, damit
            # exakt ein Netzabruf erfolgt und alle anderen Aufgaben den Cache nutzen.
            if memory_key in self._forexfactory_cache:
                return self._forexfactory_cache[memory_key]
            cache = self.cache_path(f"events_forexfactory_{start_date:%Y%m%d}_{end_date:%Y%m%d}.json")
            cached = self.load_cached_json(cache, 6)
            if cached is not None:
                self._forexfactory_cache[memory_key] = cached
                return cached
            urls = [
                "https://nfs.faireconomy.media/ff_calendar_thisweek.csv",
                "https://nfs.faireconomy.media/ff_calendar_nextweek.csv",
            ]
            rows = []
            for url in urls:
                try:
                    raw = self.fetch_url(url, timeout=8)
                    reader = csv.DictReader(io.StringIO(raw))
                    for row in reader:
                        if not isinstance(row, dict):
                            continue
                        ev = {
                            "Event": row.get("Title") or row.get("Event") or "Wirtschaftstermin",
                            "Country": row.get("Country") or row.get("Currency") or "",
                            "Currency": row.get("Country") or row.get("Currency") or "",
                            "Date": row.get("Date") or row.get("date") or "",
                            "Time": row.get("Time") or row.get("time") or "",
                            "Importance": row.get("Impact") or row.get("impact") or "",
                            "_source": "ForexFactory CSV",
                        }
                        dt = self.event_date(ev)
                        if dt is None or (start_date.date() <= dt.date() <= end_date.date()):
                            rows.append(ev)
                except Exception as exc:
                    self.errors.append(f"Event Quelle ForexFactory: {exc}")
            self.save_cached_json(cache, rows)
            self._forexfactory_cache[memory_key] = rows
            return rows

    def fetch_events_for_country(self, country, start_date, end_date):
        memory_key = (country, start_date.date().isoformat(), end_date.date().isoformat())
        if memory_key in self._event_cache:
            return self._event_cache[memory_key]
        cache = self.cache_path(f"events_{country.replace(' ', '_')}_{start_date:%Y%m%d}_{end_date:%Y%m%d}.json")
        cached = self.load_cached_json(cache, 6)
        if cached is not None:
            self._event_cache[memory_key] = cached
            return cached

        # Die beiden gemeinsamen Wochenkalender werden pro Analyse exakt einmal
        # geladen und enthalten im Kundenaudit die tatsächlich verwendeten
        # Termine aller benötigten Währungen. Sie bilden deshalb den schnellen
        # Primärweg. Die bisherige Länderkaskade bleibt vollständig als Reserve
        # erhalten, wird aber nur noch benötigt, wenn der Wochenkalender für die
        # angefragte Währung wirklich keine Zeile liefert.
        events = []
        target_currency = None
        for cur, ctry in EVENT_COUNTRIES.items():
            if ctry == country:
                target_currency = cur
                break
        if target_currency:
            for ev in self.fetch_forexfactory_events(start_date, end_date):
                ev_cur = str(ev.get("Currency") or ev.get("Country") or "").upper().strip()
                if ev_cur == target_currency:
                    events.append(ev)
        if not events:
            events.extend(self.fetch_tradingeconomics_events_for_country(country, start_date, end_date))
        self.save_cached_json(cache, events)
        self._event_cache[memory_key] = events
        return events

    def event_datetime(self, event):
        """Liest Datum und Uhrzeit aus TradingEconomics oder ForexFactory Zeilen.
        Rückgabe ist naive lokale Zeit der Quelle. Für die UI reicht das als Terminzeit Hinweis.
        """
        date_val = None
        for key in ("Date", "date", "CalendarReference", "calendarReference"):
            date_val = event.get(key) if isinstance(event, dict) else None
            if date_val:
                break
        if not date_val:
            return None
        date_text = str(date_val).strip().replace("Z", "").split(".")[0]
        time_text = str(event.get("Time") or event.get("time") or "").strip() if isinstance(event, dict) else ""
        candidates = []
        if "T" in date_text:
            candidates.extend([date_text[:19], date_text[:16], date_text[:10]])
        else:
            if time_text and time_text.lower() not in ("all day", "tentative", "", "day 1", "day 2"):
                candidates.append(f"{date_text} {time_text}")
            candidates.append(date_text)
        formats = (
            "%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M",
            "%Y-%m-%d %I:%M%p", "%Y-%m-%d %I%p",
            "%m-%d-%Y %I:%M%p", "%m-%d-%Y %I%p", "%m/%d/%Y %I:%M%p", "%m/%d/%Y %I%p",
            "%d.%m.%Y %H:%M", "%Y-%m-%d", "%m-%d-%Y", "%m/%d/%Y", "%d.%m.%Y",
        )
        for cand in candidates:
            cand = re.sub(r"\s+", " ", cand.strip())
            for fmt in formats:
                try:
                    return datetime.strptime(cand, fmt)
                except Exception:
                    pass
        return None

    def event_date(self, event):
        return self.event_datetime(event)

    def event_priority(self, title):
        t = str(title or "").lower()
        if any(k in t for k in ("non-farm", "non farm", "nonfarm", "payroll", "federal funds rate", "official bank rate", "overnight rate", "official cash rate", "rate statement", "rate decision", "cpi", "consumer price", "inflation", "fomc statement")):
            return 3
        if any(k in t for k in ("gdp", "unemployment", "retail sales", "pmi", "ppi", "average hourly earnings", "earnings")):
            return 2
        return 1

    def event_risk_from_events(self, events):
        if not events:
            return "ruhig"
        dates = {}
        max_prio = 0
        for ev in events:
            d = ev.get("date", "Termin offen")
            dates[d] = dates.get(d, 0) + 1
            max_prio = max(max_prio, int(ev.get("priority", 1) or 1))
        clustered = any(v >= 3 for v in dates.values())
        if clustered and max_prio >= 3:
            return "sehr hoch"
        if max_prio >= 3 or len(events) >= 3:
            return "erhöht"
        return "beobachten"

    def high_impact_events(self, currencies, days=14):
        start = datetime.now()
        end = start + timedelta(days=days)
        results = []
        raw_events_seen = 0
        high_events_seen = 0
        source_counts = {}
        country_counts = {}
        requested = list(currencies or [])
        for cur in requested:
            country = EVENT_COUNTRIES.get(cur)
            if not country:
                continue
            country_events = self.fetch_events_for_country(country, start, end)
            country_counts[cur] = len(country_events or [])
            for ev in country_events:
                if not isinstance(ev, dict):
                    continue
                raw_events_seen += 1
                dt = self.event_datetime(ev)
                if dt and not (start.date() <= dt.date() <= end.date()):
                    continue
                title = str(ev.get("Event") or ev.get("event") or ev.get("Name") or ev.get("name") or "Wirtschaftstermin")
                importance = str(ev.get("Importance") or ev.get("importance") or ev.get("ImportanceLevel") or "").lower()
                text = title.lower()
                is_high = importance in ("3", "high") or "high" in importance or any(k in text for k in HIGH_IMPACT_KEYWORDS)
                if not is_high:
                    continue
                high_events_seen += 1
                source = ev.get("_source", "unbekannt")
                source_counts[source] = source_counts.get(source, 0) + 1
                priority = self.event_priority(title)
                results.append({
                    "currency": cur,
                    "country": country,
                    "datetime": dt.isoformat(timespec="minutes") if dt else "",
                    "date": dt.strftime("%Y-%m-%d") if dt else "Termin offen",
                    "time": dt.strftime("%H:%M") if dt and (dt.hour or dt.minute) else "Uhrzeit offen",
                    "event": translate_event_title(title),
                    "event_original": title,
                    "importance": "hoch",
                    "priority": priority,
                    "source": source,
                })
        results.sort(key=lambda e: (e.get("date") == "Termin offen", e.get("date"), e.get("time") == "Uhrzeit offen", e.get("time"), -int(e.get("priority", 1)), e.get("currency"), e.get("event")))
        seen = set()
        clean = []
        for ev in results:
            key = (ev.get("currency"), ev.get("date"), ev.get("time"), ev.get("event"))
            if key in seen:
                continue
            seen.add(key)
            clean.append(ev)
        display = clean[:4]
        self._last_event_audit = {
            "requested_currencies": requested,
            "window_start": start.strftime("%Y-%m-%d"),
            "window_end": end.strftime("%Y-%m-%d"),
            "window_days": days,
            "raw_events_seen": raw_events_seen,
            "high_impact_events_found": len(clean),
            "events_displayed": len(display),
            "source_counts": source_counts,
            "country_event_counts": country_counts,
            "display_limit": 4,
            "status": "OK" if raw_events_seen > 0 else "KEINE_DATEN",
        }
        return display

    def analyze_pair(self, setup):
        pair = setup.get("pair", "")
        direction = setup.get("direction", "")
        if "/" not in pair:
            return None
        base, quote = pair.split("/")[:2]
        base_2y = self.get_yield(base, 2)
        quote_2y = self.get_yield(quote, 2)
        base_10y = self.get_yield(base, 10)
        quote_10y = self.get_yield(quote, 10)

        def maturity_result(maturity, base_row, quote_row):
            available = base_row.get("yield") is not None and quote_row.get("yield") is not None
            if not available:
                return {
                    "maturity": maturity, "base": base, "quote": quote, "available": False,
                    "base_yield": base_row.get("yield"), "quote_yield": quote_row.get("yield"),
                    "spread": 0.0, "state": "NEUTRAL", "score": 50.0,
                }
            spread_value = round(base_row["yield"] - quote_row["yield"], 3)
            state_value = self.spread_supports_direction(pair, direction, spread_value)
            return {
                "maturity": maturity, "base": base, "quote": quote, "available": True,
                "base_yield": base_row.get("yield"), "quote_yield": quote_row.get("yield"),
                "spread": spread_value, "state": state_value,
                "score": self.macro_score(spread_value, state_value),
            }

        two = maturity_result(2, base_2y, quote_2y)
        ten = maturity_result(10, base_10y, quote_10y)

        curve_available = two["available"] and ten["available"]
        if curve_available:
            base_curve = round(base_10y["yield"] - base_2y["yield"], 3)
            quote_curve = round(quote_10y["yield"] - quote_2y["yield"], 3)
            curve_spread = round(base_curve - quote_curve, 3)
            curve_state = self.spread_supports_direction(pair, direction, curve_spread)
            curve = {
                "available": True, "base": base, "quote": quote,
                "base_curve": base_curve, "quote_curve": quote_curve,
                "spread": curve_spread, "state": curve_state,
                "score": self.curve_score(curve_spread, curve_state),
            }
        else:
            curve = {
                "available": False, "base": base, "quote": quote,
                "base_curve": None, "quote_curve": None,
                "spread": 0.0, "state": "NEUTRAL", "score": 50.0,
            }

        histories = {
            2: (
                self.history_for_impulse(base, 2, base_2y),
                self.history_for_impulse(quote, 2, quote_2y),
            ),
            10: (
                self.history_for_impulse(base, 10, base_10y),
                self.history_for_impulse(quote, 10, quote_10y),
            ),
        }
        impulse = self.calculate_yield_impulse(pair, direction, histories)

        score = self.combine_maturity_scores(
            score_2y=two["score"],
            score_10y=ten["score"],
            score_curve=curve["score"],
            score_impulse=impulse["score"],
            available_2y=two["available"],
            available_10y=ten["available"],
            available_curve=curve["available"],
            available_impulse=impulse["available"],
        )
        if any((two["available"], ten["available"], curve["available"], impulse["available"])):
            state = "SUPPORT" if score > 52 else "HEADWIND" if score < 48 else "NEUTRAL"
        else:
            state = "NEUTRAL"

        events = self.high_impact_events([base, quote], days=14)
        event_risk = self.event_risk_from_events(events)
        event_penalty = self.event_risk_penalty(event_risk)
        label = self.macro_label(state, score)
        return {
            "pair": pair, "direction": direction, "base": base, "quote": quote,
            "base_yield": base_10y.get("yield"), "quote_yield": quote_10y.get("yield"),
            "spread": ten["spread"], "support_state": state,
            "base_yield_2y": base_2y.get("yield"), "quote_yield_2y": quote_2y.get("yield"),
            "spread_2y": two["spread"], "support_state_2y": two["state"], "score_2y": two["score"],
            "base_yield_10y": base_10y.get("yield"), "quote_yield_10y": quote_10y.get("yield"),
            "spread_10y": ten["spread"], "support_state_10y": ten["state"], "score_10y": ten["score"],
            "base_curve": curve["base_curve"], "quote_curve": curve["quote_curve"],
            "curve_spread": curve["spread"], "support_state_curve": curve["state"],
            "score_curve": curve["score"], "curve_available": curve["available"],
            "score_impulse": impulse["score"], "impulse_available": impulse["available"],
            "impulse_state": impulse["state"], "impulse_label": impulse["label"],
            "impulse_change_5d": impulse["change_5d"],
            "impulse_change_20d": impulse["change_20d"],
            "impulse_directional_change": impulse["directional_change"],
            "impulse_latest_date": impulse["latest_date"],
            "impulse_interpretation": impulse["interpretation"],
            "impulse_audit": {
                "raw_change": impulse["raw_change"],
                "directional_change": impulse["directional_change"],
                "component_changes": impulse["component_changes"],
                "latest_common_date": impulse["latest_date"],
                "history_sources": {
                    "base_2y": self._impulse_history_sources.get((base, 2), "nicht verfügbar"),
                    "quote_2y": self._impulse_history_sources.get((quote, 2), "nicht verfügbar"),
                    "base_10y": self._impulse_history_sources.get((base, 10), "nicht verfügbar"),
                    "quote_10y": self._impulse_history_sources.get((quote, 10), "nicht verfügbar"),
                },
                "history_errors": {
                    "base_2y": self._impulse_history_errors.get((base, 2), ""),
                    "quote_2y": self._impulse_history_errors.get((quote, 2), ""),
                    "base_10y": self._impulse_history_errors.get((base, 10), ""),
                    "quote_10y": self._impulse_history_errors.get((quote, 10), ""),
                },
            },
            "macro_weights": {"2y": 35, "10y": 20, "curve": 15, "zinsimpuls": 30},
            "base_source_2y": base_2y.get("source"), "quote_source_2y": quote_2y.get("source"),
            "base_source_10y": base_10y.get("source"), "quote_source_10y": quote_10y.get("source"),
            "base_fetched_at_2y": base_2y.get("fetched_at"), "quote_fetched_at_2y": quote_2y.get("fetched_at"),
            "base_fetched_at_10y": base_10y.get("fetched_at"), "quote_fetched_at_10y": quote_10y.get("fetched_at"),
            "bond_audit": {
                "2y": {"base_attempts": base_2y.get("attempts", []), "quote_attempts": quote_2y.get("attempts", [])},
                "10y": {"base_attempts": base_10y.get("attempts", []), "quote_attempts": quote_10y.get("attempts", [])},
            },
            "macro_score": round(score, 1), "macro_label": label, "macro_stars": star_text(score),
            "event_risk": event_risk, "event_penalty": round(event_penalty, 1),
            "event_volatility": self.expected_volatility_score(event_risk),
            "event_score": None, "event_stars": "", "events": events,
            "event_audit": getattr(self, "_last_event_audit", {}),
            "interpretation": self.interpret_bond(pair, direction, two, ten, curve, impulse, score),
        }

    def final_confluence(self, season_row, macro_row):
        return self.final_quality_score(season_row, macro_row)

    def prefetch_currency_macro(self, currency):
        """Bereitet Renditen und Impulshistorien einer Währung gemeinsam vor."""
        currency = str(currency or "").upper()
        current_rows = {}
        for maturity in (2, 10):
            current_rows[maturity] = self.get_yield(currency, maturity)
        for maturity in (2, 10):
            self.history_for_impulse(currency, maturity, current_rows[maturity])
        return currency

    def prefetch_macro_inputs(self, rows):
        """Lädt unabhängige Makrodaten kontrolliert parallel und nur einmal.

        Berechnung und Reihenfolge der finalen Paarbewertung bleiben unverändert.
        Vorbereitet werden lediglich die pro Währung wiederverwendbaren Daten,
        damit drei Watchlist Paare nicht nacheinander auf dieselben Quellen warten.
        """
        currencies = set()
        for setup in list(rows or []):
            pair = str((setup or {}).get("pair") or "").upper()
            if "/" not in pair:
                continue
            base, quote = pair.split("/")[:2]
            if base:
                currencies.add(base)
            if quote:
                currencies.add(quote)

        start = datetime.now()
        end = start + timedelta(days=14)
        countries = {
            EVENT_COUNTRIES[currency]
            for currency in currencies
            if currency in EVENT_COUNTRIES
        }
        tasks = []
        worker_count = min(MACRO_PREFETCH_WORKERS, max(1, len(currencies) + len(countries)))
        with ThreadPoolExecutor(max_workers=worker_count, thread_name_prefix="meridian_macro") as executor:
            for currency in sorted(currencies):
                tasks.append((executor.submit(self.prefetch_currency_macro, currency), f"Zinsdaten {currency}"))
            for country in sorted(countries):
                tasks.append((
                    executor.submit(self.fetch_events_for_country, country, start, end),
                    f"Termine {country}",
                ))

            labels = {future: label for future, label in tasks}
            total = max(1, len(labels))
            for completed, future in enumerate(as_completed(labels), 1):
                label = labels[future]
                try:
                    future.result()
                except Exception as exc:
                    self.errors.append(f"Makro Vorbereitung {label}: {exc}")
                self.progress(
                    68 + int(completed / total * 14),
                    f"Makrodaten vorbereiten {completed} von {total}",
                )

    def analyze_watchlist(self, final_watchlist):
        self.errors = []
        results = []
        rows = list(final_watchlist or [])[:3]
        if rows:
            self.progress(68, "Makrodaten parallel vorbereiten")
            self.prefetch_macro_inputs(rows)
        total = max(1, len(rows))
        for i, setup in enumerate(rows, 1):
            self.progress(82 + int(i / total * 13), f"Makros prüfen {setup.get('pair')}")
            macro = self.analyze_pair(setup)
            if not macro:
                continue
            macro["cot_score"] = safe_float(setup.get("cot_confidence", setup.get("confidence", 50)), 50)
            macro["seasonality_score"] = safe_float(setup.get("seasonality_score", 50), 50)
            macro["seasonality_verdict"] = setup.get("verdict", "NEUTRAL")
            quality = final_watchlist_quality_breakdown(
                macro["cot_score"],
                macro["seasonality_score"],
                macro.get("macro_score", 50),
                macro.get("event_penalty", 0),
            )
            macro.update(quality)
            macro["final_confluence"] = quality["final_quality"]
            macro["final_confluence_stars"] = star_text(macro["final_confluence"])
            macro["final_quality_stars"] = star_text(macro["final_quality"])
            results.append(macro)
        results.sort(key=lambda row: safe_float(row.get("final_quality", 0), 0), reverse=True)
        return results


MARKET_PULSE_CACHE_FILE = USER_DATA_DIR / "market_pulse_cache.json"
MARKET_PULSE_CACHE_VERSION = 8

FOREX_YAHOO_SYMBOLS = {
    "EUR/USD": "EURUSD=X",
    "GBP/USD": "GBPUSD=X",
    "AUD/USD": "AUDUSD=X",
    "NZD/USD": "NZDUSD=X",
    "USD/JPY": "JPY=X",
    "USD/CHF": "CHF=X",
    "USD/CAD": "CAD=X",
    "EUR/GBP": "EURGBP=X",
    "EUR/JPY": "EURJPY=X",
    "EUR/CHF": "EURCHF=X",
    "EUR/CAD": "EURCAD=X",
    "EUR/AUD": "EURAUD=X",
    "EUR/NZD": "EURNZD=X",
    "GBP/JPY": "GBPJPY=X",
    "GBP/CHF": "GBPCHF=X",
    "GBP/CAD": "GBPCAD=X",
    "GBP/AUD": "GBPAUD=X",
    "GBP/NZD": "GBPNZD=X",
    "AUD/JPY": "AUDJPY=X",
    "AUD/CHF": "AUDCHF=X",
    "AUD/CAD": "AUDCAD=X",
    "AUD/NZD": "AUDNZD=X",
    "NZD/JPY": "NZDJPY=X",
    "NZD/CHF": "NZDCHF=X",
    "NZD/CAD": "NZDCAD=X",
    "CAD/JPY": "CADJPY=X",
    "CAD/CHF": "CADCHF=X",
    "CHF/JPY": "CHFJPY=X",
}

MARKET_PULSE_ALL_PAIRS = tuple(FOREX_YAHOO_SYMBOLS) + (
    "XAU/USD",
    "XAG/USD",
    "NAS100/USD",
    "SP500/USD",
)

MARKET_PULSE_DISPLAY_NAMES = {
    "NAS100/USD": "NASDAQ 100",
    "SP500/USD": "S&P 500",
}


def market_pulse_display_name(pair):
    return MARKET_PULSE_DISPLAY_NAMES.get(pair, pair)


def market_pulse_yahoo_symbols(pair):
    if pair in FOREX_YAHOO_SYMBOLS:
        return (FOREX_YAHOO_SYMBOLS[pair],)
    for cfg in SINGLE_ASSET_MARKETS.values():
        if cfg.get("pair") == pair:
            symbols = cfg.get("yahoo")
            if isinstance(symbols, (list, tuple)):
                return tuple(symbols)
            return (symbols,) if symbols else ()
    return ()


def market_pulse_stooq_symbol(pair):
    clean = pair.replace("/", "").lower()
    special = {
        "XAU/USD": "gc.f",
        "XAG/USD": "si.f",
        "NAS100/USD": "nq.f",
        "SP500/USD": "es.f",
    }
    return special.get(pair, clean)


def market_pulse_stooq_symbols(pair):
    """Stooq Kassamarkt zuerst, Future als robuste Metall Reserve."""
    special = {
        "XAU/USD": ("xauusd", "gc.f"),
        "XAG/USD": ("xagusd", "si.f"),
        "NAS100/USD": ("nq.f",),
        "SP500/USD": ("es.f",),
    }
    return special.get(pair, (market_pulse_stooq_symbol(pair),))


class MarketPulsePriceProvider:
    """Separates Kursmodul für die Market Pulse Anzeige. Keine Engine Werte werden verändert."""

    def __init__(self, cache_file=MARKET_PULSE_CACHE_FILE):
        self.cache_file = Path(cache_file)

    def load_cache(self):
        try:
            if not self.cache_file.exists():
                return {"created": "", "markets": {}}
            raw = json.loads(self.cache_file.read_text(encoding="utf-8"))
            if isinstance(raw, dict) and raw.get("version") == MARKET_PULSE_CACHE_VERSION and isinstance(raw.get("markets"), dict):
                return {"created": raw.get("created", ""), "markets": raw.get("markets", {})}
            if isinstance(raw, dict) and isinstance(raw.get("markets"), dict):
                return {"created": "", "markets": {}}
            if isinstance(raw, dict):
                legacy_markets = {
                    pair: value for pair, value in raw.items()
                    if isinstance(value, dict) and value.get("series")
                }
                legacy_times = [value.get("updated_at", "") for value in legacy_markets.values() if value.get("updated_at")]
                return {"created": max(legacy_times or [""]), "markets": legacy_markets}
        except Exception:
            pass
        return {"created": "", "markets": {}}

    def save_cache(self, cache):
        try:
            self.cache_file.parent.mkdir(parents=True, exist_ok=True)
            temp_file = self.cache_file.with_suffix(self.cache_file.suffix + ".tmp")
            temp_file.write_text(json.dumps(cache, indent=2, ensure_ascii=False), encoding="utf-8")
            temp_file.replace(self.cache_file)
        except Exception:
            pass

    def fetch_many(self, pairs, start_date):
        requested_pairs = list(dict.fromkeys(pair for pair in pairs if pair))
        created_at = datetime.now().isoformat(timespec="seconds")
        today_key = datetime.now().strftime("%Y-%m-%d")
        previous_cache = self.load_cache()
        markets = dict(previous_cache.get("markets", {}))
        results = {}
        errors = []
        fresh_count = 0
        paused_providers = set()
        for pair in requested_pairs:
            series = None
            source = None
            price_data = None
            for provider_name, provider in (("Yahoo", self.fetch_yahoo), ("Stooq", self.fetch_stooq), ("Frankfurter", self.fetch_frankfurter)):
                if provider_name in paused_providers:
                    continue
                try:
                    fetched = provider(pair, start_date)
                    if isinstance(fetched, dict):
                        candidate_series = fetched.get("series", [])
                        candidate_data = fetched
                    else:
                        candidate_series = fetched or []
                        candidate_data = {"series": candidate_series}
                    if candidate_series and len(candidate_series) >= 2:
                        series = candidate_series
                        price_data = candidate_data
                        source = provider_name
                        break
                except Exception as exc:
                    errors.append(f"{pair} {provider_name}: {exc}")
                    if provider_name == "Yahoo" and isinstance(exc, urllib.error.HTTPError) and exc.code in (401, 403, 429):
                        paused_providers.add(provider_name)
                        errors.append(f"Yahoo Abrufe für diesen Durchlauf nach HTTP {exc.code} pausiert")
            if series and len(series) >= 2:
                market_data = {
                    "source": source,
                    "updated_at": created_at,
                    "series": series,
                    "current_price": price_data.get("current_price") if price_data else None,
                    "previous_close": price_data.get("previous_close") if price_data else None,
                    "previous_close_date": price_data.get("previous_close_date", "") if price_data else "",
                    "today_change_percent": price_data.get("today_change_percent") if price_data else None,
                    "today_change_source": price_data.get("today_change_source", "") if price_data else "",
                    "reference_price": price_data.get("reference_price") if price_data else None,
                    "reference_date": price_data.get("reference_date", "") if price_data else "",
                    "week_reference_price": price_data.get("week_reference_price") if price_data else None,
                    "week_reference_date": price_data.get("week_reference_date", "") if price_data else "",
                    "provider_symbol": price_data.get("provider_symbol", "") if price_data else "",
                    "daily_reference_source": price_data.get("daily_reference_source", "") if price_data else "",
                    "cot_reference_source": price_data.get("cot_reference_source", "") if price_data else "",
                    "provider_debug": price_data.get("provider_debug", {}) if price_data else {},
                }
                markets[pair] = market_data
                results[pair] = {**market_data, "cache": False}
                fresh_count += 1
            else:
                errors.append(f"{pair}: keine Kursdaten verfügbar")
                cached = markets.get(pair)
                if isinstance(cached, dict) and cached.get("series"):
                    results[pair] = {**cached, "cache": True}

        cache_created = created_at if fresh_count else previous_cache.get("created", "")
        self.save_cache({"version": MARKET_PULSE_CACHE_VERSION, "created": cache_created, "markets": markets})
        return {
            "date": today_key,
            "updated_at": cache_created,
            "results": results,
            "errors": errors,
            "used_cache_only": fresh_count == 0 and bool(results),
            "complete_success": fresh_count == len(requested_pairs),
        }

    def fetch_yahoo(self, pair, start_date):
        start_dt = self.normalize_start(start_date)
        period1 = int(start_dt.timestamp())
        period2 = int((datetime.now() + timedelta(days=1)).timestamp())
        last_error = None
        for symbol in market_pulse_yahoo_symbols(pair):
            try:
                encoded_symbol = urllib.parse.quote(symbol)

                # Historie für COT und Wochenreferenz. Diese Abfrage darf nicht
                # als Quelle für den Vortagesschluss verwendet werden, weil
                # chartPreviousClose sich auf den Beginn dieses langen Zeitraums
                # beziehen kann.
                history_url = (
                    f"https://query1.finance.yahoo.com/v8/finance/chart/{encoded_symbol}"
                    f"?period1={period1}&period2={period2}&interval=1d"
                )
                history_data = self.read_json(history_url)
                result = (history_data.get("chart", {}).get("result") or [{}])[0]
                meta = result.get("meta") or {}
                timestamps = result.get("timestamp") or []
                quote = (result.get("indicators", {}).get("quote") or [{}])[0]
                closes = quote.get("close") or []
                offset = int(meta.get("gmtoffset") or 0)
                series = []
                for ts, close in zip(timestamps, closes):
                    if close is None:
                        continue
                    date_key = datetime.utcfromtimestamp(int(ts) + offset).strftime("%Y-%m-%d")
                    series.append({"date": date_key, "close": float(close)})
                series = self.clean_series(series)
                if len(series) < 2:
                    continue

                # Separater Kurzabruf für den aktuellen Kurs und den echten
                # vorherigen Marktschluss derselben Yahoo Symbolquelle. Bei
                # range=1d bezeichnet chartPreviousClose den Schluss vor der
                # aktuellen Session und nicht den Beginn der COT Historie.
                quote_url = (
                    f"https://query1.finance.yahoo.com/v8/finance/chart/{encoded_symbol}"
                    f"?range=1d&interval=5m&includePrePost=true"
                )
                quote_result = {}
                quote_meta = {}
                quote_intraday = []
                try:
                    quote_data = self.read_json(quote_url)
                    quote_result = (quote_data.get("chart", {}).get("result") or [{}])[0]
                    quote_meta = quote_result.get("meta") or {}
                    quote_timestamps = quote_result.get("timestamp") or []
                    quote_indicators = quote_result.get("indicators", {}) or {}
                    quote_values = (quote_indicators.get("quote") or [{}])[0]
                    quote_closes = quote_values.get("close") or []
                    quote_offset_debug = int(quote_meta.get("gmtoffset") or offset)
                    for qts, qclose in zip(quote_timestamps, quote_closes):
                        if qclose is None:
                            continue
                        quote_intraday.append({
                            "timestamp": int(qts),
                            "local_time": datetime.utcfromtimestamp(int(qts) + quote_offset_debug).isoformat(timespec="seconds"),
                            "close": float(qclose),
                        })
                    quote_intraday = quote_intraday[-12:]
                except Exception:
                    # Der lange Historienabruf bleibt als belastbarer Fallback
                    # nutzbar, falls Yahoo den Intraday Endpunkt temporär sperrt.
                    quote_result = {}
                    quote_meta = {}
                    quote_intraday = []

                # Für Market Pulse wird ausschließlich der funktionierende Yahoo
                # Chart Endpunkt verwendet. Die zuvor getesteten sechs Quote und
                # QuoteSummary Endpunkte wurden entfernt, da sie ohne Yahoo Session
                # mit 401 oder 404 antworteten und den Realtime Abruf stark
                # verlangsamten. Der gemeinsame Cache und alle Engine Auswertungen
                # bleiben davon unberührt.
                quote_snapshot = {}
                snapshot_url = ""
                snapshot_attempts = []

                current_price = quote_meta.get("regularMarketPrice")
                if current_price is None:
                    current_price = meta.get("regularMarketPrice")
                if current_price is None:
                    current_price = series[-1]["close"]
                current_price = float(current_price)

                # Für "Markt heute" wird bevorzugt das fertige Yahoo Prozentfeld
                # verwendet. Nur wenn es fehlt, wird aus dem Yahoo Quote Previous
                # Close derselben Realtime Quelle abgeleitet. Die Daily Serie ist
                # ausschließlich Fallback und bleibt weiterhin die Quelle für COT.
                market_ts = quote_meta.get("regularMarketTime") or meta.get("regularMarketTime")
                quote_offset = int(quote_meta.get("gmtoffset") or offset)
                if market_ts is not None:
                    current_date = datetime.utcfromtimestamp(int(market_ts) + quote_offset).strftime("%Y-%m-%d")
                else:
                    current_date = datetime.utcfromtimestamp(int(datetime.now().timestamp()) + quote_offset).strftime("%Y-%m-%d")

                completed = [row for row in series if row["date"] < current_date]
                previous_row = completed[-1] if completed else series[-2]
                daily_previous_close = float(previous_row["close"])

                previous_close = quote_meta.get("previousClose")
                previous_close_source = "Yahoo chart meta previousClose"
                if previous_close is None:
                    previous_close = quote_meta.get("chartPreviousClose")
                    previous_close_source = "Yahoo chart meta chartPreviousClose"
                if previous_close is None:
                    previous_close = daily_previous_close
                    previous_close_source = "Yahoo daily series previous completed close fallback"
                previous_close = float(previous_close)

                today_change_percent = quote_meta.get("regularMarketChangePercent")
                today_change_source = "Yahoo chart meta regularMarketChangePercent"
                if today_change_percent is None:
                    today_change_percent = market_pulse_percent(current_price, previous_close)
                    today_change_source = f"calculated from {previous_close_source}"
                today_change_percent = float(today_change_percent)

                cot_candidates = [row for row in series if row["date"] >= start_dt.strftime("%Y-%m-%d")]
                reference_row = cot_candidates[0] if cot_candidates else series[0]

                target_week_date = (datetime.strptime(current_date, "%Y-%m-%d") - timedelta(days=7)).strftime("%Y-%m-%d")
                week_candidates = [row for row in series if row["date"] <= target_week_date]
                week_row = week_candidates[-1] if week_candidates else reference_row

                market_time_iso = ""
                if market_ts is not None:
                    market_time_iso = datetime.utcfromtimestamp(int(market_ts) + quote_offset).isoformat(timespec="seconds")
                provider_debug = {
                    "provider": "Yahoo",
                    "provider_symbol": symbol,
                    "history_url": history_url,
                    "quote_url": quote_url,
                    "snapshot_url": snapshot_url,
                    "snapshot_attempts": snapshot_attempts,
                    "snapshot_mode": "disabled_unauthed_quote_endpoints",
                    "quote_snapshot_full": quote_snapshot,
                    "quote_chart_response_full": quote_data if quote_result else {},
                    "history_chart_response_full": history_data,
                    "quote_chart_meta_full": quote_meta,
                    "history_chart_meta_full": meta,
                    "selected_snapshot_url": snapshot_url,
                    "fetched_at": datetime.now().isoformat(timespec="seconds"),
                    "exchange_name": quote_meta.get("exchangeName") or meta.get("exchangeName") or "",
                    "instrument_type": quote_meta.get("instrumentType") or meta.get("instrumentType") or "",
                    "currency": quote_meta.get("currency") or meta.get("currency") or "",
                    "exchange_timezone_name": quote_meta.get("exchangeTimezoneName") or meta.get("exchangeTimezoneName") or "",
                    "timezone": quote_meta.get("timezone") or meta.get("timezone") or "",
                    "gmtoffset": quote_offset,
                    "market_state": quote_meta.get("marketState") or meta.get("marketState") or "",
                    "regular_market_time": market_ts,
                    "regular_market_time_local": market_time_iso,
                    "regular_market_price_snapshot": quote_snapshot.get("regularMarketPrice"),
                    "regular_market_price_quote": quote_meta.get("regularMarketPrice"),
                    "regular_market_price_history": meta.get("regularMarketPrice"),
                    "regular_market_change_percent_snapshot": quote_snapshot.get("regularMarketChangePercent"),
                    "change_percent_snapshot": quote_snapshot.get("changePercent"),
                    "regular_market_change_snapshot": quote_snapshot.get("regularMarketChange"),
                    "regular_market_previous_close_snapshot": quote_snapshot.get("regularMarketPreviousClose"),
                    "regular_market_previous_close_quote": quote_meta.get("previousClose"),
                    "chart_previous_close_quote": quote_meta.get("chartPreviousClose"),
                    "regular_market_previous_close_history": meta.get("previousClose"),
                    "chart_previous_close_history": meta.get("chartPreviousClose"),
                    "used_current_price": current_price,
                    "used_previous_close": previous_close,
                    "used_previous_close_date": previous_row["date"],
                    "used_today_change_percent": today_change_percent,
                    "used_today_change_source": today_change_source,
                    "daily_previous_close_for_comparison": daily_previous_close,
                    "used_cot_reference_price": float(reference_row["close"]),
                    "used_cot_reference_date": reference_row["date"],
                    "used_week_reference_price": float(week_row["close"]),
                    "used_week_reference_date": week_row["date"],
                    "daily_series_tail": series[-12:],
                    "intraday_series_tail": quote_intraday,
                }
                return {
                    "series": series,
                    "current_price": current_price,
                    "previous_close": previous_close,
                    "previous_close_date": previous_row["date"],
                    "today_change_percent": today_change_percent,
                    "today_change_source": today_change_source,
                    "reference_price": float(reference_row["close"]),
                    "reference_date": reference_row["date"],
                    "week_reference_price": float(week_row["close"]),
                    "week_reference_date": week_row["date"],
                    "provider_symbol": symbol,
                    "daily_reference_source": today_change_source,
                    "cot_reference_source": "Yahoo daily close",
                    "provider_debug": provider_debug,
                }
            except Exception as exc:
                last_error = exc
                if isinstance(exc, urllib.error.HTTPError) and exc.code in (401, 403, 429):
                    break
        if last_error:
            raise last_error
        return {"series": []}

    def fetch_stooq(self, pair, start_date):
        start_dt = self.normalize_start(start_date)
        d1 = start_dt.strftime("%Y%m%d")
        last_error = None
        for symbol in market_pulse_stooq_symbols(pair):
            try:
                url = f"https://stooq.com/q/d/l/?s={urllib.parse.quote(symbol)}&d1={d1}&i=d"
                text = self.read_text(url)
                rows = list(csv.DictReader(io.StringIO(text)))
                series = []
                for row in rows:
                    close = row.get("Close")
                    if not close or close == "No data":
                        continue
                    series.append({"date": row.get("Date"), "close": float(close)})
                series = self.clean_series(series)
                if len(series) < 2:
                    continue
                current_price = float(series[-1]["close"])
                previous_close = float(series[-2]["close"])
                week_row = series[max(0, len(series) - 6)]
                reference_candidates = [row for row in series if row["date"] >= start_dt.strftime("%Y-%m-%d")]
                reference_row = reference_candidates[0] if reference_candidates else series[0]
                return {
                    "series": series,
                    "current_price": current_price,
                    "previous_close": previous_close,
                    "previous_close_date": series[-2]["date"],
                    "today_change_percent": market_pulse_percent(current_price, previous_close),
                    "today_change_source": "Stooq letzter Tagesclose",
                    "reference_price": float(reference_row["close"]),
                    "reference_date": reference_row["date"],
                    "week_reference_price": float(week_row["close"]),
                    "week_reference_date": week_row["date"],
                    "provider_symbol": symbol,
                    "daily_reference_source": "Stooq Tagesdaten",
                    "cot_reference_source": "Stooq Tagesdaten",
                    "provider_debug": {"provider": "Stooq", "provider_symbol": symbol, "url": url},
                }
            except Exception as exc:
                last_error = exc
        if last_error:
            raise last_error
        return {"series": []}

    def fetch_frankfurter(self, pair, start_date):
        if "/" not in pair:
            return []
        base, quote = pair.split("/", 1)
        if base not in MARKETS or quote not in MARKETS:
            return []
        if base == "USD" or quote == "USD" or base == "EUR" or quote == "EUR":
            start_dt = self.normalize_start(start_date)
            url = f"https://api.frankfurter.app/{start_dt.strftime('%Y-%m-%d')}..?from={base}&to={quote}"
            data = self.read_json(url)
            rates = data.get("rates") or {}
            series = []
            for date_key, values in sorted(rates.items()):
                val = values.get(quote)
                if val is not None:
                    series.append({"date": date_key, "close": float(val)})
            return self.clean_series(series)
        return []

    def read_json(self, url):
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=12) as resp:
            return json.loads(resp.read().decode("utf-8", errors="replace"))

    def read_text(self, url):
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=12) as resp:
            return resp.read().decode("utf-8", errors="replace")

    def normalize_start(self, start_date):
        if isinstance(start_date, datetime):
            dt = start_date
        else:
            raw = str(start_date or "").strip()
            dt = None
            for fmt in ("%Y-%m-%d", "%d.%m.%Y", "%Y/%m/%d"):
                try:
                    dt = datetime.strptime(raw[:10], fmt)
                    break
                except Exception:
                    pass
            if dt is None:
                dt = datetime.now() - timedelta(days=45)
        min_dt = datetime.now() - timedelta(days=90)
        if dt < min_dt:
            dt = min_dt
        return dt

    def clean_series(self, series):
        cleaned = []
        seen = set()
        for row in series:
            try:
                date_key = str(row.get("date"))[:10]
                close = float(row.get("close"))
                if date_key and date_key not in seen and close > 0:
                    cleaned.append({"date": date_key, "close": close})
                    seen.add(date_key)
            except Exception:
                continue
        return sorted(cleaned, key=lambda x: x["date"])


def market_pulse_percent(new, old):
    try:
        new = float(new)
        old = float(old)
        if old == 0:
            return 0.0
        return (new / old - 1.0) * 100.0
    except Exception:
        return 0.0


def market_pulse_signal_return(raw_return, direction):
    return raw_return if direction == "LONG" else -raw_return


def market_pulse_status(signal_return):
    if signal_return >= 0.35:
        return "COT Richtung bestätigt", COLORS["green"]
    if signal_return <= -0.35:
        return "Kurzfristiger Pullback", COLORS["orange"]
    return "Noch neutral", COLORS["yellow"]


class App(tk.Tk):
    RESULT_MOTION_DURATION_MS = 680
    MACRO_RESULT_MOTION_DURATION_MS = 1150
    RESULT_MOTION_FRAME_MS = 24
    RESULT_MOTION_INITIAL_DELAY_MS = 70
    RESULT_MOTION_STAGGER_MS = 48
    RESULT_MOTION_MAX_DELAY_MS = 520

    def __init__(self):
        super().__init__()
        self.title(APP_NAME)
        self.geometry("1850x950")
        self.minsize(1800, 820)
        self.configure(bg=COLORS["bg"])
        self.set_app_icon()

        self.app_settings = load_app_settings()
        self.engine = WeeklyCotEngine(self.set_progress)
        self.engine.set_analysis_engine(self.app_settings["analysis_engine"])
        self.strengths = {}
        self.top3 = []
        self.all_pairs = []
        self.seasonality = []
        self.single_asset_seasonality = []
        self.final_watchlist = []
        self.weekly_movers = {}
        self.season_engine = SeasonalityEngine(self.set_progress)
        self.macro_engine = MacroEngine(self.set_progress)
        self.macro_results = []
        # Neu in 0.0.3: persistentes Wochenarchiv als Grundlage für spätere
        # Kalibrierung der Meridian Scores gegen tatsächliche Marktbewegungen.
        self.weekly_archive = WeeklyArchiveStore()
        self.weekly_archive_window = None
        self.champions_results = {}
        self.champions_ready = False
        self.champions_generating = False
        self._champions_glow_job = None
        self._champions_glow_phase = 0
        self.entry_engine_window = None
        # Verhindert innerhalb einer Programmsitzung, dass der geschützte
        # TradingView-Indikator versehentlich mehrfach geöffnet wird.
        self.entry_engine_link_opened = False
        # TradingView Profile werden ausschließlich aus den finalen Makro
        # Watchlists erzeugt. Das Champions Modul ist bewusst keine Datenquelle.
        self.entry_engine_engine_rows = {}
        self.entry_engine_profiles_building = False
        self.entry_engine_profiles_ready = False
        self.entry_engine_profile_errors = []
        self.entry_engine_profile_queue = None
        self.entry_engine_profile_generation = 0
        self._entry_engine_profile_refresh = None
        # Die Engine eines abgeschlossenen Ergebnislaufs bleibt fest an dessen
        # Ranking und Erklärungen gebunden. Erst eine bewusst vorbereitete neue
        # Analyse entsperrt die Auswahl wieder.
        self.result_engine_key = None
        # Navigation zwischen den drei Hauptauswertungen. Die Daten bleiben im
        # Speicher; ein Seitenwechsel startet keine neue Berechnung.
        self.current_main_view = "cot"
        # Zentrale Bewegungssteuerung für Ergebnisbalken. Sie verändert nur die
        # Darstellung und greift weder in Scores noch in Rankings ein.
        self._result_motion_indices = {}

        self.build_ui()
        self.bind_all("<MouseWheel>", self.on_mousewheel)
        self.render_empty()
        self.refresh_weekly_archive_button()

    def _begin_result_motion(self, group):
        """Startet eine neue, dezent gestaffelte Darstellungssequenz."""
        self._result_motion_indices[str(group)] = 0

    def _next_result_motion_delay(self, group):
        """Liefert den nächsten begrenzten Zeitversatz für eine Ergebnisgruppe."""
        key = str(group)
        index = int(self._result_motion_indices.get(key, 0))
        self._result_motion_indices[key] = index + 1
        return min(
            self.RESULT_MOTION_MAX_DELAY_MS,
            self.RESULT_MOTION_INITIAL_DELAY_MS + index * self.RESULT_MOTION_STAGGER_MS,
        )

    @staticmethod
    def _result_motion_ease(progress):
        """Ruhiges Auslaufen ohne Sprung oder federnden Effekt."""
        value = max(0.0, min(1.0, safe_float(progress, 0.0)))
        return 1.0 - (1.0 - value) ** 3

    @staticmethod
    def _blend_ui_color(first, second, amount=0.35):
        """Mischt zwei Hexfarben für die dezente Lichtkante der Animation."""
        try:
            ratio = max(0.0, min(1.0, float(amount)))
            a = str(first).lstrip("#")
            b = str(second).lstrip("#")
            if len(a) != 6 or len(b) != 6:
                return first
            values = []
            for offset in (0, 2, 4):
                start = int(a[offset:offset + 2], 16)
                end = int(b[offset:offset + 2], 16)
                values.append(round(start + (end - start) * ratio))
            return "#%02x%02x%02x" % tuple(values)
        except Exception:
            return first

    def _animate_canvas_result(self, canvas, renderer, delay=0, duration=None):
        """Animiert eine reine Canvas Darstellung von links nach rechts."""
        if canvas is None:
            return
        duration_ms = max(1, int(duration or self.RESULT_MOTION_DURATION_MS))
        token = object()
        state = {"reveal": 0.0}
        setattr(canvas, "_meridian_result_motion_token", token)

        def is_active():
            try:
                return bool(canvas.winfo_exists()) and getattr(canvas, "_meridian_result_motion_token", None) is token
            except tk.TclError:
                return False

        def draw(event=None):
            if not is_active():
                return
            try:
                renderer(canvas, state["reveal"])
            except tk.TclError:
                return

        canvas.bind("<Configure>", draw, add="+")
        draw()

        def start_animation():
            if not is_active():
                return
            started = time.perf_counter()

            def tick():
                if not is_active():
                    return
                elapsed_ms = (time.perf_counter() - started) * 1000.0
                linear = min(1.0, elapsed_ms / duration_ms)
                state["reveal"] = self._result_motion_ease(linear)
                draw()
                if linear < 1.0:
                    try:
                        canvas.after(self.RESULT_MOTION_FRAME_MS, tick)
                    except tk.TclError:
                        return
                else:
                    state["reveal"] = 1.0
                    draw()

            tick()

        try:
            canvas.after(max(0, int(delay)), start_animation)
        except tk.TclError:
            return

    def _animate_number_label(self, label, target, formatter, delay=0, duration=None):
        """Zählt eine sichtbare Ergebniszahl synchron zum zugehörigen Balken hoch."""
        if label is None:
            return
        target_value = safe_float(target, 0.0)
        duration_ms = max(1, int(duration or self.RESULT_MOTION_DURATION_MS))
        token = object()
        setattr(label, "_meridian_result_motion_token", token)

        def is_active():
            try:
                return bool(label.winfo_exists()) and getattr(label, "_meridian_result_motion_token", None) is token
            except tk.TclError:
                return False

        def start_animation():
            if not is_active():
                return
            started = time.perf_counter()

            def tick():
                if not is_active():
                    return
                elapsed_ms = (time.perf_counter() - started) * 1000.0
                linear = min(1.0, elapsed_ms / duration_ms)
                value = target_value * self._result_motion_ease(linear)
                try:
                    label.config(text=formatter(value if linear < 1.0 else target_value))
                except tk.TclError:
                    return
                if linear < 1.0:
                    try:
                        label.after(self.RESULT_MOTION_FRAME_MS, tick)
                    except tk.TclError:
                        return

            tick()

        try:
            label.config(text=formatter(0.0))
            label.after(max(0, int(delay)), start_animation)
        except tk.TclError:
            return


    HELP_TOPICS = {
        "guide": {
            "title": "Analyzer Pro, How to use",
            "intro": "Der Analyzer führt dich in drei Schritten von der institutionellen COT Vorauswahl bis zur finalen Wochen Watchlist. Vor dem Start bestimmst du mit der Analyse Engine, wie konservativ oder dynamisch die COT Daten interpretiert werden.",
            "points": [
                ("0. Analyse Engine wählen", "Classic Meridian arbeitet ruhiger, Flow Momentum reagiert schneller und Hybrid Intelligence verbindet Positionierung und Dynamik. Die gewählte Engine gilt für den gesamten Analyselauf."),
                ("1. COT Analyse", "Lädt die offiziellen CFTC Berichte, bewertet die Positionierung nach der gewählten Engine und erstellt drei reine Forex Setups."),
                ("2. Seasonality", "Prüft, wie sich jedes COT Setup in derselben Jahresphase historisch entwickelt hat."),
                ("3. Makros", "Bewertet Zinsstruktur und bevorstehende Hochrisiko Termine und erstellt daraus die finale Watchlist."),
                ("4. Champions", "Wird erst nach allen drei Analysephasen freigeschaltet und zeigt das jeweils beste finale Setup von Classic, Flow Momentum und Hybrid Intelligence."),
                ("5. Meridian Entry Engine", "Wird nach der finalen Makroprüfung freigeschaltet. Sie erzeugt ein geschütztes TradingView Profil aus den Top 3 der gewählten Engine oder aus den finalen Top 3 aller drei Engines."),
                ("Market Pulse", "Vergleicht aktuelle Kurse mit dem Vortag und dem COT Referenzkurs. Er überwacht die Setups, erzeugt aber kein neues Handelssignal."),
            ],
            "use": "Wähle zuerst die Engine passend zu deinem Tradingstil und arbeite danach die drei Schritte von links nach rechts ab. Hohe Übereinstimmung erhöht die Qualität, ersetzt aber weder Chart Setup noch Risikomanagement.",
        },
        "engines": {
            "title": "Welche Analyse Engine passt zu mir?",
            "intro": "Alle drei Engines verwenden dieselben offiziellen CFTC Daten und dieselbe Forex Paarbildung. Der Unterschied liegt darin, welche institutionellen Informationen die Richtung bestimmen und wie schnell die Bewertung auf neue Kapitalbewegungen reagiert.",
            "points": [
                ("Classic Meridian, konservativ", "Der Commercial Bias ist der Richtungsanker. Aktueller Flow bestätigt oder schwächt ihn. Empfohlen für Swing und Position Trader, die ruhigere Signale und weniger häufige Wechsel bevorzugen."),
                ("Flow Momentum, dynamisch", "Aktuelle Ein und Vier Wochen Veränderungen, Beschleunigung und Open Interest stehen im Vordergrund. Empfohlen für aktive Swing Trader, die institutionelle Rotation und mögliche Trendwechsel früher sehen möchten."),
                ("Hybrid Intelligence, ausgewogen", "Commercial Positionierung dient nur als 104 Wochen Kontext. Commercial Flow, Large Specs und Beschleunigung dürfen die Richtung bestätigen, neutralisieren oder drehen. Empfohlen als ausgewogene Standardanalyse zwischen Stabilität und früher Reaktion."),
                ("Wichtig", "Keine Engine ist grundsätzlich besser. Classic kann später reagieren, Flow kann häufiger wechseln und Hybrid kann bei Konflikten bewusst neutraler bleiben. Wähle die Logik, die zu deinem Zeithorizont und deiner Risikotoleranz passt."),
            ],
            "use": "Wähle die Engine vor dem Start der COT Analyse. Ein fertiger Lauf bleibt aus Gründen der Nachvollziehbarkeit an diese Engine gebunden. Für einen Wechsel bereitest du eine neue COT Analyse vor.",
        },
        "cot": {
            "title": "COT Analyse und Weekly Engine Check",
            "intro": "Die COT Analyse wertet die Positionierung großer Marktteilnehmer aus den offiziellen CFTC Wochenberichten aus.",
            "points": [
                ("Commercials", "Dienen als struktureller Gegenpol und liefern den grundlegenden Long oder Short Bias."),
                ("Large Speculators", "Zeigen, wie stark spekulatives Kapital die Richtung bestätigt oder ihr entgegensteht."),
                ("Open Interest", "Prüft, ob neue Marktteilnahme den Positionsfluss bestätigt oder ob nur Positionen abgebaut werden."),
            ],
            "use": "Achte auf den Report Stand und den Datencheck. Erst nach einem vollständigen Lauf sind Ranking und Top 3 belastbar.",
        },
        "top3": {
            "title": "Top 3 COT Setups",
            "intro": "Die Top 3 sind die drei bestbewerteten Forex Kombinationen des aktuellen COT Rankings.",
            "points": [
                ("Richtung", "LONG bedeutet Stärke der Basiswährung gegenüber der Kurswährung. SHORT bedeutet das Gegenteil."),
                ("Meridian Qualität", "Der Score fasst die zur gewählten Engine gehörenden Faktoren zusammen. Höher bedeutet mehr Übereinstimmung."),
                ("Begründung", "Die Detailansicht zeigt, welche Faktoren das Setup tragen und wo Konflikte bestehen."),
            ],
            "use": "Vergleiche nicht nur den Rang. Prüfe auch Seasonality, Makros und mögliche Konfliktfaktoren, bevor du ein Setup weiterverfolgst.",
        },
        "seasonality": {
            "title": "Seasonality",
            "intro": "Die Saisonalität prüft die historische Entwicklung des Marktes in der aktuellen Jahresphase, jeweils in Richtung des COT Signals.",
            "points": [
                ("Trefferquote", "Zeigt, in wie vielen Vergleichsjahren die Bewegung zum aktuellen Long oder Short Bias passte."),
                ("Durchschnitt", "Misst die mittlere richtungsbezogene Entwicklung im festgelegten Prüfzeitraum."),
                ("Zuverlässigkeit", "Berücksichtigt Datenmenge und Streuung. Eine hohe Trefferquote bei großer Streuung bleibt vorsichtig zu lesen."),
            ],
            "use": "Seasonality bestätigt oder belastet ein bestehendes COT Setup. Sie erzeugt keine eigenständige Richtung.",
        },
        "macro": {
            "title": "Makro Prüfung",
            "intro": "Die Makro Ebene ergänzt COT und Seasonality um den aktuellen relativen Zinsvorteil, seine jüngste Veränderung und bevorstehende Ereignisrisiken.",
            "points": [
                ("2Y Rendite", "Zeigt den aktuellen kurzfristigen Zinsvorteil und geldpolitische Erwartungen."),
                ("10Y Rendite", "Zeigt den längerfristigen relativen Renditevorteil zwischen Basis und Kurswährung."),
                ("Yield Curve", "Vergleicht die Form der Zinskurven und ergänzt den strukturellen Kapitalfluss."),
                ("Zinsimpuls", "Prüft über 5 und 20 Handelstage, ob sich der relative Renditevorteil zugunsten oder entgegen dem Analyzer Bias entwickelt. Er zählt 30 Prozent innerhalb der Makro Ebene."),
                ("High Impact Events", "Markiert mögliche Volatilitätsimpulse. Sie sind ein Timing Hinweis, kein neues Signal."),
            ],
            "use": "Makro Unterstützung stärkt die finale Einordnung. Gegenwind ist ein Warnsignal, hebt das ursprüngliche COT Ergebnis aber nicht rückwirkend auf. Die gesamte Makro Wirkung bleibt auf höchstens fünf Watchlist Punkte begrenzt.",
        },
        "market_pulse": {
            "title": "Market Pulse",
            "intro": "Der Market Pulse prüft, ob sich aktuelle Kurse in Richtung der vorhandenen COT Setups bewegen.",
            "points": [
                ("Markt heute", "Prozentuale Kursbewegung gegenüber dem vom Provider gelieferten Vortagesschluss."),
                ("Signal heute", "Dieselbe Bewegung aus Sicht des Signals. Bei SHORT wird das Vorzeichen umgekehrt."),
                ("Seit COT", "Vergleicht den aktuellen Kurs mit dem Referenzkurs am COT Stichtag."),
                ("Setup Pulse", "Skaliert die Entwicklung in Signalrichtung auf 0 bis 100. 50 ist ungefähr neutral."),
            ],
            "use": "Nutze den Pulse als Verlaufskontrolle. Ein Pullback ändert die Engine Richtung nicht. Beachte den Datenstand und den Countdown des Kurscaches.",
        },
        "pulse_dashboard": {
            "title": "Pulse Dashboard",
            "intro": "Das Dashboard fasst die aktuelle Entwicklung der Top Setups in wenigen Kennzahlen zusammen.",
            "points": [
                ("Top Setup heute", "Zählt, wie viele Top Setups heute in Signalrichtung laufen."),
                ("Seit COT", "Zählt, wie viele Setups seit dem COT Referenzkurs positiv in Signalrichtung liegen."),
                ("Stärkstes Setup", "Zeigt die beste aktuelle Entwicklung in Signalrichtung."),
                ("Beobachten", "Markiert das aktuell schwächste Setup, ohne daraus ein neues Gegensignal abzuleiten."),
            ],
            "use": "Die Übersicht hilft beim Priorisieren. Für die genaue Einordnung prüfst du anschließend die Karten und die Beobachtungsliste.",
        },
        "watchlist": {
            "title": "Market Pulse Beobachtungsliste",
            "intro": "Die Tabelle trennt die reine Marktbewegung von der Performance aus Sicht des Long oder Short Signals.",
            "points": [
                ("Markt", "Zeigt, was der Kurs tatsächlich gemacht hat."),
                ("Signal", "Zeigt, ob diese Bewegung für die bestehende Richtung positiv oder negativ war."),
                ("Einordnung", "Beschreibt Bestätigung, Neutralität oder kurzfristigen Pullback."),
            ],
            "use": "Lies Markt und Signal immer gemeinsam. Besonders bei SHORT Setups haben beide Werte entgegengesetzte Vorzeichen.",
        },
        "final_watchlist_use": {
            "title": "Finale Top 3 Watchlist im Trading nutzen",
            "intro": "Die finale Watchlist bündelt die stärksten Kandidaten nach COT Analyse, Seasonality und Makro Prüfung. Sie hilft bei der Marktauswahl, ersetzt aber niemals die konkrete Ausführung im Chart.",
            "points": [
                ("Fundierte Vorauswahl", "Mehrere fundamentale und statistische Daten werden zusammengeführt, damit du Märkte mit höherer Übereinstimmung gezielt priorisieren kannst."),
                ("COT bleibt der Richtungsanker", "COT bestimmt weiterhin Paar und Analyzer Bias. Seasonality und Makro dürfen die Qualität nur innerhalb klarer Grenzen verfeinern."),
                ("Dynamische Qualitätswertung", "Seasonality verändert den COT Basiswert um höchstens acht Punkte. Das Zins Makro inklusive 5 und 20 Tage Impuls wirkt stufenlos mit höchstens fünf Punkten. Termine erzeugen maximal vier Punkte Abschlag."),
                ("Kein Timing Tool", "Die Watchlist sagt nicht, wann du einsteigen sollst. Sie liefert weder einen fertigen Entry noch automatisch Stop Loss oder Take Profit."),
                ("Umsetzung im Chart", "Prüfe weiterhin Marktstruktur, Setup, Einstiegszone, Invalidierung und Chance Risiko Verhältnis direkt im Chart."),
                ("Risikomanagement", "High Impact Termine und Gegenwind helfen bei Positionsgröße und Timing. Auch eine hohe Qualität ist keine Gewinngarantie."),
            ],
            "use": "Nutze die Top 3 als fokussierte Arbeitsliste für deine Chartanalyse. So triffst du Entscheidungen auf Basis mehrerer belastbarer Faktoren, statt Märkte zufällig auszuwählen. Der finale Trade entsteht trotzdem erst durch dein bestätigtes Chart Setup und konsequentes Risikomanagement.",
        },
        "entry_engine": {
            "title": "Meridian Entry Engine richtig verwenden",
            "intro": "Die Entry Engine verbindet die vollständig geprüfte Makro Watchlist mit einer technischen Multi Timeframe Prüfung in TradingView. Sie übernimmt keine Analyseaufgabe des Analyzer Pro und erzeugt keinen eigenständigen LONG oder SHORT Bias.",
            "points": [
                ("Analyse vollständig abschließen", "Das TradingView Profil wird erst nach COT Daten, Seasonality und Makro freigeschaltet. Champions werden dafür nicht verwendet."),
                ("Indikator einmalig einrichten", "Öffne den geschützten TradingView Indikator zuerst über den Button. Ist die Meridian Entry Engine bereits im Chart vorhanden, füge sie nicht erneut hinzu, sondern öffne nur ihre Einstellungen."),
                ("Profil auswählen", "Option A überträgt die finalen Top 3 der aktuell gewählten Engine. Option B überträgt die finalen Top 3 aller drei Engines und führt doppelte Paare sicher zusammen."),
                ("Profil einfügen", "Kopiere den vollständigen Profiltext und füge ihn im ersten Einstellungsfeld der TradingView Entry Engine ein. Paar, Bias, Engine und offizieller CFTC Datenstand werden danach automatisch erkannt."),
                ("Charts bequem wechseln", "Nach dem Einfügen kannst du alle im Profil freigegebenen Forex Charts durchsehen. Nicht enthaltene Paare bleiben ohne technische Bewertung."),
                ("CFTC Datenstand", "Das Profil besitzt kein starres Ablaufdatum. Es zeigt den verwendeten offiziellen CFTC Bericht und wird nach einer neuen vollständigen Analyzer Auswertung ersetzt."),
                ("Technische Bestätigung lesen", "H4 bewertet Trend und Handelsspielraum, H1 Struktur und Setup, M15 Timing, Momentum und Marktphase. Der Readiness Score fasst die technische Qualität zusammen."),
                ("Kein Kauf jetzt Werkzeug", "Grün bedeutet technische Unterstützung des Analyzer Bias. Gelb bedeutet beobachten oder warten. Rot bedeutet, dass aktuell keine technische Bestätigung für diese Richtung vorliegt."),
            ],
            "use": "Arbeite immer in dieser Reihenfolge: Fundamentalanalyse vollständig abschließen, Indikator einmalig in TradingView einrichten, Profil kopieren, in die Indikator Einstellungen einfügen, freigegebene Charts auf M15 prüfen und erst danach einen eigenen Risiko und Ausführungsplan erstellen. Die Engine ersetzt weder Stop Loss, Positionsgröße noch Marktkenntnis.",
        },
        "single_assets": {
            "title": "Zusatzmärkte",
            "intro": "Gold, Silber, NASDAQ 100 und S&P 500 werden als eigenständige COT Märkte bewertet, nicht als Forex Cross Pair.",
            "points": [
                ("Eigenes Ranking", "Jeder Zusatzmarkt erhält seinen eigenen COT Bias und Qualitätsscore."),
                ("Sichtbarkeit", "Die Märkte bleiben als interne Basiswerte sichtbar, auch wenn sie nicht zu den Forex Top 3 gehören."),
            ],
            "use": "Nutze sie als ergänzende Marktinformation. Vergleiche ihre Scores nicht unkritisch eins zu eins mit einem Währungspaar.",
        },
        "checkup": {
            "title": "Engine Checkup",
            "intro": "Der Checkup erzeugt Audit Dateien und prüft, ob Rohdaten, Wochenfenster und Engine Berechnungen nachvollziehbar zusammenpassen.",
            "points": [
                ("OK", "Die kontrollierten Rohwerte stimmen mit den verwendeten Engine Werten überein."),
                ("PRÜFEN", "Mindestens ein Datenpunkt oder Vergleich benötigt Aufmerksamkeit."),
                ("Audit Dateien", "JSON, CSV und TXT dienen der technischen Nachvollziehbarkeit und verändern keine Analyse."),
            ],
            "use": "Führe den Checkup nach einer abgeschlossenen Analyse aus, besonders nach Daten oder Programmänderungen.",
        },
    }

    def help_button(self, parent, topic, bg=None, compact=True):
        # Das Hilfefenster wird immer an das Fenster gebunden, aus dem es
        # geöffnet wurde. Das ist besonders beim separaten Market Pulse wichtig:
        # Der Market Pulse bleibt sichtbar, während der Hilfedialog darüber liegt.
        btn = tk.Button(
            parent, text="?", command=lambda: self.show_help_topic(topic, parent.winfo_toplevel()),
            font=("Segoe UI", 9 if compact else 10, "bold"),
            fg=COLORS["blue"], bg=bg or parent["bg"],
            activeforeground=COLORS["text"], activebackground=COLORS["card2"],
            relief="flat", bd=0, cursor="hand2", padx=6, pady=1,
        )
        return btn

    def section_title(self, parent, text, topic, size=16, color=None, bg=None, padx=16, pady=(12, 4)):
        row = tk.Frame(parent, bg=bg or parent["bg"])
        row.pack(fill="x", padx=padx, pady=pady)
        self.label(row, text, size, color or COLORS["text"], "bold", bg or parent["bg"]).pack(side="left")
        self.help_button(row, topic, bg or parent["bg"]).pack(side="left", padx=(7, 0))
        return row

    def show_help_topic(self, topic, owner=None):
        data = self.HELP_TOPICS.get(topic, self.HELP_TOPICS["guide"])
        owner = owner if owner is not None and owner.winfo_exists() else self
        win = tk.Toplevel(owner)
        win.title(f"How to use, {data['title']}")
        win.configure(bg=COLORS["bg"])
        win.transient(owner)
        win.grab_set()

        # Nur der Hilfedialog wird geschlossen. Danach erhält exakt das Fenster,
        # aus dem die Hilfe geöffnet wurde, Fokus und Vordergrund zurück.
        def close_help():
            try:
                win.grab_release()
            except tk.TclError:
                pass
            win.destroy()
            try:
                if owner.winfo_exists():
                    owner.deiconify()
                    owner.lift()
                    owner.focus_force()
            except tk.TclError:
                pass

        # Das Hilfefenster erhält eine feste Kopf- und Fußzeile. Nur der
        # eigentliche Erklärungstext scrollt, falls der verfügbare Bildschirm
        # kleiner als der benötigte Inhalt ist. Dadurch bleibt VERSTANDEN immer
        # sichtbar und kein Text wird beim ersten Öffnen abgeschnitten.
        shell = self.card(win, COLORS["card"])
        shell.pack(fill="both", expand=True, padx=14, pady=14)

        head = tk.Frame(shell, bg=COLORS["header"])
        head.pack(fill="x")
        tk.Label(
            head, text="HOW TO USE", font=("Segoe UI", 9, "bold"),
            fg=COLORS["blue"], bg=COLORS["header"],
        ).pack(anchor="w", padx=18, pady=(14, 2))
        tk.Label(
            head, text=data["title"], font=("Segoe UI", 20, "bold"),
            fg=COLORS["text"], bg=COLORS["header"], justify="left",
            wraplength=630,
        ).pack(anchor="w", fill="x", padx=18, pady=(0, 12))

        footer = tk.Frame(shell, bg=COLORS["card"])
        footer.pack(side="bottom", fill="x", padx=18, pady=(8, 14))
        self.button(
            footer, "VERSTANDEN", close_help, COLORS["blue"], COLORS["dark"]
        ).pack(side="right", ipadx=18, ipady=5)

        content_host = tk.Frame(shell, bg=COLORS["card"])
        content_host.pack(fill="both", expand=True, padx=(18, 10), pady=(14, 0))
        content_host.grid_rowconfigure(0, weight=1)
        content_host.grid_columnconfigure(0, weight=1)

        canvas = tk.Canvas(
            content_host, bg=COLORS["card"], highlightthickness=0,
            bd=0, relief="flat",
        )
        scrollbar = tk.Scrollbar(
            content_host, orient="vertical", command=canvas.yview,
            relief="flat", bd=0,
        )
        canvas.configure(yscrollcommand=scrollbar.set)
        canvas.grid(row=0, column=0, sticky="nsew")

        body = tk.Frame(canvas, bg=COLORS["card"])
        body_window = canvas.create_window((0, 0), window=body, anchor="nw")
        responsive_wrap_widgets = []

        def sync_scrollregion(_event=None):
            canvas.configure(scrollregion=canvas.bbox("all"))

        def sync_body_width(event):
            available = max(320, event.width)
            canvas.itemconfigure(body_window, width=available)
            # Die Textbreite folgt der tatsächlich verfügbaren Canvasbreite.
            # Dadurch ragt kein Label rechts unter die Scrollleiste oder aus
            # einem schmaleren Fenster heraus.
            for widget, inset in responsive_wrap_widgets:
                try:
                    widget.configure(wraplength=max(240, available - inset))
                except tk.TclError:
                    pass

        body.bind("<Configure>", sync_scrollregion)
        canvas.bind("<Configure>", sync_body_width)

        intro_label = self.label(
            body, data["intro"], 11, COLORS["text"], "normal",
            COLORS["card"], wrap=700,
        )
        intro_label.pack(anchor="w", fill="x", pady=(0, 12))
        responsive_wrap_widgets.append((intro_label, 8))

        for title, text in data.get("points", []):
            box = tk.Frame(
                body, bg=COLORS["card2"], highlightthickness=1,
                highlightbackground=COLORS["line"],
            )
            box.pack(fill="x", pady=4)
            point_title = tk.Label(
                box, text=title, font=("Segoe UI", 10, "bold"),
                fg=COLORS["blue"], bg=COLORS["card2"], justify="left",
                wraplength=680,
            )
            point_title.pack(anchor="w", fill="x", padx=11, pady=(8, 1))
            point_text = self.label(
                box, text, 9, COLORS["muted"], "normal",
                COLORS["card2"], wrap=680,
            )
            point_text.pack(anchor="w", fill="x", padx=11, pady=(0, 8))
            responsive_wrap_widgets.append((point_title, 30))
            responsive_wrap_widgets.append((point_text, 30))

        use_box = tk.Frame(
            body, bg=COLORS["header"], highlightthickness=1,
            highlightbackground=COLORS["blue"],
        )
        use_box.pack(fill="x", pady=(12, 8))
        tk.Label(
            use_box, text="SO NUTZT DU ES", font=("Segoe UI", 9, "bold"),
            fg=COLORS["blue"], bg=COLORS["header"],
        ).pack(anchor="w", padx=11, pady=(8, 1))
        use_text = self.label(
            use_box, data["use"], 10, COLORS["text"], "normal",
            COLORS["header"], wrap=680,
        )
        use_text.pack(anchor="w", fill="x", padx=11, pady=(0, 9))
        responsive_wrap_widgets.append((use_text, 30))

        # Erst nach dem Aufbau lässt sich die tatsächlich benötigte Größe
        # zuverlässig bestimmen. Die Startgröße passt sich dem Inhalt an,
        # bleibt aber innerhalb des sichtbaren Bildschirms.
        win.update_idletasks()
        screen_w = max(800, win.winfo_screenwidth())
        screen_h = max(600, win.winfo_screenheight())
        desired_w = min(900, max(800, shell.winfo_reqwidth() + 40))
        desired_h = min(int(screen_h * 0.86), max(540, shell.winfo_reqheight() + 28))
        desired_w = min(desired_w, int(screen_w * 0.92))
        desired_h = min(desired_h, int(screen_h * 0.92))
        win.minsize(min(720, desired_w), min(500, desired_h))

        parent_x = owner.winfo_rootx()
        parent_y = owner.winfo_rooty()
        parent_w = owner.winfo_width()
        parent_h = owner.winfo_height()
        x = parent_x + max(0, (parent_w - desired_w) // 2)
        y = parent_y + max(0, (parent_h - desired_h) // 2)
        x = max(0, min(x, screen_w - desired_w))
        y = max(0, min(y, screen_h - desired_h))
        win.geometry(f"{desired_w}x{desired_h}+{x}+{y}")

        # Die Scrollleiste wird nur eingeblendet, wenn der Inhalt wirklich
        # höher als der sichtbare Bereich ist.
        def update_scrollbar_visibility(_event=None):
            win.update_idletasks()
            needs_scroll = body.winfo_reqheight() > canvas.winfo_height() + 2
            if needs_scroll:
                scrollbar.grid(row=0, column=1, sticky="ns", padx=(8, 0))
            else:
                scrollbar.grid_remove()
                canvas.yview_moveto(0)

        def scroll_help(event):
            if body.winfo_reqheight() <= canvas.winfo_height() + 2:
                return "break"
            delta = -1 if event.delta > 0 else 1
            canvas.yview_scroll(delta * 3, "units")
            return "break"

        win.after_idle(update_scrollbar_visibility)
        win.bind("<Configure>", update_scrollbar_visibility, add="+")
        canvas.bind("<MouseWheel>", scroll_help)
        body.bind("<MouseWheel>", scroll_help)
        win.protocol("WM_DELETE_WINDOW", close_help)
        win.bind("<Escape>", lambda _e: close_help())
        win.bind("<Return>", lambda _e: close_help())
        try:
            owner.deiconify()
            owner.lift()
            win.lift(owner)
            win.focus_force()
        except tk.TclError:
            win.focus_set()

    def card(self, parent, bg=None):
        return tk.Frame(parent, bg=bg or COLORS["card"], highlightthickness=1, highlightbackground=COLORS["line"])

    def label(self, parent, text="", size=11, color=None, weight="normal", bg=None, anchor="w", wrap=None):
        return tk.Label(
            parent,
            text=text,
            font=("Segoe UI", size, weight),
            fg=color or COLORS["text"],
            bg=bg or parent["bg"],
            anchor=anchor,
            justify="left",
            wraplength=wrap or 0,
        )

    def button(self, parent, text, cmd, bg=None, fg=None):
        return tk.Button(
            parent,
            text=text,
            command=cmd,
            font=("Segoe UI", 11, "bold"),
            fg=fg or COLORS["text"],
            bg=bg or COLORS["button"],
            activebackground=bg or COLORS["button"],
            activeforeground=fg or COLORS["text"],
            relief="flat",
            bd=0,
            cursor="hand2",
        )

    def on_mousewheel(self, event):
        try:
            self.detail_canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        except Exception:
            pass

    def on_strength_mousewheel(self, event):
        try:
            self.strength_canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        except Exception:
            pass

    def set_app_icon(self):
        """Setzt Titelleisten- und Taskleisten-Icon, mit Fallback-Kette.

        Windows nutzt bevorzugt eine .ico Datei (mehrere Aufloesungen fuer
        Titelleiste, Taskleiste, Alt+Tab und Desktop-Verknuepfung). Fehlt sie
        oder schlaegt sie fehl (z.B. auf anderen Betriebssystemen), wird ein
        PNG ueber iconphoto versucht. Fehlt auch das, laeuft die App normal
        weiter, nur ohne eigenes Icon - kein Grund, den Start abzubrechen.
        """
        ico_path = APP_DIR / "meridian_icon.ico"
        png_path = APP_DIR / "meridian_icon_64.png"
        try:
            if ico_path.exists():
                self.iconbitmap(default=str(ico_path))
                return
        except Exception:
            pass
        try:
            if png_path.exists():
                self._app_icon_img = tk.PhotoImage(file=str(png_path))
                self.iconphoto(True, self._app_icon_img)
        except Exception:
            pass

    def build_ui(self):
        root = tk.Frame(self, bg=COLORS["bg"])
        root.pack(fill="both", expand=True, padx=10, pady=7)

        # Kompakter Prozesskopf: links Marke und Titel, rechts die drei Schritte
        # in derselben Reihenfolge wie der Arbeitsablauf.
        header = self.card(root, COLORS["header"])
        header.pack(fill="x", pady=(0, 5))
        header.grid_columnconfigure(0, weight=1, minsize=480)
        header.grid_columnconfigure(1, weight=0)

        brand_line = tk.Frame(header, bg=COLORS["header"])
        brand_line.grid(row=0, column=0, rowspan=2, sticky="w", padx=16, pady=8)
        self._brand_logo_img = None
        logo_path = APP_DIR / "meridian_logo_mark.png"
        if logo_path.exists():
            try:
                self._brand_logo_img = tk.PhotoImage(file=str(logo_path))
                tk.Label(brand_line, image=self._brand_logo_img, bg=COLORS["header"], bd=0).pack(side="left", padx=(0, 9))
            except Exception:
                self._brand_logo_img = None
        text_box = tk.Frame(brand_line, bg=COLORS["header"])
        text_box.pack(side="left")
        self.label(text_box, "MERIDIAN", 10, COLORS["blue"], "bold", COLORS["header"]).pack(anchor="w")
        title_line = tk.Frame(text_box, bg=COLORS["header"])
        title_line.pack(anchor="w", pady=(1, 0))
        tk.Label(title_line, text="Meridian ANALYZER", font=("Segoe UI", 22, "bold"), fg=COLORS["text"], bg=COLORS["header"]).pack(side="left")
        tk.Label(title_line, text=f"  PRO V{APP_VERSION}", font=("Segoe UI", 12, "bold"), fg=COLORS["yellow"], bg=COLORS["header"]).pack(side="left", padx=(6, 0), pady=(6, 0))
        # Nur das Symbol, kein Text: minimaler Platzbedarf, deshalb hier direkt
        # hinter der Versionsnummer statt in einer der Toolbar-Zeilen, wo jedes
        # zusaetzliche Element sofort zu Breitenproblemen fuehrt. Rueckmeldung
        # laeuft weiterhin ueber die bestehende Status-Zeile (self.status).
        self.update_btn = tk.Label(
            title_line, text="↻", font=("Segoe UI", 14, "bold"),
            fg=COLORS["blue"], bg=COLORS["header"], cursor="hand2",
        )
        self.update_btn.pack(side="left", padx=(8, 0), pady=(4, 0))
        self.update_btn.bind("<Button-1>", lambda _e: self.check_for_updates())

        actions = tk.Frame(header, bg=COLORS["header"])
        actions.grid(row=0, column=1, sticky="e", padx=14, pady=(7, 1))
        actions.grid_columnconfigure(0, minsize=205)
        actions.grid_columnconfigure(1, minsize=245)
        actions.grid_columnconfigure(2, minsize=205)
        actions.grid_columnconfigure(3, minsize=215)

        cot_box = tk.Frame(actions, bg=COLORS["header"])
        cot_box.grid(row=0, column=0, sticky="ew", padx=(0, 7))
        self.start_btn = self.button(cot_box, "1. COT ANALYSE STARTEN", self.start_or_prepare, COLORS["green"], "#04120A")
        self.start_btn.config(wraplength=185, justify="center")
        self.start_btn.pack(fill="x", ipady=6)
        selector_line = tk.Frame(cot_box, bg=COLORS["header"])
        selector_line.pack(fill="x", pady=(4, 0))
        self.label(selector_line, "ENGINE", 8, COLORS["muted"], "bold", COLORS["header"]).pack(side="left", padx=(0, 2))
        self.help_button(selector_line, "engines", COLORS["header"]).pack(side="left", padx=(0, 5))
        self.engine_var = tk.StringVar(value=ENGINE_LABELS[self.app_settings["analysis_engine"]])
        self.engine_selector = ttk.Combobox(selector_line, textvariable=self.engine_var, values=list(ENGINE_LABELS.values()), state="readonly", font=("Segoe UI", 9, "bold"), width=22)
        self.engine_selector.pack(side="left", fill="x", expand=True, ipady=2)
        self.engine_selector.bind("<<ComboboxSelected>>", self.on_engine_changed)

        self.season_btn_header = self.button(actions, "2. SEASONALITÄT PRÜFEN", self.footer_primary_action, COLORS["button"], COLORS["muted"])
        self.season_btn_header.config(wraplength=225, justify="center")
        self.season_btn_header.grid(row=0, column=1, sticky="ew", ipady=6)
        self.season_btn_header.config(state="disabled", disabledforeground=COLORS["muted"])

        self.macro_btn_header = self.button(actions, "3. MAKROS PRÜFEN", self.start_macro, COLORS["button"], COLORS["muted"])
        self.macro_btn_header.config(wraplength=185, justify="center")
        self.macro_btn_header.grid(row=0, column=2, sticky="ew", padx=(7, 0), ipady=6)
        self.macro_btn_header.config(state="disabled", disabledforeground=COLORS["muted"])

        self.champions_btn_header = self.button(actions, "🏆  4. CHAMPIONS FREISCHALTEN", self.open_or_build_champions, COLORS["button"], COLORS["muted"])
        self.champions_btn_header.config(wraplength=195, justify="center")
        self.champions_btn_header.grid(row=0, column=3, sticky="ew", padx=(7, 0), ipady=6)
        self.champions_btn_header.config(state="disabled", disabledforeground=COLORS["muted"])

        info_line = tk.Frame(header, bg=COLORS["header"])
        info_line.grid(row=1, column=1, sticky="ew", padx=14, pady=(0, 6))
        info_line.grid_columnconfigure(0, weight=1)
        self.engine_hint = self.label(info_line, "", 8, COLORS["muted"], "normal", COLORS["header"], wrap=380)
        self.engine_hint.grid(row=0, column=0, sticky="w")
        self.status = self.label(info_line, "Bereit", 9, COLORS["muted"], "bold", COLORS["header"], "e")
        self.status.grid(row=0, column=1, sticky="e", padx=(12, 0))
        self.audit_lbl = self.label(info_line, "Checkup: nicht erstellt", 8, COLORS["muted"], "bold", COLORS["header"], "e")
        self.audit_lbl.grid(row=0, column=2, sticky="e", padx=(12, 0))
        self.button(info_line, "HOW TO USE  ?", lambda: self.show_help_topic("guide"), COLORS["card2"], COLORS["blue"]).grid(row=0, column=3, sticky="e", padx=(12, 0), ipadx=8, ipady=2)

        check = self.card(root, COLORS["card"])
        self.check_frame = check
        check.pack(fill="x", pady=(0, 5))
        check.grid_columnconfigure(0, weight=1)
        check.grid_columnconfigure(1, weight=0)
        check_title = tk.Frame(check, bg=COLORS["card"])
        check_title.grid(row=0, column=0, sticky="w", padx=14, pady=(8, 2))
        self.label(check_title, "DATEN UND WEEKLY ENGINE CHECK", 13, COLORS["text"], "bold", COLORS["card"]).pack(side="left")
        self.help_button(check_title, "cot", COLORS["card"]).pack(side="left", padx=(6, 0))

        self.data_status = self.label(check, "", 9, COLORS["yellow"], "bold", COLORS["card"], "e")
        self.data_status.grid(row=0, column=1, sticky="e", padx=14, pady=(8, 2))

        safety = tk.Frame(check, bg=COLORS["card"])
        safety.grid(row=1, column=0, columnspan=2, sticky="ew", padx=14, pady=(5, 3))
        # Nur die linke Spalte wächst. Dadurch bleibt die komplette CFTC
        # Statusgruppe kompakt und sauber am rechten Rand ausgerichtet.
        safety.grid_columnconfigure(0, weight=1)
        self.cftc_loaded_lbl = self.label(safety, "Noch nicht geprüft", 10, COLORS["yellow"], "bold", COLORS["card"], "e")
        self.cftc_loaded_lbl.grid(row=0, column=1, sticky="e", padx=(12, 14))
        self.report_lbl = self.label(safety, "Report: noch nicht geladen", 9, COLORS["muted"], "normal", COLORS["card"], "e")
        self.report_lbl.grid(row=0, column=2, sticky="e", padx=(0, 14))
        self.cache_lbl = self.label(safety, "Cache: noch nicht geprüft", 9, COLORS["muted"], "normal", COLORS["card"], "e")
        self.cache_lbl.grid(row=0, column=3, sticky="e", padx=(0, 14))
        self.market_count_lbl = self.label(safety, "Märkte: 0", 9, COLORS["muted"], "normal", COLORS["card"], "e")
        self.market_count_lbl.grid(row=0, column=4, sticky="e")

        self.source_lbl = self.label(check, "Quelle: CFTC historische Reports", 9, COLORS["muted"], "normal", COLORS["card"])
        self.source_lbl.grid(row=2, column=0, sticky="w", padx=14, pady=(1, 0))
        self.cftc_note_lbl = self.label(check, "Die CFTC veröffentlicht Reports zeitversetzt. Verwendet wird automatisch der neueste offiziell verfügbare Bericht.", 8, COLORS["muted"], "normal", COLORS["card"], wrap=760)
        self.cftc_note_lbl.grid(row=3, column=0, sticky="w", padx=14, pady=(2, 4))

        self.progress_label = self.label(check, "Bereit für aktuelle COT Wochenanalyse", 9, COLORS["muted"], "bold", COLORS["card"])
        self.progress_label.grid(row=4, column=0, columnspan=2, sticky="w", padx=14, pady=(7, 4))
        self.progress_canvas = tk.Canvas(check, height=20, bg=COLORS["dark"], highlightthickness=1, highlightbackground=COLORS["line"])
        self.progress_canvas.grid(row=5, column=0, columnspan=2, sticky="ew", padx=14, pady=(0, 10))

        top = tk.Frame(root, bg=COLORS["bg"])
        self.top_watch_frame = top
        top.pack(fill="x", pady=(0, 4))
        for i in range(3):
            top.grid_columnconfigure(i, weight=1)
        self.watch_cards = []
        for i in range(3):
            c = self.card(top, COLORS["card2"])
            c.grid(row=0, column=i, sticky="nsew", padx=4)
            self.watch_cards.append(c)

        self.asset_strip = self.card(root, COLORS["card"])
        self.asset_strip.pack(fill="x", pady=(0, 5))
        self.asset_strip.grid_columnconfigure(0, weight=0)
        self.asset_strip.grid_columnconfigure(1, weight=1)
        self.asset_header = tk.Frame(self.asset_strip, bg=COLORS["card"])
        self.asset_header.grid(row=0, column=0, sticky="nsw", padx=(14, 9), pady=7)
        self.label(self.asset_header, "ZUSATZMÄRKTE", 9, COLORS["yellow"], "bold", COLORS["card"]).pack(anchor="w")
        self.label(self.asset_header, "Metalle und Indizes", 8, COLORS["muted"], "bold", COLORS["card"]).pack(anchor="w", pady=(1, 0))
        self.asset_grid = tk.Frame(self.asset_strip, bg=COLORS["card"])
        self.asset_grid.grid(row=0, column=1, sticky="nsew", padx=(0, 11), pady=6)
        for i in range(4):
            self.asset_grid.grid_columnconfigure(i, weight=1)
        self.asset_cards = []
        for i in range(4):
            c = tk.Frame(self.asset_grid, bg=COLORS["card2"], highlightthickness=1, highlightbackground=COLORS["line"])
            c.grid(row=0, column=i, sticky="nsew", padx=3)
            self.asset_cards.append(c)

        mid = tk.Frame(root, bg=COLORS["bg"])
        mid.pack(fill="both", expand=True)
        mid.grid_columnconfigure(0, weight=34, minsize=430)
        mid.grid_columnconfigure(1, weight=66, minsize=760)
        mid.grid_rowconfigure(0, weight=1)

        self.strength_container = self.card(mid, COLORS["card"])
        self.strength_container.grid(row=0, column=0, sticky="nsew", padx=(0, 4))
        self.strength_container.grid_rowconfigure(0, weight=1)
        self.strength_container.grid_columnconfigure(0, weight=1)
        self.strength_canvas = tk.Canvas(self.strength_container, bg=COLORS["card"], highlightthickness=0)
        self.strength_scroll = tk.Scrollbar(self.strength_container, orient="vertical", command=self.strength_canvas.yview)
        self.strength_canvas.configure(yscrollcommand=self.strength_scroll.set)
        self.strength_canvas.grid(row=0, column=0, sticky="nsew")
        self.strength_scroll.grid(row=0, column=1, sticky="ns")
        self.strength_card = tk.Frame(self.strength_canvas, bg=COLORS["card"])
        self.strength_window = self.strength_canvas.create_window((0, 0), window=self.strength_card, anchor="nw")
        self.strength_card.bind("<Configure>", lambda e: self.strength_canvas.configure(scrollregion=self.strength_canvas.bbox("all")))
        self.strength_canvas.bind("<Configure>", lambda e: self.strength_canvas.itemconfig(self.strength_window, width=e.width))

        self.detail_container = self.card(mid, COLORS["card"])
        self.detail_container.grid(row=0, column=1, sticky="nsew", padx=(4, 0))
        self.detail_container.grid_rowconfigure(0, weight=1)
        self.detail_container.grid_columnconfigure(0, weight=1)
        self.detail_canvas = tk.Canvas(self.detail_container, bg=COLORS["card"], highlightthickness=0)
        self.detail_scroll = tk.Scrollbar(self.detail_container, orient="vertical", command=self.detail_canvas.yview)
        self.detail_canvas.configure(yscrollcommand=self.detail_scroll.set)
        self.detail_canvas.grid(row=0, column=0, sticky="nsew")
        self.detail_scroll.grid(row=0, column=1, sticky="ns")
        self.detail_card = tk.Frame(self.detail_canvas, bg=COLORS["card"])
        self.detail_window = self.detail_canvas.create_window((0, 0), window=self.detail_card, anchor="nw")
        self.detail_card.bind("<Configure>", lambda e: self.detail_canvas.configure(scrollregion=self.detail_canvas.bbox("all")))
        self.detail_canvas.bind("<Configure>", lambda e: self.detail_canvas.itemconfig(self.detail_window, width=e.width))
        self.detail_canvas.bind("<Enter>", lambda e: self.detail_canvas.bind_all("<MouseWheel>", self.on_mousewheel))
        self.detail_canvas.bind("<Leave>", lambda e: self.detail_canvas.unbind_all("<MouseWheel>"))
        self.strength_canvas.bind("<Enter>", lambda e: self.strength_canvas.bind_all("<MouseWheel>", self.on_strength_mousewheel))
        self.strength_canvas.bind("<Leave>", lambda e: self.strength_canvas.unbind_all("<MouseWheel>"))

        bottom = tk.Frame(root, bg=COLORS["bg"])
        bottom.pack(side="bottom", fill="x", pady=(5, 0), before=mid)
        # Wieder eine Zeile (Update-Button lebt jetzt nur noch als Icon im
        # Header, nicht mehr hier) - dafuer etwas kompaktere Abstaende und
        # kleinere Schrift, damit es trotz sechs Werkzeug-Buttons plus
        # Navigation in einer Reihe passt (gemessen ca. 1700px statt der
        # vorherigen ca. 2100px mit Update-Button).
        self.season_btn = self.season_btn_header
        self.macro_btn = self.macro_btn_header
        self.button(bottom, "COT Ampel ansehen", self.show_cot_raw_table, COLORS["button"], COLORS["text"]).pack(side="left", ipadx=8, ipady=5)
        self.button(bottom, "Meridian Strength Matrix", self.show_strength_matrix, COLORS["button"], COLORS["text"]).pack(side="left", padx=5, ipadx=8, ipady=5)
        self.button(bottom, "Meridian Market Pulse", self.show_market_pulse, COLORS["button"], COLORS["text"]).pack(side="left", padx=5, ipadx=8, ipady=5)
        entry_engine_slot = tk.Frame(bottom, bg=COLORS["bg"])
        entry_engine_slot.pack(side="left", padx=5)
        self.entry_engine_btn = self.button(entry_engine_slot, "Meridian Entry Engine", self.show_entry_engine_dashboard, COLORS["button"], COLORS["muted"])
        self.entry_engine_btn.pack(ipadx=8, ipady=5)
        self.entry_engine_btn.config(state="disabled", disabledforeground=COLORS["muted"])
        self.entry_engine_lock_hint = self.label(
            entry_engine_slot,
            "Freigabe nach COT,\nSaisonalität und Makro",
            7,
            COLORS["yellow"],
            "bold",
            COLORS["bg"],
            "center",
        )
        self.entry_engine_lock_hint.pack(pady=(2, 0))
        self.button(bottom, "Engine Checkup", self.show_diagnose, COLORS["button"], COLORS["text"]).pack(side="left", padx=5, ipadx=8, ipady=5)
        self.weekly_archive_btn = self.button(bottom, "Wochenarchiv", self.show_weekly_archive, COLORS["button"], COLORS["text"])
        self.weekly_archive_btn.pack(side="left", padx=5, ipadx=8, ipady=5)

        nav = tk.Frame(bottom, bg=COLORS["bg"])
        nav.pack(side="right")
        self.nav_back_btn = self.button(nav, "←  ZURÜCK", self.show_previous_main_view, COLORS["button"], COLORS["text"])
        self.nav_back_btn.pack(side="left", padx=(0, 5), ipadx=8, ipady=5)
        self.nav_view_lbl = self.label(nav, "COT Analyse · 1 von 3", 9, COLORS["muted"], "bold", COLORS["bg"], "center")
        self.nav_view_lbl.pack(side="left", padx=6)
        self.nav_forward_btn = self.button(nav, "WEITER  →", self.show_next_main_view, COLORS["button"], COLORS["text"])
        self.nav_forward_btn.pack(side="left", padx=(5, 0), ipadx=8, ipady=5)

        initial_info = ENGINE_PROFILE_INFO[self.app_settings["analysis_engine"]]
        self.engine_hint.config(text=initial_info["subtitle"], fg=COLORS.get(initial_info.get("accent", "blue"), COLORS["blue"]))

    def set_entry_engine_button(self, enabled):
        """Schaltet das TradingView Modul erst nach der finalen Makroprüfung frei."""
        btn = getattr(self, "entry_engine_btn", None)
        if btn is None:
            return
        state = "normal" if enabled else "disabled"
        fg = COLORS["text"] if enabled else COLORS["muted"]
        btn.config(
            state=state,
            bg=COLORS["button"],
            activebackground=COLORS["button"],
            fg=fg,
            activeforeground=fg,
            disabledforeground=COLORS["muted"],
        )
        hint = getattr(self, "entry_engine_lock_hint", None)
        if hint is not None:
            hint.config(
                text="Auswertung vollständig\nabgeschlossen" if enabled else "Freigabe nach COT,\nSaisonalität und Makro",
                fg=COLORS["green"] if enabled else COLORS["yellow"],
            )

    def reset_entry_engine_profiles(self):
        self.entry_engine_profile_generation += 1
        self.entry_engine_engine_rows = {}
        self.entry_engine_profiles_building = False
        self.entry_engine_profiles_ready = False
        self.entry_engine_profile_errors = []
        self.entry_engine_profile_queue = None
        self._entry_engine_profile_refresh = None

    def selected_entry_engine_profile(self):
        if not self.macro_results or self.result_engine_key not in ENTRY_PROFILE_ENGINE_CODES:
            return None
        return build_entry_profile_token(
            ENTRY_PROFILE_ENGINE_CODES[self.result_engine_key],
            list(self.macro_results)[:3],
            report_date=self.engine.report_date,
        )

    def combined_entry_engine_profile(self):
        if not self.entry_engine_profiles_ready:
            return None, []

        chosen = {}
        conflicts = set()
        for engine_key in (ENGINE_CLASSIC, ENGINE_FLOW, ENGINE_HYBRID):
            for row in list(self.entry_engine_engine_rows.get(engine_key, []))[:3]:
                pair_code = normalize_entry_profile_pair(row.get("pair"))
                direction = str(row.get("direction", "")).upper()
                if not pair_code or direction not in ("LONG", "SHORT"):
                    continue
                if pair_code in chosen and str(chosen[pair_code].get("direction", "")).upper() != direction:
                    conflicts.add(pair_code)
                    continue
                if pair_code not in chosen:
                    combined_row = dict(row)
                    combined_row["source_engines"] = [ENGINE_LABELS[engine_key]]
                    chosen[pair_code] = combined_row
                else:
                    chosen[pair_code].setdefault("source_engines", []).append(ENGINE_LABELS[engine_key])

        for pair_code in conflicts:
            chosen.pop(pair_code, None)

        rows = list(chosen.values())
        return build_entry_profile_token(
            "ALL",
            rows,
            report_date=self.engine.report_date,
        ), sorted(conflicts)

    def start_entry_engine_profile_build(self):
        """Berechnet die finalen Makro Top 3 aller Engines unabhängig von Champions."""
        if self.entry_engine_profiles_building or self.entry_engine_profiles_ready:
            return
        if not self.macro_results or self.result_engine_key is None:
            return

        self.entry_engine_profiles_building = True
        self.entry_engine_profile_errors = []
        profile_queue = queue.Queue()
        self.entry_engine_profile_queue = profile_queue
        profile_generation = self.entry_engine_profile_generation
        selected_key = self.result_engine_key
        selected_rows = copy.deepcopy(list(self.macro_results)[:3])
        self.entry_engine_engine_rows = {selected_key: selected_rows}

        def worker():
            rows_by_engine = {selected_key: selected_rows}
            errors = []
            try:
                for engine_key in (ENGINE_CLASSIC, ENGINE_FLOW, ENGINE_HYBRID):
                    if engine_key == selected_key:
                        continue
                    clone = copy.copy(self.engine)
                    clone.progress = lambda pct, text: None
                    clone.set_analysis_engine(engine_key)
                    strengths = clone.compute_current_strengths()
                    top3, _ = clone.compute_pairs(strengths)

                    season_engine = SeasonalityEngine(progress=lambda pct, text: None)
                    season_rows = season_engine.analyze_top3(top3, self.engine.report_date)
                    errors.extend(f"{ENGINE_LABELS[engine_key]} Seasonality: {error}" for error in season_engine.errors)

                    macro_engine = MacroEngine(progress=lambda pct, text: None)
                    macro_rows = macro_engine.analyze_watchlist(season_rows[:3])
                    errors.extend(f"{ENGINE_LABELS[engine_key]} Makro: {error}" for error in macro_engine.errors)
                    for row in macro_rows:
                        row["engine_key"] = engine_key
                        row["engine_label"] = ENGINE_LABELS[engine_key]
                    rows_by_engine[engine_key] = macro_rows[:3]

                profile_queue.put(("done", profile_generation, rows_by_engine, errors))
            except Exception as exc:
                profile_queue.put(("error", profile_generation, str(exc)))

        threading.Thread(target=worker, daemon=True).start()
        self.after(140, self.poll_entry_engine_profile_build)

    def poll_entry_engine_profile_build(self):
        if self.entry_engine_profile_queue is None:
            return
        try:
            while True:
                item = self.entry_engine_profile_queue.get_nowait()
                if item[1] != self.entry_engine_profile_generation:
                    continue
                if item[0] == "done":
                    _, _, rows_by_engine, errors = item
                    self.entry_engine_engine_rows = rows_by_engine
                    self.entry_engine_profile_errors = errors
                    self.entry_engine_profiles_ready = all(rows_by_engine.get(key) for key in (ENGINE_CLASSIC, ENGINE_FLOW, ENGINE_HYBRID))
                    self.entry_engine_profiles_building = False
                    callback = self._entry_engine_profile_refresh
                    if callable(callback):
                        callback()
                    return
                if item[0] == "error":
                    _, _, error_message = item
                    self.entry_engine_profiles_building = False
                    self.entry_engine_profiles_ready = False
                    self.entry_engine_profile_errors = [error_message]
                    callback = self._entry_engine_profile_refresh
                    if callable(callback):
                        callback()
                    return
        except queue.Empty:
            pass
        self.after(140, self.poll_entry_engine_profile_build)

    def _show_entry_engine_dashboard_legacy(self):
        """Öffnet die geführte Brücke zwischen Analyzer Bias und TradingView."""
        if not self.top3 or self.result_engine_key is None:
            messagebox.showwarning(
                "COT Prüfung erforderlich",
                "Die Meridian Entry Engine wird nach einer erfolgreich abgeschlossenen COT Analyse freigeschaltet.",
            )
            return
        try:
            if self.entry_engine_window is not None and self.entry_engine_window.winfo_exists():
                self.entry_engine_window.destroy()
        except tk.TclError:
            pass

        win = tk.Toplevel(self)
        self.entry_engine_window = win
        win.title("Meridian Entry Engine")
        win.configure(bg=COLORS["bg"])
        win.minsize(980, 650)

        screen_w = max(1100, win.winfo_screenwidth())
        screen_h = max(720, win.winfo_screenheight())
        width = min(1280, int(screen_w * 0.92))
        height = min(860, int(screen_h * 0.90))
        parent_x = self.winfo_rootx()
        parent_y = self.winfo_rooty()
        parent_w = max(self.winfo_width(), width)
        parent_h = max(self.winfo_height(), height)
        x = max(0, min(parent_x + (parent_w - width) // 2, screen_w - width))
        y = max(0, min(parent_y + (parent_h - height) // 2, screen_h - height))
        win.geometry(f"{width}x{height}+{x}+{y}")

        def close_window():
            self.entry_engine_window = None
            win.destroy()

        win.protocol("WM_DELETE_WINDOW", close_window)
        win.bind("<Escape>", lambda _event: close_window())

        outer = tk.Frame(win, bg=COLORS["bg"])
        outer.pack(fill="both", expand=True, padx=14, pady=14)
        scroll = tk.Scrollbar(outer, orient="vertical", relief="flat", bd=0)
        scroll.pack(side="right", fill="y")
        canvas = tk.Canvas(
            outer, bg=COLORS["bg"], highlightthickness=0, bd=0,
            yscrollcommand=scroll.set,
        )
        canvas.pack(side="left", fill="both", expand=True)
        scroll.configure(command=canvas.yview)
        body = tk.Frame(canvas, bg=COLORS["bg"])
        body_window = canvas.create_window((0, 0), window=body, anchor="nw")

        def sync_canvas(_event=None):
            canvas.itemconfigure(body_window, width=max(920, canvas.winfo_width()))
            canvas.configure(scrollregion=canvas.bbox("all"))

        body.bind("<Configure>", sync_canvas)
        canvas.bind("<Configure>", sync_canvas)

        def scroll_dashboard(event):
            if getattr(event, "num", None) == 4:
                canvas.yview_scroll(-1, "units")
            elif getattr(event, "num", None) == 5:
                canvas.yview_scroll(1, "units")
            elif getattr(event, "delta", 0):
                canvas.yview_scroll(-1 if event.delta > 0 else 1, "units")
            return "break"

        win.bind("<MouseWheel>", scroll_dashboard)
        win.bind("<Button-4>", scroll_dashboard)
        win.bind("<Button-5>", scroll_dashboard)

        if self.macro_results:
            candidates = list(self.macro_results)[:3]
            stage_title = "RESEARCH ABGESCHLOSSEN"
            stage_detail = "COT, Seasonality und Makro sind geprüft. Die finalen Kandidaten sind bereit."
            stage_color = COLORS["green"]
            score_label = "FINALE QUALITÄT"
        elif self.final_watchlist:
            candidates = list(self.final_watchlist)[:3]
            stage_title = "SEASONALITY GEPRÜFT"
            stage_detail = "Der technische Check ist möglich. Die Makroprüfung der Wochenkandidaten ist noch offen."
            stage_color = COLORS["yellow"]
            score_label = "RESEARCH SCORE"
        elif self.top3:
            candidates = list(self.top3)[:3]
            stage_title = "COT-KANDIDATEN BEREIT"
            stage_detail = "Ein technischer Vorab-Check ist möglich. Seasonality und Makro anschließend ergänzen."
            stage_color = COLORS["yellow"]
            score_label = "COT QUALITÄT"
        else:
            candidates = []
            stage_title = "ANALYSE NOCH OFFEN"
            stage_detail = "Starte zuerst die COT-Analyse im Analyzer Pro."
            stage_color = COLORS["muted"]
            score_label = "QUALITÄT"

        def candidate_score(row):
            for key in ("final_quality", "final_confluence", "final_score", "confidence", "selection_score"):
                if row.get(key) is not None:
                    return safe_float(row.get(key), 0.0)
            return 0.0

        # Heller als die globale Sekundärfarbe, damit längere Hilfetexte auch auf
        # kleineren Displays und bei Windows Skalierung komfortabel lesbar bleiben.
        entry_body = "#C8D6E5"
        entry_soft = "#AFC3D8"

        # Header
        header = self.card(body, COLORS["header"])
        header.pack(fill="x", padx=2, pady=(0, 10))
        tk.Frame(header, bg=COLORS["green"], height=3).pack(fill="x")
        header_content = tk.Frame(header, bg=COLORS["header"])
        header_content.pack(fill="x", padx=20, pady=16)
        header_content.grid_columnconfigure(1, weight=1)

        if getattr(self, "_brand_logo_img", None) is not None:
            tk.Label(header_content, image=self._brand_logo_img, bg=COLORS["header"], bd=0).grid(row=0, column=0, rowspan=3, sticky="nw", padx=(0, 12))

        title_box = tk.Frame(header_content, bg=COLORS["header"])
        title_box.grid(row=0, column=1, rowspan=3, sticky="w")
        self.label(title_box, "Meridian ANALYZER PRO", 9, COLORS["green"], "bold", COLORS["header"]).pack(anchor="w")
        title_line = tk.Frame(title_box, bg=COLORS["header"])
        title_line.pack(anchor="w", pady=(2, 0))
        self.label(title_line, "Meridian ENTRY ENGINE", 24, COLORS["text"], "bold", COLORS["header"]).pack(side="left")
        self.help_button(title_line, "entry_engine", COLORS["header"], compact=False).pack(side="left", padx=(8, 0), pady=(5, 0))
        self.label(
            title_box,
            "Von der fundamentalen Wochenanalyse zur technischen Entry-Bestätigung in TradingView.",
            11, entry_body, "normal", COLORS["header"], wrap=720,
        ).pack(anchor="w", pady=(4, 0))

        stage = tk.Frame(header_content, bg=COLORS["card2"], highlightthickness=1, highlightbackground=stage_color)
        stage.grid(row=0, column=2, rowspan=3, sticky="e", padx=(16, 0))
        self.label(stage, "AKTUELLER ANALYSESTAND", 9, entry_soft, "bold", COLORS["card2"]).pack(anchor="w", padx=15, pady=(11, 3))
        self.label(stage, stage_title, 12, stage_color, "bold", COLORS["card2"]).pack(anchor="w", padx=15)
        self.label(stage, stage_detail, 9, entry_body, "normal", COLORS["card2"], wrap=300).pack(anchor="w", padx=15, pady=(3, 11))

        # Der Ablauf erklärt den Kundennutzen jedes Schrittes statt interner UI Zustände.
        process = self.card(body, COLORS["card"])
        process.pack(fill="x", padx=2, pady=(0, 12))
        process.grid_columnconfigure(0, weight=1)
        process.grid_columnconfigure(2, weight=1)
        process.grid_columnconfigure(4, weight=1)
        process_items = [
            (0, "01", "FUNDAMENTALE AUSWAHL", "Paar und Analyzer-Bias aus dem Analyzer übernehmen.", COLORS["blue"]),
            (2, "02", "TECHNISCHER ENTRY-CHECK", "H4, H1 und M15 im TradingView-Chart bewerten.", COLORS["green"]),
            (4, "03", "EIGENE TRADEPLANUNG", "Nur bei Bestätigung Entry, Stop und Risiko planen.", COLORS["yellow"]),
        ]
        for column, number, title, description, tone in process_items:
            cell = tk.Frame(process, bg=COLORS["card"])
            cell.grid(row=0, column=column, sticky="ew", padx=17, pady=12)
            heading = tk.Frame(cell, bg=COLORS["card"])
            heading.pack(fill="x")
            self.label(heading, number, 10, tone, "bold", COLORS["card"]).pack(side="left")
            self.label(heading, title, 11, COLORS["text"], "bold", COLORS["card"]).pack(side="left", padx=(9, 0))
            self.label(cell, description, 9, entry_body, "normal", COLORS["card"], wrap=430).pack(anchor="w", fill="x", pady=(4, 0))
        self.label(process, "›", 18, COLORS["line"], "bold", COLORS["card"], "center").grid(row=0, column=1, padx=3)
        self.label(process, "›", 18, COLORS["line"], "bold", COLORS["card"], "center").grid(row=0, column=3, padx=3)

        # Kandidatenauswahl
        candidate_head = tk.Frame(body, bg=COLORS["bg"])
        candidate_head.pack(fill="x", padx=4, pady=(3, 6))
        self.label(candidate_head, "1. KANDIDAT FÜR DEN TECHNISCHEN CHECK AUSWÄHLEN", 15, COLORS["text"], "bold", COLORS["bg"]).pack(side="left")
        self.label(candidate_head, "ARBEITSAUFTRAG AKTUALISIERT SICH AUTOMATISCH", 9, COLORS["green"], "bold", COLORS["bg"]).pack(side="right", pady=(6, 0))

        candidate_area = self.card(body, COLORS["card"])
        candidate_area.pack(fill="x", padx=2, pady=(0, 12))
        self.label(
            candidate_area,
            "Wähle das Analyzer-Setup, das du jetzt im Chart prüfen möchtest. Paar und Bias werden nicht neu berechnet, sondern exakt aus deiner Analyse übernommen.",
            11, entry_body, "normal", COLORS["card"], wrap=1220,
        ).pack(anchor="w", fill="x", padx=16, pady=(13, 10))

        candidate_buttons = []
        selected_index = {"value": 0}
        candidates_row = tk.Frame(candidate_area, bg=COLORS["card"])
        candidates_row.pack(fill="x", padx=14, pady=(0, 14))
        for col in range(3):
            candidates_row.grid_columnconfigure(col, weight=1, uniform="entry_candidates")

        # Dynamischer Arbeitsauftrag
        action_head = tk.Frame(body, bg=COLORS["bg"])
        action_head.pack(fill="x", padx=4, pady=(3, 6))
        self.label(action_head, "2. TRADINGVIEW-CHECK DURCHFÜHREN", 15, COLORS["text"], "bold", COLORS["bg"]).pack(side="left")
        self.label(action_head, "PRIVATER INDIKATOR  •  QUELLCODE GESCHÜTZT", 9, COLORS["green"], "bold", COLORS["bg"]).pack(side="right", pady=(6, 0))

        action = self.card(body, COLORS["card"])
        action.pack(fill="x", padx=2, pady=(0, 12))
        action.grid_columnconfigure(0, weight=0)
        action.grid_columnconfigure(1, weight=1)
        action.grid_columnconfigure(2, weight=2)

        selected = candidates[0]
        initial_pair = str(selected.get("pair", "—"))
        initial_bias = str(selected.get("direction", "—")).upper()
        initial_tone = COLORS["green"] if initial_bias == "LONG" else COLORS["red"]

        accent = tk.Frame(action, bg=initial_tone, width=4)
        accent.grid(row=0, column=0, rowspan=5, sticky="ns")
        summary = tk.Frame(action, bg=COLORS["card2"], width=300)
        summary.grid(row=0, column=1, rowspan=5, sticky="nsew", padx=(0, 0))
        summary.grid_propagate(False)
        self.label(summary, "AUSGEWÄHLTER ANALYZER-KANDIDAT", 9, entry_soft, "bold", COLORS["card2"]).pack(anchor="w", padx=19, pady=(18, 5))
        pair_value = self.label(summary, initial_pair, 24, COLORS["text"], "bold", COLORS["card2"])
        pair_value.pack(anchor="w", padx=18)
        bias_value = self.label(summary, initial_bias, 17, initial_tone, "bold", COLORS["card2"])
        bias_value.pack(anchor="w", padx=18, pady=(1, 6))
        quality_value = self.label(summary, f"{score_label}: {candidate_score(selected):.1f} / 100", 10, COLORS["yellow"], "bold", COLORS["card2"])
        quality_value.pack(anchor="w", padx=18, pady=(0, 18))

        instruction = tk.Frame(action, bg=COLORS["card"])
        instruction.grid(row=0, column=2, rowspan=3, sticky="nsew", padx=20, pady=(14, 4))
        task_title = self.label(instruction, f"TECHNISCHER CHECK  ·  {initial_pair}  ·  {initial_bias}", 14, initial_tone, "bold", COLORS["card"])
        task_title.pack(anchor="w", fill="x")
        task_text = self.label(
            instruction,
            "",
            11, entry_body, "normal", COLORS["card"], wrap=820,
        )
        task_text.pack(anchor="w", fill="x", pady=(7, 0))

        feedback = self.label(action, "", 10, entry_soft, "normal", COLORS["card"])
        feedback.grid(row=3, column=2, sticky="w", padx=20, pady=(2, 3))

        def task_copy(pair, bias):
            return (
                f"1   Öffne in TradingView den Forex-Chart {pair}.\n"
                "2   Prüfe, ob die Meridian Entry Engine bereits im Chart liegt, und füge sie nur einmal hinzu.\n"
                f"3   Stelle als Währungspaar {pair} und als Analyzer-Bias {bias} ein.\n"
                "4   Nutze M15 als Arbeitschart und bewerte anschließend den angezeigten Dashboard-Status."
            )

        task_text.config(text=task_copy(initial_pair, initial_bias))

        def bias_tone(bias):
            return COLORS["green"] if bias == "LONG" else COLORS["red"] if bias == "SHORT" else COLORS["muted"]

        def candidate_button_text(index, row, active):
            pair = str(row.get("pair", "—"))
            bias = str(row.get("direction", "—")).upper()
            state = "✓  AKTIVER KANDIDAT" if active else "KANDIDAT AUSWÄHLEN"
            return f"{state}\n#{index + 1}   {pair}   {bias}\n{score_label.title()}  {candidate_score(row):.1f} / 100"

        def refresh_candidate_buttons():
            for button_index, button in enumerate(candidate_buttons):
                row = candidates[button_index]
                bias = str(row.get("direction", "—")).upper()
                tone = bias_tone(bias)
                active = button_index == selected_index["value"]
                button.config(
                    text=candidate_button_text(button_index, row, active),
                    fg=tone if active else COLORS["text"],
                    activeforeground=tone,
                    bg=COLORS["card2"] if active else COLORS["button"],
                    activebackground=COLORS["card2"],
                    highlightthickness=2 if active else 1,
                    highlightbackground=tone if active else COLORS["line"],
                    highlightcolor=tone if active else COLORS["line"],
                )

        def select_candidate(index):
            if index < 0 or index >= len(candidates):
                return
            selected_index["value"] = index
            row = candidates[index]
            pair = str(row.get("pair", "—"))
            bias = str(row.get("direction", "—")).upper()
            tone = bias_tone(bias)
            accent.config(bg=tone)
            pair_value.config(text=pair)
            bias_value.config(text=bias, fg=tone)
            quality_value.config(text=f"{score_label}: {candidate_score(row):.1f} / 100")
            task_title.config(text=f"TECHNISCHER CHECK  ·  {pair}  ·  {bias}", fg=tone)
            task_text.config(text=task_copy(pair, bias))
            feedback.config(text=f"Auswahl übernommen: Der TradingView-Check ist für {pair} · {bias} vorbereitet.", fg=entry_body)
            refresh_candidate_buttons()

        for index, row in enumerate(candidates):
            bias = str(row.get("direction", "—")).upper()
            tone = bias_tone(bias)
            active = index == 0
            button = tk.Button(
                candidates_row,
                text=candidate_button_text(index, row, active),
                command=lambda i=index: select_candidate(i),
                font=("Segoe UI", 11, "bold"),
                fg=tone if active else COLORS["text"],
                bg=COLORS["card2"] if active else COLORS["button"],
                activeforeground=tone,
                activebackground=COLORS["card2"],
                relief="flat", bd=0,
                highlightthickness=2 if active else 1,
                highlightbackground=tone if active else COLORS["line"],
                highlightcolor=tone if active else COLORS["line"],
                cursor="hand2", justify="left", anchor="w", padx=16, pady=11,
            )
            button.grid(row=0, column=index, sticky="nsew", padx=(0 if index == 0 else 5, 0 if index == len(candidates) - 1 else 5))
            button.bind("<Enter>", lambda _event, b=button, i=index: b.config(bg=COLORS["card2"]) if selected_index["value"] != i else None)
            button.bind("<Leave>", lambda _event, b=button, i=index: b.config(bg=COLORS["button"]) if selected_index["value"] != i else None)
            candidate_buttons.append(button)

        def copy_link():
            try:
                win.clipboard_clear()
                win.clipboard_append(ENTRY_ENGINE_URL)
                win.update_idletasks()
                feedback.config(text="TradingView-Link wurde kopiert.", fg=COLORS["green"])
            except Exception as exc:
                feedback.config(text=f"Der TradingView-Link konnte nicht kopiert werden: {exc}", fg=COLORS["orange"])

        def open_tradingview():
            if self.entry_engine_link_opened:
                apply_launch_state()
                feedback.config(text="TradingView wurde in dieser Sitzung bereits geöffnet. Nutze bei Bedarf weiterhin „Link kopieren“.", fg=entry_soft)
                return
            row = candidates[selected_index["value"]]
            pair = str(row.get("pair", "—"))
            bias = str(row.get("direction", "—")).upper()
            # Sofort sperren, damit auch ein schneller Doppelklick keinen
            # zweiten Browseraufruf auslösen kann.
            self.entry_engine_link_opened = True
            apply_launch_state()
            win.update_idletasks()
            try:
                import webbrowser
                opened = bool(webbrowser.open(ENTRY_ENGINE_URL, new=2))
            except Exception:
                opened = False
            if opened:
                feedback.config(text=f"TradingView wurde einmal geöffnet. Stelle dort {pair} und Analyzer-Bias {bias} ein.", fg=entry_body)
            else:
                self.entry_engine_link_opened = False
                apply_launch_state()
                copy_link()
                feedback.config(text="Der Browser konnte nicht geöffnet werden. Der TradingView-Link wurde kopiert.", fg=COLORS["orange"])

        action_buttons = tk.Frame(action, bg=COLORS["card"])
        action_buttons.grid(row=4, column=2, sticky="ew", padx=20, pady=(4, 15))
        action_buttons.grid_columnconfigure(1, weight=1)

        open_indicator_button = self.button(action_buttons, "TRADINGVIEW INDIKATOR ÖFFNEN", open_tradingview, COLORS["green"], "#04120A")
        open_indicator_button.grid(row=0, column=0, sticky="w", ipadx=14, ipady=8)

        launch_note = tk.Frame(action_buttons, bg=COLORS["card2"], highlightthickness=1, highlightbackground=COLORS["line"])
        launch_note.grid(row=0, column=1, sticky="ew", padx=10)
        self.label(launch_note, "INDIKATOR NUR EINMAL HINZUFÜGEN", 9, COLORS["green"], "bold", COLORS["card2"]).pack(anchor="w", padx=11, pady=(7, 1))
        self.label(
            launch_note,
            "TradingView wurde geöffnet. Prüfe zuerst, ob die Meridian Entry Engine bereits im Chart vorhanden ist. Erneutes Hinzufügen kann eine zweite Instanz mit abweichenden Einstellungen laden.",
            9, entry_body, "normal", COLORS["card2"], wrap=330,
        ).pack(anchor="w", fill="x", padx=11, pady=(0, 7))

        self.button(action_buttons, "LINK KOPIEREN", copy_link, COLORS["button"], COLORS["blue"]).grid(row=0, column=2, sticky="e", ipadx=8, ipady=8)

        def apply_launch_state():
            if self.entry_engine_link_opened:
                open_indicator_button.config(
                    text="TRADINGVIEW GEÖFFNET  ✓",
                    state="disabled",
                    bg=COLORS["button"],
                    activebackground=COLORS["button"],
                    fg=COLORS["muted"],
                    activeforeground=COLORS["muted"],
                    disabledforeground=COLORS["muted"],
                    cursor="arrow",
                )
                launch_note.grid()
            else:
                open_indicator_button.config(
                    text="TRADINGVIEW INDIKATOR ÖFFNEN",
                    state="normal",
                    bg=COLORS["green"],
                    activebackground=COLORS["green"],
                    fg="#04120A",
                    activeforeground="#04120A",
                    cursor="hand2",
                )
                launch_note.grid_remove()

        apply_launch_state()

        # Kompakte Bedienhinweise ohne den bereits sichtbaren Arbeitsauftrag zu wiederholen.
        guide_head = tk.Frame(body, bg=COLORS["bg"])
        guide_head.pack(fill="x", padx=4, pady=(7, 5))
        self.label(guide_head, "3. RICHTIG ANWENDEN UND EINORDNEN", 15, COLORS["text"], "bold", COLORS["bg"]).pack(side="left")

        guide = self.card(body, COLORS["card"])
        guide.pack(fill="x", padx=2, pady=(0, 10))
        steps = [
            ("01", "Einmal öffnen und anmelden", "Öffne den geschützten Indikator nur einmal. Ist er bereits im Chart vorhanden, nutze ausschließlich seine Einstellungen. Wähle Desktop Premium am PC oder Mobile Kompakt am Smartphone."),
            ("02", "M15 als Arbeitschart", "Die Engine verbindet H4, H1 und M15. Führe den Check im M15-Chart des ausgewählten Währungspaares durch."),
            ("03", "Bestätigung statt Handelssignal", "Readiness und Status zeigen die technische Unterstützung für den Analyzer-Bias. Ausführung und Risiko entscheidest du selbst."),
        ]
        steps_grid = tk.Frame(guide, bg=COLORS["card"])
        steps_grid.pack(fill="x", padx=10, pady=10)
        for col in range(3):
            steps_grid.grid_columnconfigure(col, weight=1, uniform="entry_steps")
        for index, (number, title, text) in enumerate(steps):
            row, col = 0, index
            step = tk.Frame(steps_grid, bg=COLORS["card2"], highlightthickness=1, highlightbackground=COLORS["line"])
            step.grid(row=row, column=col, sticky="nsew", padx=4, pady=4)
            line = tk.Frame(step, bg=COLORS["card2"])
            line.pack(fill="x", padx=14, pady=(12, 4))
            self.label(line, number, 10, COLORS["green"], "bold", COLORS["card2"]).pack(side="left")
            self.label(line, title, 11, COLORS["text"], "bold", COLORS["card2"]).pack(side="left", padx=(9, 0))
            self.label(step, text, 10, entry_body, "normal", COLORS["card2"], wrap=520).pack(anchor="w", fill="x", padx=14, pady=(0, 13))

        # Bewertungslogik verständlich, aber ohne geschützte Parameter offenzulegen.
        metric_head = tk.Frame(body, bg=COLORS["bg"])
        metric_head.pack(fill="x", padx=4, pady=(7, 5))
        self.label(metric_head, "DIE SECHS TECHNISCHEN PRÜFBEREICHE", 15, COLORS["text"], "bold", COLORS["bg"]).pack(side="left")
        self.label(metric_head, "AUTOMATISCHE MULTI-TIMEFRAME-BEWERTUNG IN TRADINGVIEW", 9, entry_soft, "bold", COLORS["bg"]).pack(side="right", pady=(5, 0))

        metrics = self.card(body, COLORS["card"])
        metrics.pack(fill="x", padx=2, pady=(0, 10))
        metric_grid = tk.Frame(metrics, bg=COLORS["card"])
        metric_grid.pack(fill="x", padx=10, pady=10)
        for col in range(2):
            metric_grid.grid_columnconfigure(col, weight=1, uniform="entry_metrics")
        metric_items = [
            ("H4 TREND", "Bewertet, ob der übergeordnete Trend den Analyzer-Bias unterstützt und wie klar die Richtung ausgeprägt ist."),
            ("H4 TRADE SPACE", "Prüft, ob bis zum nächsten relevanten technischen Hindernis noch genügend Bewegungsspielraum vorhanden ist."),
            ("H1 STRUKTUR", "Bewertet, ob Hochs, Tiefs und die mittelfristige Marktstruktur auf H1 zum Analyzer-Bias passen."),
            ("H1 SETUP", "Prüft, ob sich der Markt in einer technisch sinnvollen Pullback- oder Fortsetzungsphase befindet."),
            ("M15 TIMING", "Sucht die kurzfristige Bestätigung für den Einstieg, ohne selbst ein Kauf- oder Verkaufssignal auszugeben."),
            ("MOMENTUM", "Bewertet die aktuelle Richtungsstärke und warnt vor einem zu schwachen oder bereits überdehnten Markt."),
        ]
        for index, (title, text) in enumerate(metric_items):
            row, col = divmod(index, 2)
            metric = tk.Frame(metric_grid, bg=COLORS["card2"], highlightthickness=1, highlightbackground=COLORS["line"])
            metric.grid(row=row, column=col, sticky="nsew", padx=5, pady=5)
            self.label(metric, title, 11, COLORS["blue"], "bold", COLORS["card2"]).pack(anchor="w", padx=15, pady=(12, 4))
            self.label(metric, text, 10, entry_body, "normal", COLORS["card2"], wrap=700).pack(anchor="w", fill="x", padx=15, pady=(0, 13))

        status_head = tk.Frame(body, bg=COLORS["bg"])
        status_head.pack(fill="x", padx=4, pady=(7, 5))
        self.label(status_head, "SO IST DER DASHBOARD-STATUS ZU VERSTEHEN", 15, COLORS["text"], "bold", COLORS["bg"]).pack(side="left")

        statuses = tk.Frame(body, bg=COLORS["bg"])
        statuses.pack(fill="x", padx=2, pady=(0, 10))
        for col in range(3):
            statuses.grid_columnconfigure(col, weight=1, uniform="entry_status")
        status_items = [
            ("●  RICHTUNG BESTÄTIGT", COLORS["green"], "Trend, Struktur, Timing und Momentum liefern ausreichend technische Unterstützung für den Analyzer-Bias. Ein eigener Risiko- und Ausführungsplan bleibt erforderlich."),
            ("●  BIAS INTAKT – NOCH WARTEN", COLORS["yellow"], "Die übergeordnete Richtung kann passen, aber mindestens eine wichtige Entry-Ebene ist noch nicht bereit. Das Dashboard nennt den entscheidenden Grund."),
            ("●  AKTUELL KEIN TRADE", COLORS["red"], "Die technische Gesamtstruktur unterstützt den gewählten Analyzer-Bias aktuell nicht. Aus dieser Bewertung keinen Einstieg ableiten."),
        ]
        for col, (title, tone, text) in enumerate(status_items):
            status_box = tk.Frame(statuses, bg=COLORS["card"], highlightthickness=1, highlightbackground=tone)
            status_box.grid(row=0, column=col, sticky="nsew", padx=(0 if col == 0 else 5, 0 if col == 2 else 5))
            self.label(status_box, title, 12, tone, "bold", COLORS["card"]).pack(anchor="w", padx=15, pady=(13, 4))
            self.label(status_box, text, 10, entry_body, "normal", COLORS["card"], wrap=520).pack(anchor="w", fill="x", padx=15, pady=(0, 14))

        risk = tk.Frame(body, bg=COLORS["header"], highlightthickness=1, highlightbackground=COLORS["yellow"])
        risk.pack(fill="x", padx=2, pady=(2, 12))
        self.label(risk, "VERANTWORTUNG BLEIBT BEIM TRADER", 11, COLORS["yellow"], "bold", COLORS["header"]).pack(anchor="w", padx=16, pady=(13, 3))
        self.label(
            risk,
            "Die Meridian Entry Engine ist eine technische Einstiegshilfe. Sie berechnet weder Positionsgröße noch Stop Loss oder Take Profit und stellt keine Erfolgsgarantie dar. Prüfe Ereignisrisiko, Invalidierung, Chance Risiko Verhältnis und maximale Kontobelastung vor jedem Trade eigenständig.",
            10, entry_body, "normal", COLORS["header"], wrap=1320,
        ).pack(anchor="w", fill="x", padx=16, pady=(0, 14))

        bottom = tk.Frame(body, bg=COLORS["bg"])
        bottom.pack(fill="x", padx=2, pady=(0, 10))
        self.label(bottom, "Meridian ANALYZER PRO  •  FUNDAMENTALE AUSWAHL + TECHNISCHE BESTÄTIGUNG", 9, entry_soft, "bold", COLORS["bg"]).pack(side="left", pady=(8, 0))
        self.button(bottom, "FENSTER SCHLIESSEN", close_window, COLORS["button"], COLORS["text"]).pack(side="right", ipadx=14, ipady=7)

        win.after_idle(sync_canvas)
        win.after(80, lambda: (win.lift(), win.focus_force()))

    def show_entry_engine_dashboard(self):
        """Geführte Übergabe finaler Makro Watchlists an das TradingView Modul."""
        if not self.macro_results or self.result_engine_key is None:
            messagebox.showwarning(
                "Finale Makro Watchlist erforderlich",
                "Schließe zuerst COT Daten, Seasonality und Makro vollständig ab. "
                "Erst danach kann der Analyzer ein gültiges TradingView Profil erzeugen.",
            )
            return

        try:
            selected_profile = self.selected_entry_engine_profile()
        except Exception as exc:
            messagebox.showerror("TradingView Profil", f"Das Profil konnte nicht erstellt werden.\n\n{exc}")
            return
        if not selected_profile:
            messagebox.showerror("TradingView Profil", "Für die aktuelle finale Makro Watchlist konnte kein Profil erstellt werden.")
            return

        try:
            if self.entry_engine_window is not None and self.entry_engine_window.winfo_exists():
                self.entry_engine_window.destroy()
        except tk.TclError:
            pass

        win = tk.Toplevel(self)
        self.entry_engine_window = win
        win.title("Meridian Entry Engine")
        win.configure(bg=COLORS["bg"])
        win.minsize(1040, 700)

        screen_w = max(1180, win.winfo_screenwidth())
        screen_h = max(760, win.winfo_screenheight())
        width = min(1380, int(screen_w * 0.94))
        height = min(900, int(screen_h * 0.92))
        x = max(0, min(self.winfo_rootx() + 30, screen_w - width))
        y = max(0, min(self.winfo_rooty() + 20, screen_h - height))
        win.geometry(f"{width}x{height}+{x}+{y}")

        def close_window():
            self._entry_engine_profile_refresh = None
            self.entry_engine_window = None
            win.destroy()

        win.protocol("WM_DELETE_WINDOW", close_window)
        win.bind("<Escape>", lambda _event: close_window())

        outer = tk.Frame(win, bg=COLORS["bg"])
        outer.pack(fill="both", expand=True, padx=14, pady=14)
        scrollbar = tk.Scrollbar(outer, orient="vertical", relief="flat", bd=0)
        scrollbar.pack(side="right", fill="y")
        canvas = tk.Canvas(outer, bg=COLORS["bg"], highlightthickness=0, bd=0, yscrollcommand=scrollbar.set)
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.configure(command=canvas.yview)
        body = tk.Frame(canvas, bg=COLORS["bg"])
        body_window = canvas.create_window((0, 0), window=body, anchor="nw")

        def sync_canvas(_event=None):
            canvas.itemconfigure(body_window, width=max(980, canvas.winfo_width()))
            canvas.configure(scrollregion=canvas.bbox("all"))

        def scroll_dashboard(event):
            if getattr(event, "num", None) == 4:
                canvas.yview_scroll(-1, "units")
            elif getattr(event, "num", None) == 5:
                canvas.yview_scroll(1, "units")
            elif getattr(event, "delta", 0):
                canvas.yview_scroll(-1 if event.delta > 0 else 1, "units")
            return "break"

        body.bind("<Configure>", sync_canvas)
        canvas.bind("<Configure>", sync_canvas)
        win.bind("<MouseWheel>", scroll_dashboard)
        win.bind("<Button-4>", scroll_dashboard)
        win.bind("<Button-5>", scroll_dashboard)

        entry_body = "#D5E2EE"
        entry_soft = "#B5C9DC"
        current_engine_label = ENGINE_LABELS[self.result_engine_key]
        current_engine_color = COLORS.get(ENGINE_PROFILE_INFO[self.result_engine_key].get("accent", "green"), COLORS["green"])

        def candidate_score(row):
            for key in ("final_quality", "final_confluence", "final_score", "confidence", "selection_score"):
                if row.get(key) is not None:
                    return safe_float(row.get(key), 0.0)
            return 0.0

        def set_profile_text(widget, value):
            widget.config(state="normal")
            widget.delete("1.0", "end")
            widget.insert("1.0", value)
            widget.mark_set("insert", "1.0")

        def protect_profile_text(widget):
            def readonly_key(event):
                control_pressed = bool(event.state & 0x4)
                if control_pressed and str(event.keysym).lower() in ("a", "c"):
                    return None
                if event.keysym in ("Left", "Right", "Up", "Down", "Home", "End", "Prior", "Next"):
                    return None
                return "break"
            widget.bind("<Key>", readonly_key)
            widget.bind("<<Paste>>", lambda _event: "break")
            widget.bind("<<Cut>>", lambda _event: "break")

        def copy_to_clipboard(value, success_text, feedback_label):
            try:
                win.clipboard_clear()
                win.clipboard_append(value)
                win.update_idletasks()
                feedback_label.config(text=success_text, fg=COLORS["green"])
            except Exception as exc:
                feedback_label.config(text=f"Kopieren nicht möglich: {exc}", fg=COLORS["orange"])

        header = self.card(body, COLORS["header"])
        header.pack(fill="x", padx=2, pady=(0, 11))
        tk.Frame(header, bg=COLORS["green"], height=3).pack(fill="x")
        header_content = tk.Frame(header, bg=COLORS["header"])
        header_content.pack(fill="x", padx=20, pady=16)
        header_content.grid_columnconfigure(1, weight=1)

        if getattr(self, "_brand_logo_img", None) is not None:
            tk.Label(header_content, image=self._brand_logo_img, bg=COLORS["header"], bd=0).grid(
                row=0, column=0, rowspan=3, sticky="nw", padx=(0, 12)
            )
        title_box = tk.Frame(header_content, bg=COLORS["header"])
        title_box.grid(row=0, column=1, rowspan=3, sticky="w")
        self.label(title_box, "Meridian ANALYZER PRO", 9, COLORS["green"], "bold", COLORS["header"]).pack(anchor="w")
        self.label(title_box, "Meridian ENTRY ENGINE", 24, COLORS["text"], "bold", COLORS["header"]).pack(anchor="w", pady=(2, 0))
        self.label(
            title_box,
            "Deine finale Makro Watchlist wird als geschütztes Profil an TradingView übergeben. "
            "Paar und Analyzer Bias werden dort automatisch erkannt.",
            11, entry_body, "normal", COLORS["header"], wrap=780,
        ).pack(anchor="w", pady=(4, 0))

        stage = tk.Frame(header_content, bg=COLORS["card2"], highlightthickness=1, highlightbackground=COLORS["green"])
        stage.grid(row=0, column=2, rowspan=3, sticky="e", padx=(18, 0))
        self.label(stage, "ANALYSESTATUS", 9, entry_soft, "bold", COLORS["card2"]).pack(anchor="w", padx=15, pady=(11, 3))
        self.label(stage, "COT, SEASONALITY UND MAKRO GEPRÜFT", 11, COLORS["green"], "bold", COLORS["card2"], wrap=300).pack(anchor="w", padx=15)
        self.label(stage, f"Aktive Engine: {current_engine_label}", 9, entry_body, "normal", COLORS["card2"]).pack(anchor="w", padx=15, pady=(4, 1))
        self.label(
            stage,
            f"CFTC Datenstand: {selected_profile['report_date_text']}",
            9,
            entry_body,
            "normal",
            COLORS["card2"],
        ).pack(anchor="w", padx=15, pady=(0, 11))

        process = self.card(body, COLORS["card"])
        process.pack(fill="x", padx=2, pady=(0, 12))
        process.grid_columnconfigure(0, weight=1)
        process.grid_columnconfigure(1, weight=1)
        process.grid_columnconfigure(2, weight=1)
        process.grid_columnconfigure(3, weight=1)
        process_items = (
            ("01", "INDIKATOR ÖFFNEN", "Füge die Meridian Entry Engine einmalig in TradingView hinzu.", COLORS["green"]),
            ("02", "PROFIL KOPIEREN", "Wähle die aktuelle Engine oder alle drei Engines.", COLORS["blue"]),
            ("03", "PROFIL EINFÜGEN", "Übertrage den vollständigen Text in die Indikator Einstellungen.", COLORS["green"]),
            ("04", "CHARTS PRÜFEN", "Paar, Engine und Bias werden anschließend automatisch erkannt.", COLORS["yellow"]),
        )
        for column, (number, title, description, tone) in enumerate(process_items):
            cell = tk.Frame(process, bg=COLORS["card"])
            cell.grid(row=0, column=column, sticky="nsew", padx=17, pady=12)
            line = tk.Frame(cell, bg=COLORS["card"])
            line.pack(fill="x")
            self.label(line, number, 10, tone, "bold", COLORS["card"]).pack(side="left")
            self.label(line, title, 11, COLORS["text"], "bold", COLORS["card"]).pack(side="left", padx=(9, 0))
            self.label(cell, description, 9, entry_body, "normal", COLORS["card"], wrap=430).pack(anchor="w", fill="x", pady=(4, 0))

        launch_head = tk.Frame(body, bg=COLORS["bg"])
        launch_head.pack(fill="x", padx=4, pady=(3, 6))
        self.label(launch_head, "1. EINMALIGE EINRICHTUNG IN TRADINGVIEW", 15, COLORS["text"], "bold", COLORS["bg"]).pack(side="left")
        self.label(launch_head, "DIESER SCHRITT IST NUR EINMAL NOTWENDIG", 9, COLORS["yellow"], "bold", COLORS["bg"]).pack(side="right", pady=(6, 0))

        launch = self.card(body, COLORS["card"])
        launch.pack(fill="x", padx=2, pady=(0, 12))
        launch.grid_columnconfigure(1, weight=1)
        launch_feedback = self.label(
            launch,
            "Beim ersten Start öffnet TradingView direkt die Eingaben. Lass dieses Fenster geöffnet, kehre hierher zurück und mache mit Schritt 2 weiter.",
            9,
            entry_body,
            "normal",
            COLORS["card"],
        )
        launch_feedback.grid(row=1, column=0, columnspan=3, sticky="w", padx=16, pady=(0, 12))

        def copy_link():
            copy_to_clipboard(ENTRY_ENGINE_URL, "TradingView Link wurde kopiert.", launch_feedback)

        def apply_launch_state():
            if self.entry_engine_link_opened:
                open_indicator_button.config(
                    text="TRADINGVIEW BEREITS GEÖFFNET",
                    state="disabled",
                    bg=COLORS["button"],
                    activebackground=COLORS["button"],
                    fg=COLORS["muted"],
                    disabledforeground=COLORS["muted"],
                )

        def open_tradingview():
            if self.entry_engine_link_opened:
                apply_launch_state()
                return
            self.entry_engine_link_opened = True
            apply_launch_state()
            win.update_idletasks()
            try:
                import webbrowser
                opened = bool(webbrowser.open(ENTRY_ENGINE_URL, new=2))
            except Exception:
                opened = False
            if opened:
                launch_feedback.config(
                    text="TradingView wurde geöffnet. Lass das Eingabefenster geöffnet und kehre zum Analyzer zurück, um jetzt das Profil zu kopieren.",
                    fg=entry_body,
                )
            else:
                self.entry_engine_link_opened = False
                open_indicator_button.config(
                    text="TRADINGVIEW INDIKATOR ÖFFNEN",
                    state="normal",
                    bg=COLORS["green"],
                    fg="#04120A",
                )
                copy_link()
                launch_feedback.config(text="Der Browser konnte nicht geöffnet werden. Der TradingView Link wurde kopiert.", fg=COLORS["orange"])

        open_indicator_button = self.button(launch, "TRADINGVIEW INDIKATOR EINMALIG ÖFFNEN", open_tradingview, COLORS["green"], "#04120A")
        open_indicator_button.grid(row=0, column=0, sticky="w", padx=16, pady=14, ipadx=13, ipady=8)
        note = tk.Frame(launch, bg=COLORS["card2"], highlightthickness=1, highlightbackground=COLORS["line"])
        note.grid(row=0, column=1, sticky="ew", padx=8, pady=12)
        self.label(note, "BEREITS EINGERICHTET?", 9, COLORS["yellow"], "bold", COLORS["card2"]).pack(anchor="w", padx=11, pady=(7, 1))
        self.label(
            note,
            "Ist die Meridian Entry Engine bereits im Chart vorhanden, füge sie nicht erneut hinzu. "
            "Öffne in TradingView nur das Zahnrad des vorhandenen Indikators und fahre direkt mit Schritt 2 fort.",
            9, entry_body, "normal", COLORS["card2"], wrap=610,
        ).pack(anchor="w", fill="x", padx=11, pady=(0, 7))
        self.button(launch, "LINK KOPIEREN", copy_link, COLORS["button"], COLORS["blue"]).grid(
            row=0, column=2, sticky="e", padx=16, pady=14, ipadx=9, ipady=8
        )
        apply_launch_state()

        candidate_head = tk.Frame(body, bg=COLORS["bg"])
        candidate_head.pack(fill="x", padx=4, pady=(3, 6))
        self.label(candidate_head, f"FINALE MAKRO TOP 3  •  {current_engine_label.upper()}", 15, COLORS["text"], "bold", COLORS["bg"]).pack(side="left")
        self.label(candidate_head, "KEINE CHAMPION DATEN", 9, COLORS["green"], "bold", COLORS["bg"]).pack(side="right", pady=(6, 0))

        candidate_area = self.card(body, COLORS["card"])
        candidate_area.pack(fill="x", padx=2, pady=(0, 12))
        candidate_row = tk.Frame(candidate_area, bg=COLORS["card"])
        candidate_row.pack(fill="x", padx=12, pady=12)
        for column in range(3):
            candidate_row.grid_columnconfigure(column, weight=1, uniform="macro_candidates")
        for index, row in enumerate(list(self.macro_results)[:3]):
            pair = str(row.get("pair", "—"))
            bias = str(row.get("direction", "—")).upper()
            tone = COLORS["green"] if bias == "LONG" else COLORS["red"]
            card = tk.Frame(candidate_row, bg=COLORS["card2"], highlightthickness=1, highlightbackground=tone)
            card.grid(row=0, column=index, sticky="nsew", padx=(0 if index == 0 else 5, 0 if index == 2 else 5))
            self.label(card, f"#{index + 1}  FINALE MAKRO WATCHLIST", 9, entry_soft, "bold", COLORS["card2"]).pack(anchor="w", padx=14, pady=(11, 3))
            self.label(card, pair, 17, COLORS["text"], "bold", COLORS["card2"]).pack(anchor="w", padx=14)
            self.label(card, f"{bias}  •  Qualität {candidate_score(row):.1f} / 100", 11, tone, "bold", COLORS["card2"]).pack(anchor="w", padx=14, pady=(2, 11))

        profile_head = tk.Frame(body, bg=COLORS["bg"])
        profile_head.pack(fill="x", padx=4, pady=(4, 6))
        self.label(profile_head, "2. ANALYZER PROFIL AUSWÄHLEN UND KOPIEREN", 15, COLORS["text"], "bold", COLORS["bg"]).pack(side="left")
        self.label(profile_head, "ENTHÄLT PAARE, BIAS, ENGINE UND OFFIZIELLEN CFTC DATENSTAND", 9, entry_soft, "bold", COLORS["bg"]).pack(side="right", pady=(6, 0))

        profiles = tk.Frame(body, bg=COLORS["bg"])
        profiles.pack(fill="x", padx=2, pady=(0, 12))
        profiles.grid_columnconfigure(0, weight=1, uniform="profile")
        profiles.grid_columnconfigure(1, weight=1, uniform="profile")

        selected_card = tk.Frame(profiles, bg=COLORS["card"], highlightthickness=1, highlightbackground=current_engine_color)
        selected_card.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        self.label(selected_card, f"OPTION A  •  NUR {current_engine_label.upper()}", 10, current_engine_color, "bold", COLORS["card"]).pack(anchor="w", padx=16, pady=(14, 3))
        self.label(selected_card, "Top 3 der aktuell ausgewerteten Engine", 15, COLORS["text"], "bold", COLORS["card"]).pack(anchor="w", padx=16)
        self.label(
            selected_card,
            "Ideal, wenn du ausschließlich mit der Engine arbeiten möchtest, mit der du COT, Seasonality und Makro gerade abgeschlossen hast.",
            10, entry_body, "normal", COLORS["card"], wrap=610,
        ).pack(anchor="w", fill="x", padx=16, pady=(5, 9))
        selected_text = tk.Text(
            selected_card, height=3, wrap="word", font=("Consolas", 9),
            fg=entry_body, bg=COLORS["card2"], insertbackground=COLORS["text"],
            relief="flat", bd=0, padx=9, pady=8,
        )
        selected_text.pack(fill="x", padx=16)
        protect_profile_text(selected_text)
        set_profile_text(selected_text, selected_profile["token"])
        selected_feedback = self.label(
            selected_card,
            f"Datengrundlage: offizieller CFTC Bericht vom {selected_profile['report_date_text']}",
            9,
            entry_soft,
            "normal",
            COLORS["card"],
        )
        selected_feedback.pack(anchor="w", padx=16, pady=(6, 5))
        self.button(
            selected_card,
            "TOP 3 DIESER ENGINE KOPIEREN",
            lambda: copy_to_clipboard(
                selected_profile["token"],
                f"Profil für {current_engine_label} wurde vollständig kopiert.",
                selected_feedback,
            ),
            current_engine_color, "#04120A",
        ).pack(anchor="w", padx=16, pady=(0, 15), ipadx=12, ipady=7)

        combined_card = tk.Frame(profiles, bg=COLORS["card"], highlightthickness=1, highlightbackground=COLORS["blue"])
        combined_card.grid(row=0, column=1, sticky="nsew", padx=(6, 0))
        self.label(combined_card, "OPTION B  •  ALLE 3 ENGINES", 10, COLORS["blue"], "bold", COLORS["card"]).pack(anchor="w", padx=16, pady=(14, 3))
        self.label(combined_card, "Bis zu 9 finale Makro Kandidaten", 15, COLORS["text"], "bold", COLORS["card"]).pack(anchor="w", padx=16)
        self.label(
            combined_card,
            "Der Analyzer berechnet die finalen Top 3 von Classic Meridian, Flow Momentum und Hybrid Intelligence getrennt und führt sie sicher zusammen.",
            10, entry_body, "normal", COLORS["card"], wrap=610,
        ).pack(anchor="w", fill="x", padx=16, pady=(5, 9))
        combined_text = tk.Text(
            combined_card, height=3, wrap="word", font=("Consolas", 9),
            fg=entry_body, bg=COLORS["card2"], insertbackground=COLORS["text"],
            relief="flat", bd=0, padx=9, pady=8,
        )
        combined_text.pack(fill="x", padx=16)
        protect_profile_text(combined_text)
        set_profile_text(combined_text, "Die finalen Makro Top 3 aller Engines werden vorbereitet.")
        combined_feedback = self.label(combined_card, "Bitte einen kurzen Moment warten.", 9, entry_soft, "normal", COLORS["card"])
        combined_feedback.pack(anchor="w", padx=16, pady=(6, 5))
        combined_data = {"profile": None}

        def copy_combined_profile():
            profile = combined_data.get("profile")
            if profile:
                copy_to_clipboard(
                    profile["token"],
                    "Das Profil mit den finalen Top 3 aller Engines wurde vollständig kopiert.",
                    combined_feedback,
                )

        combined_copy_button = self.button(
            combined_card, "ALLE 3 ENGINES WERDEN VORBEREITET", copy_combined_profile, COLORS["button"], COLORS["muted"]
        )
        combined_copy_button.pack(anchor="w", padx=16, pady=(0, 15), ipadx=12, ipady=7)
        combined_copy_button.config(state="disabled", disabledforeground=COLORS["muted"])

        def refresh_combined_profile():
            try:
                if not win.winfo_exists():
                    return
            except tk.TclError:
                return
            if self.entry_engine_profiles_ready:
                try:
                    profile, conflicts = self.combined_entry_engine_profile()
                    combined_data["profile"] = profile
                    set_profile_text(combined_text, profile["token"])
                    conflict_note = ""
                    if conflicts:
                        display = ", ".join(f"{pair[:3]}/{pair[3:]}" for pair in conflicts)
                        conflict_note = f" Gegensätzliche Engine Bias wurden sicher ausgeschlossen: {display}."
                    combined_feedback.config(
                        text=f"{len(profile['rows'])} eindeutige Paare. CFTC Datenstand: {profile['report_date_text']}.{conflict_note}",
                        fg=COLORS["green"] if not conflicts else COLORS["yellow"],
                    )
                    combined_copy_button.config(
                        text="TOP 3 ALLER ENGINES KOPIEREN",
                        command=copy_combined_profile,
                        state="normal",
                        bg=COLORS["blue"],
                        activebackground=COLORS["blue"],
                        fg="#04120A",
                        activeforeground="#04120A",
                    )
                except Exception as exc:
                    set_profile_text(combined_text, "Das Gesamtprofil konnte nicht erstellt werden.")
                    combined_feedback.config(text=str(exc), fg=COLORS["orange"])
            elif not self.entry_engine_profiles_building:
                error_text = self.entry_engine_profile_errors[0] if self.entry_engine_profile_errors else "Vorbereitung nicht abgeschlossen."
                set_profile_text(combined_text, "Die finalen Makro Top 3 aller Engines sind noch nicht verfügbar.")
                combined_feedback.config(text=error_text, fg=COLORS["orange"])

                def retry():
                    self.entry_engine_profile_errors = []
                    set_profile_text(combined_text, "Die finalen Makro Top 3 aller Engines werden erneut vorbereitet.")
                    combined_feedback.config(text="Bitte einen kurzen Moment warten.", fg=entry_soft)
                    combined_copy_button.config(text="ALLE 3 ENGINES WERDEN VORBEREITET", state="disabled", bg=COLORS["button"], fg=COLORS["muted"])
                    self.start_entry_engine_profile_build()

                combined_copy_button.config(
                    text="GESAMTPROFIL ERNEUT VORBEREITEN",
                    command=retry,
                    state="normal",
                    bg=COLORS["button"],
                    activebackground=COLORS["button"],
                    fg=COLORS["blue"],
                    activeforeground=COLORS["blue"],
                )

        self._entry_engine_profile_refresh = refresh_combined_profile
        if self.entry_engine_profiles_ready:
            refresh_combined_profile()
        else:
            self.start_entry_engine_profile_build()

        guide_head = tk.Frame(body, bg=COLORS["bg"])
        guide_head.pack(fill="x", padx=4, pady=(4, 6))
        self.label(guide_head, "3. PROFIL IN TRADINGVIEW EINFÜGEN UND CHARTS PRÜFEN", 15, COLORS["text"], "bold", COLORS["bg"]).pack(side="left")

        guide = self.card(body, COLORS["card"])
        guide.pack(fill="x", padx=2, pady=(0, 12))
        guide.grid_columnconfigure(0, weight=1)
        guide.grid_columnconfigure(1, weight=1)
        instructions = (
            ("01", "TradingView Eingaben öffnen", "Beim ersten Hinzufügen sind sie bereits geöffnet. Später öffnest du am vorhandenen Indikator nur das Zahnrad."),
            ("02", "Profil vollständig einfügen", "Füge den kopierten Text in das erste Feld „Analyzer Profil“ ein und ersetze dort einen eventuell vorhandenen Inhalt."),
            ("03", "Hinweis und Darstellung festlegen", "Bestätige den Nutzungshinweis und wähle Desktop oder Mobile sowie die gewünschte Position im Chart."),
            ("04", "Freigegebene Charts durchsehen", "TradingView erkennt beim Chartwechsel Paar, Analyzer Bias und geladenes Engine Profil automatisch."),
            ("05", "CFTC Datenstand beachten", f"Dieses Profil basiert auf dem offiziellen CFTC Bericht vom {selected_profile['report_date_text']}. Es gibt kein starres Ablaufdatum."),
            ("06", "Nach neuer Auswertung erneuern", "Sobald der Analyzer einen neueren offiziellen CFTC Bericht verarbeitet hat, kopierst du das neu erzeugte Profil erneut."),
        )
        for index, (number, title, description) in enumerate(instructions):
            row, column = divmod(index, 2)
            item = tk.Frame(guide, bg=COLORS["card2"], highlightthickness=1, highlightbackground=COLORS["line"])
            item.grid(row=row, column=column, sticky="nsew", padx=8, pady=7)
            self.label(item, number, 10, COLORS["green"], "bold", COLORS["card2"]).pack(anchor="w", padx=13, pady=(10, 1))
            self.label(item, title, 11, COLORS["text"], "bold", COLORS["card2"]).pack(anchor="w", padx=13)
            self.label(item, description, 9, entry_body, "normal", COLORS["card2"], wrap=620).pack(anchor="w", fill="x", padx=13, pady=(3, 11))

        strength_reader = tk.Frame(
            guide,
            bg=COLORS["header"],
            highlightthickness=1,
            highlightbackground=COLORS["green"],
        )
        strength_reader.grid(row=3, column=0, columnspan=2, sticky="nsew", padx=8, pady=(12, 8))

        reader_header = tk.Frame(strength_reader, bg=COLORS["header"])
        reader_header.pack(fill="x", padx=18, pady=(16, 5))
        self.label(
            reader_header,
            "SO LIEST DU DIE Meridian ENTRY ENGINE",
            15,
            COLORS["text"],
            "bold",
            COLORS["header"],
        ).pack(side="left")
        self.label(
            reader_header,
            "ERST STATUS PRÜFEN  •  DANN STÄRKEPROFIL EINORDNEN",
            9,
            COLORS["green"],
            "bold",
            COLORS["header"],
        ).pack(side="right", pady=(5, 0))

        self.label(
            strength_reader,
            "Das Meridian Stärkeprofil zeigt, wie weit die technische Unterstützung des Analyzer Bias entwickelt ist. "
            "Es ist kein Kauf oder Verkaufssignal und muss immer zusammen mit dem angezeigten Bias Status gelesen werden.",
            10,
            entry_body,
            "normal",
            COLORS["header"],
            wrap=1260,
        ).pack(anchor="w", fill="x", padx=18, pady=(0, 10))

        core_rule = tk.Frame(
            strength_reader,
            bg=COLORS["card2"],
            highlightthickness=1,
            highlightbackground=COLORS["yellow"],
        )
        core_rule.pack(fill="x", padx=18, pady=(0, 13))
        self.label(
            core_rule,
            "WICHTIGSTE REGEL",
            9,
            COLORS["yellow"],
            "bold",
            COLORS["card2"],
        ).pack(side="left", padx=(13, 10), pady=10)
        self.label(
            core_rule,
            "H4 TREND und H1 STRUKTUR dürfen nicht gegen den Analyzer Bias laufen. "
            "Erst bei „BIAS INTAKT“ beginnt die aktive Suche nach einem eigenen Trading Setup.",
            10,
            COLORS["text"],
            "bold",
            COLORS["card2"],
            wrap=1080,
        ).pack(side="left", fill="x", expand=True, padx=(0, 13), pady=10)

        meter_shell = tk.Frame(
            strength_reader,
            bg=COLORS["card2"],
            highlightthickness=1,
            highlightbackground=COLORS["line"],
        )
        meter_shell.pack(fill="x", padx=18, pady=(0, 5))
        self.label(
            meter_shell,
            "Meridian STÄRKEPROFIL",
            9,
            entry_soft,
            "bold",
            COLORS["card2"],
        ).pack(anchor="w", padx=12, pady=(9, 5))

        strength_gradient = (
            "#691924", "#841E27", "#A2262B", "#C2302E", "#DA402B",
            "#E65626", "#E87425", "#E7912A", "#DEAE32", "#D2C23F",
            "#A4C643", "#69BE49", "#2DB15B", "#169453", "#0A7044",
        )
        meter = tk.Frame(meter_shell, bg=COLORS["dark"])
        meter.pack(fill="x", padx=12, pady=(0, 8))
        for column, tone in enumerate(strength_gradient):
            meter.grid_columnconfigure(column, weight=1, uniform="entry_strength_segment")
            segment = tk.Frame(meter, bg=tone, height=18)
            segment.grid(
                row=0,
                column=column,
                sticky="nsew",
                padx=(0 if column == 0 else 1, 0),
            )

        scale = tk.Frame(meter_shell, bg=COLORS["card2"])
        scale.pack(fill="x", padx=12, pady=(0, 9))
        for column in range(20):
            scale.grid_columnconfigure(column, weight=1, uniform="entry_strength_scale")
        self.label(scale, "0", 9, COLORS["red"], "bold", COLORS["card2"]).grid(row=0, column=0, sticky="w")
        self.label(scale, "45", 9, COLORS["yellow"], "bold", COLORS["card2"]).grid(row=0, column=9)
        self.label(scale, "75", 9, COLORS["green"], "bold", COLORS["card2"]).grid(row=0, column=15)
        self.label(scale, "100", 9, "#0A7044", "bold", COLORS["card2"]).grid(row=0, column=19, sticky="e")

        strength_zones = tk.Frame(strength_reader, bg=COLORS["header"])
        strength_zones.pack(fill="x", padx=13, pady=(4, 12))
        for column in range(3):
            strength_zones.grid_columnconfigure(column, weight=1, uniform="entry_strength_zone")
        zone_items = (
            (
                "ROT  •  0 BIS 44",
                "SCHUTZBEREICH",
                COLORS["red"],
                "Keine aktive Einstiegssuche. Die technische Basis unterstützt den Analyzer Bias noch nicht ausreichend. "
                "Bei „BIAS NOCH OFFEN“ oder „AKTUELL KEIN TRADE“ wird keine Position geplant.",
            ),
            (
                "GELB  •  45 BIS 74",
                "SETUPZONE",
                COLORS["yellow"],
                "Zeigt das Dashboard „BIAS INTAKT“, bestätigen H4 und H1 bereits die Grundrichtung. "
                "Jetzt darf aktiv nach einem eigenen Einstieg gesucht werden. Du musst nicht warten, bis alles grün ist.",
            ),
            (
                "GRÜN  •  75 BIS 100",
                "BESTÄTIGUNGSZONE",
                COLORS["green"],
                "Die technische Übereinstimmung ist stark. Trotzdem keinen automatischen Einstieg ableiten. "
                "Prüfe Marktphase, mögliche Überdehnung und ob die Bewegung bereits weit fortgeschritten ist.",
            ),
        )
        for column, (range_text, title, tone, description) in enumerate(zone_items):
            zone = tk.Frame(
                strength_zones,
                bg=COLORS["card"],
                highlightthickness=1,
                highlightbackground=tone,
            )
            zone.grid(
                row=0,
                column=column,
                sticky="nsew",
                padx=(0 if column == 0 else 5, 0 if column == 2 else 5),
            )
            self.label(zone, range_text, 9, tone, "bold", COLORS["card"]).pack(anchor="w", padx=14, pady=(12, 2))
            self.label(zone, title, 12, COLORS["text"], "bold", COLORS["card"]).pack(anchor="w", padx=14)
            self.label(
                zone,
                description,
                10,
                entry_body,
                "normal",
                COLORS["card"],
                wrap=410,
            ).pack(anchor="w", fill="x", padx=14, pady=(5, 13))

        self.label(
            strength_reader,
            "DIE ANZEIGEN IN EINFACHEN WORTEN",
            12,
            COLORS["text"],
            "bold",
            COLORS["header"],
        ).pack(anchor="w", padx=18, pady=(2, 5))

        metric_help = tk.Frame(strength_reader, bg=COLORS["header"])
        metric_help.pack(fill="x", padx=13, pady=(0, 12))
        for column in range(3):
            metric_help.grid_columnconfigure(column, weight=1, uniform="entry_metric_help")
        metric_help_items = (
            ("H4 TREND", "Zeigt die übergeordnete Richtung. „GEGEN BIAS“ bedeutet keine Einstiegssuche."),
            ("H1 STRUKTUR", "Prüft die mittelfristige Struktur. Auch sie darf nicht gegen den Analyzer Bias laufen."),
            ("H1 SETUP", "Zeigt, ob Pullback oder Fortsetzung technisch bereits sinnvoll vorbereitet sind."),
            ("M15 TIMING", "Hilft beim kurzfristigen Timing und bestätigt, ob der Markt in die gewünschte Richtung anläuft."),
            ("MOMENTUM", "Zeigt Richtungsstärke und warnt, wenn der Markt zu schwach oder bereits überdehnt ist."),
            ("M15 MARKTPHASE", "Unterscheidet Seitwärtsphase, Übergang, Richtung und einen möglichen Ausbruch."),
        )
        for index, (title, description) in enumerate(metric_help_items):
            row, column = divmod(index, 3)
            metric_info = tk.Frame(
                metric_help,
                bg=COLORS["card2"],
                highlightthickness=1,
                highlightbackground=COLORS["line"],
            )
            metric_info.grid(row=row, column=column, sticky="nsew", padx=5, pady=5)
            self.label(
                metric_info,
                title,
                10,
                COLORS["blue"],
                "bold",
                COLORS["card2"],
            ).pack(anchor="w", padx=13, pady=(10, 3))
            self.label(
                metric_info,
                description,
                9,
                entry_body,
                "normal",
                COLORS["card2"],
                wrap=410,
            ).pack(anchor="w", fill="x", padx=13, pady=(0, 11))

        routine = tk.Frame(
            strength_reader,
            bg=COLORS["dark"],
            highlightthickness=1,
            highlightbackground=COLORS["green"],
        )
        routine.pack(fill="x", padx=18, pady=(0, 17))
        self.label(
            routine,
            "DIE 10 SEKUNDEN ROUTINE",
            9,
            COLORS["green"],
            "bold",
            COLORS["dark"],
        ).pack(anchor="w", padx=13, pady=(10, 3))
        self.label(
            routine,
            "1. H4 und H1 dürfen nicht gegen den Bias laufen.   "
            "2. „BIAS INTAKT“ erlaubt die aktive Setupsuche.   "
            "3. Der Balken ordnet die technische Stärke ein.   "
            "4. Einstieg, Stop Loss und Risiko bleiben deine Entscheidung.",
            10,
            COLORS["text"],
            "bold",
            COLORS["dark"],
            wrap=1260,
        ).pack(anchor="w", fill="x", padx=13, pady=(0, 11))

        responsibility = tk.Frame(body, bg=COLORS["header"], highlightthickness=1, highlightbackground=COLORS["yellow"])
        responsibility.pack(fill="x", padx=2, pady=(2, 12))
        self.label(responsibility, "WICHTIGE EINORDNUNG", 11, COLORS["yellow"], "bold", COLORS["header"]).pack(anchor="w", padx=16, pady=(13, 3))
        self.label(
            responsibility,
            "Das Analyzer Profil überträgt ausschließlich die finale fundamentale Vorauswahl und den zugehörigen Bias. "
            "Die Entry Engine bewertet danach die technische Bestätigung im Chart. Sie erzeugt kein Kauf oder Verkaufssignal, "
            "berechnet weder Positionsgröße noch Stop Loss und ersetzt kein Risikomanagement.",
            10, entry_body, "normal", COLORS["header"], wrap=1320,
        ).pack(anchor="w", fill="x", padx=16, pady=(0, 14))

        footer = tk.Frame(body, bg=COLORS["bg"])
        footer.pack(fill="x", padx=2, pady=(0, 10))
        self.label(
            footer,
            "Meridian ANALYZER PRO  •  FINALE MAKRO WATCHLIST  •  TECHNISCHE BESTÄTIGUNG",
            9, entry_soft, "bold", COLORS["bg"],
        ).pack(side="left", pady=(8, 0))
        self.button(footer, "FENSTER SCHLIESSEN", close_window, COLORS["button"], COLORS["text"]).pack(side="right", ipadx=14, ipady=7)

        win.after_idle(sync_canvas)
        win.after(80, lambda: (win.lift(), win.focus_force()))

    @staticmethod
    def _version_tuple(value):
        """Convert a semantic-looking version into a comparable integer tuple."""
        text = str(value or "").strip()
        match = re.match(r"^(\d+(?:\.\d+){1,3})", text)
        if not match:
            raise ValueError("Ungültige Versionsnummer")
        parts = [int(part) for part in match.group(1).split(".")]
        while len(parts) < 4:
            parts.append(0)
        return tuple(parts[:4])

    def check_for_updates(self):
        """Run the update request only after an explicit user click."""
        if getattr(self, "_update_check_running", False):
            return
        self._update_check_running = True
        self.update_btn.config(state="disabled", fg=COLORS["muted"], disabledforeground=COLORS["muted"])
        self.status.config(text="Update wird geprüft …", fg=COLORS["blue"])
        threading.Thread(target=self._fetch_update_information, daemon=True).start()

    @staticmethod
    def _update_request_headers():
        return {
            "Accept": "application/json",
            "User-Agent": f"Meridian-Analyzer-Pro/{APP_VERSION}",
            "Cache-Control": "no-cache",
            "Pragma": "no-cache",
        }

    def _fetch_update_with_urllib(self):
        request = urllib.request.Request(UPDATE_ENDPOINT, headers=self._update_request_headers(), method="GET")
        try:
            import certifi  # type: ignore
            context = ssl.create_default_context(cafile=certifi.where())
        except Exception:
            context = ssl.create_default_context()
        with urllib.request.urlopen(request, timeout=UPDATE_TIMEOUT_SECONDS, context=context) as response:
            if getattr(response, "status", 200) != 200:
                raise RuntimeError(f"Serverantwort HTTP {getattr(response, 'status', 'unbekannt')}")
            return response.read(256 * 1024)

    def _fetch_update_with_powershell(self):
        script = (
            "$ErrorActionPreference='Stop'; "
            "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; "
            "$ProgressPreference='SilentlyContinue'; "
            f"$headers=@{{Accept='application/json'; 'User-Agent'='Meridian-Analyzer-Pro/{APP_VERSION}'; "
            "'Cache-Control'='no-cache'; Pragma='no-cache'}}; "
            f"(Invoke-WebRequest -UseBasicParsing -TimeoutSec {max(10, UPDATE_TIMEOUT_SECONDS + 4)} "
            f"-Headers $headers -Uri '{UPDATE_ENDPOINT}').Content"
        )
        completed = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", script],
            capture_output=True,
            timeout=max(15, UPDATE_TIMEOUT_SECONDS + 10),
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        if completed.returncode != 0:
            stderr = completed.stderr.decode("utf-8", errors="replace").strip()
            raise RuntimeError(stderr or f"PowerShell Fehlercode {completed.returncode}")
        return completed.stdout[:256 * 1024]

    def _fetch_update_with_curl(self):
        completed = subprocess.run(
            [
                "curl.exe", "-fsSL", "--connect-timeout", str(UPDATE_TIMEOUT_SECONDS),
                "--max-time", str(max(12, UPDATE_TIMEOUT_SECONDS + 6)),
                "-H", "Accept: application/json",
                "-H", f"User-Agent: Meridian-Analyzer-Pro/{APP_VERSION}",
                "-H", "Cache-Control: no-cache",
                UPDATE_ENDPOINT,
            ],
            capture_output=True,
            timeout=max(15, UPDATE_TIMEOUT_SECONDS + 10),
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        if completed.returncode != 0:
            stderr = completed.stderr.decode("utf-8", errors="replace").strip()
            raise RuntimeError(stderr or f"curl Fehlercode {completed.returncode}")
        return completed.stdout[:256 * 1024]

    def _fetch_update_raw(self):
        errors = []
        fetchers = [
            ("Python TLS", self._fetch_update_with_urllib),
            ("Windows TLS", self._fetch_update_with_powershell),
            ("Windows curl", self._fetch_update_with_curl),
        ]
        for name, fetcher in fetchers:
            try:
                raw = fetcher()
                if raw and raw.strip():
                    return raw
                errors.append(f"{name}: leere Antwort")
            except Exception as exc:
                errors.append(f"{name}: {exc}")
        raise RuntimeError("Keine sichere HTTPS-Verbindung möglich.\n\n" + "\n".join(errors))

    def _fetch_update_information(self):
        try:
            raw = self._fetch_update_raw()
            payload = json.loads(raw.decode("utf-8-sig", errors="strict"))
            if not isinstance(payload, dict):
                raise ValueError("Die Serverantwort hat kein gültiges Format.")
            latest = str(payload.get("latest_version", "")).strip()
            self._version_tuple(latest)
            self.after(0, lambda data=payload: self._finish_update_check(data, None))
        except urllib.error.HTTPError as exc:
            self.after(0, lambda err=f"Der Update-Server antwortet mit HTTP {exc.code}.": self._finish_update_check(None, err))
        except Exception as exc:
            self.after(0, lambda err=f"Die Update-Prüfung konnte nicht abgeschlossen werden.\n\n{exc}": self._finish_update_check(None, err))

    def _finish_update_check(self, payload, error):
        self._update_check_running = False
        self.update_btn.config(state="normal", fg=COLORS["blue"])
        if error:
            self.status.config(text="Update-Prüfung fehlgeschlagen", fg=COLORS["orange"])
            messagebox.showwarning("Update-Prüfung", error, parent=self)
            return

        latest = str(payload.get("latest_version", "")).strip()
        active = bool(payload.get("update_active", False))
        try:
            newer = self._version_tuple(latest) > self._version_tuple(APP_VERSION)
        except ValueError:
            self.status.config(text="Ungültige Serverversion", fg=COLORS["orange"])
            messagebox.showwarning("Update-Prüfung", "Der Server liefert eine ungültige Versionsnummer.", parent=self)
            return

        if not active:
            self.status.config(text="Update-Prüfung serverseitig deaktiviert", fg=COLORS["yellow"])
            messagebox.showinfo(
                "Update-Prüfung",
                f"Installierte Version: {APP_VERSION}\nServerversion: {latest}\n\nDie Update-Auslieferung ist auf dem Server derzeit deaktiviert.",
                parent=self,
            )
            return

        if not newer:
            self.status.config(text=f"Version {APP_VERSION} ist aktuell", fg=COLORS["green"])
            messagebox.showinfo(
                "Keine Aktualisierung verfügbar",
                f"Du verwendest bereits die aktuelle Version {APP_VERSION}.",
                parent=self,
            )
            return

        self.status.config(text=f"Neue Version {latest} verfügbar", fg=COLORS["yellow"])
        self._show_update_dialog(payload)

    def _show_update_dialog(self, payload):
        latest = str(payload.get("latest_version", "")).strip()
        download_url = str(payload.get("download_url", "")).strip()
        password = str(payload.get("download_password", "")).strip()
        release_date = str(payload.get("release_date", "")).strip()
        notes = payload.get("release_notes", [])
        if isinstance(notes, str):
            notes = [line.strip() for line in notes.splitlines() if line.strip()]
        elif not isinstance(notes, list):
            notes = []
        notes = [str(note).strip() for note in notes if str(note).strip()]

        win = tk.Toplevel(self)
        win.title(f"Update {latest} verfügbar")
        win.geometry("720x590")
        win.minsize(640, 520)
        win.configure(bg=COLORS["bg"])
        win.transient(self)
        win.grab_set()

        outer = tk.Frame(win, bg=COLORS["bg"])
        outer.pack(fill="both", expand=True, padx=18, pady=16)

        header = self.card(outer, COLORS["header"])
        header.pack(fill="x")
        self.label(header, "NEUE VERSION VERFÜGBAR", 10, COLORS["blue"], "bold", COLORS["header"]).pack(anchor="w", padx=16, pady=(13, 2))
        self.label(header, f"Meridian Analyzer Pro {latest}", 22, COLORS["text"], "bold", COLORS["header"]).pack(anchor="w", padx=16)
        meta = f"Installiert: {APP_VERSION}"
        if release_date:
            meta += f"    ·    Veröffentlicht: {release_date}"
        self.label(header, meta, 10, COLORS["muted"], "normal", COLORS["header"]).pack(anchor="w", padx=16, pady=(3, 13))

        body = self.card(outer, COLORS["card"])
        body.pack(fill="both", expand=True, pady=(10, 0))
        self.label(body, "NEUERUNGEN", 11, COLORS["text"], "bold", COLORS["card"]).pack(anchor="w", padx=16, pady=(14, 6))
        note_text = "\n".join(f"• {note}" for note in notes) if notes else "Für diese Version wurden keine Release Notes hinterlegt."
        self.label(body, note_text, 10, COLORS["muted"], "normal", COLORS["card"], wrap=650).pack(anchor="w", padx=16, pady=(0, 14))

        self.label(body, "DOWNLOADSEITE", 9, COLORS["muted"], "bold", COLORS["card"]).pack(anchor="w", padx=16)
        url_var = tk.StringVar(value=download_url or "Keine Downloadseite hinterlegt")
        url_entry = tk.Entry(body, textvariable=url_var, font=("Segoe UI", 10), fg=COLORS["text"], bg=COLORS["card2"], relief="flat", readonlybackground=COLORS["card2"])
        url_entry.configure(state="readonly")
        url_entry.pack(fill="x", padx=16, pady=(4, 10), ipady=7)

        password_box = tk.Frame(body, bg=COLORS["card2"], highlightthickness=1, highlightbackground=COLORS["line"])
        password_box.pack(fill="x", padx=16, pady=(0, 12))
        self.label(password_box, "PASSWORT", 9, COLORS["muted"], "bold", COLORS["card2"]).pack(side="left", padx=(12, 8), pady=10)
        self.label(password_box, password or "Kein Passwort hinterlegt", 11, COLORS["yellow"], "bold", COLORS["card2"]).pack(side="left", pady=10)

        feedback = self.label(body, "", 9, COLORS["muted"], "normal", COLORS["card"])
        feedback.pack(anchor="w", padx=16, pady=(0, 4))

        def copy_link():
            if not download_url:
                feedback.config(text="Auf dem Server ist keine Downloadseite hinterlegt.", fg=COLORS["orange"])
                return
            try:
                win.clipboard_clear()
                win.clipboard_append(download_url)
                win.update_idletasks()
                feedback.config(text="Downloadlink wurde in die Zwischenablage kopiert.", fg=COLORS["green"])
            except Exception as exc:
                feedback.config(text=f"Link konnte nicht kopiert werden: {exc}", fg=COLORS["orange"])

        def open_link():
            if not download_url:
                feedback.config(text="Auf dem Server ist keine Downloadseite hinterlegt.", fg=COLORS["orange"])
                return
            opened = False
            try:
                import webbrowser
                opened = bool(webbrowser.open(download_url, new=2))
            except Exception:
                opened = False
            if not opened:
                copy_link()
                feedback.config(text="Browser konnte nicht geöffnet werden. Der Link wurde kopiert.", fg=COLORS["orange"])

        buttons = tk.Frame(body, bg=COLORS["card"])
        buttons.pack(fill="x", padx=16, pady=(8, 16))
        open_btn = self.button(buttons, "DOWNLOADSEITE ÖFFNEN", open_link, COLORS["blue"], "#06131F")
        open_btn.pack(side="left", ipadx=12, ipady=7)
        if not download_url:
            open_btn.config(state="disabled", disabledforeground=COLORS["muted"])
        self.button(buttons, "LINK KOPIEREN", copy_link, COLORS["button"], COLORS["text"]).pack(side="left", padx=8, ipadx=12, ipady=7)
        self.button(buttons, "SCHLIESSEN", win.destroy, COLORS["button"], COLORS["text"]).pack(side="right", ipadx=12, ipady=7)

        win.protocol("WM_DELETE_WINDOW", win.destroy)
        win.after(50, lambda: win.focus_force())

    def available_main_views(self):
        views = ["cot"] if self.top3 else []
        if self.final_watchlist:
            views.append("seasonality")
        if self.macro_results:
            views.append("macro")
        return views

    def main_view_title(self, view):
        return {
            "cot": "COT Analyse",
            "seasonality": "Seasonality",
            "macro": "Makro Analyse",
        }.get(view, "COT Analyse")

    def update_main_navigation(self):
        if not hasattr(self, "nav_back_btn"):
            return
        views = self.available_main_views()
        if not views:
            self.nav_view_lbl.config(text="Noch keine Auswertung")
            self.nav_back_btn.config(state="disabled", disabledforeground=COLORS["muted"])
            self.nav_forward_btn.config(state="disabled", disabledforeground=COLORS["muted"])
            return
        if self.current_main_view not in views:
            self.current_main_view = views[-1]
        index = views.index(self.current_main_view)
        fixed_index = {"cot": 1, "seasonality": 2, "macro": 3}[self.current_main_view]
        self.nav_view_lbl.config(text=f"{self.main_view_title(self.current_main_view)} · {fixed_index} von 3")
        self.nav_back_btn.config(state="normal" if index > 0 else "disabled", disabledforeground=COLORS["muted"])
        self.nav_forward_btn.config(state="normal" if index < len(views) - 1 else "disabled", disabledforeground=COLORS["muted"])

    def show_main_view(self, view):
        if view not in self.available_main_views():
            return
        self.current_main_view = view
        self.render()
        self.status.config(text=f"Ansicht: {self.main_view_title(view)}", fg=COLORS["blue"])

    def show_previous_main_view(self):
        views = self.available_main_views()
        if self.current_main_view in views:
            index = views.index(self.current_main_view)
            if index > 0:
                self.show_main_view(views[index - 1])

    def show_next_main_view(self):
        views = self.available_main_views()
        if self.current_main_view in views:
            index = views.index(self.current_main_view)
            if index < len(views) - 1:
                self.show_main_view(views[index + 1])

    def on_engine_changed(self, event=None):
        selected_key = ENGINE_KEYS_BY_LABEL.get(self.engine_var.get(), DEFAULT_ANALYSIS_ENGINE)

        # Ein fertiger Ergebnislauf ist unveränderlich. Ranking, Top 3 und Erklärung
        # müssen immer dieselbe Engine zeigen. Ein Wechsel ist erst nach dem bewussten
        # Vorbereiten einer neuen COT Analyse möglich.
        if self.result_engine_key is not None and self.top3:
            self.engine_var.set(ENGINE_LABELS[self.result_engine_key])
            self.status.config(text="Engine gesperrt, zuerst neue COT Analyse vorbereiten", fg=COLORS["yellow"])
            return

        self.app_settings["analysis_engine"] = selected_key
        save_app_settings(self.app_settings)
        self.engine.set_analysis_engine(selected_key)
        info = ENGINE_PROFILE_INFO[selected_key]
        accent = COLORS.get(info.get("accent", "blue"), COLORS["blue"])
        self.status.config(text=f"Engine: {ENGINE_LABELS[selected_key]}", fg=accent)
        if getattr(self, "engine_hint", None) is not None:
            self.engine_hint.config(text=info["subtitle"], fg=accent)
        if getattr(self, "detail_card", None) is not None and not self.top3:
            self.render_engine_overview(selected_key)
            self.after_idle(lambda key=selected_key: self.render_engine_overview(key))

    def render_engine_overview(self, engine_key=None, rerun_notice=False):
        engine_key = engine_key or self.result_engine_key or getattr(self.engine, "analysis_engine", DEFAULT_ANALYSIS_ENGINE)
        info = ENGINE_PROFILE_INFO.get(engine_key, ENGINE_PROFILE_INFO[DEFAULT_ANALYSIS_ENGINE])
        accent = COLORS.get(info.get("accent", "blue"), COLORS["blue"])
        self.clear(self.detail_card)

        head = tk.Frame(self.detail_card, bg=COLORS["card"])
        head.pack(fill="x", padx=16, pady=(14, 4))
        title_box = tk.Frame(head, bg=COLORS["card"])
        title_box.pack(side="left", fill="x", expand=True)
        self.label(title_box, "AKTIVE ANALYSE ENGINE", 9, COLORS["muted"], "bold", COLORS["card"]).pack(anchor="w")
        self.label(title_box, ENGINE_LABELS[engine_key], 19, accent, "bold", COLORS["card"]).pack(anchor="w", pady=(1, 0))
        badge = tk.Label(head, text=info["subtitle"].upper(), font=("Segoe UI", 9, "bold"), fg=COLORS["bg"], bg=accent, padx=10, pady=5)
        badge.pack(side="right", padx=(12, 0), pady=(3, 0))

        self.label(self.detail_card, info["summary"], 11, COLORS["muted"], "normal", COLORS["card"], wrap=800).pack(anchor="w", padx=16, pady=(4, 10))
        if rerun_notice:
            note = tk.Frame(self.detail_card, bg=COLORS["card2"], highlightthickness=1, highlightbackground=accent)
            note.pack(fill="x", padx=16, pady=(0, 10))
            self.label(note, "ENGINE GEWECHSELT", 10, accent, "bold", COLORS["card2"]).pack(anchor="w", padx=10, pady=(7, 1))
            self.label(note, "Die neue Gewichtung gilt beim nächsten Klick auf COT Analyse starten. Die aktuell sichtbaren Top 3 stammen noch aus dem vorherigen Lauf.", 9, COLORS["muted"], "normal", COLORS["card2"], wrap=760).pack(anchor="w", padx=10, pady=(0, 7))

        self.label(self.detail_card, "GEWICHTUNG UND ENTSCHEIDUNGSLOGIK", 13, COLORS["text"], "bold", COLORS["card"]).pack(anchor="w", padx=16, pady=(3, 4))
        for index, (name, weight, desc) in enumerate(info["rules"], 1):
            row = tk.Frame(self.detail_card, bg=COLORS["card2"], highlightthickness=1, highlightbackground=COLORS["line"])
            row.pack(fill="x", padx=16, pady=4)
            number = tk.Label(row, text=str(index), font=("Segoe UI", 11, "bold"), fg=COLORS["bg"], bg=accent, width=3, pady=8)
            number.pack(side="left", fill="y")
            left = tk.Frame(row, bg=COLORS["card2"])
            left.pack(side="left", fill="x", expand=True, padx=10, pady=7)
            self.label(left, name, 11, COLORS["text"], "bold", COLORS["card2"]).pack(anchor="w")
            self.label(left, desc, 9, COLORS["muted"], "normal", COLORS["card2"], wrap=620).pack(anchor="w", pady=(2, 0))
            self.label(row, weight, 12, accent, "bold", COLORS["card2"]).pack(side="right", padx=12)

        footer = tk.Frame(self.detail_card, bg=COLORS["card2"], highlightthickness=1, highlightbackground=COLORS["line"])
        footer.pack(fill="x", padx=16, pady=(10, 14))
        self.label(footer, "TRADING STYLE", 9, COLORS["muted"], "bold", COLORS["card2"]).pack(anchor="w", padx=10, pady=(8, 1))
        self.label(footer, info["style"], 11, accent, "bold", COLORS["card2"], wrap=760).pack(anchor="w", padx=10, pady=(0, 7))
        self.label(footer, "EMPFOHLEN FÜR", 9, COLORS["muted"], "bold", COLORS["card2"]).pack(anchor="w", padx=10, pady=(2, 1))
        self.label(footer, info["suitable"], 10, COLORS["text"], "normal", COLORS["card2"], wrap=760).pack(anchor="w", padx=10, pady=(0, 7))
        self.label(footer, "STÄRKE", 9, COLORS["muted"], "bold", COLORS["card2"]).pack(anchor="w", padx=10, pady=(2, 1))
        self.label(footer, info["strength"], 10, COLORS["green"], "normal", COLORS["card2"], wrap=760).pack(anchor="w", padx=10, pady=(0, 7))
        self.label(footer, "ABWÄGUNG", 9, COLORS["muted"], "bold", COLORS["card2"]).pack(anchor="w", padx=10, pady=(2, 1))
        self.label(footer, info["tradeoff"], 10, COLORS["yellow"], "normal", COLORS["card2"], wrap=760).pack(anchor="w", padx=10, pady=(0, 9))

        # Zweistufig, damit auch nach einem Engine Wechsel während eines bereits
        # aufgebauten Fensters die neue Geometrie sofort sichtbar wird.
        self.refresh_detail_canvas(reset_to_top=True)
        self.after_idle(lambda: self.refresh_detail_canvas(reset_to_top=True))

    def refresh_detail_canvas(self, reset_to_top=True):
        """Synchronisiert die neu aufgebauten Engine Inhalte sofort mit dem Canvas.

        Tkinter berechnet die angeforderte Höhe verschachtelter Frames teilweise erst
        im nächsten Idle Zyklus. Ohne diese Synchronisierung kann die Engine Seite
        nach einem Profilwechsel leer wirken, bis eine Scroll Aktion ein Redraw auslöst.
        """
        if not getattr(self, "detail_canvas", None) or not getattr(self, "detail_card", None):
            return
        try:
            self.detail_card.update_idletasks()
            self.detail_canvas.update_idletasks()
            width = max(1, self.detail_canvas.winfo_width())
            self.detail_canvas.itemconfigure(self.detail_window, width=width)
            self.detail_canvas.configure(scrollregion=self.detail_canvas.bbox("all"))
            if reset_to_top:
                self.detail_canvas.yview_moveto(0)
            self.detail_canvas.update_idletasks()
        except tk.TclError:
            return

    def clear(self, frame):
        for w in frame.winfo_children():
            w.destroy()

    def set_engine_selector_locked(self, locked):
        if getattr(self, "engine_selector", None) is None:
            return
        self.engine_selector.config(state="disabled" if locked else "readonly")
        if locked and self.result_engine_key:
            self.engine_var.set(ENGINE_LABELS[self.result_engine_key])
            info = ENGINE_PROFILE_INFO[self.result_engine_key]
            self.engine_hint.config(
                text=f"Ergebnis fest mit {ENGINE_LABELS[self.result_engine_key]} berechnet. Für einen Wechsel zuerst neue COT Analyse vorbereiten.",
                fg=COLORS.get(info.get("accent", "blue"), COLORS["blue"]),
            )

    def start_or_prepare(self):
        if self.top3 or self.result_engine_key is not None:
            self.prepare_new_analysis()
        else:
            self.start()

    def prepare_new_analysis(self):
        self.reset_entry_engine_profiles()
        self.macro_results = []
        self.seasonality = []
        self.single_asset_seasonality = []
        self.final_watchlist = []
        self.top3 = []
        self.all_pairs = []
        self.strengths = {}
        self.result_engine_key = None
        self.current_main_view = "cot"
        self.set_engine_selector_locked(False)
        self.engine.set_analysis_engine(self.app_settings.get("analysis_engine", DEFAULT_ANALYSIS_ENGINE))
        self.start_btn.config(state="normal", text="1. COT ANALYSE STARTEN")
        self.status.config(text="Neue Analyse vorbereitet, Engine auswählen", fg=COLORS["blue"])
        self.render_empty()

    def footer_primary_action(self):
        # Dieser Button bleibt ausschließlich für Schritt 2 zuständig. Der Neustart
        # nach der finalen Makroprüfung läuft bewusst über den COT Hauptbutton.
        self.start_seasonality()

    def restart_full_analysis(self):
        # Kompatibilitätsmethode für ältere Aufrufe. Ein Neustart wird nur vorbereitet,
        # damit zuerst die Engine Übersicht erscheint und der Nutzer die Engine wählen kann.
        self.prepare_new_analysis()

    def set_seasonality_buttons(self, enabled, text=None):
        label = text or ("2. SEASONALITY PRÜFEN" if enabled else "2. SEASONALITY NACH COT")
        state = "normal" if enabled else "disabled"
        bg = COLORS["green"] if enabled else COLORS["button"]
        fg = "#04120A" if enabled else COLORS["muted"]
        for attr in ("season_btn", "season_btn_header"):
            btn = getattr(self, attr, None)
            if btn is not None:
                btn.config(text=label, state=state, bg=bg, activebackground=bg, fg=fg, activeforeground=fg, disabledforeground=COLORS["muted"])

    def set_macro_buttons(self, enabled, text=None):
        label = text or ("3. MAKROS PRÜFEN" if enabled else "3. MAKROS NACH SEASONALITY")
        state = "normal" if enabled else "disabled"
        bg = COLORS["blue"] if enabled else COLORS["button"]
        fg = "#04120A" if enabled else COLORS["muted"]
        for attr in ("macro_btn", "macro_btn_header"):
            btn = getattr(self, attr, None)
            if btn is not None:
                btn.config(text=label, state=state, bg=bg, activebackground=bg, fg=fg, activeforeground=fg, disabledforeground=COLORS["muted"])

    def set_champions_button(self, enabled, text=None):
        btn = getattr(self, "champions_btn_header", None)
        if btn is None:
            return
        label = text or ("🏆  CHAMPIONS BEREIT" if enabled else "🏆  4. CHAMPIONS NACH MAKROS")
        if enabled:
            btn.config(text=label, state="normal", bg="#C99720", activebackground="#F5D76E", fg="#120D02", activeforeground="#120D02", disabledforeground=COLORS["muted"])
        else:
            btn.config(text=label, state="disabled", bg=COLORS["button"], activebackground=COLORS["button"], fg=COLORS["muted"], activeforeground=COLORS["muted"], disabledforeground=COLORS["muted"])

    def start_champions_glow(self):
        self.stop_champions_glow()
        self._champions_glow_phase = 0
        def pulse():
            btn = getattr(self, "champions_btn_header", None)
            if btn is None or str(btn.cget("state")) == "disabled":
                return
            palette = [("#A87913", "#FFF1A8"), ("#D4AF37", "#120D02"), ("#F2CF63", "#120D02"), ("#D4AF37", "#120D02")]
            bg, fg = palette[self._champions_glow_phase % len(palette)]
            btn.config(bg=bg, activebackground="#F5D76E", fg=fg, activeforeground="#120D02")
            self._champions_glow_phase += 1
            if self._champions_glow_phase < 12:
                self._champions_glow_job = self.after(150, pulse)
            else:
                btn.config(bg="#C99720", fg="#120D02")
                self._champions_glow_job = None
        pulse()

    def stop_champions_glow(self):
        if self._champions_glow_job:
            try:
                self.after_cancel(self._champions_glow_job)
            except Exception:
                pass
        self._champions_glow_job = None

    def open_or_build_champions(self):
        if not self.macro_results:
            messagebox.showwarning("Champions gesperrt", "Bitte zuerst COT, Seasonality und Makros vollständig abschließen.")
            return
        if self.champions_ready and self.champions_results:
            self.show_champions_window()
            return
        if self.champions_generating:
            return
        self.champions_generating = True
        self.stop_champions_glow()
        self.set_champions_button(False, "🏆  CHAMPIONS WERDEN ERMITTELT...")
        self.status.config(text="Champions Finale wird erstellt", fg="#D4AF37")
        self.set_progress(72, "Drei Analysephilosophien treffen sich im Champions Finale")
        self.champions_queue = queue.Queue()

        def worker():
            try:
                champions = {}
                season_errors = []
                macro_errors = []
                engine_keys = (ENGINE_CLASSIC, ENGINE_FLOW, ENGINE_HYBRID)
                for idx, engine_key in enumerate(engine_keys, 1):
                    clone = copy.copy(self.engine)
                    clone.progress = lambda pct, text: None
                    clone.set_analysis_engine(engine_key)
                    strengths = clone.compute_current_strengths()
                    top3, _ = clone.compute_pairs(strengths)
                    self.champions_queue.put(("progress", 70 + idx * 5, f"{ENGINE_LABELS[engine_key]} Ranking abgeschlossen"))

                    season_engine = SeasonalityEngine(progress=lambda pct, text: None)
                    season_rows = season_engine.analyze_top3(top3, self.engine.report_date)
                    season_errors.extend(season_engine.errors)
                    macro_engine = MacroEngine(progress=lambda pct, text: None)
                    macro_rows = macro_engine.analyze_watchlist(season_rows[:3])
                    macro_errors.extend(macro_engine.errors)
                    macro_rows.sort(key=lambda r: safe_float(r.get("final_quality", 0), 0), reverse=True)
                    if macro_rows:
                        winner = macro_rows[0]
                        source = next((r for r in season_rows if r.get("pair") == winner.get("pair") and r.get("direction") == winner.get("direction")), season_rows[0] if season_rows else {})
                        winner["engine_key"] = engine_key
                        winner["engine_label"] = ENGINE_LABELS[engine_key]
                        winner["cot_confidence"] = safe_float(source.get("cot_confidence", source.get("confidence", winner.get("cot_score", 50))), 50)
                        winner["seasonality_score"] = safe_float(source.get("seasonality_score", winner.get("seasonality_score", 50)), 50)
                        winner["seasonality_verdict"] = source.get("verdict", winner.get("seasonality_verdict", "NEUTRAL"))
                        winner["source_setup"] = source
                        champions[engine_key] = winner
                    self.champions_queue.put(("progress", 78 + idx * 7, f"{ENGINE_LABELS[engine_key]} Champion ermittelt"))
                self.champions_queue.put(("done", champions, season_errors, macro_errors))
            except Exception as exc:
                self.champions_queue.put(("error", str(exc)))

        threading.Thread(target=worker, daemon=True).start()
        self.after(120, self.poll_champions_worker)

    def poll_champions_worker(self):
        try:
            while True:
                item = self.champions_queue.get_nowait()
                if item[0] == "progress":
                    _, pct, text = item
                    self.set_progress(pct, text)
                elif item[0] == "done":
                    _, champions, season_errors, macro_errors = item
                    self.champions_results = champions
                    self.champions_ready = len(champions) == 3
                    self.champions_generating = False
                    if not self.champions_ready:
                        raise RuntimeError("Nicht alle drei Engines konnten einen finalen Champion liefern.")
                    self.set_progress(100, "Champions Finale freigeschaltet")
                    self.status.config(text="Champions bereit", fg="#F2CF63")
                    self.set_champions_button(True, "🏆  CHAMPIONS ÖFFNEN")
                    self.start_champions_glow()
                    self.save_weekly_archive_champions()
                    self.show_champions_window()
                    return
                elif item[0] == "error":
                    raise RuntimeError(item[1])
        except queue.Empty:
            self.after(120, self.poll_champions_worker)
        except Exception as exc:
            self.champions_generating = False
            self.set_champions_button(True, "🏆  CHAMPIONS ERNEUT VERSUCHEN")
            self.status.config(text="Champions Fehler", fg=COLORS["red"])
            messagebox.showerror("Champions Fehler", str(exc))

    def champion_reason(self, engine_key, row):
        pair = row.get("pair", "")
        direction = row.get("direction", "")
        cot = safe_float(row.get("cot_score", row.get("cot_confidence", 50)), 50)
        season = safe_float(row.get("seasonality_score", 50), 50)
        macro = safe_float(row.get("macro_score", 50), 50)
        quality = safe_float(row.get("final_quality", row.get("final_confluence", 50)), 50)
        source = row.get("source_setup", {}) or {}
        if engine_key == ENGINE_CLASSIC:
            core = "die stärkste langfristig bestätigte Commercial Positionierung"
        elif engine_key == ENGINE_FLOW:
            core = "die dynamischste aktuelle institutionelle Kapitalrotation"
        else:
            core = "den ausgewogensten Gesamtkontext aus Positionierung, Flow und Marktqualität"
        season_text = "saisonalen Rückenwind" if season >= 55 else "eine neutrale saisonale Lage" if season >= 45 else "saisonalen Gegenwind"
        macro_text = "Makro Unterstützung" if macro >= 55 else "ein neutrales Makroumfeld" if macro >= 45 else "Makro Gegenwind"
        return f"{pair} {direction} verbindet {core} mit {season_text} und {macro_text}. Die finale Qualitätswertung beträgt {quality:.1f} Punkte."

    def show_champions_window(self):
        if not self.champions_results:
            return

        win = tk.Toplevel(self)
        win.title(f"Meridian Engine Champions · {self.engine.report_date}")
        win.geometry("1480x920")
        win.minsize(1220, 790)
        win.configure(bg="#070A10")
        win.transient(self)

        scroll_shell = tk.Frame(win, bg="#070A10")
        scroll_shell.pack(fill="both", expand=True)

        scrollbar = tk.Scrollbar(
            scroll_shell, orient="vertical", bg="#101827", troughcolor="#070A10",
            activebackground="#D4AF37", highlightthickness=0, bd=0
        )
        scrollbar.pack(side="right", fill="y")

        canvas = tk.Canvas(
            scroll_shell, bg="#070A10", highlightthickness=0,
            yscrollcommand=scrollbar.set
        )
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.config(command=canvas.yview)

        body = tk.Frame(canvas, bg="#0B111C")
        body_window = canvas.create_window(0, 0, anchor="nw", window=body)

        def resize_layout(event=None):
            width = max(canvas.winfo_width(), 1180)
            canvas.itemconfigure(body_window, width=width)
            canvas.coords(body_window, 0, 0)
            canvas.delete("champion_border")
            height = max(canvas.winfo_height(), body.winfo_reqheight())
            canvas.create_rectangle(12, 12, width - 12, height - 12, outline="#6F5114", width=2, tags="champion_border")
            canvas.create_rectangle(18, 18, width - 18, height - 18, outline="#D4AF37", width=1, tags="champion_border")
            canvas.tag_lower("champion_border")
            canvas.configure(scrollregion=(0, 0, width, max(height, body.winfo_reqheight() + 26)))

        canvas.bind("<Configure>", resize_layout)
        body.bind("<Configure>", resize_layout)

        def scroll_mousewheel(event):
            # Windows/macOS liefern event.delta, Linux nutzt Button 4/5.
            if getattr(event, "num", None) == 4:
                canvas.yview_scroll(-1, "units")
            elif getattr(event, "num", None) == 5:
                canvas.yview_scroll(1, "units")
            elif getattr(event, "delta", 0):
                direction = -1 if event.delta > 0 else 1
                canvas.yview_scroll(direction * 3, "units")
            return "break"

        win.bind("<MouseWheel>", scroll_mousewheel)
        win.bind("<Button-4>", scroll_mousewheel)
        win.bind("<Button-5>", scroll_mousewheel)

        hero = tk.Frame(body, bg="#0B111C")
        hero.pack(fill="x", padx=46, pady=(28, 16))
        hero.grid_columnconfigure(0, weight=1)
        hero.grid_columnconfigure(1, weight=0)

        title_box = tk.Frame(hero, bg="#0B111C")
        title_box.grid(row=0, column=0, sticky="nsew", padx=(170, 16))
        tk.Label(title_box, text="🏆", font=("Segoe UI Emoji", 44), fg="#F2CF63", bg="#0B111C").pack()
        title_label = tk.Label(title_box, text="ENGINE CHAMPIONS", font=("Segoe UI", 30, "bold"), fg="#F2CF63", bg="#0B111C")
        title_label.pack()
        tk.Label(
            title_box,
            text="Nach Abschluss aller Analysen präsentiert jede Meridian Engine genau das Setup, das ihren Ansatz in der aktuellen Marktphase am besten repräsentiert.",
            font=("Segoe UI", 11), fg="#C9B77D", bg="#0B111C", wraplength=780, justify="center"
        ).pack(pady=(7, 0))
        tk.Label(
            title_box,
            text="Wenn jede Engine nach COT, Seasonality und Makro nur eine Handelsidee wählen dürfte",
            font=("Segoe UI", 10, "italic"), fg="#8FA4BF", bg="#0B111C"
        ).pack(pady=(5, 0))

        report = tk.Frame(hero, bg="#101827", highlightthickness=1, highlightbackground="#6F5114")
        report.grid(row=0, column=1, sticky="ne", pady=(7, 0))
        tk.Label(report, text="FINAL REPORT", font=("Segoe UI", 9, "bold"), fg="#D4AF37", bg="#101827").pack(anchor="w", padx=14, pady=(10, 3))
        tk.Label(report, text=str(self.engine.report_date), font=("Segoe UI", 12, "bold"), fg="#FFFFFF", bg="#101827").pack(anchor="w", padx=14)
        tk.Label(report, text="✓ COT abgeschlossen", font=("Segoe UI", 8, "bold"), fg=COLORS["green"], bg="#101827").pack(anchor="w", padx=14, pady=(8, 1))
        tk.Label(report, text="✓ Seasonality abgeschlossen", font=("Segoe UI", 8, "bold"), fg=COLORS["green"], bg="#101827").pack(anchor="w", padx=14, pady=1)
        tk.Label(report, text="✓ Makro abgeschlossen", font=("Segoe UI", 8, "bold"), fg=COLORS["green"], bg="#101827").pack(anchor="w", padx=14, pady=(1, 10))

        separator = tk.Frame(body, bg="#6F5114", height=1)
        separator.pack(fill="x", padx=72, pady=(0, 18))

        # Neu in 0.0.3: Transparente Konflikt/Konsens Anzeige zwischen den drei
        # Champions. Verändert keine Scores, sondern macht nur sichtbar, wenn
        # zwei Engines für dasselbe Paar entgegengesetzte Richtungen berechnet
        # haben, beziehungsweise wenn mehrere Engines übereinstimmen.
        champion_rows_by_engine = {
            engine_key: [self.champions_results[engine_key]]
            for engine_key in (ENGINE_CLASSIC, ENGINE_FLOW, ENGINE_HYBRID)
            if engine_key in self.champions_results
        }
        champion_conflicts = build_direction_conflict_index(champion_rows_by_engine)
        champion_consensus = build_consensus_records(champion_rows_by_engine, include_single=False)
        if champion_conflicts:
            conflict_banner = tk.Frame(body, bg="#2A1216", highlightthickness=1, highlightbackground=COLORS["red"])
            conflict_banner.pack(fill="x", padx=72, pady=(0, 14))
            tk.Label(conflict_banner, text="⚠ WIDERSPRUCH ZWISCHEN ENGINES", font=("Segoe UI", 10, "bold"), fg=COLORS["red"], bg="#2A1216").pack(anchor="w", padx=14, pady=(9, 2))
            for conflict in champion_conflicts.values():
                tk.Label(conflict_banner, text=f"{conflict['pair']}: {conflict['detail']}", font=("Segoe UI", 9), fg="#F0C4C8", bg="#2A1216", wraplength=1300, justify="left").pack(anchor="w", padx=14, pady=(0, 2))
            tk.Label(conflict_banner, text=DIRECTION_CONFLICT_MESSAGE, font=("Segoe UI", 9, "italic"), fg="#C99", bg="#2A1216", wraplength=1300, justify="left").pack(anchor="w", padx=14, pady=(0, 9))
        elif champion_consensus:
            consensus_banner = tk.Frame(body, bg="#0F2318", highlightthickness=1, highlightbackground=COLORS["green"])
            consensus_banner.pack(fill="x", padx=72, pady=(0, 14))
            tk.Label(consensus_banner, text="✓ ENGINE KONSENS", font=("Segoe UI", 10, "bold"), fg=COLORS["green"], bg="#0F2318").pack(anchor="w", padx=14, pady=(9, 2))
            for record in champion_consensus:
                tk.Label(
                    consensus_banner,
                    text=f"{record['pair']} {record['direction']} — {record['level']} ({', '.join(record['engine_labels'])})",
                    font=("Segoe UI", 9), fg="#B8E8C8", bg="#0F2318",
                ).pack(anchor="w", padx=14, pady=(0, 2))
            tk.Label(consensus_banner, text="Reine Information: unabhängige Übereinstimmung mehrerer Engines, kein zusätzlicher Punktebonus auf die Scores.", font=("Segoe UI", 9, "italic"), fg="#9C9", bg="#0F2318").pack(anchor="w", padx=14, pady=(0, 9))

        # Das Setup mit der höchsten finalen Qualitätswertung steht als Wochen-Podium
        # in der Mitte. Das verändert keine Engine-Wertung, sondern nur die Präsentation.
        engine_keys = (ENGINE_CLASSIC, ENGINE_FLOW, ENGINE_HYBRID)
        overall_key = max(
            engine_keys,
            key=lambda key: safe_float(
                self.champions_results[key].get("final_quality", self.champions_results[key].get("final_confluence", 0)), 0
            ),
        )
        side_keys = [key for key in engine_keys if key != overall_key]
        display_keys = (side_keys[0], overall_key, side_keys[1])

        cards = tk.Frame(body, bg="#0B111C")
        cards.pack(fill="both", expand=True, padx=42, pady=(0, 18))
        cards.grid_rowconfigure(0, weight=1)
        cards.grid_columnconfigure(0, weight=10, uniform="champ_side")
        cards.grid_columnconfigure(1, weight=12)
        cards.grid_columnconfigure(2, weight=10, uniform="champ_side")

        styles = {
            ENGINE_CLASSIC: {
                "title": "CLASSIC CHAMPION",
                "subtitle": "Beste langfristige Commercial Position",
                "badges": ("KONSERVATIV", "COMMERCIAL", "SWING"),
                "accent": COLORS["blue"],
            },
            ENGINE_FLOW: {
                "title": "FLOW CHAMPION",
                "subtitle": "Stärkste institutionelle Dynamik",
                "badges": ("DYNAMISCH", "ROTATION", "MOMENTUM"),
                "accent": COLORS["green"],
            },
            ENGINE_HYBRID: {
                "title": "HYBRID CHAMPION",
                "subtitle": "Ausgewogenster Gesamtkontext",
                "badges": ("AUSGEWOGEN", "KONTEXT", "MULTI FAKTOR"),
                "accent": COLORS["yellow"],
            },
        }

        for col, engine_key in enumerate(display_keys):
            row = self.champions_results[engine_key]
            is_overall = engine_key == overall_key
            card_bg = "#121D30" if is_overall else "#101827"
            border = "#F2CF63" if is_overall else "#B88922"
            thickness = 3 if is_overall else 2
            card = tk.Frame(cards, bg=card_bg, highlightthickness=thickness, highlightbackground=border)
            card.grid(
                row=0, column=col, sticky="nsew", padx=10,
                pady=(0, 0) if is_overall else (30, 18)
            )

            style = styles[engine_key]
            if is_overall:
                ribbon = tk.Label(
                    card, text="★  HÖCHSTE GESAMTBEWERTUNG DIESER WOCHE  ★",
                    font=("Segoe UI", 9, "bold"), fg="#120D02", bg="#F2CF63"
                )
                ribbon.pack(fill="x")
                icon_pad = (16, 3)
            else:
                icon_pad = (20, 3)

            tk.Label(card, text="✦   🏆   ✦", font=("Segoe UI Emoji", 19 if is_overall else 17, "bold"), fg="#F2CF63", bg=card_bg).pack(pady=icon_pad)
            tk.Label(
                card, text=style["title"],
                font=("Segoe UI", 14 if is_overall else 12, "bold"),
                fg=style["accent"], bg=card_bg
            ).pack()
            tk.Label(card, text=ENGINE_LABELS[engine_key], font=("Segoe UI", 9, "bold"), fg="#8FA4BF", bg=card_bg).pack(pady=(2, 3))
            tk.Label(card, text=style["subtitle"], font=("Segoe UI", 9, "italic"), fg="#C9B77D", bg=card_bg).pack(pady=(0, 14))

            tk.Label(card, text=row.get("pair", "—"), font=("Segoe UI", 34 if is_overall else 30, "bold"), fg="#FFFFFF", bg=card_bg).pack()
            dcol = COLORS["green"] if row.get("direction") == "LONG" else COLORS["red"]
            tk.Label(card, text=row.get("direction", ""), font=("Segoe UI", 19 if is_overall else 17, "bold"), fg=dcol, bg=card_bg).pack(pady=(1, 8))
            q = safe_float(row.get("final_quality", row.get("final_confluence", 50)), 50)
            tk.Label(card, text=f"{star_text(q)}   {q:.1f}", font=("Segoe UI", 15 if is_overall else 13, "bold"), fg="#F2CF63", bg=card_bg).pack(pady=(0, 14))

            tk.Frame(card, bg="#8A681C" if is_overall else "#6F5114", height=1).pack(fill="x", padx=24)
            tk.Label(card, text="WARUM DIESER CHAMPION?", font=("Segoe UI", 9, "bold"), fg="#D4AF37", bg=card_bg).pack(anchor="w", padx=24, pady=(15, 5))
            tk.Label(
                card, text=self.champion_reason(engine_key, row), font=("Segoe UI", 10),
                fg="#D8E1ED", bg=card_bg, justify="left", wraplength=390 if is_overall else 350
            ).pack(anchor="w", padx=24)

            metrics = (
                f"COT {safe_float(row.get('cot_score', 50), 50):.1f}   ·   "
                f"Saison {safe_float(row.get('seasonality_score', 50), 50):.1f}   ·   "
                f"Makro {safe_float(row.get('macro_score', 50), 50):.1f}"
            )
            tk.Label(card, text=metrics, font=("Segoe UI", 9, "bold"), fg="#AFC0D4", bg=card_bg).pack(pady=(17, 10))

            badge_row = tk.Frame(card, bg=card_bg)
            badge_row.pack(pady=(0, 20))
            for badge in style["badges"]:
                tk.Label(
                    badge_row, text=f"  {badge}  ", font=("Segoe UI", 8, "bold"),
                    fg="#F2CF63", bg="#19243A", highlightthickness=1, highlightbackground="#6F5114"
                ).pack(side="left", padx=3)

        footer = tk.Frame(body, bg="#0E1522", highlightthickness=1, highlightbackground="#6F5114")
        footer.pack(fill="x", padx=52, pady=(0, 12))
        pairs = [self.champions_results[k].get("pair") for k in engine_keys]
        unique = len(set(pairs))
        summary = (
            "Drei unterschiedliche Marktchancen zeigen die klar getrennten Analysephilosophien."
            if unique == 3 else
            "Zwei Engines bevorzugen dasselbe Paar. Die Eigenständigkeit jeder Engine bleibt vollständig sichtbar."
            if unique == 2 else
            "Alle drei Analysephilosophien bevorzugen aktuell dasselbe Paar."
        )
        overall_row = self.champions_results[overall_key]
        overall_text = (
            f"Wochen-Podium: {overall_row.get('pair', '—')} {overall_row.get('direction', '')} aus "
            f"{ENGINE_LABELS[overall_key]} erzielt mit "
            f"{safe_float(overall_row.get('final_quality', overall_row.get('final_confluence', 0)), 0):.1f} Punkten "
            "die höchste finale Qualitätswertung."
        )
        tk.Label(footer, text="RESEARCH SUMMARY", font=("Segoe UI", 10, "bold"), fg="#D4AF37", bg="#0E1522").pack(anchor="w", padx=16, pady=(10, 2))
        tk.Label(footer, text=overall_text, font=("Segoe UI", 10, "bold"), fg="#F2CF63", bg="#0E1522").pack(anchor="w", padx=16, pady=(0, 2))
        tk.Label(footer, text=summary, font=("Segoe UI", 10), fg="#C7D2E1", bg="#0E1522").pack(anchor="w", padx=16, pady=(0, 10))

        disclaimer = tk.Frame(body, bg="#0B1019", highlightthickness=1, highlightbackground="#4D5666")
        disclaimer.pack(fill="x", padx=52, pady=(0, 28))
        tk.Label(disclaimer, text="WICHTIGER HINWEIS", font=("Segoe UI", 9, "bold"), fg="#D4AF37", bg="#0B1019").pack(anchor="w", padx=16, pady=(10, 3))
        tk.Label(
            disclaimer,
            text=(
                "Die Engine Champions stellen Ergebnisse einer automatisierten Research-Analyse dar und rechtfertigen für sich allein keine endgültige Handelsentscheidung. "
                "Die konkrete Umsetzung im Chart, einschließlich moderner technischer Analyse und eines angemessenen Risikomanagements, bleibt ein wesentlicher Bestandteil des Tradingprozesses. "
                "Die Software dient ausschließlich Informations- und Analysezwecken, stellt keine Anlageberatung und keine Aufforderung zum Kauf oder Verkauf von Finanzinstrumenten dar. "
                "Jede Handelsentscheidung erfolgt eigenverantwortlich."
            ),
            font=("Segoe UI", 9), fg="#AFC0D4", bg="#0B1019", justify="left", wraplength=1320
        ).pack(anchor="w", padx=16, pady=(0, 11))

        # Dezenter Titel-Glanz und ein kurzer Goldimpuls am Wochen-Podium.
        shine = ["#8A681C", "#C99720", "#FFF1A8", "#F2CF63", "#C99720"]
        steps = {"i": 0}
        def shimmer():
            if not win.winfo_exists() or steps["i"] >= 14:
                return
            title_label.config(fg=shine[steps["i"] % len(shine)])
            steps["i"] += 1
            win.after(110, shimmer)
        win.after(120, shimmer)
        win.after(80, resize_layout)

    def show_final_restart_state(self):
        # Nach Schritt 3 gibt es genau eine Aktion. Der erste Klick bereitet eine
        # neue Auswertung vor, zeigt die Engine Übersicht und entsperrt die Auswahl.
        self.show_standard_action_buttons()
        self.start_btn.config(
            state="normal",
            text="NEUE AUSWERTUNG VORBEREITEN",
            bg=COLORS["green"],
            activebackground=COLORS["green"],
            fg="#04120A",
            activeforeground="#04120A",
        )
        for attr in ("season_btn_header", "macro_btn_header"):
            btn = getattr(self, attr, None)
            if btn is not None:
                try:
                    btn.grid_remove()
                except Exception:
                    pass


    def show_standard_action_buttons(self):
        start_btn = getattr(self, "start_btn", None)
        if start_btn is not None and not start_btn.winfo_ismapped():
            try:
                start_btn.pack(fill="x", ipady=6)
            except Exception:
                pass
        for attr in ("season_btn_header", "macro_btn_header", "champions_btn_header"):
            btn = getattr(self, attr, None)
            if btn is not None and not btn.winfo_ismapped():
                try:
                    btn.grid()
                except Exception:
                    pass


    def set_progress(self, pct, text):
        self.progress_label.config(text=text)
        self.progress_canvas.delete("all")
        width = max(1, self.progress_canvas.winfo_width())
        height = max(18, self.progress_canvas.winfo_height())
        self.progress_canvas.create_rectangle(0, 0, int(width * pct / 100), height, fill=COLORS["green"], outline="")
        self.progress_canvas.create_text(width // 2, height // 2, text=f"{pct:.0f} %", fill=COLORS["text"], font=("Segoe UI", 9, "bold"))
        self.update_idletasks()

    def render_empty(self):
        if self.result_engine_key is None:
            self.set_engine_selector_locked(False)
        self.reset_entry_engine_profiles()
        self.seasonality = []
        self.single_asset_seasonality = []
        self.final_watchlist = []
        self.macro_results = []
        self.champions_results = {}
        self.champions_ready = False
        self.champions_generating = False
        self.stop_champions_glow()
        self.set_champions_button(False)
        self.show_standard_action_buttons()
        self.set_seasonality_buttons(False)
        self.set_macro_buttons(False)
        self.set_entry_engine_button(False)
        self.set_progress(0, "Bereit für aktuelle COT Wochenanalyse")
        self.data_status.config(text="")
        self.cftc_loaded_lbl.config(text="Noch nicht geprüft", fg=COLORS["yellow"])
        self.report_lbl.config(text="Report: noch nicht geladen", fg=COLORS["muted"])
        self.cache_lbl.config(text="Cache: noch nicht geprüft", fg=COLORS["muted"])
        self.market_count_lbl.config(text="Märkte: 0", fg=COLORS["muted"])
        for i, card in enumerate(self.watch_cards):
            self.clear(card)
            self.label(card, f"#{i + 1} TOP SETUP", 11, COLORS["muted"], "bold", COLORS["card2"]).pack(anchor="w", padx=16, pady=(14, 0))
            tk.Label(card, text="WARTET", font=("Segoe UI", 25, "bold"), fg=COLORS["muted"], bg=COLORS["card2"]).pack(anchor="w", padx=16, pady=(8, 0))
            self.label(card, "Klicke auf Top 3 berechnen", 10, COLORS["muted"], "bold", COLORS["card2"]).pack(anchor="w", padx=16, pady=(8, 16))

        self.render_single_asset_strip()

        self.clear(self.strength_card)
        self.label(self.strength_card, "Meridian RESEARCH STATUS", 16, COLORS["text"], "bold", COLORS["card"]).pack(anchor="w", padx=16, pady=(14, 4))
        self.label(self.strength_card, "Noch keine Analyse gestartet.", 11, COLORS["muted"], "normal", COLORS["card"]).pack(anchor="w", padx=16, pady=(0, 12))

        self.render_engine_overview(getattr(self.engine, "analysis_engine", DEFAULT_ANALYSIS_ENGINE))
        self.update_main_navigation()

    def start(self):
        self.on_engine_changed()
        self.start_btn.config(state="disabled", text="COT ANALYSE LÄUFT...")
        self.status.config(text="Weekly Engine läuft", fg=COLORS["yellow"])
        self.render_empty()

        # Der Prüfstatus erscheint erst, wenn die Analyse wirklich gestartet wurde.
        # Der obere Gesamtstatus bleibt bis zum fertigen Ergebnis leer, damit kein
        # doppelter Statushinweis in der Datenkarte angezeigt wird.
        self.data_status.config(text="")
        self.cftc_loaded_lbl.config(text="CFTC Daten werden geprüft", fg=COLORS["yellow"])
        self.report_lbl.config(text="Report: wird ermittelt", fg=COLORS["muted"])
        self.cache_lbl.config(text="Cache: wird geprüft", fg=COLORS["muted"])
        self.market_count_lbl.config(text="Märkte: 0", fg=COLORS["muted"])
        self.after(300, self.finish)

    def save_weekly_archive_snapshot(self, depth_level=1):
        """Speichert die aktuellen Top 3 aller drei Engines im Wochenarchiv.

        Läuft komplett ohne zusätzlichen Netzwerkzugriff (nutzt bereits
        geladene CFTC Daten via build_all_engine_profile_audit). Fehler hier
        dürfen den normalen Analyseablauf nie unterbrechen, deshalb wird
        alles defensiv abgefangen.
        """
        try:
            if not self.strengths or not getattr(self.engine, "report_date", None):
                return
            profiles = self.build_all_engine_profile_audit()
            payload = {}
            for engine_key, profile in profiles.items():
                top3 = list(profile.get("top3", []) or [])[:3]
                if not top3:
                    continue
                payload[engine_key] = {
                    "depth_level": int(depth_level),
                    "top3": [
                        {
                            "pair": row.get("pair"),
                            "direction": row.get("direction"),
                            "confidence": row.get("confidence"),
                            "final_quality": row.get("final_quality", row.get("final_confluence", row.get("confidence"))),
                            "cot_score": row.get("cot_confidence", row.get("confidence")),
                            "seasonality_score": row.get("seasonality_score"),
                            "macro_score": row.get("macro_score"),
                        }
                        for row in top3
                    ],
                }
            if payload:
                self.weekly_archive.merge_week(self.engine.report_date, engines=payload)
            self.refresh_weekly_archive_button()
        except Exception as exc:
            # Bewusst nur loggen, nie eine Fehlermeldung an den Nutzer werfen -
            # das Wochenarchiv ist ein Diagnose Zusatzfeature, kein Kernpfad.
            self.weekly_archive.last_error = str(exc)

    def save_weekly_archive_champions(self):
        """Ergänzt den aktuellen Wochenarchiv Eintrag um die finalen Champions."""
        try:
            if not getattr(self, "champions_results", None) or not getattr(self.engine, "report_date", None):
                return
            champions_payload = {
                engine_key: {
                    "pair": row.get("pair"),
                    "direction": row.get("direction"),
                    "final_quality": row.get("final_quality", row.get("final_confluence")),
                }
                for engine_key, row in self.champions_results.items()
            }
            self.weekly_archive.merge_week(self.engine.report_date, engines={}, champions=champions_payload)
            self.refresh_weekly_archive_button()
        except Exception as exc:
            self.weekly_archive.last_error = str(exc)

    def refresh_weekly_archive_button(self):
        btn = getattr(self, "weekly_archive_btn", None)
        if btn is None:
            return
        try:
            week_count = len(self.weekly_archive.list_weeks())
        except Exception:
            week_count = 0
        btn.config(text=f"Wochenarchiv ({week_count})" if week_count else "Wochenarchiv")

    def show_weekly_archive(self):
        """Zeigt archivierte Wochen und erlaubt den Abgleich mit der Realität."""
        try:
            if self.weekly_archive_window is not None and self.weekly_archive_window.winfo_exists():
                self.weekly_archive_window.deiconify()
                self.weekly_archive_window.lift()
                self.weekly_archive_window.focus_force()
                return
        except tk.TclError:
            pass

        weeks = self.weekly_archive.list_weeks()
        win = tk.Toplevel(self)
        self.weekly_archive_window = win
        win.title("Meridian Wochenarchiv")
        win.configure(bg=COLORS["bg"])
        win.geometry("1180x760")
        win.minsize(980, 600)
        win.transient(self)

        def close_window():
            self.weekly_archive_window = None
            win.destroy()
        win.protocol("WM_DELETE_WINDOW", close_window)

        header = self.card(win, COLORS["header"])
        header.pack(fill="x", padx=14, pady=14)
        title_row = tk.Frame(header, bg=COLORS["header"])
        title_row.pack(fill="x", padx=14, pady=(12, 2))
        self.label(title_row, "Meridian Wochenarchiv", 20, COLORS["text"], "bold", COLORS["header"]).pack(side="left")
        backfill_btn = self.button(
            title_row, "↻  Ergebnisse mit Markt abgleichen",
            lambda: self.start_weekly_archive_backfill(win),
            COLORS["blue"], COLORS["dark"],
        )
        backfill_btn.pack(side="right", ipadx=10, ipady=6)
        self.label(
            header,
            "Zeigt, was jede Engine pro COT Report Woche als Top 3 berechnet hat. "
            "Der Abgleich prüft nachträglich die tatsächliche Kursbewegung seit dem "
            "jeweiligen Report Datum und markiert Treffer beziehungsweise Fehlschläge. "
            "Das ist die Datenbasis für eine spätere Kalibrierung der Scores - noch "
            "keine fertige Statistik.",
            9, COLORS["muted"], "normal", COLORS["header"], wrap=1100,
        ).pack(anchor="w", padx=14, pady=(0, 12))

        body_shell = tk.Frame(win, bg=COLORS["bg"])
        body_shell.pack(fill="both", expand=True, padx=14, pady=(0, 14))
        canvas = tk.Canvas(body_shell, bg=COLORS["bg"], highlightthickness=0)
        scrollbar = tk.Scrollbar(body_shell, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        body = tk.Frame(canvas, bg=COLORS["bg"])
        body_window = canvas.create_window((0, 0), window=body, anchor="nw")
        body.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(body_window, width=e.width))

        if not weeks:
            self.label(body, "Noch keine Wochen archiviert. Nach der nächsten COT Analyse erscheint hier der erste Eintrag.", 11, COLORS["muted"], "normal", COLORS["bg"]).pack(anchor="w", padx=8, pady=20)
        else:
            for week in weeks:
                self.render_weekly_archive_week(body, week)

        win.after(80, lambda: (win.lift(), win.focus_force()))

    def render_weekly_archive_week(self, parent, week):
        card = self.card(parent, COLORS["card"])
        card.pack(fill="x", padx=4, pady=6)
        head = tk.Frame(card, bg=COLORS["card"])
        head.pack(fill="x", padx=14, pady=(10, 4))
        self.label(head, f"Report {week.get('report_date_text', week.get('report_date', ''))}", 13, COLORS["text"], "bold", COLORS["card"]).pack(side="left")
        self.label(head, f"aktualisiert {week.get('updated_at', '')[:16].replace('T', ' ')}", 9, COLORS["muted"], "normal", COLORS["card"], "e").pack(side="right")

        engines = week.get("engines", {}) or {}
        outcomes = week.get("outcome", {}) or {}
        grid = tk.Frame(card, bg=COLORS["card"])
        grid.pack(fill="x", padx=10, pady=(0, 10))
        for col, engine_key in enumerate((ENGINE_CLASSIC, ENGINE_FLOW, ENGINE_HYBRID)):
            grid.grid_columnconfigure(col, weight=1)
            box = tk.Frame(grid, bg=COLORS["card2"], highlightthickness=1, highlightbackground=COLORS["line"])
            box.grid(row=0, column=col, sticky="nsew", padx=4)
            engine_payload = engines.get(engine_key, {})
            self.label(box, ENGINE_LABELS.get(engine_key, engine_key), 10, COLORS["blue"], "bold", COLORS["card2"]).pack(anchor="w", padx=10, pady=(8, 2))
            top3 = engine_payload.get("top3", []) or []
            if not top3:
                self.label(box, "Keine Daten", 9, COLORS["muted"], "normal", COLORS["card2"]).pack(anchor="w", padx=10, pady=(0, 8))
                continue
            for row in top3:
                pair = row.get("pair", "")
                direction = row.get("direction", "")
                pair_code = normalize_entry_profile_pair(pair)
                quality = safe_float(row.get("final_quality", row.get("confidence", 50)), 50)
                dcol = COLORS["green"] if direction == "LONG" else COLORS["red"]
                line = tk.Frame(box, bg=COLORS["card2"])
                line.pack(fill="x", padx=10, pady=(2, 0))
                self.label(line, f"{pair} {direction}", 9, dcol, "bold", COLORS["card2"]).pack(side="left")
                self.label(line, f"{quality:.1f}", 9, COLORS["yellow"], "bold", COLORS["card2"], "e").pack(side="right")

                # Neu in 0.0.3: mehrere unabhängige Zeithorizonte statt eines
                # einzelnen Werts, der beim nächsten Abgleich überschrieben würde.
                any_outcome = False
                for horizon in WEEKLY_ARCHIVE_OUTCOME_HORIZONS_DAYS:
                    outcome_key = f"{engine_key}:{pair_code}:{direction}:{horizon}d"
                    outcome = outcomes.get(outcome_key)
                    if not outcome:
                        continue
                    any_outcome = True
                    hit = bool(outcome.get("hit"))
                    result_col = COLORS["green"] if hit else COLORS["red"]
                    result_txt = f"{horizon}T: {'TREFFER' if hit else 'VERFEHLT'} {safe_float(outcome.get('signal_return_pct', 0), 0):+.2f}%"
                    self.label(box, result_txt, 8, result_col, "bold", COLORS["card2"]).pack(anchor="e", padx=10, pady=(0, 1))
                if not any_outcome:
                    self.label(box, "Noch nicht abgeglichen", 8, COLORS["muted"], "normal", COLORS["card2"]).pack(anchor="e", padx=10, pady=(0, 3))
                else:
                    tk.Frame(box, bg=COLORS["card2"], height=3).pack(fill="x")

    def start_weekly_archive_backfill(self, win):
        """Vergleicht archivierte Vorhersagen mit der tatsächlichen Kursbewegung.

        Läuft im Hintergrund-Thread, weil dafür Kursdaten nachgeladen werden.
        Für jeden fälligen Zeithorizont (siehe WEEKLY_ARCHIVE_OUTCOME_HORIZONS_DAYS)
        wird der historische Schlusskurs am jeweiligen Zieldatum verwendet, nicht
        der aktuelle Live Kurs. Dadurch bleibt ein einmal gemessener 5 Tage Wert
        auch dann korrekt, wenn der Abgleich erst viel später (z.B. nach 40 Tagen)
        erneut ausgeführt wird - er misst dann trotzdem exakt die 5 Tage Bewegung
        nach, plus zusätzlich die inzwischen fällig gewordenen 14 und 28 Tage Werte.
        """
        weeks = self.weekly_archive.list_weeks()
        # Gruppiert nach (report_date, pair, direction), damit pro Markt nur einmal
        # Kursdaten geladen werden, auch wenn mehrere Engines dasselbe Paar wählten.
        groups = {}
        for week in weeks:
            report_date = week.get("report_date", "")
            try:
                report_dt = datetime.strptime(report_date[:10], "%Y-%m-%d")
            except Exception:
                continue
            age_days = (datetime.now() - report_dt).days
            outcomes = week.get("outcome", {}) or {}
            for engine_key, payload in (week.get("engines", {}) or {}).items():
                for row in payload.get("top3", []) or []:
                    pair = row.get("pair", "")
                    direction = row.get("direction", "")
                    pair_code = normalize_entry_profile_pair(pair)
                    if not pair_code or direction not in ("LONG", "SHORT"):
                        continue
                    due_horizons = []
                    for horizon in WEEKLY_ARCHIVE_OUTCOME_HORIZONS_DAYS:
                        if age_days < horizon:
                            continue  # dieser Horizont ist noch nicht erreicht
                        outcome_key = f"{engine_key}:{pair_code}:{direction}:{horizon}d"
                        if outcome_key in outcomes:
                            continue  # dieser Horizont wurde bereits gemessen
                        due_horizons.append(horizon)
                    if not due_horizons:
                        continue
                    group_key = (report_date, pair, direction)
                    group = groups.setdefault(group_key, {"horizons": set(), "engines": set()})
                    group["horizons"].update(due_horizons)
                    group["engines"].add(engine_key)

        if not groups:
            messagebox.showinfo("Wochenarchiv Abgleich", "Keine offenen Abgleiche gefunden (entweder alles aktuell oder noch kein Zeithorizont erreicht).")
            return

        total_jobs = sum(len(g["horizons"]) * len(g["engines"]) for g in groups.values())
        result_queue = queue.Queue()

        def nearest_close_on_or_before(series, target_date_text):
            """Letzter verfügbarer Handelstag Schlusskurs auf oder vor dem Zieldatum.

            Bewusst kein Blick in die Zukunft (kein Kurs nach dem Zieldatum), damit
            ein Horizont Ergebnis nicht versehentlich Daten von später nutzt.
            """
            candidates = [row for row in (series or []) if str(row.get("date", "")) <= target_date_text]
            if not candidates:
                return None
            candidates = sorted(candidates, key=lambda row: row.get("date", ""))
            return candidates[-1]

        def worker():
            provider = MarketPulsePriceProvider()
            done, failed = 0, 0
            for (report_date, pair, direction), group in groups.items():
                try:
                    fetched = provider.fetch_many([pair], report_date)
                    info = (fetched.get("results") or {}).get(pair, {})
                    series = info.get("series") or []
                    reference = info.get("reference_price")
                    reference_date = info.get("reference_date", report_date)
                    if reference is None or not series:
                        failed += len(group["horizons"]) * len(group["engines"])
                        continue
                    try:
                        report_dt = datetime.strptime(report_date[:10], "%Y-%m-%d")
                    except Exception:
                        failed += len(group["horizons"]) * len(group["engines"])
                        continue

                    for horizon in sorted(group["horizons"]):
                        target_date_text = (report_dt + timedelta(days=horizon)).strftime("%Y-%m-%d")
                        horizon_point = nearest_close_on_or_before(series, target_date_text)
                        if horizon_point is None:
                            failed += len(group["engines"])
                            continue
                        horizon_price = horizon_point.get("close")
                        horizon_date = horizon_point.get("date")
                        raw_return = market_pulse_percent(horizon_price, reference)
                        signal_return = market_pulse_signal_return(raw_return, direction)
                        outcome_payload = {
                            "measured_at": datetime.now().isoformat(timespec="seconds"),
                            "reference_date": reference_date,
                            "reference_price": reference,
                            "horizon_target_date": target_date_text,
                            "horizon_date": horizon_date,
                            "horizon_price": horizon_price,
                            "raw_return_pct": round(raw_return, 3),
                            "signal_return_pct": round(signal_return, 3),
                            "hit": signal_return > 0,
                        }
                        for engine_key in group["engines"]:
                            ok = self.weekly_archive.record_outcome(
                                report_date, pair, direction, engine_key, horizon, outcome_payload
                            )
                            done += 1 if ok else 0
                            failed += 0 if ok else 1
                except Exception:
                    failed += len(group["horizons"]) * len(group["engines"])
            result_queue.put(("done", done, failed))

        threading.Thread(target=worker, daemon=True).start()
        messagebox.showinfo(
            "Wochenarchiv Abgleich",
            f"Abgleich für {total_jobs} offene Setup/Zeithorizont Kombinationen "
            f"({len(groups)} Märkte) gestartet. Dies läuft im Hintergrund.",
        )

        def poll():
            try:
                _, done, failed = result_queue.get_nowait()
            except queue.Empty:
                self.after(400, poll)
                return
            messagebox.showinfo("Wochenarchiv Abgleich", f"Abgleich fertig: {done} aktualisiert, {failed} ohne verfügbare Kursdaten.")
            try:
                if win.winfo_exists():
                    for child in win.winfo_children():
                        pass
                    self.weekly_archive_window = None
                    win.destroy()
                    self.show_weekly_archive()
            except tk.TclError:
                pass

        self.after(400, poll)

    def finish(self):
        try:
            self.strengths, self.top3, self.all_pairs = self.engine.run()
            self.result_engine_key = self.engine.analysis_engine
            self.current_main_view = "cot"
            self.set_engine_selector_locked(True)
            self.weekly_movers = getattr(self.engine, "weekly_movers", {}) or {}
            self.set_progress(100, "Top 3 Watchlist für kommende Woche fertig")
            self.status.config(text="Fertig", fg=COLORS["green"])
            self.start_btn.config(state="normal", text="1. COT ANALYSE NEU STARTEN")
            self.render()
            self.set_seasonality_buttons(True, "2. SEASONALITY PRÜFEN")
            self.set_macro_buttons(False)
            self.set_entry_engine_button(False)
            self.audit_lbl.config(text="Checkup: per Button erstellen", fg=COLORS["muted"])
            self.save_weekly_archive_snapshot(depth_level=1)
        except Exception as exc:
            self.start_btn.config(state="normal", text="1. COT ANALYSE NEU STARTEN")
            self.status.config(text="Fehler", fg=COLORS["red"])
            self.data_status.config(text="RESEARCH HEALTH FEHLER", fg=COLORS["red"])
            self.cftc_loaded_lbl.config(text="CFTC Datenprüfung fehlgeschlagen", fg=COLORS["red"])
            messagebox.showerror("Analyse Fehler", str(exc))

    def start_seasonality(self):
        if not self.top3:
            messagebox.showwarning("Noch kein COT Ergebnis", "Bitte zuerst die COT Top 3 berechnen.")
            return
        # Seasonality prüft jetzt die Forex Top 3 plus die vier Zusatzmärkte.
        # Die Forex Top 3 bleiben in der Hauptwatchlist, die Zusatzmärkte bekommen ihren eigenen 4 Wochen Check im Dashboard.
        self.single_asset_seasonality = []
        self.set_seasonality_buttons(False, "SEASONALITY LÄUFT...")
        self.status.config(text="Seasonality läuft", fg=COLORS["yellow"])
        self.set_progress(55, "Seasonality Daten laden")
        self.seasonality_queue = queue.Queue()

        def worker():
            try:
                engine = SeasonalityEngine(
                    progress=lambda pct, text: self.seasonality_queue.put(("progress", pct, text))
                )
                candidates = list(self.top3) + list(self.get_single_asset_results())
                result = engine.analyze_top3(candidates, self.engine.report_date)
                self.seasonality_queue.put(("done", result, engine.errors))
            except Exception as exc:
                self.seasonality_queue.put(("error", str(exc)))

        threading.Thread(target=worker, daemon=True).start()
        self.after(120, self.poll_seasonality_worker)

    def poll_seasonality_worker(self):
        try:
            while True:
                item = self.seasonality_queue.get_nowait()
                kind = item[0]
                if kind == "progress":
                    _, pct, text = item
                    self.set_progress(pct, text)
                elif kind == "done":
                    _, result, errors = item
                    self.seasonality = result
                    self.single_asset_seasonality = [r for r in result if r.get("is_single_asset")]
                    self.final_watchlist = [r for r in result if not r.get("is_single_asset")]
                    self.season_engine.errors = errors
                    self.set_progress(100, "Finale Meridian Watchlist fertig")
                    self.status.config(text="Fertig", fg=COLORS["green"])
                    self.set_seasonality_buttons(True, "SEASONALITY ERNEUT PRÜFEN")
                    self.set_macro_buttons(True, "3. MAKROS PRÜFEN")
                    self.current_main_view = "seasonality"
                    self.render()
                    # Audit Dateien werden bewusst nur noch per Engine Checkup Button erzeugt.
                    return
                elif kind == "error":
                    _, message = item
                    self.status.config(text="Seasonality Fehler", fg=COLORS["red"])
                    self.set_seasonality_buttons(True, "2. SEASONALITY PRÜFEN")
                    self.set_macro_buttons(False)
                    messagebox.showerror("Seasonality Fehler", message)
                    return
        except queue.Empty:
            pass
        self.after(120, self.poll_seasonality_worker)

    def start_macro(self):
        if not self.final_watchlist:
            messagebox.showwarning("Seasonality fehlt", "Bitte zuerst die Seasonality Prüfung abschließen.")
            return
        self.set_macro_buttons(False, "MAKROS LAUFEN...")
        self.status.config(text="Makros laufen", fg=COLORS["yellow"])
        self.set_progress(68, "Makro Daten laden")
        self.macro_queue = queue.Queue()

        def worker():
            try:
                engine = MacroEngine(progress=lambda pct, text: self.macro_queue.put(("progress", pct, text)))
                result = engine.analyze_watchlist(self.final_watchlist)
                self.macro_queue.put(("done", result, engine.errors))
            except Exception as exc:
                self.macro_queue.put(("error", str(exc)))

        threading.Thread(target=worker, daemon=True).start()
        self.after(120, self.poll_macro_worker)

    def poll_macro_worker(self):
        try:
            while True:
                item = self.macro_queue.get_nowait()
                kind = item[0]
                if kind == "progress":
                    _, pct, text = item
                    self.set_progress(pct, text)
                elif kind == "done":
                    _, result, errors = item
                    self.macro_results = result
                    self.reset_entry_engine_profiles()
                    if self.result_engine_key is not None:
                        self.entry_engine_engine_rows[self.result_engine_key] = copy.deepcopy(list(result)[:3])
                    self.macro_engine.errors = errors
                    self.set_progress(100, "Makros geprüft und finale Watchlist aktualisiert")
                    self.status.config(text="Fertig", fg=COLORS["green"])
                    self.set_macro_buttons(False, "MAKROS GEPRÜFT")
                    self.show_final_restart_state()
                    self.current_main_view = "macro"
                    self.render()
                    self.audit_lbl.config(text="Checkup: finale Daten bereit", fg=COLORS["muted"])
                    self.set_champions_button(True, "🏆  4. CHAMPIONS FREISCHALTEN")
                    self.start_champions_glow()
                    self.set_entry_engine_button(bool(self.macro_results))
                    if self.result_engine_key is not None and self.macro_results:
                        try:
                            self.weekly_archive.merge_week(self.engine.report_date, engines={
                                self.result_engine_key: {
                                    "depth_level": 3,
                                    "top3": [
                                        {
                                            "pair": row.get("pair"),
                                            "direction": row.get("direction"),
                                            "confidence": row.get("cot_confidence", row.get("confidence")),
                                            "final_quality": row.get("final_quality", row.get("final_confluence")),
                                            "cot_score": row.get("cot_confidence", row.get("confidence")),
                                            "seasonality_score": row.get("seasonality_score"),
                                            "macro_score": row.get("macro_score"),
                                        }
                                        for row in list(self.macro_results)[:3]
                                    ],
                                }
                            })
                            self.refresh_weekly_archive_button()
                        except Exception as exc:
                            self.weekly_archive.last_error = str(exc)
                    return
                elif kind == "error":
                    _, message = item
                    self.status.config(text="Makro Fehler", fg=COLORS["red"])
                    self.set_macro_buttons(True, "3. MAKROS PRÜFEN")
                    messagebox.showerror("Makro Fehler", message)
                    return
        except queue.Empty:
            pass
        self.after(120, self.poll_macro_worker)

    def finish_seasonality(self):
        # Kompatibilitätsmethode. Die Seasonality läuft seit v2.0.2 im Hintergrund,
        # damit die Oberfläche bei langsamen Yahoo Finance Downloads nicht einfriert.
        self.start_seasonality()

    def render(self):
        usable = len([c for c, s in self.engine.records.items() if len(s) >= 5])
        health = self.build_data_health()
        if health["status"] == "OK":
            if health.get("usd_proxy_active"):
                status_text, status_color = "DATEN GEPRÜFT", COLORS["green"]
            else:
                status_text, status_color = "RESEARCH HEALTH OK", COLORS["green"]
        elif health["status"] == "FAIL":
            status_text, status_color = "RESEARCH HEALTH FEHLER", COLORS["red"]
        else:
            status_text, status_color = "DATEN HINWEIS", COLORS["yellow"]
        self.data_status.config(text=status_text, fg=status_color)
        self.source_lbl.config(text="Quelle: CFTC historische Reports, lokal zwischengespeichert")

        cache_status = getattr(self.engine, "cftc_cache_status", "not_checked")
        cache_timestamp = getattr(self.engine, "cftc_cache_timestamp", None)
        if cache_timestamp:
            if cache_timestamp.date() == datetime.now().date():
                cache_time_text = f"heute {cache_timestamp.strftime('%H:%M')}"
            else:
                cache_time_text = cache_timestamp.strftime("%d.%m.%Y %H:%M")
        else:
            cache_time_text = "unbekannt"

        if health["status"] == "FAIL":
            self.cftc_loaded_lbl.config(text="CFTC Datenprüfung fehlgeschlagen", fg=COLORS["red"])
            self.cache_lbl.config(text=f"Cache: {cache_time_text}", fg=COLORS["muted"])
        elif cache_status == "cache_fallback":
            self.cftc_loaded_lbl.config(text="⚠ Gespeicherte CFTC Daten", fg=COLORS["yellow"])
            self.cache_lbl.config(text=f"Cache: {cache_time_text}", fg=COLORS["yellow"])
        elif cache_status == "cache_today":
            self.cftc_loaded_lbl.config(text="✓ Aktuelle CFTC Daten", fg=COLORS["green"])
            self.cache_lbl.config(text=f"Cache: {cache_time_text}", fg=COLORS["muted"])
        elif cache_status == "downloaded_today":
            self.cftc_loaded_lbl.config(text="✓ Aktuelle CFTC Daten", fg=COLORS["green"])
            self.cache_lbl.config(text=f"Aktualisiert: {cache_time_text}", fg=COLORS["muted"])
        else:
            fallback_color = COLORS["green"] if health["status"] == "OK" else COLORS["yellow"]
            self.cftc_loaded_lbl.config(text="CFTC Daten verfügbar", fg=fallback_color)
            self.cache_lbl.config(text=f"Cache: {cache_time_text}", fg=COLORS["muted"])

        self.report_lbl.config(text=f"Report: {self.engine.report_date}", fg=COLORS["muted"])
        self.market_count_lbl.config(text=f"Märkte: {usable}", fg=COLORS["muted"])
        self.render_watchlist()
        self.render_single_asset_strip()
        macro_mode = self.current_main_view == "macro" and bool(getattr(self, "macro_results", []) or [])
        if macro_mode:
            try:
                # Die finale Makrofolie ist eine eigene Abschlussseite.
                # Deshalb werden die großen Top 3 Karten und die Zusatzmärkte hier bewusst ausgeblendet.
                self.top_watch_frame.pack_forget()
                self.asset_strip.pack_forget()
                self.strength_container.grid_remove()
                self.detail_container.grid(row=0, column=0, columnspan=2, sticky="nsew", padx=(0, 0))
                self.detail_canvas.yview_moveto(0)
                self.show_final_restart_state()
            except Exception:
                pass
        else:
            try:
                # Normale COT und Seasonality Ansicht wiederherstellen.
                if not self.top_watch_frame.winfo_manager():
                    self.top_watch_frame.pack(fill="x", pady=(0, 5), after=self.check_frame)
                if not self.asset_strip.winfo_manager():
                    self.asset_strip.pack(fill="x", pady=(0, 6), after=self.top_watch_frame)
                self.detail_container.grid(row=0, column=1, sticky="nsew", padx=(5, 0))
                self.strength_container.grid(row=0, column=0, sticky="nsew", padx=(0, 5))
            except Exception:
                pass
            self.render_strengths()
        self.render_details()
        self.update_main_navigation()

    def render_single_asset_strip(self):
        items = self.get_single_asset_results()
        by_pair = {item.get("pair"): item for item in items}
        wanted = [cfg for cfg in SINGLE_ASSET_MARKETS.values()]
        final_by_pair = {item.get("pair"): item for item in (getattr(self, "single_asset_seasonality", []) or []) if item.get("is_single_asset")} if self.current_main_view == "seasonality" else {}
        for i, card in enumerate(getattr(self, "asset_cards", [])):
            self.clear(card)
            cfg = wanted[i] if i < len(wanted) else {}
            pair = cfg.get("pair", "")
            item = final_by_pair.get(pair) or by_pair.get(pair)
            label = cfg.get("label", pair or "Zusatzmarkt")
            if not item:
                tk.Label(card, text=label, font=("Segoe UI", 12, "bold"), fg=COLORS["text"], bg=COLORS["card2"]).pack(anchor="w", padx=12, pady=(9, 0))
                tk.Label(card, text="WARTET", font=("Segoe UI", 14, "bold"), fg=COLORS["muted"], bg=COLORS["card2"]).pack(anchor="w", padx=12, pady=(2, 0))
                tk.Label(card, text="nach COT Analyse", font=("Segoe UI", 8, "bold"), fg=COLORS["muted"], bg=COLORS["card2"]).pack(anchor="w", padx=12, pady=(1, 9))
                continue
            direction = item.get("direction", "")
            color = COLORS["green"] if direction == "LONG" else COLORS["red"]
            score = safe_float(item.get("final_score", item.get("confidence", 0)), 0)
            rank = item.get("original_rank", "")
            title = item.get("display_name", label)
            tk.Label(card, text=title, font=("Segoe UI", 12, "bold"), fg=COLORS["text"], bg=COLORS["card2"]).pack(anchor="w", padx=12, pady=(8, 0))
            main = tk.Frame(card, bg=COLORS["card2"])
            main.pack(fill="x", padx=12, pady=(1, 0))
            tk.Label(main, text=direction, font=("Segoe UI", 16, "bold"), fg=color, bg=COLORS["card2"]).pack(side="left")
            tk.Label(main, text=f"{score:.1f}", font=("Segoe UI", 16, "bold"), fg=score_color(score), bg=COLORS["card2"]).pack(side="right")
            small = f"{item.get('pair', pair)}"
            if rank:
                small += f"  Rang {rank}"
            tk.Label(card, text=small, font=("Segoe UI", 8, "bold"), fg=COLORS["muted"], bg=COLORS["card2"]).pack(anchor="w", padx=12, pady=(0, 2))

            # Final 2.0: Die Zusatzmärkte bekommen dieselbe sichtbare Seasonality Marke
            # wie die Top 3 Forex Setups. So ist nach Button 2 sofort klar,
            # ob der 4 Wochen Check bullish, bearish oder neutral ausfällt.
            if item.get("seasonality_score") is not None or item.get("verdict"):
                status = item.get("verdict", "NEUTRAL")
                status_col = seasonality_color(status)
                status_text = self.final_status_text(status).replace("SEASONALITY ", "")
                season_line = tk.Frame(card, bg=COLORS["card2"])
                season_line.pack(anchor="w", padx=12, pady=(0, 8))
                self.status_dot(season_line, status_col, 11).pack(side="left", padx=(0, 6))
                tk.Label(season_line, text=status_text, font=("Segoe UI", 8, "bold"), fg=status_col, bg=COLORS["card2"]).pack(side="left")
            else:
                tk.Label(card, text="Seasonality noch offen", font=("Segoe UI", 8, "bold"), fg=COLORS["muted"], bg=COLORS["card2"]).pack(anchor="w", padx=12, pady=(0, 8))

    def render_watchlist(self):
        final_mode = self.current_main_view == "seasonality" and bool(self.final_watchlist)
        source = self.final_watchlist if final_mode else self.top3
        for i, card in enumerate(self.watch_cards):
            self.clear(card)
            title = f"#{i + 1} FINAL SETUP" if final_mode else f"#{i + 1} TOP SETUP"
            self.label(card, title, 10, COLORS["muted"], "bold", COLORS["card2"]).pack(anchor="w", padx=14, pady=(8, 0))
            if i >= len(source):
                tk.Label(card, text="KEINE DATEN", font=("Segoe UI", 24, "bold"), fg=COLORS["red"], bg=COLORS["card2"]).pack(anchor="w", padx=16, pady=(8, 0))
                continue

            p = source[i]
            direction = p.get("direction", "")
            color = COLORS["green"] if direction == "LONG" else COLORS["red"]
            tk.Label(card, text=p.get("display_name", p["pair"]), font=("Segoe UI", 25, "bold"), fg=COLORS["text"], bg=COLORS["card2"]).pack(anchor="w", padx=16, pady=(2, 0))
            tk.Label(card, text=direction, font=("Segoe UI", 16, "bold"), fg=color, bg=COLORS["card2"]).pack(anchor="w", padx=16)

            if final_mode:
                status = p.get("verdict", "NEUTRAL")
                status_col = seasonality_color(status)
                tk.Label(card, text=f"{p['final_score']:.1f}", font=("Segoe UI", 24, "bold"), fg=status_col, bg=COLORS["card2"]).pack(anchor="w", padx=16, pady=(2, 0))
                tk.Label(card, text="Meridian QUALITÄT", font=("Segoe UI", 13, "bold"), fg=status_col, bg=COLORS["card2"]).pack(anchor="w", padx=16, pady=(0, 0))
                status_line = tk.Frame(card, bg=COLORS["card2"])
                status_line.pack(anchor="w", padx=16, pady=(4, 0))
                self.status_dot(status_line, status_col, 14).pack(side="left", padx=(0, 7))
                tk.Label(status_line, text=status, font=("Segoe UI", 12, "bold"), fg=status_col, bg=COLORS["card2"]).pack(side="left")
                mini_course = "steigend" if p.get("direction") == "LONG" else "fallend"
                if status in ("STARK_KONFLIKT", "KONFLIKT", "LEICHT_NEGATIV"):
                    mini_course = "fallend" if p.get("direction") == "LONG" else "steigend"
                elif status == "NEUTRAL":
                    mini_course = "unklar"
                self.label(card, f"COT {p['cot_confidence']:.1f}  |  Saison: {self.final_status_text(status).replace('SEASONALITY ', '')}, historisch {mini_course}", 9, COLORS["muted"], "bold", COLORS["card2"], wrap=480).pack(anchor="w", padx=16, pady=(2, 8))
            else:
                qcol = score_color(p.get("confidence", 50))
                tk.Label(card, text=f"{p['confidence']:.1f} Meridian Qualität", font=("Segoe UI", 18, "bold"), fg=qcol, bg=COLORS["card2"]).pack(anchor="w", padx=16, pady=(4, 0))
                self.label(card, f"Kategorie: {quality_short(p.get('confidence', 50))}  |  Stark: {p['strong']} ({p.get('strong_signed_strength', 0):+.0f})  Schwach: {p['weak']} ({p.get('weak_signed_strength', 0):+.0f})", 10, COLORS["muted"], "bold", COLORS["card2"]).pack(anchor="w", padx=16, pady=(2, 14))

    def status_dot(self, parent, color, size=16):
        c = tk.Canvas(parent, width=size, height=size, bg=parent.cget("bg"), highlightthickness=0)
        c.create_oval(2, 2, size - 2, size - 2, fill=color, outline=color)
        return c

    def status_row(self, parent, title, value, color, small=None):
        row = tk.Frame(parent, bg=COLORS["card2"], highlightthickness=1, highlightbackground=COLORS["line"])
        row.pack(fill="x", padx=16, pady=4)
        self.status_dot(row, color, 15).pack(side="left", padx=(10, 8), pady=8)
        left = tk.Frame(row, bg=COLORS["card2"])
        left.pack(side="left", fill="x", expand=True, padx=(0, 8), pady=6)
        tk.Label(left, text=title, font=("Segoe UI", 10, "bold"), fg=COLORS["text"], bg=COLORS["card2"], anchor="w").pack(anchor="w")
        if small:
            tk.Label(left, text=small, font=("Segoe UI", 8), fg=COLORS["muted"], bg=COLORS["card2"], anchor="w", wraplength=330, justify="left").pack(anchor="w", pady=(2, 0))
        tk.Label(row, text=value, font=("Segoe UI", 10, "bold"), fg=color, bg=COLORS["card2"], anchor="e").pack(side="right", padx=10, pady=8)

    def get_single_asset_results(self):
        source = list(getattr(self, "all_pairs", []) or [])
        wanted = [cfg.get("pair") for cfg in SINGLE_ASSET_MARKETS.values()]
        by_pair = {p.get("pair"): p for p in source if p.get("is_single_asset")}
        return [by_pair[pair] for pair in wanted if pair in by_pair]

    def render_single_asset_row(self, parent, item):
        direction = item.get("direction", "")
        color = COLORS["green"] if direction == "LONG" else COLORS["red"]
        title = item.get("display_name", item.get("pair", ""))
        score = safe_float(item.get("confidence", 0), 0)
        rank = item.get("original_rank", "")
        small = f"{item.get('pair', '')} {direction}, Score {score:.1f}"
        if rank:
            small += f", Rang {rank} im Gesamtranking"
        self.status_row(parent, title, direction, color, small)


    def mover_text(self, mover):
        if not mover:
            return "Noch keine Vorwochenveränderung berechnet"
        parts = [
            f"Stärke {mover.get('previous_strength', 50):.1f} auf {mover.get('current_strength', 50):.1f}",
            f"Commercial Flow {mover.get('commercial_flow', 50):.1f}",
            f"Large Specs {mover.get('large_spec_flow', 50):.1f}",
            f"Beschleunigung {mover.get('flow_acceleration', 50):.1f}",
            f"OI {mover.get('oi_participation', 50):.1f}",
        ]
        if mover.get("is_proxy"):
            parts.append("USD Proxy")
        return ", ".join(parts)

    def render_weekly_movers(self):
        movers = getattr(self, "weekly_movers", {}) or {}
        winner = movers.get("winner")
        loser = movers.get("loser")
        if not winner and not loser:
            if self.top3:
                self.status_row(self.strength_card, "Gewinner der Woche", "KEINE VORWOCHE", COLORS["muted"], "Für die Change Anzeige wird ein direkter Vorwochen Report benötigt")
            return

        if winner:
            value = f"{winner.get('currency', '')} {winner.get('change', 0):+0.1f}"
            self.status_row(self.strength_card, "Gewinner der Woche", value, COLORS["green"], self.mover_text(winner))

        if loser:
            value = f"{loser.get('currency', '')} {loser.get('change', 0):+0.1f}"
            self.status_row(self.strength_card, "Verlierer der Woche", value, COLORS["red"], self.mover_text(loser))

    def render_strengths(self):
        self.clear(self.strength_card)
        self.label(self.strength_card, "Meridian RESEARCH STATUS", 16, COLORS["text"], "bold", COLORS["card"]).pack(anchor="w", padx=16, pady=(14, 4))
        self.label(self.strength_card, "Vertrauenscheck für die finale Analyse. Grün bedeutet: Die Berechnung darf verwendet werden. Hinweise wie USD Proxy werden transparent gezeigt, sind aber kein Fehler.", 10, COLORS["muted"], "normal", COLORS["card"], wrap=520).pack(anchor="w", padx=16, pady=(0, 10))

        health = self.build_data_health() if self.engine.records else {"status": "WAIT"}
        if health.get("status") == "OK":
            if health.get("usd_proxy_active"):
                self.status_row(self.strength_card, "COT Daten", "GEPRÜFT", COLORS["green"], f"Report {self.engine.report_date}, USD Proxy")
            else:
                self.status_row(self.strength_card, "COT Daten", "VALIDIERT", COLORS["green"], f"Report {self.engine.report_date}")
        elif health.get("status") == "FAIL":
            self.status_row(self.strength_card, "COT Daten", "FEHLER", COLORS["red"], "Analyse prüfen")
        elif health.get("status") == "WARN":
            self.status_row(self.strength_card, "COT Daten", "HINWEIS", COLORS["yellow"], f"Report {self.engine.report_date}")
        else:
            self.status_row(self.strength_card, "COT Daten", "OFFEN", COLORS["muted"], "Noch nicht gestartet")

        if health.get("notes"):
            self.status_row(self.strength_card, "Daten Hinweis", "OK", COLORS["blue"], health.get("notes", [""])[0])

        if self.top3:
            self.status_row(self.strength_card, "Top 3 COT Filter", "ABGESCHLOSSEN", COLORS["green"], "3 Haupt Setups gefunden")
        else:
            self.status_row(self.strength_card, "Top 3 COT Filter", "OFFEN", COLORS["muted"], "Zuerst COT starten")

        self.render_weekly_movers()

        single_assets = self.get_single_asset_results()
        if single_assets:
            bias_summary = ", ".join(f"{p.get('display_name', p.get('pair'))} {p.get('direction')}" for p in single_assets)
            self.status_row(self.strength_card, "Zusatzmärkte", "AKTIV", COLORS["green"], bias_summary)
        elif self.top3:
            self.status_row(self.strength_card, "Zusatzmärkte", "KEINE DATEN", COLORS["red"], "Gold, Silber, Nasdaq 100 und S&P 500 Mapping prüfen")
        else:
            self.status_row(self.strength_card, "Zusatzmärkte", "OFFEN", COLORS["muted"], "Werden direkt unter den Top 3 angezeigt")

        season_rows = (list(self.final_watchlist or []) + list(getattr(self, "single_asset_seasonality", []) or [])) if self.current_main_view == "seasonality" else []
        if season_rows:
            sample = season_rows[0]
            modes = sorted(set(r.get("data_mode", "unbekannt") for r in season_rows))
            years = [r.get("years", 0) for r in season_rows]
            self.status_row(self.strength_card, "Seasonality", "GEPRÜFT", COLORS["green"], f"Yahoo Finance, {min(years)} bis {max(years)} Jahre, {', '.join(modes)}")
            confirmed = sum(1 for r in season_rows if r.get("verdict") in ("STARK_BESTÄTIGT", "BESTÄTIGT", "LEICHT_POSITIV"))
            neutral = sum(1 for r in season_rows if r.get("verdict") == "NEUTRAL")
            conflict = sum(1 for r in season_rows if r.get("verdict") in ("STARK_KONFLIKT", "KONFLIKT", "LEICHT_NEGATIV"))
            if confirmed:
                color, value = COLORS["green"], f"{confirmed} BESTÄTIGT"
            elif conflict == len(season_rows):
                color, value = COLORS["red"], "COT KONFLIKT"
            else:
                color, value = COLORS["yellow"], "NEUTRAL"
            self.status_row(self.strength_card, "Saisonaler Rückenwind", value, color, f"{neutral} neutral, {conflict} Konflikt")
            best = self.final_watchlist[0]
            self.status_row(self.strength_card, "Höchste Priorität", f"{best['pair']} {best['direction']}", score_color(best["final_score"]), f"Final {best['final_score']:.1f}")
        elif self.top3:
            self.status_row(self.strength_card, "Seasonality", "NOCH OFFEN", COLORS["yellow"], "Button 2 starten")
        else:
            self.status_row(self.strength_card, "Seasonality", "GESPERRT", COLORS["muted"], "Erst nach COT")

        self.label(self.strength_card, "Was die Kreise bedeuten", 13, COLORS["text"], "bold", COLORS["card"]).pack(anchor="w", padx=16, pady=(18, 4))
        self.status_row(self.strength_card, "Grün", "BESTÄTIGT", COLORS["green"], "Saison stützt den COT Bias")
        self.status_row(self.strength_card, "Gelb", "NEUTRAL", COLORS["yellow"], "Keine klare saisonale Aussage")
        self.status_row(self.strength_card, "Rot", "KONFLIKT", COLORS["red"], "Saison spricht gegen COT")

        self.label(self.strength_card, "Hinweis: Die Währungsstärke war nur eine Zwischenrechnung. Für die finale Entscheidung zählt die Kombination aus COT Bias und Seasonality der drei ausgewählten Paare.", 10, COLORS["muted"], "normal", COLORS["card"], wrap=520).pack(anchor="w", padx=16, pady=(16, 0))

    def render_component_row(self, parent, label, base_value, quote_value, base_points, quote_points):
        # Legacy helper, bleibt für mögliche Debug Ausgaben erhalten.
        row = tk.Frame(parent, bg=COLORS["card2"], highlightthickness=1, highlightbackground=COLORS["line"])
        row.pack(fill="x", padx=16, pady=2)
        tk.Label(row, text=label, font=("Segoe UI", 10, "bold"), fg=COLORS["text"], bg=COLORS["card2"], width=28, anchor="w").pack(side="left", padx=8, pady=5)
        tk.Label(row, text=f"Basis {base_value:.1f}", font=("Segoe UI", 10, "bold"), fg=score_color(base_value), bg=COLORS["card2"], width=18, anchor="e").pack(side="left", padx=8)
        tk.Label(row, text=f"Gegenseite {quote_value:.1f}", font=("Segoe UI", 10, "bold"), fg=score_color(quote_value), bg=COLORS["card2"], width=18, anchor="e").pack(side="left", padx=8)

    def factor_row(self, parent, title, score, text):
        verdict, color = verdict_from_component(score)
        row = tk.Frame(parent, bg=COLORS["card2"], highlightthickness=1, highlightbackground=COLORS["line"])
        row.pack(fill="x", padx=16, pady=3)

        left = tk.Frame(row, bg=COLORS["card2"])
        left.pack(side="left", fill="x", expand=True, padx=10, pady=8)
        tk.Label(left, text=title, font=("Segoe UI", 10, "bold"), fg=COLORS["text"], bg=COLORS["card2"], anchor="w").pack(anchor="w")
        tk.Label(left, text=text, font=("Segoe UI", 9), fg=COLORS["muted"], bg=COLORS["card2"], anchor="w", justify="left", wraplength=520).pack(anchor="w", pady=(2, 0))

        right = tk.Frame(row, bg=COLORS["card2"])
        right.pack(side="right", padx=10, pady=8)
        tk.Label(right, text=f"{score:.0f}/100", font=("Segoe UI", 12, "bold"), fg=color, bg=COLORS["card2"], anchor="e").pack(anchor="e")
        tk.Label(right, text=verdict.upper(), font=("Segoe UI", 8, "bold"), fg=color, bg=COLORS["card2"], anchor="e").pack(anchor="e")

    def render_pair_breakdown(self, pair):
        # Nutzerfreundliche Research Erklärung statt technischer Base/Quote Normalisierungen.
        conf = safe_float(pair.get("confidence", 50), 50)
        qlabel = quality_label(conf)
        qshort = quality_short(conf)
        _, _, qcol = research_category(conf)

        box = tk.Frame(self.detail_card, bg=COLORS["card2"], highlightthickness=1, highlightbackground=COLORS["line"])
        box.pack(fill="x", padx=16, pady=(6, 8))
        left = tk.Frame(box, bg=COLORS["card2"])
        left.pack(side="left", padx=12, pady=10)
        tk.Label(left, text=f"{conf:.1f}", font=("Segoe UI", 24, "bold"), fg=qcol, bg=COLORS["card2"]).pack(anchor="w")
        tk.Label(left, text="Meridian QUALITÄT", font=("Segoe UI", 9, "bold"), fg=COLORS["muted"], bg=COLORS["card2"]).pack(anchor="w")
        mid = tk.Frame(box, bg=COLORS["card2"])
        mid.pack(side="left", fill="x", expand=True, padx=12, pady=10)
        tk.Label(mid, text=f"Kategorie: {qshort}", font=("Segoe UI", 13, "bold"), fg=qcol, bg=COLORS["card2"], anchor="w").pack(anchor="w")
        tk.Label(mid, text=qlabel, font=("Segoe UI", 10, "bold"), fg=COLORS["text"], bg=COLORS["card2"], anchor="w", wraplength=720, justify="left").pack(anchor="w", pady=(2, 0))
        tk.Label(mid, text="Die Meridian Qualität ist eine Research Bewertung für die Vorauswahl, keine garantierte Trefferwahrscheinlichkeit.", font=("Segoe UI", 9), fg=COLORS["muted"], bg=COLORS["card2"], anchor="w", wraplength=680, justify="left").pack(anchor="w", pady=(2, 0))

        self.label(self.detail_card, "Warum das Setup in die Watchlist kam", 11, COLORS["yellow"], "bold", COLORS["card"]).pack(anchor="w", padx=16, pady=(2, 2))

        strong = pair.get("strong", "starke Währung")
        weak = pair.get("weak", "schwache Währung")
        gap = abs(safe_float(pair.get("diff", 0), 0))

        factors = [
            (
                "Relative Stärke",
                pair.get("matrix_relative_strength", 50),
                f"{strong} wird als stärkere Währung gegen {weak} als schwächere Währung gestellt. Signed Strength Spread: {pair.get('signed_pair_spread', gap):.1f} Punkte.",
            ),
            (
                "Commercial Bias",
                pair.get("matrix_position", 50),
                "Ebene 1 bestimmt die Richtung: Commercial Longs gegen Commercial Shorts. Ein klarer Commercial Überhang legt den Long oder Short Bias fest. Der COT Index bleibt nur Kontext.",
            ),
            (
                "Frischer Kapitalfluss",
                pair.get("matrix_flow", 50),
                "Ebene 2 misst die Veränderung getrennt: Long Aufbau, Short Abbau, Short Aufbau und Long Abbau. Dadurch erkennt die Engine, ob wirklich frisches Kapital in Bias Richtung fließt.",
            ),
            (
                "Open Interest",
                pair.get("matrix_market_activity", 50),
                "Open Interest prüft, ob frischer Flow durch neue Marktteilnahme bestätigt wird oder ob der Bias durch Positionsabbau gedämpft werden sollte.",
            ),
            (
                "Flow Beschleunigung",
                pair.get("matrix_momentum", 50),
                "Die Engine prüft, ob sich die Positionsverschiebungen in den letzten Reports beschleunigen oder nachlassen. Das erhöht oder dämpft nur die Qualität.",
            ),
        ]

        for title, score, text in factors:
            self.factor_row(self.detail_card, title, safe_float(score, 50), text)

        strengths = []
        risks = []
        for title, score, text in factors:
            score = safe_float(score, 50)
            if score >= 58:
                strengths.append(title)
            elif score <= 42:
                risks.append(title)
        total_factors = len(factors)
        supportive_count = sum(1 for _, score, _ in factors if safe_float(score, 50) >= 55)
        conflict_count = sum(1 for _, score, _ in factors if safe_float(score, 50) <= 45)
        ctext = f"Konfluenz: {supportive_count} von {total_factors} Faktoren unterstützen das Setup. {confluence_label(supportive_count, total_factors).capitalize()}."
        ccolor = COLORS["green"] if supportive_count >= 3 and conflict_count <= 1 else COLORS["yellow"] if supportive_count >= 2 else COLORS["red"]
        self.label(self.detail_card, ctext, 11, ccolor, "bold", COLORS["card"], wrap=760).pack(anchor="w", padx=16, pady=(6, 2))

        summary = ""
        if strengths:
            summary += "Stärken: " + ", ".join(strengths[:4]) + ". "
        if risks:
            summary += "Zu beachten: " + ", ".join(risks[:3]) + "."
        if not summary:
            summary = "Das Setup ist insgesamt ausgewogen. Die Engine stuft es als beobachtenswert ein, aber ohne extreme Einzelsignale."
        self.label(self.detail_card, summary, 10, COLORS["muted"], "normal", COLORS["card"], wrap=760).pack(anchor="w", padx=16, pady=(4, 10))

    def render_rules(self, parent, engine_key=None):
        engine_key = engine_key or self.result_engine_key or getattr(self.engine, "analysis_engine", DEFAULT_ANALYSIS_ENGINE)
        info = ENGINE_PROFILE_INFO.get(engine_key, ENGINE_PROFILE_INFO[DEFAULT_ANALYSIS_ENGINE])
        rules = list(info["rules"]) + [
            ("Commercial COT Index", "Kontext", "Historische Einordnung. Bei Flow Momentum bewusst nur schwach, bei Classic als sichtbarer Kontext genutzt."),
            ("Seasonality", "Finaler Filter", "Wird erst nach der COT Shortlist geprüft und verändert die gewählte Engine Gewichtung nicht."),
        ]
        accent = COLORS.get(info.get("accent", "blue"), COLORS["yellow"])
        for idx, (name, weight, desc) in enumerate(rules, 1):
            name = f"{idx}. {name}" if not name[:1].isdigit() else name
            row = tk.Frame(parent, bg=COLORS["card2"], highlightthickness=1, highlightbackground=COLORS["line"])
            row.pack(fill="x", padx=16, pady=4)
            left = tk.Frame(row, bg=COLORS["card2"])
            left.pack(side="left", fill="x", expand=True, padx=10, pady=8)
            tk.Label(left, text=name, font=("Segoe UI", 11, "bold"), fg=COLORS["text"], bg=COLORS["card2"]).pack(anchor="w")
            tk.Label(left, text=desc, font=("Segoe UI", 9), fg=COLORS["muted"], bg=COLORS["card2"], wraplength=650, justify="left").pack(anchor="w", pady=(2,0))
            tk.Label(row, text=weight, font=("Segoe UI", 11, "bold"), fg=accent, bg=COLORS["card2"]).pack(side="right", padx=10)

    def render_result_engine_summary(self, engine_key):
        info = ENGINE_PROFILE_INFO.get(engine_key, ENGINE_PROFILE_INFO[DEFAULT_ANALYSIS_ENGINE])
        accent = COLORS.get(info.get("accent", "blue"), COLORS["blue"])
        panel = tk.Frame(self.detail_card, bg=COLORS["card2"], highlightthickness=1, highlightbackground=accent)
        panel.pack(fill="x", padx=16, pady=(12, 4))
        top = tk.Frame(panel, bg=COLORS["card2"])
        top.pack(fill="x", padx=12, pady=(9, 3))
        self.label(top, "ERGEBNIS ENGINE", 9, COLORS["muted"], "bold", COLORS["card2"]).pack(side="left")
        self.label(top, ENGINE_LABELS[engine_key], 14, accent, "bold", COLORS["card2"], "e").pack(side="right")
        self.label(panel, info["summary"], 9, COLORS["muted"], "normal", COLORS["card2"], wrap=800).pack(anchor="w", padx=12, pady=(0, 7))
        weights = "   |   ".join(f"{name}: {weight}" for name, weight, _ in info["rules"][:5])
        self.label(panel, weights, 9, accent, "bold", COLORS["card2"], wrap=800).pack(anchor="w", padx=12, pady=(0, 9))

    def render_details(self):
        self.clear(self.detail_card)

        # Jede Workflow Stufe besitzt eine eigene, abgeschlossene Detailansicht.
        # Inhalte vorheriger oder nachfolgender Schritte werden nicht angehängt.
        if self.current_main_view == "macro" and getattr(self, "macro_results", None):
            self.render_macro_slide()
            return

        if self.current_main_view == "seasonality" and self.final_watchlist:
            self.render_seasonality_view()
            return

        active_key = self.result_engine_key or getattr(self.engine, "analysis_engine", DEFAULT_ANALYSIS_ENGINE)
        self.render_result_engine_summary(active_key)
        self.section_title(self.detail_card, "TOP 3 COT BEGRÜNDUNG", "top3", 16, COLORS["text"], COLORS["card"], 16, (12, 4))
        for p in self.top3:
            col = COLORS["green"] if p["direction"] == "LONG" else COLORS["red"]
            tk.Label(self.detail_card, text=f"{p['pair']} {p['direction']}    {p['confidence']:.1f} Meridian Qualität", font=("Segoe UI", 14, "bold"), fg=col, bg=COLORS["card"]).pack(anchor="w", padx=16, pady=(8, 0))
            self.label(self.detail_card, p["why"], 10, COLORS["muted"], "normal", COLORS["card"], wrap=760).pack(anchor="w", padx=16, pady=(2, 4))
            self.render_pair_breakdown(p)

        single_assets = self.get_single_asset_results()
        if single_assets:
            self.section_title(self.detail_card, "ZUSATZMÄRKTE METALLE UND INDIZES", "single_assets", 16, COLORS["text"], COLORS["card"], 16, (18, 4))
            self.label(self.detail_card, "Diese vier Märkte werden nicht als Forex Cross Pair gerechnet. Sie laufen als eigene COT Single Assets im Gesamtranking und bleiben sichtbar, auch wenn sie nicht in die Top 3 fallen.", 10, COLORS["muted"], "normal", COLORS["card"], wrap=760).pack(anchor="w", padx=16, pady=(0, 6))
            for p in single_assets:
                col = COLORS["green"] if p["direction"] == "LONG" else COLORS["red"]
                rank_text = f"Rang {p.get('original_rank', '')}" if p.get("original_rank") else "im Ranking"
                tk.Label(self.detail_card, text=f"{p.get('display_name', p['pair'])} {p['direction']}    {p['confidence']:.1f} Meridian Qualität    {rank_text}", font=("Segoe UI", 13, "bold"), fg=col, bg=COLORS["card"]).pack(anchor="w", padx=16, pady=(7, 0))
                self.label(self.detail_card, p.get("why", "Single Asset COT Bias."), 10, COLORS["muted"], "normal", COLORS["card"], wrap=760).pack(anchor="w", padx=16, pady=(2, 4))

        active_key = self.result_engine_key or getattr(self.engine, "analysis_engine", DEFAULT_ANALYSIS_ENGINE)
        info = ENGINE_PROFILE_INFO.get(active_key, ENGINE_PROFILE_INFO[DEFAULT_ANALYSIS_ENGINE])
        accent = COLORS.get(info.get("accent", "blue"), COLORS["blue"])
        self.label(self.detail_card, f"SCORE LOGIK, {ENGINE_LABELS[active_key]}", 16, accent, "bold", COLORS["card"]).pack(anchor="w", padx=16, pady=(18, 4))
        self.label(self.detail_card, info["summary"], 10, COLORS["muted"], "normal", COLORS["card"], wrap=760).pack(anchor="w", padx=16, pady=(0, 6))
        self.render_rules(self.detail_card, active_key)

        self.label(self.detail_card, "DATEN CHECK", 15, COLORS["text"], "bold", COLORS["card"]).pack(anchor="w", padx=16, pady=(18, 4))
        lines = [
            "Quelle: CFTC Historical Reports, aktuelles Jahr höchstens einmal täglich aktualisiert",
            f"Letztes Report Datum: {self.engine.report_date}",
            f"Geladene Jahre: {', '.join(map(str, sorted(self.engine.years_loaded)))}",
            f"Gelesene Tabellenzeilen: {self.engine.rows_loaded}",
            "Gefundene Wochen je Währung: " + " | ".join(self.engine.debug),
        ]
        if self.engine.validation_warnings:
            lines.append("Validierungshinweise: " + " | ".join(self.engine.validation_warnings[:6]))
        if self.engine.validation_errors:
            lines.append("Validierungsfehler: " + " | ".join(self.engine.validation_errors[:6]))
        if self.engine.errors:
            lines.append("Download Hinweise: " + " | ".join(self.engine.errors[:6]))
        for line in lines:
            self.label(self.detail_card, line, 10, COLORS["muted"], "normal", COLORS["card"], wrap=800).pack(anchor="w", padx=16, pady=2)

    def final_status_text(self, verdict):
        if verdict == "STARK_BESTÄTIGT":
            return "SEASONALITY SEHR POSITIV"
        if verdict == "BESTÄTIGT":
            return "SEASONALITY POSITIV"
        if verdict == "LEICHT_POSITIV":
            return "SEASONALITY LEICHT POSITIV"
        if verdict == "LEICHT_NEGATIV":
            return "SEASONALITY LEICHT NEGATIV"
        if verdict == "KONFLIKT":
            return "SEASONALITY NEGATIV"
        if verdict == "STARK_KONFLIKT":
            return "SEASONALITY SEHR NEGATIV"
        return "SEASONALITY NEUTRAL"

    def seasonality_alignment_text(self, row):
        direction = row.get("direction", "").upper()
        verdict = row.get("verdict", "NEUTRAL")
        status = self.final_status_text(verdict).replace("SEASONALITY ", "")
        if verdict in ("STARK_BESTÄTIGT", "BESTÄTIGT", "LEICHT_POSITIV"):
            course = "steigender Verlauf" if direction == "LONG" else "fallender Verlauf"
            strength = "passend zum" if verdict != "LEICHT_POSITIV" else "leicht passend zum"
            return f"Seasonality: {status} ({course}, {strength} {direction} Bias)"
        if verdict in ("STARK_KONFLIKT", "KONFLIKT", "LEICHT_NEGATIV"):
            course = "fallender Verlauf" if direction == "LONG" else "steigender Verlauf"
            strength = "spricht klar gegen den" if verdict == "STARK_KONFLIKT" else "spricht gegen den"
            if verdict == "LEICHT_NEGATIV":
                strength = "leicht gegen den"
            return f"Seasonality: {status} ({course}, {strength} {direction} Bias)"
        return f"Seasonality: {status} (kein klarer historischer Verlauf zum {direction} Bias)"

    def seasonality_interpretation_text(self, row):
        direction = row.get("direction", "").upper()
        verdict = row.get("verdict", "NEUTRAL")
        if verdict in ("STARK_BESTÄTIGT", "BESTÄTIGT"):
            course = "steigenden Verlauf" if direction == "LONG" else "fallenden Verlauf"
            return f"Die historische Statistik zeigt im aktuellen Zeitraum einen {course} und bestätigt damit den institutionellen {direction} Bias. Dieses Paar bleibt ein priorisierter Meridian Kandidat."
        if verdict == "LEICHT_POSITIV":
            course = "steigenden Verlauf" if direction == "LONG" else "fallenden Verlauf"
            return f"Die historische Statistik zeigt im aktuellen Zeitraum leichten Rückenwind durch einen eher {course}. COT bleibt der Hauptgrund, die Statistik unterstützt das Setup zusätzlich."
        if verdict in ("STARK_KONFLIKT", "KONFLIKT"):
            course = "fallenden Verlauf" if direction == "LONG" else "steigenden Verlauf"
            return f"Die historische Statistik zeigt im aktuellen Zeitraum einen {course} und spricht damit gegen den institutionellen {direction} Bias. Dieses Paar ist trotz COT Signal nur mit erhöhter Vorsicht interessant."
        if verdict == "LEICHT_NEGATIV":
            course = "fallenden Verlauf" if direction == "LONG" else "steigenden Verlauf"
            return f"Die historische Statistik ist leicht gegenläufig und zeigt eher einen {course}. Das Setup bleibt möglich, sollte aber im Chart besonders sauber bestätigt werden."
        return f"Die historische Statistik liefert keinen klaren Richtungsbias zum institutionellen {direction} Setup. COT bleibt der Hauptgrund, die Statistik ist neutral."

    def render_metric_box(self, parent, title, value, color):
        box = tk.Frame(parent, bg=COLORS["dark"], highlightthickness=1, highlightbackground=COLORS["line"])
        box.pack(side="left", fill="x", expand=True, padx=4, pady=6)
        tk.Label(box, text=title, font=("Segoe UI", 9, "bold"), fg=COLORS["muted"], bg=COLORS["dark"]).pack(anchor="w", padx=8, pady=(6, 0))
        tk.Label(box, text=value, font=("Segoe UI", 14, "bold"), fg=color, bg=COLORS["dark"]).pack(anchor="w", padx=8, pady=(0, 7))

    def render_seasonality_health(self):
        season_rows = list(self.final_watchlist or []) + list(getattr(self, "single_asset_seasonality", []) or [])
        if not season_rows:
            return
        sample = season_rows[0]
        modes = sorted(set(r.get("data_mode", "unbekannt") for r in season_rows))
        files = sorted(set(Path(r.get("cache_file", "")).name for r in season_rows if r.get("cache_file")))
        years = [r.get("years", 0) for r in season_rows]
        min_years = min(years) if years else 0
        max_years = max(years) if years else 0
        health = tk.Frame(self.detail_card, bg=COLORS["card2"], highlightthickness=1, highlightbackground=COLORS["line"])
        health.pack(fill="x", padx=16, pady=(8, 14))
        tk.Label(health, text="SEASONALITY QUICK CHECK", font=("Segoe UI", 13, "bold"), fg=COLORS["blue"], bg=COLORS["card2"]).pack(anchor="w", padx=12, pady=(10, 2))
        file_text = f"{len(files)} Cache Dateien" if files else "keine Cache Datei"
        info = (
            f"Quelle: Yahoo Finance Wochenkurse, lokal gecached | Datenmodus: {', '.join(modes)} | "
            f"Analysefenster: KW {sample.get('calendar_week')} plus {sample.get('lookahead_weeks')} Wochen | "
            f"Historie je Wert: {min_years} bis {max_years} Vergleichsjahre | {file_text}"
        )
        self.label(health, info, 10, COLORS["muted"], "bold", COLORS["card2"], wrap=860).pack(anchor="w", padx=12, pady=(0, 6))
        assets = [r for r in season_rows if r.get("is_single_asset")]
        if assets:
            summary_parts = []
            for r in assets:
                verdict = r.get("verdict", "NEUTRAL")
                summary_parts.append(f"{r.get('display_name', r.get('pair'))}: {self.final_status_text(verdict).replace('SEASONALITY ', '')}")
            self.label(health, "Zusatzmärkte: " + " | ".join(summary_parts), 9, COLORS["muted"], "bold", COLORS["card2"], wrap=860).pack(anchor="w", padx=12, pady=(0, 10))

    def macro_by_pair(self):
        return {r.get("pair"): r for r in (getattr(self, "macro_results", []) or [])}

    def quality_label(self, score):
        score = safe_float(score, 50)
        if score >= 82:
            return "SEHR HOCH"
        if score >= 70:
            return "HOCH"
        if score >= 58:
            return "GUT"
        if score >= 48:
            return "GEMISCHT"
        return "VORSICHT"

    def score_color_local(self, score):
        score = safe_float(score, 50)
        if score >= 70:
            return COLORS["green"]
        if score >= 50:
            return COLORS["yellow"]
        return COLORS["red"]

    def score_cell(self, parent, title, stars, score, color, width=16):
        cell = tk.Frame(parent, bg=parent.cget("bg"), width=width * 10)
        cell.pack(side="left", fill="x", expand=True, padx=4, pady=4)
        tk.Label(cell, text=title, font=("Segoe UI", 8, "bold"), fg=COLORS["muted"], bg=cell.cget("bg")).pack(anchor="w")
        tk.Label(cell, text=str(stars), font=("Segoe UI", 11, "bold"), fg=color, bg=cell.cget("bg")).pack(anchor="w")
        if score is None:
            score_txt = "kein Score"
        else:
            score_txt = f"Score {safe_float(score, 50):.1f}"
        tk.Label(cell, text=score_txt, font=("Segoe UI", 8, "bold"), fg=color, bg=cell.cget("bg")).pack(anchor="w")

    def render_seasonality_detail_panel(self):
        rows = list(self.final_watchlist or [])
        if not rows:
            return

        panel = tk.Frame(self.detail_card, bg=COLORS["card2"], highlightthickness=1, highlightbackground=COLORS["blue"])
        panel.pack(fill="x", padx=16, pady=(4, 12))
        tk.Label(panel, text="SEASONALITY DETAILCHECK", font=("Segoe UI", 16, "bold"), fg=COLORS["blue"], bg=COLORS["card2"]).pack(anchor="w", padx=14, pady=(12, 2))
        sample = rows[0]
        start_txt = sample.get("analysis_date", "")
        end_txt = sample.get("analysis_end_date", "")
        intro = (
            f"Historischer Vergleich ab dem aktuellen Analysezeitpunkt {start_txt} bis {end_txt}. "
            "Die Statistik wird passend zum COT Bias ausgewertet. Bei SHORT gilt ein historisch fallender Markt als Treffer. "
            "Streuung beeinflusst vor allem die Zuverlässigkeit und nicht mehr übermäßig die Richtung."
        )
        self.label(panel, intro, 9, COLORS["muted"], "normal", COLORS["card2"], wrap=1320).pack(anchor="w", padx=14, pady=(0, 8))

        grid = tk.Frame(panel, bg=COLORS["card2"])
        grid.pack(fill="x", padx=10, pady=(0, 12))
        for col in range(3):
            grid.grid_columnconfigure(col, weight=1, uniform="season_detail")

        for idx, row in enumerate(rows[:3]):
            verdict = row.get("verdict", "NEUTRAL")
            color = seasonality_color(verdict)
            card = tk.Frame(grid, bg=COLORS["card"], highlightthickness=1, highlightbackground=color)
            card.grid(row=0, column=idx, sticky="nsew", padx=4)

            head = tk.Frame(card, bg=COLORS["card"])
            head.pack(fill="x", padx=10, pady=(9, 4))
            tk.Label(head, text=f"{row.get('display_name', row.get('pair'))} {row.get('direction', '')}", font=("Segoe UI", 12, "bold"), fg=COLORS["text"], bg=COLORS["card"]).pack(side="left")
            tk.Label(head, text=f"{row.get('seasonality_score', 50):.1f}", font=("Segoe UI", 13, "bold"), fg=color, bg=COLORS["card"]).pack(side="right")

            status = self.final_status_text(verdict).replace("SEASONALITY ", "")
            tk.Label(card, text=status, font=("Segoe UI", 9, "bold"), fg=color, bg=COLORS["card"]).pack(anchor="w", padx=10)

            metrics = tk.Frame(card, bg=COLORS["card"])
            metrics.pack(fill="x", padx=8, pady=(6, 4))
            values = [
                ("Trefferquote", f"{row.get('hit_rate', 0):.0f} %"),
                ("Durchschnitt", f"{row.get('average_return_pct', 0):+.2f} %"),
                ("Median", f"{row.get('median_return_pct', 0):+.2f} %"),
                ("Jahre", str(row.get('years', 0))),
            ]
            for m_idx, (title, value) in enumerate(values):
                cell = tk.Frame(metrics, bg=COLORS["dark"], highlightthickness=1, highlightbackground=COLORS["line"])
                cell.grid(row=m_idx // 2, column=m_idx % 2, sticky="nsew", padx=2, pady=2)
                metrics.grid_columnconfigure(m_idx % 2, weight=1)
                tk.Label(cell, text=title, font=("Segoe UI", 8, "bold"), fg=COLORS["muted"], bg=COLORS["dark"]).pack(anchor="w", padx=6, pady=(4, 0))
                tk.Label(cell, text=value, font=("Segoe UI", 10, "bold"), fg=COLORS["text"], bg=COLORS["dark"]).pack(anchor="w", padx=6, pady=(0, 4))

            reliability = row.get("reliability_label", "MITTEL")
            rel_color = COLORS["green"] if reliability == "HOCH" else COLORS["yellow"] if reliability == "MITTEL" else COLORS["red"]
            detail = (
                f"Streuung {row.get('stdev_return_pct', 0):.2f} %  |  Zuverlässigkeit {reliability}  |  "
                f"{row.get('positive_years', 0)} von {row.get('years', 0)} Jahren passend zum {row.get('direction', '')} Bias"
            )
            self.label(card, detail, 8, rel_color, "bold", COLORS["card"], wrap=400).pack(anchor="w", padx=10, pady=(3, 4))
            self.label(card, self.seasonality_interpretation_text(row), 8, COLORS["muted"], "normal", COLORS["card"], wrap=400).pack(anchor="w", padx=10, pady=(0, 9))

    def render_macro_slide(self):
        macro_rows = list(getattr(self, "macro_results", []) or [])
        if not macro_rows:
            box = tk.Frame(self.detail_card, bg=COLORS["card2"], highlightthickness=1, highlightbackground=COLORS["line"])
            box.pack(fill="x", padx=16, pady=(8, 10))
            tk.Label(box, text="MAKROS PRÜFEN", font=("Segoe UI", 16, "bold"), fg=COLORS["blue"], bg=COLORS["card2"]).pack(anchor="w", padx=12, pady=(10, 2))
            self.label(box, "Nach der Seasonality kann hier die finale Makro Prüfung gestartet werden. Die bestehende COT und Seasonality Engine bleibt dabei unangetastet. Geprüft werden 2 und 10 Jahres Renditen, die Yield Curve, der Zinsimpuls über 5 und 20 Handelstage sowie hochrelevante Ereignisse der nächsten 14 Tage.", 10, COLORS["muted"], "normal", COLORS["card2"], wrap=920).pack(anchor="w", padx=12, pady=(0, 10))
            return

        self._begin_result_motion("macro")

        self.section_title(self.detail_card, "FINALE MARKTPRÜFUNG", "macro", 21, COLORS["blue"], COLORS["card"], 16, (12, 2))
        self.label(self.detail_card, "Abschlussfolie nach COT und Seasonality. 2Y und 10Y Renditen zeigen den aktuellen Zinsvorteil. Der neue Zinsimpuls prüft zusätzlich, ob sich dieser Vorteil über 5 und 20 Handelstage verbessert oder abschwächt. Die Yield Curve ergänzt den Strukturvergleich. High Impact Events markieren mögliche Volatilitätsfenster.", 10, COLORS["muted"], "normal", COLORS["card"], wrap=1320).pack(anchor="w", padx=16, pady=(0, 10))

        split = tk.Frame(self.detail_card, bg=COLORS["card"])
        split.pack(fill="both", expand=False, padx=16, pady=(0, 10))
        # Die Zinsstruktur benötigt für drei Kennzahlen etwas mehr Platz als die Eventseite.
        # Eine asymmetrische, responsive Aufteilung verhindert abgeschnittene Curve Inhalte.
        split.grid_columnconfigure(0, weight=11)
        split.grid_columnconfigure(1, weight=9)

        left = tk.Frame(split, bg=COLORS["card2"], highlightthickness=1, highlightbackground=COLORS["blue"])
        right = tk.Frame(split, bg=COLORS["card2"], highlightthickness=1, highlightbackground=COLORS["orange"])
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 6))
        right.grid(row=0, column=1, sticky="nsew", padx=(6, 0))

        tk.Label(left, text="ZINSSTRUKTUR", font=("Segoe UI", 15, "bold"), fg=COLORS["blue"], bg=COLORS["card2"]).pack(anchor="w", padx=14, pady=(12, 2))
        self.label(left, "Aktueller Zinsvorteil und seine Veränderung auf einen Blick. 2Y, 10Y und Yield Curve bilden die Struktur. Der Zinsimpuls zeigt, ob sich der relative Vorteil passend zum Analyzer Bias entwickelt.", 9, COLORS["muted"], "normal", COLORS["card2"], wrap=540).pack(anchor="w", fill="x", padx=14, pady=(0, 8))

        def macro_component_state(value, direction):
            directional = safe_float(value, 0) * (1 if str(direction).upper() == "LONG" else -1)
            if directional > 0.08:
                return "Unterstützung", COLORS["green"], directional
            if directional < -0.08:
                return "Gegenwind", COLORS["red"], directional
            return "Neutral", COLORS["yellow"], directional

        def bond_source_status(row_data):
            """Kompakter UI Status, ohne technische Quellenbezeichnungen offenzulegen."""
            sources = [
                row_data.get("base_source_2y"), row_data.get("quote_source_2y"),
                row_data.get("base_source_10y"), row_data.get("quote_source_10y"),
            ]
            sources = [str(source).strip() for source in sources if source]
            official_markers = (
                "US Treasury", "EZB", "Bank of England", "Japan Ministry of Finance",
                "SNB", "Bank of Canada", "Reserve Bank of Australia",
                "Reserve Bank of New Zealand",
            )
            official_count = sum(
                any(marker.lower() in source.lower() for marker in official_markers)
                for source in sources
            )
            if sources and official_count == len(sources):
                return "✓  OFFIZIELLE BONDQUELLEN AKTIV", COLORS["green"]
            if official_count:
                return "✓  MISCHQUELLEN AKTIV", COLORS["yellow"]
            return "✓  RESERVEQUELLEN AKTIV", COLORS["blue"]

        def macro_metric(parent, column, title, weight, base, quote, base_value, quote_value, spread, direction, curve=False, motion_delay=0):
            metric = tk.Frame(parent, bg=COLORS["card2"], highlightthickness=1, highlightbackground=COLORS["line"])
            metric.grid(row=0, column=column, sticky="nsew", padx=3)
            state, state_color, directional = macro_component_state(spread, direction)
            tk.Label(metric, text=f"{title}  {weight}", font=("Segoe UI", 8, "bold"), fg=COLORS["muted"], bg=COLORS["card2"]).pack(anchor="w", padx=8, pady=(7, 1))
            tk.Label(metric, text=state, font=("Segoe UI", 10, "bold"), fg=state_color, bg=COLORS["card2"]).pack(anchor="w", padx=8)

            canvas = tk.Canvas(metric, height=8, bg=COLORS["card2"], highlightthickness=0, bd=0)
            canvas.pack(fill="x", padx=8, pady=(4, 5))

            # Der Zielwert bleibt unverändert. Nur seine sichtbare Breite wird
            # beim Aufbau der Ergebnisfolie sanft freigegeben.
            strength_ratio = min(1.0, max(0.06, abs(directional) * (0.63 if curve else 0.50)))

            def redraw_bar(active_canvas, reveal):
                width = max(24, int(active_canvas.winfo_width()))
                fill_width = int(width * strength_ratio * reveal)
                active_canvas.delete("all")
                active_canvas.create_rectangle(0, 1, width, 7, fill=COLORS["line"], outline="")
                if fill_width > 0:
                    active_canvas.create_rectangle(0, 1, fill_width, 7, fill=state_color, outline="")
                    if reveal < 0.995 and fill_width > 4:
                        head = self._blend_ui_color(state_color, COLORS["text"], 0.42)
                        active_canvas.create_rectangle(max(0, fill_width - 3), 1, fill_width, 7, fill=head, outline="")

            self._animate_canvas_result(
                canvas,
                redraw_bar,
                delay=motion_delay,
                duration=self.MACRO_RESULT_MOTION_DURATION_MS,
            )

            if base_value is None or quote_value is None:
                details = "Daten nicht vollständig\nNeutraler Fallback"
            elif curve:
                details = f"{base} {base_value:+.2f} PP  |  {quote} {quote_value:+.2f} PP\nDifferenz {safe_float(spread, 0):+.2f} PP"
            else:
                details = f"{base} {base_value:.2f} %  |  {quote} {quote_value:.2f} %\nSpread {safe_float(spread, 0):+.2f} PP"
            self.label(metric, details, 8, COLORS["text"], "normal", COLORS["card2"], wrap=145).pack(anchor="w", fill="x", padx=8, pady=(0, 7))

        for macro_index, r in enumerate(macro_rows[:3]):
            row_motion_delay = self.RESULT_MOTION_INITIAL_DELAY_MS + macro_index * 170
            score = safe_float(r.get("macro_score", 50), 50)
            col = self.score_color_local(score)
            row = tk.Frame(left, bg=COLORS["card"], highlightthickness=1, highlightbackground=col)
            row.pack(fill="x", padx=12, pady=6)

            top = tk.Frame(row, bg=COLORS["card"])
            top.pack(fill="x", padx=11, pady=(9, 5))
            tk.Label(top, text=f"{r.get('pair')}  {r.get('direction')}", font=("Segoe UI", 12, "bold"), fg=COLORS["text"], bg=COLORS["card"]).pack(side="left")
            source_text, source_color = bond_source_status(r)
            tk.Label(
                top, text=source_text, font=("Segoe UI", 8, "bold"),
                fg=source_color, bg=COLORS["card"],
            ).pack(side="left", padx=(10, 0), pady=(2, 0))
            verdict = str(r.get("macro_label") or ("Unterstützung" if score >= 55 else "Gegenwind" if score < 45 else "Neutral")).upper()
            verdict_label = tk.Label(top, text=f"{verdict}   {score:.1f}", font=("Segoe UI", 11, "bold"), fg=col, bg=COLORS["card"])
            verdict_label.pack(side="right")
            self._animate_number_label(
                verdict_label,
                score,
                lambda value, verdict_text=verdict: f"{verdict_text}   {value:.1f}",
                delay=row_motion_delay,
                duration=self.MACRO_RESULT_MOTION_DURATION_MS,
            )

            metrics = tk.Frame(row, bg=COLORS["card"])
            metrics.pack(fill="x", padx=8, pady=(0, 6))
            metrics.grid_columnconfigure(0, weight=10, uniform="macro_metric")
            metrics.grid_columnconfigure(1, weight=10, uniform="macro_metric")
            metrics.grid_columnconfigure(2, weight=11, uniform="macro_metric")
            base = r.get("base")
            quote = r.get("quote")
            direction = r.get("direction")
            macro_metric(metrics, 0, "2Y", "35 %", base, quote, r.get("base_yield_2y"), r.get("quote_yield_2y"), r.get("spread_2y"), direction, motion_delay=row_motion_delay)
            macro_metric(metrics, 1, "10Y", "20 %", base, quote, r.get("base_yield_10y"), r.get("quote_yield_10y"), r.get("spread_10y"), direction, motion_delay=row_motion_delay + 42)
            macro_metric(metrics, 2, "CURVE", "15 %", base, quote, r.get("base_curve"), r.get("quote_curve"), r.get("curve_spread"), direction, curve=True, motion_delay=row_motion_delay + 84)

            impulse_available = bool(r.get("impulse_available"))
            impulse_state = str(r.get("impulse_state") or "NEUTRAL")
            impulse_color = COLORS["green"] if impulse_state == "SUPPORT" else COLORS["red"] if impulse_state == "HEADWIND" else COLORS["yellow"]
            impulse_box = tk.Frame(row, bg=COLORS["card2"], highlightthickness=1, highlightbackground=COLORS["line"])
            impulse_box.pack(fill="x", padx=11, pady=(0, 7))
            impulse_head = tk.Frame(impulse_box, bg=COLORS["card2"])
            impulse_head.pack(fill="x", padx=8, pady=(6, 2))
            tk.Label(impulse_head, text="ZINSIMPULS  30 %", font=("Segoe UI", 9, "bold"), fg=COLORS["muted"], bg=COLORS["card2"]).pack(side="left")
            tk.Label(impulse_head, text=str(r.get("impulse_label") or "STABIL"), font=("Segoe UI", 10, "bold"), fg=impulse_color, bg=COLORS["card2"]).pack(side="right")

            impulse_scale = tk.Canvas(impulse_box, height=28, bg=COLORS["card2"], highlightthickness=0, bd=0)
            impulse_scale.pack(fill="x", padx=8, pady=(1, 2))
            impulse_score_value = safe_float(r.get("score_impulse", 50), 50)

            def redraw_impulse(active_canvas, reveal, score_value=impulse_score_value, available=impulse_available):
                width = max(160, int(active_canvas.winfo_width()))
                active_canvas.delete("all")
                left, right = 2, width - 2
                top, bottom = 5, 13
                segments = 72
                red = (191, 49, 67)
                amber = (224, 175, 48)
                green = (0, 207, 126)

                def blend(first, second, amount):
                    values = [round(first[i] + (second[i] - first[i]) * amount) for i in range(3)]
                    return "#%02x%02x%02x" % tuple(values)

                segment_width = (right - left) / segments
                active_canvas.create_rectangle(left, top, right, bottom, fill=COLORS["line"], outline="")
                visible_segments = min(segments, max(0, int(math.ceil(segments * reveal))))
                for index in range(visible_segments):
                    ratio = index / max(1, segments - 1)
                    color = blend(red, amber, ratio * 2) if ratio <= 0.5 else blend(amber, green, (ratio - 0.5) * 2)
                    x1 = left + index * segment_width
                    x2 = left + (index + 1) * segment_width + 0.5
                    active_canvas.create_rectangle(x1, top, x2, bottom, fill=color, outline="")

                if 0.0 < reveal < 0.995:
                    head_x = left + reveal * (right - left)
                    active_canvas.create_rectangle(max(left, head_x - 3), top, head_x, bottom, fill="#F7FAFF", outline="")

                normalized = clamp((score_value - 20.0) / 60.0, 0.0, 1.0) if available else 0.5
                marker_x = left + normalized * (right - left)
                marker_color = "#f6fbff" if available else COLORS["muted"]
                if reveal >= 0.995:
                    active_canvas.create_polygon(marker_x - 5, 0, marker_x + 5, 0, marker_x, 5, fill=marker_color, outline="")
                    active_canvas.create_line(marker_x, 3, marker_x, bottom + 2, fill=marker_color, width=2)
                active_canvas.create_text(left, 22, text="GEGENWIND", anchor="w", fill=COLORS["muted"], font=("Segoe UI", 7, "bold"))
                active_canvas.create_text(width / 2, 22, text="NEUTRAL", anchor="center", fill=COLORS["muted"], font=("Segoe UI", 7, "bold"))
                active_canvas.create_text(right, 22, text="UNTERSTÜTZUNG", anchor="e", fill=COLORS["muted"], font=("Segoe UI", 7, "bold"))

            self._animate_canvas_result(
                impulse_scale,
                redraw_impulse,
                delay=row_motion_delay + 126,
                duration=self.MACRO_RESULT_MOTION_DURATION_MS,
            )

            def format_impulse(value):
                return "noch nicht verfügbar" if value is None else f"{safe_float(value, 0):+.2f} PP"

            impulse_detail = (
                f"5 Handelstage {format_impulse(r.get('impulse_change_5d'))}   |   "
                f"20 Handelstage {format_impulse(r.get('impulse_change_20d'))}   |   "
                f"Score {safe_float(r.get('score_impulse', 50), 50):.1f}"
            )
            self.label(impulse_box, impulse_detail, 8, COLORS["text"], "bold", COLORS["card2"], wrap=500).pack(anchor="w", padx=8, pady=(0, 1))
            self.label(impulse_box, str(r.get("impulse_interpretation") or "Der Zinsimpuls bleibt neutral."), 8, COLORS["muted"], "normal", COLORS["card2"], wrap=500).pack(anchor="w", padx=8, pady=(0, 6))

            interpretation = str(r.get("interpretation", "Makro Prüfung neutral.")).replace("Makro Urteil:", "").strip()
            verdict_box = tk.Frame(row, bg=COLORS["card2"])
            verdict_box.pack(fill="x", padx=11, pady=(0, 9))
            tk.Label(verdict_box, text="MAKRO URTEIL", font=("Segoe UI", 8, "bold"), fg=col, bg=COLORS["card2"]).pack(anchor="w", padx=8, pady=(6, 1))
            self.label(verdict_box, interpretation, 8, COLORS["text"], "normal", COLORS["card2"], wrap=510).pack(anchor="w", fill="x", padx=8, pady=(0, 6))

        tk.Label(right, text="HIGH IMPACT EVENTS", font=("Segoe UI", 15, "bold"), fg=COLORS["orange"], bg=COLORS["card2"]).pack(anchor="w", padx=14, pady=(12, 2))
        self.label(right, "Nur die wichtigsten Termine der nächsten 14 Tage. Das ist kein Handelssignal, sondern ein Timing und Volatilitätshinweis.", 9, COLORS["muted"], "normal", COLORS["card2"], wrap=640).pack(anchor="w", padx=14, pady=(0, 8))

        for r in macro_rows[:3]:
            events = r.get("events") or []
            risk = r.get("event_risk", "ruhig")
            penalty = safe_float(r.get("event_penalty", 0), 0)
            risk_col = COLORS["red"] if risk == "sehr hoch" else COLORS["yellow"] if risk in ("erhöht", "beobachten") else COLORS["green"]
            box = tk.Frame(right, bg=COLORS["card"], highlightthickness=1, highlightbackground=COLORS["line"])
            box.pack(fill="x", padx=12, pady=5)
            head = tk.Frame(box, bg=COLORS["card"])
            head.pack(fill="x", padx=10, pady=(8, 1))
            volatility = int(safe_float(r.get("event_volatility", 1), 1))
            tk.Label(head, text=f"{r.get('pair')}  Eventlage: {risk.upper()}", font=("Segoe UI", 12, "bold"), fg=risk_col, bg=COLORS["card"]).pack(side="left")
            tk.Label(head, text=f"Erwartete Volatilität {volatility}/10", font=("Segoe UI", 11, "bold"), fg=risk_col, bg=COLORS["card"]).pack(side="right")
            if not events:
                self.label(box, "Keine relevanten Hochrisiko Termine aus den angebundenen Quellen gefunden. Eventlage bleibt neutral, es gibt weder Bonus noch Malus.", 8, COLORS["muted"], "normal", COLORS["card"], wrap=640).pack(anchor="w", padx=10, pady=(0, 9))
            else:
                for ev in events[:2]:
                    time_txt = ev.get('time') or 'Uhrzeit offen'
                    txt = f"{ev.get('date')}  {time_txt} Uhr    {ev.get('currency')}: {ev.get('event')}" if time_txt != 'Uhrzeit offen' else f"{ev.get('date')}  Uhrzeit offen    {ev.get('currency')}: {ev.get('event')}"
                    self.label(box, txt, 8, COLORS["text"], "bold", COLORS["card"], wrap=640).pack(anchor="w", padx=10, pady=(0, 2))
                if len(events) > 2:
                    self.label(box, f"+ {len(events) - 2} weiterer relevanter Termin im 14 Tage Fenster", 8, COLORS["muted"], "normal", COLORS["card"], wrap=640).pack(anchor="w", padx=10, pady=(0, 2))
                self.label(box, "Hinweis: Termine heben den COT Bias nicht auf. Sie zeigen nur mögliche Volatilitätsfenster für Timing und Risikomanagement.", 8, COLORS["muted"], "normal", COLORS["card"], wrap=640).pack(anchor="w", padx=10, pady=(2, 8))

        table = tk.Frame(self.detail_card, bg=COLORS["card2"], highlightthickness=1, highlightbackground=COLORS["green"])
        table.pack(fill="x", padx=16, pady=(2, 16))
        final_head = tk.Frame(table, bg=COLORS["card2"])
        final_head.pack(fill="x", padx=14, pady=(12, 2))
        tk.Label(final_head, text="FINALE WATCHLIST QUALITÄT", font=("Segoe UI", 16, "bold"), fg=COLORS["green"], bg=COLORS["card2"]).pack(side="left")
        self.help_button(final_head, "final_watchlist_use", COLORS["card2"], compact=False).pack(side="left", padx=(7, 0))
        self.label(table, "Die finale Qualität startet beim COT Basiswert. Seasonality verändert ihn dynamisch um höchstens acht Punkte. Das gesamte Zins Makro bleibt trotz des neuen Zinsimpulses auf höchstens fünf Punkte begrenzt. Wichtige Termine erzeugen maximal vier Punkte Timing Abschlag. COT bestimmt weiterhin Paar und Analyzer Bias. Makro und Termine können diesen Bias nicht umdrehen.", 9, COLORS["muted"], "normal", COLORS["card2"], wrap=1320).pack(anchor="w", padx=14, pady=(0, 8))

        season_by_pair = {r.get("pair"): r for r in (self.final_watchlist or [])}
        for idx, r in enumerate(macro_rows[:3], 1):
            season = season_by_pair.get(r.get("pair"), {})
            final_score = safe_float(r.get("final_quality", r.get("final_confluence", 50)), 50)
            final_col = self.score_color_local(final_score)
            row = tk.Frame(table, bg=COLORS["card"], highlightthickness=1, highlightbackground=final_col)
            row.pack(fill="x", padx=12, pady=5)
            head = tk.Frame(row, bg=COLORS["card"])
            head.pack(fill="x", padx=12, pady=(9, 2))
            pair_title = f"#{idx} {r.get('pair')} {r.get('direction')}"
            tk.Label(head, text=pair_title, font=("Segoe UI", 14, "bold"), fg=COLORS["text"], bg=COLORS["card"]).pack(side="left")
            tk.Label(head, text=f"QUALITÄT: {self.quality_label(final_score)}    {r.get('final_quality_stars', r.get('final_confluence_stars', '☆☆☆☆☆'))}  {final_score:.1f}", font=("Segoe UI", 13, "bold"), fg=final_col, bg=COLORS["card"]).pack(side="right")

            cells = tk.Frame(row, bg=COLORS["card"])
            cells.pack(fill="x", padx=12, pady=(2, 8))
            cot_score = safe_float(r.get("cot_score", season.get("cot_confidence", 50)), 50)
            sea_score = safe_float(r.get("seasonality_score", season.get("seasonality_score", 50)), 50)
            macro_score = safe_float(r.get("macro_score", 50), 50)
            event_penalty = safe_float(r.get("event_penalty", 0), 0)
            season_adjustment = safe_float(r.get("seasonality_adjustment", seasonality_quality_adjustment(sea_score)), 0)
            macro_adjustment = safe_float(r.get("macro_adjustment", macro_quality_adjustment(macro_score)), 0)
            self.score_cell(cells, "COT", star_text(cot_score), cot_score, self.score_color_local(cot_score))
            self.score_cell(cells, "Saison", star_text(sea_score), sea_score, self.score_color_local(sea_score))
            self.score_cell(cells, "Zins Makro inklusive Impuls", r.get("macro_stars", star_text(macro_score)), macro_score, self.score_color_local(macro_score))
            volatility = int(safe_float(r.get("event_volatility", 1), 1))
            self.score_cell(cells, "Erwartete Volatilität", f"{volatility}/10", None, COLORS["green"] if volatility <= 3 else COLORS["yellow"] if volatility <= 6 else COLORS["red"])
            self.score_cell(cells, "Finale Qualität", r.get("final_quality_stars", star_text(final_score)), final_score, final_col)

            note = (
                f"Scoreaufbau: COT Basis {cot_score:.1f}, Saison {season_adjustment:+.1f}, "
                f"Makro {macro_adjustment:+.1f}, Termine {event_penalty:.1f} Punkte Abschlag, "
                f"final {final_score:.1f}. Fazit: {r.get('macro_label', 'neutral').capitalize()}, "
                f"Watchlist Qualität {self.quality_label(final_score)}."
            )
            self.label(row, note, 9, COLORS["muted"], "bold", COLORS["card"], wrap=1300).pack(anchor="w", padx=12, pady=(0, 10))


    def render_seasonality_view(self):
        """Zeigt ausschließlich die Ergebnisse des aktiven Seasonality Schritts."""
        rows = list(self.final_watchlist or [])

        self.section_title(self.detail_card, "SEASONALITY AUSWERTUNG", "seasonality", 18, COLORS["blue"], COLORS["card"], 16, (12, 2))
        self.label(
            self.detail_card,
            "Historischer Vier Wochen Vergleich ab dem aktuellen Analysetag. Die Statistik wird passend zum COT Bias gelesen: Bei LONG zählt ein historischer Anstieg, bei SHORT ein historischer Rückgang als Treffer.",
            10, COLORS["muted"], "normal", COLORS["card"], wrap=980
        ).pack(anchor="w", padx=16, pady=(0, 8))

        if rows:
            confirmed = sum(1 for row in rows if row.get("verdict") in ("STARK_BESTÄTIGT", "BESTÄTIGT", "LEICHT_POSITIV"))
            neutral = sum(1 for row in rows if row.get("verdict", "NEUTRAL") == "NEUTRAL")
            conflict = sum(1 for row in rows if row.get("verdict") in ("STARK_KONFLIKT", "KONFLIKT", "LEICHT_NEGATIV"))
            sample = rows[0]
            summary = tk.Frame(self.detail_card, bg=COLORS["card2"], highlightthickness=1, highlightbackground=COLORS["line"])
            summary.pack(fill="x", padx=16, pady=(2, 8))
            tk.Label(summary, text="SCHNELLÜBERBLICK", font=("Segoe UI", 12, "bold"), fg=COLORS["text"], bg=COLORS["card2"]).pack(anchor="w", padx=12, pady=(9, 2))
            summary_text = (
                f"Analysefenster {sample.get('analysis_date', '')} bis {sample.get('analysis_end_date', '')}  |  "
                f"{confirmed} unterstützend  |  {neutral} neutral  |  {conflict} gegenläufig"
            )
            self.label(summary, summary_text, 10, COLORS["muted"], "bold", COLORS["card2"], wrap=940).pack(anchor="w", padx=12, pady=(0, 9))

        self.render_seasonality_health()
        self.render_seasonality_detail_panel()

    def render_final_watchlist(self):
        season_rows = list(self.final_watchlist or [])
        asset_rows = list(getattr(self, "single_asset_seasonality", []) or [])
        all_rows = season_rows + asset_rows

        self.label(self.detail_card, "FINALE Meridian WATCHLIST", 17, COLORS["yellow"], "bold", COLORS["card"]).pack(anchor="w", padx=16, pady=(10, 2))
        self.label(
            self.detail_card,
            "Richtung kommt aus dem aktuellen Commercial Long/Short Überhang. Die Qualität kommt aus Positionsverschiebungen. Seasonality ist ein Zusatzfilter und bewertet, ob die Statistik den COT Bias unterstützt oder bremst.",
            10, COLORS["muted"], "normal", COLORS["card"], wrap=940
        ).pack(anchor="w", padx=16, pady=(0, 6))

        if season_rows:
            grid = tk.Frame(self.detail_card, bg=COLORS["card"])
            grid.pack(fill="x", padx=16, pady=(0, 8))
            for col_idx in range(min(3, len(season_rows))):
                grid.grid_columnconfigure(col_idx, weight=1)
            for i, r in enumerate(season_rows[:3]):
                verdict = r.get("verdict", "NEUTRAL")
                col = seasonality_color(verdict)
                direction = r.get("direction", "")
                dir_col = COLORS["green"] if direction == "LONG" else COLORS["red"]
                box = tk.Frame(grid, bg=COLORS["card2"], highlightthickness=2, highlightbackground=col)
                box.grid(row=0, column=i, sticky="nsew", padx=4)
                tk.Label(box, text=f"#{i + 1} {r.get('display_name', r.get('pair'))}", font=("Segoe UI", 13, "bold"), fg=COLORS["text"], bg=COLORS["card2"]).pack(anchor="w", padx=10, pady=(8, 0))
                line = tk.Frame(box, bg=COLORS["card2"])
                line.pack(fill="x", padx=10, pady=(0, 1))
                tk.Label(line, text=direction, font=("Segoe UI", 14, "bold"), fg=dir_col, bg=COLORS["card2"]).pack(side="left")
                tk.Label(line, text=f"{r.get('final_score', r.get('confidence', 0)):.1f}", font=("Segoe UI", 15, "bold"), fg=col, bg=COLORS["card2"]).pack(side="right")
                status = self.final_status_text(verdict).replace("SEASONALITY ", "")
                stat = tk.Frame(box, bg=COLORS["card2"])
                stat.pack(anchor="w", padx=10, pady=(1, 8))
                self.status_dot(stat, col, 11).pack(side="left", padx=(0, 5))
                tk.Label(stat, text=status, font=("Segoe UI", 9, "bold"), fg=col, bg=COLORS["card2"]).pack(side="left")
                window_text = f"Trefferquote {r.get('hit_rate', 0):.0f} %  |  {r.get('analysis_date', '')} bis {r.get('analysis_end_date', '')}"
                self.label(box, window_text, 8, COLORS["muted"], "normal", COLORS["card2"], wrap=360).pack(anchor="w", padx=10, pady=(0, 8))

        if all_rows:
            pos = [r.get("display_name", r.get("pair")) for r in all_rows if r.get("verdict") in ("STARK_BESTÄTIGT", "BESTÄTIGT", "LEICHT_POSITIV")]
            neg = [r.get("display_name", r.get("pair")) for r in all_rows if r.get("verdict") in ("STARK_KONFLIKT", "KONFLIKT", "LEICHT_NEGATIV")]
            neu = [r.get("display_name", r.get("pair")) for r in all_rows if r.get("verdict", "NEUTRAL") == "NEUTRAL"]
            summary = []
            if pos:
                summary.append("Bestätigt: " + ", ".join(pos))
            if neg:
                summary.append("Gegenläufig: " + ", ".join(neg))
            if neu:
                summary.append("Neutral: " + ", ".join(neu))
            box = tk.Frame(self.detail_card, bg=COLORS["card2"], highlightthickness=1, highlightbackground=COLORS["line"])
            box.pack(fill="x", padx=16, pady=(0, 8))
            tk.Label(box, text="SEASONALITY KURZFAZIT", font=("Segoe UI", 12, "bold"), fg=COLORS["blue"], bg=COLORS["card2"]).pack(anchor="w", padx=10, pady=(8, 1))
            self.label(box, " | ".join(summary) if summary else "Keine klare saisonale Aussage.", 10, COLORS["muted"], "bold", COLORS["card2"], wrap=940).pack(anchor="w", padx=10, pady=(0, 8))

        self.render_seasonality_detail_panel()

    def write_macro_audit_files(self):
        rows = list(getattr(self, "macro_results", []) or [])
        if not rows:
            return None
        AUDIT_DIR.mkdir(exist_ok=True)
        safe_date = str(self.engine.report_date).replace("/", "-").replace(":", "-")
        path = AUDIT_DIR / f"macro_audit_{safe_date}.json"
        summary_path = AUDIT_DIR / f"macro_audit_{safe_date}_summary.txt"
        payload = {
            "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "engine_version": "2.2 Makro Check mit 2Y, 10Y, Yield Curve und Zinsimpuls. COT und Seasonality Berechnungen bleiben unverändert.",
            "report_date": self.engine.report_date,
            "bond_sources": "Offizielle Institutionen als Primärquelle, bestehende Anbieter ausschließlich als technische Reserve, mit lokalem Cache",
            "event_sources": "TradingEconomics Calendar Guest API plus ForexFactory CSV Fallback, 14 Tage Filter, High Impact Schlüsselwortfilter",
            "event_source_audit": [r.get("event_audit", {}) for r in rows],
            "bond_source_audit": [r.get("bond_audit", {}) for r in rows],
            "macro_results": rows,
            "errors": getattr(self.macro_engine, "errors", []),
            "note": "Die Makro Prüfung ist eine eigenständige Qualitätsanzeige. Der Zinsimpuls misst die Veränderung über 5 und 20 Handelstage. Die gesamte Makro Wirkung bleibt auf plus oder minus fünf finale Punkte begrenzt.",
        }
        path.write_text(json.dumps(sanitize_audit_payload(payload), indent=2, ensure_ascii=False), encoding="utf-8")
        lines = [
            "Meridian Makro Audit",
            f"Erstellt: {payload['created_at']}",
            f"Report Datum: {self.engine.report_date}",
            "Modul: 2Y, 10Y, Yield Curve und Zinsimpuls plus High Impact Events, eigenständig neben COT und Seasonality",
            "Bonddaten: 2Y 35 Prozent, 10Y 20 Prozent, Yield Curve 15 Prozent, Zinsimpuls 30 Prozent. Spreads = Basiswährung minus Kurswährung",
            "Zinsimpuls: Veränderung des relativen 2Y und 10Y Renditevorteils über 5 und 20 Handelstage, immer passend zum Analyzer Bias gelesen",
            "Events: nächste 14 Tage, nur hohe Relevanz nach Quelle oder Schlüsselwortfilter",
            "",
            "Makro Ergebnisse:",
        ]
        for r in rows:
            b2 = r.get("base_yield_2y")
            q2 = r.get("quote_yield_2y")
            b10 = r.get("base_yield_10y")
            q10 = r.get("quote_yield_10y")
            bc = r.get("base_curve")
            qc = r.get("quote_curve")
            if b2 is not None and q2 is not None and b10 is not None and q10 is not None:
                ytxt = (f"2Y {r.get('base')} {b2:.2f} %, {r.get('quote')} {q2:.2f} %, Spread {r.get('spread_2y'):+.2f} PP | "
                        f"10Y {r.get('base')} {b10:.2f} %, {r.get('quote')} {q10:.2f} %, Spread {r.get('spread_10y'):+.2f} PP | "
                        f"Curve {r.get('base')} {bc:+.2f} PP, {r.get('quote')} {qc:+.2f} PP, Differenz {r.get('curve_spread'):+.2f} PP")
            else:
                ytxt = "Bonddaten teilweise unvollständig, verfügbare Bausteine wurden neu gewichtet"
            ea = r.get("event_audit", {}) or {}
            impulse_5d = r.get("impulse_change_5d")
            impulse_20d = r.get("impulse_change_20d")
            impulse_text = (
                f"Zinsimpuls {r.get('impulse_label', 'STABIL')} | Score {r.get('score_impulse', 50)} | "
                f"5T {impulse_5d:+.3f} PP" if impulse_5d is not None else
                f"Zinsimpuls {r.get('impulse_label', 'HISTORIE BAUT SICH AUF')} | 5T nicht verfügbar"
            )
            impulse_text += f" | 20T {impulse_20d:+.3f} PP" if impulse_20d is not None else " | 20T nicht verfügbar"
            lines.append(f"{r.get('pair')} {r.get('direction')}: {r.get('macro_label')} | Score {r.get('macro_score')} | {ytxt} | {impulse_text} | Events angezeigt {len(r.get('events') or [])}, High Impact gefunden {ea.get('high_impact_events_found', 'n/a')}, Rohtermine {ea.get('raw_events_seen', 'n/a')}, Quellen {ea.get('source_counts', {})}, erwartete Volatilität {r.get('event_volatility', 1)}/10, kleiner Abschlag {r.get('event_penalty', 0)} | Finale Qualität {r.get('final_quality', r.get('final_confluence'))}")
            for ev in (r.get("events") or [])[:6]:
                lines.append(f"  Event: {ev.get('date')} {ev.get('time', 'Uhrzeit offen')} {ev.get('currency')} {ev.get('event')} | Quelle {ev.get('source', 'unbekannt')}")
        if getattr(self.macro_engine, "errors", []):
            lines += ["", "Hinweise:"] + list(getattr(self.macro_engine, "errors", []))[:20]
        summary_path.write_text("\n".join(lines), encoding="utf-8")
        return path, summary_path

    def write_seasonality_audit_files(self):
        season_rows = list(self.final_watchlist or []) + list(getattr(self, "single_asset_seasonality", []) or [])
        if not season_rows:
            return None
        AUDIT_DIR.mkdir(exist_ok=True)
        safe_date = str(self.engine.report_date).replace("/", "-").replace(":", "-")
        path = AUDIT_DIR / f"seasonality_audit_{safe_date}.json"
        summary_path = AUDIT_DIR / f"seasonality_audit_{safe_date}_summary.txt"
        payload = {
            "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "engine_version": f"V{APP_VERSION} Meridian Engine Clean Flow plus separater richtungsbezogener Seasonality Check",
            "report_date": self.engine.report_date,
            "seasonality_source": "Yahoo Finance Wochenkurse, lokal gecached",
            "seasonality_health": {
                "source": "Yahoo Finance",
                "data_modes": sorted(set(r.get("data_mode", "unbekannt") for r in season_rows)),
                "cache_files": sorted(set(r.get("cache_file", "") for r in season_rows)),
                "lookahead_weeks": SEASONALITY_LOOKAHEAD_WEEKS,
                "calendar_week": season_rows[0].get("calendar_week") if season_rows else None,
                "years_min": min([r.get("years", 0) for r in season_rows]) if season_rows else 0,
                "years_max": max([r.get("years", 0) for r in season_rows]) if season_rows else 0,
            },
            "top3_cot": self.top3,
            "final_watchlist": self.final_watchlist,
            "single_asset_seasonality": getattr(self, "single_asset_seasonality", []),
            "note": "Die historische Statistik prüft den Verlauf der kommenden 4 Wochen ab aktueller Kalenderwoche in Richtung des COT Bias. Der Final Research Score wird bei bestätigter Seasonality angehoben und bei Konflikt gesenkt.",
        }
        path.write_text(json.dumps(sanitize_audit_payload(payload), indent=2, ensure_ascii=False), encoding="utf-8")
        lines = [
            "Meridian Seasonality Audit",
            f"Erstellt: {payload['created_at']}",
            f"Report Datum: {self.engine.report_date}",
            "Quelle: Yahoo Finance Wochenkurse, lokal gecached",
            f"Analysefenster: KW {season_rows[0].get('calendar_week') if season_rows else '?'} plus {SEASONALITY_LOOKAHEAD_WEEKS} Wochen",
            f"Datenmodus: {', '.join(sorted(set(r.get('data_mode', 'unbekannt') for r in season_rows)))}",
            f"Vergleichsjahre: {min([r.get('years', 0) for r in season_rows]) if season_rows else 0} bis {max([r.get('years', 0) for r in season_rows]) if season_rows else 0}",
            "",
            "Finale Watchlist:",
        ]
        for i, r in enumerate(season_rows, 1):
            lines.append(f"#{i} {r['pair']} {r['direction']} | Research {r['final_score']:.1f} | Historische Statistik {r['seasonality_score']:.1f} | {r['verdict']} | Trefferquote {r['hit_rate']:.1f} % | Durchschnitt zum Bias {r['average_return_pct']:+.2f} % | Paar tatsächlich {r.get('average_raw_return_pct', 0):+.2f} %")
        summary_path.write_text("\n".join(lines), encoding="utf-8")
        return path, summary_path

    def save_result(self):
        if not self.top3:
            messagebox.showwarning("Noch kein Ergebnis", "Bitte zuerst die Top 3 berechnen.")
            return
        path = APP_DIR / "last_meridian_weekly_engine_result.json"
        path.write_text(json.dumps({
            "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "report_date": self.engine.report_date,
            "years_loaded": self.engine.years_loaded,
            "weights": self.engine.weights,
            "strengths": self.strengths,
            "top3": self.top3,
            "seasonality": self.seasonality,
            "final_watchlist": self.final_watchlist,
            "single_asset_seasonality": getattr(self, "single_asset_seasonality", []),
            "macro_results": getattr(self, "macro_results", []),
            "debug": self.engine.debug,
        }, indent=2), encoding="utf-8")
        messagebox.showinfo("Gespeichert", f"Ergebnis gespeichert:\n{path}")

    def build_data_health(self):
        today = datetime.now()
        report_dt = None
        try:
            report_dt = datetime.strptime(str(self.engine.report_date), "%Y-%m-%d")
        except Exception:
            pass

        currency_checks = []
        usable = 0
        latest_dates = []
        for curr, series in sorted(self.engine.records.items()):
            if not series:
                currency_checks.append({"currency": curr, "status": "missing", "weeks": 0})
                continue
            latest = series[-1]
            latest_dates.append(latest["date"])
            ok = len(series) >= max(5, self.engine.lookback_weeks + 1) and latest.get("open_interest", 0) > 0
            if ok:
                usable += 1
            currency_checks.append({
                "currency": curr,
                "status": "ok" if ok else "weak",
                "weeks": len(series),
                "latest_date": latest["date"].strftime("%Y-%m-%d"),
                "market": latest.get("market", ""),
                "open_interest": round(latest.get("open_interest", 0.0)),
                "large_spec_net": round(latest.get("spec_net", 0.0)),
                "commercial_net": round(latest.get("commercial_net", 0.0)),
            })

        age_days = None
        if report_dt:
            age_days = (today - report_dt).days
        same_latest_count = 0
        if latest_dates:
            max_dt = max(latest_dates)
            same_latest_count = sum(1 for d in latest_dates if d == max_dt)

        status = "OK"
        warnings = []
        notes = []
        errors = []
        if report_dt is None:
            status = "WARN"
            warnings.append("Report Datum konnte nicht geprüft werden.")
        elif age_days is not None and age_days > 21:
            status = "WARN"
            warnings.append(f"Letzter Report ist {age_days} Tage alt. Bitte CFTC Daten aktualisieren.")
        elif age_days is not None and age_days < -3:
            status = "WARN"
            warnings.append("Report Datum liegt auffällig in der Zukunft. Systemdatum oder Datenquelle prüfen.")
        if usable < 7:
            status = "WARN"
            warnings.append(f"Nur {usable} verwertbare Währungen gefunden.")
        stale_direct = [c for c in currency_checks if c.get("latest_date") and c.get("latest_date") != self.engine.report_date and not (self.engine.used_usd_proxy and c.get("currency") == "USD")]
        if stale_direct:
            status = "WARN"
            warnings.append("Stale Rohdaten erkannt: " + ", ".join(f"{c['currency']}={c.get('latest_date')}" for c in stale_direct))
        if self.engine.used_usd_proxy:
            notes.append("USD wird transparent als Proxy aus den aktuellen Nicht USD Meridian Qualitätswerten berechnet, weil kein aktueller Dollar Index Rohdatensatz vorliegt.")
        if same_latest_count < min(6, usable) and not self.engine.used_usd_proxy:
            status = "WARN"
            warnings.append("Nicht alle Rohdaten Währungen besitzen dasselbe letzte Report Datum.")
        for w in self.engine.validation_warnings:
            if "USD" in w and ("Proxy" in w or "Dollar Index" in w):
                notes.append(w)
            else:
                warnings.append(w)
        errors.extend(self.engine.validation_errors)
        if errors:
            status = "FAIL"

        return {
            "status": status,
            "warnings": warnings,
            "notes": notes,
            "errors": errors,
            "usd_proxy_active": self.engine.used_usd_proxy,
            "report_date": self.engine.report_date,
            "report_age_days": age_days,
            "usable_currencies": usable,
            "same_latest_date_count": same_latest_count,
            "rows_loaded": self.engine.rows_loaded,
            "years_loaded": self.engine.years_loaded,
            "currency_checks": currency_checks,
            "interpretation": "Dieser Check prüft Datenfrische, geladene Zeilen, verwertbare Währungen, Open Interest und das letzte Report Datum. Er ersetzt keinen Abgleich gegen die offizielle CFTC Webseite, zeigt aber sofort, ob die Engine echte geladene COT Rohdaten nutzt.",
        }

    def build_audit(self):
        return {
            "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
            "engine_version": f"V{APP_VERSION} Meridian Engine Clean Flow plus separater richtungsbezogener Seasonality Check",
            "report_date": self.engine.report_date,
            "years_loaded": self.engine.years_loaded,
            "source_files": self.engine.source_files,
            "rows_loaded": self.engine.rows_loaded,
            "weights": self.engine.weights,
            "lookback_weeks": self.engine.lookback_weeks,
            "data_health_check": self.build_data_health(),
            "data_check": self.engine.debug,
            "currencies": self.strengths,
            "top3": self.top3,
            "all_pairs": self.all_pairs,
            "seasonality": self.seasonality,
            "final_watchlist": self.final_watchlist,
            "single_asset_seasonality": getattr(self, "single_asset_seasonality", []),
            "note": "Confidence ist Research Confidence, keine garantierte Trefferwahrscheinlichkeit. Paar Scores sind bei 95 gedeckelt. Die Rohdaten stammen aus offiziellen CFTC Legacy Dateien. Das aktuelle Jahr wird höchstens einmal pro lokalem Kalendertag geladen und anschließend aus dem geprüften Cache verwendet.",
        }


    def write_pair_research_report(self):
        """Exportiert alle berechneten COT Paare und die zugrunde liegenden Währungsscores.

        Diese Datei ist bewusst kein neues Handelssignal. Sie ist ein Diagnose Report,
        damit nachvollziehbar bleibt, ob die Top 3 wirklich aus der gesamten Pair Rangliste
        entstehen oder ob eine einzelne Währung, zum Beispiel EUR, die Woche dominiert.
        """
        if not self.all_pairs:
            return None
        AUDIT_DIR.mkdir(exist_ok=True)
        safe_date = str(self.engine.report_date).replace("/", "-").replace(":", "-")
        pair_path = AUDIT_DIR / f"research_pair_ranking_{safe_date}.csv"
        currency_path = AUDIT_DIR / f"research_currency_scores_{safe_date}.csv"
        summary_path = AUDIT_DIR / f"research_pair_ranking_{safe_date}_summary.txt"

        pair_headers = [
            "original_rank", "final_watchlist_rank", "pair", "direction", "cot_confidence", "selection_score",
            "diversity_penalty", "diversity_note", "score", "signed_currency_gap",
            "abs_currency_gap", "strong_currency", "weak_currency", "base", "quote",
            "base_strength", "quote_strength", "momentum_gap", "commercial_gap",
            "alignment_gap", "consistency_gap", "market_quality", "matrix_relative_strength", "matrix_position", "matrix_flow", "matrix_momentum", "matrix_market_activity", "selected_top3"
        ]
        top3_pairs = {p.get("pair") for p in self.top3}
        top3_rank = {p.get("pair"): i for i, p in enumerate(self.top3, 1)}
        with pair_path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=pair_headers, extrasaction="ignore")
            writer.writeheader()
            for rank, pair_data in enumerate(self.all_pairs, 1):
                base, quote = pair_data.get("pair", "/").split("/")
                base_strength = self.strengths.get(base, {}).get("strength", "")
                quote_strength = self.strengths.get(quote, {}).get("strength", "")
                writer.writerow({
                    "original_rank": pair_data.get("original_rank", rank),
                    "final_watchlist_rank": top3_rank.get(pair_data.get("pair", ""), ""),
                    "pair": pair_data.get("pair", ""),
                    "direction": pair_data.get("direction", ""),
                    "cot_confidence": pair_data.get("confidence", ""),
                    "selection_score": pair_data.get("selection_score", pair_data.get("confidence", "")),
                    "diversity_penalty": pair_data.get("diversity_penalty", 0),
                    "diversity_note": pair_data.get("diversity_note", ""),
                    "score": pair_data.get("score", ""),
                    "signed_currency_gap": pair_data.get("diff", ""),
                    "abs_currency_gap": abs(pair_data.get("diff", 0)) if isinstance(pair_data.get("diff", 0), (int, float)) else "",
                    "strong_currency": pair_data.get("strong", ""),
                    "weak_currency": pair_data.get("weak", ""),
                    "base": base,
                    "quote": quote,
                    "base_strength": base_strength,
                    "quote_strength": quote_strength,
                    "momentum_gap": pair_data.get("momentum_gap", ""),
                    "commercial_gap": pair_data.get("commercial_gap", ""),
                    "alignment_gap": pair_data.get("alignment_gap", ""),
                    "consistency_gap": pair_data.get("consistency_gap", ""),
                    "market_quality": pair_data.get("quality", ""),
                    "matrix_relative_strength": pair_data.get("matrix_relative_strength", ""),
                    "matrix_position": pair_data.get("matrix_position", ""),
                    "matrix_flow": pair_data.get("matrix_flow", ""),
                    "matrix_momentum": pair_data.get("matrix_momentum", ""),
                    "matrix_market_activity": pair_data.get("matrix_market_activity", ""),
                    "selected_top3": "YES" if pair_data.get("pair") in top3_pairs else "NO",
                })

        currency_headers = [
            "rank", "currency", "strength",
            "commercial_position", "commercial_weekly_change",
            "large_spec_position", "large_spec_weekly_change",
            "open_interest_confirmation", "flow_trend_filter",
            "bias_score", "flow_score", "momentum_score", "participation_score",
            "large_spec_momentum", "commercial_flow",
            "alignment", "flow_consistency", "market_participation",
            "latest_date", "market"
        ]
        ranked_currencies = sorted(self.strengths.items(), key=lambda kv: kv[1].get("strength", 0), reverse=True)
        with currency_path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=currency_headers, extrasaction="ignore")
            writer.writeheader()
            for rank, (currency, data) in enumerate(ranked_currencies, 1):
                raw = data.get("raw_audit", {})
                writer.writerow({
                    "rank": rank,
                    "currency": currency,
                    "strength": data.get("strength", ""),
                    "commercial_position": data.get("commercial_position", ""),
                    "commercial_weekly_change": data.get("commercial_weekly_change", ""),
                    "large_spec_position": data.get("large_spec_position", ""),
                    "large_spec_weekly_change": data.get("large_spec_weekly_change", ""),
                    "open_interest_confirmation": data.get("open_interest_confirmation", ""),
                    "flow_trend_filter": data.get("flow_trend_filter", ""),
                    "latest_date": data.get("latest_date", ""),
                    "market": raw.get("market", ""),
                })

        top10 = self.all_pairs[:10]
        strongest = ranked_currencies[0] if ranked_currencies else ("?", {})
        weakest = ranked_currencies[-1] if ranked_currencies else ("?", {})
        long_count = sum(1 for p in self.all_pairs if p.get("direction") == "LONG")
        short_count = sum(1 for p in self.all_pairs if p.get("direction") == "SHORT")
        top_lines = [
            f"#{i} {p['pair']} {p['direction']} | COT {p['confidence']:.1f} | Auswahl {p.get('selection_score', p['confidence']):.1f} | Gap {p['diff']:.1f} | {p.get('strong')} gegen {p.get('weak')}"
            for i, p in enumerate(top10, 1)
        ]
        final_lines = [
            f"#{i} {p['pair']} {p['direction']} | COT {p['confidence']:.1f} | Auswahl {p.get('selection_score', p['confidence']):.1f} | Malus {p.get('diversity_penalty', 0):.1f} | Original Rang {p.get('original_rank', '?')}"
            for i, p in enumerate(self.top3, 1)
        ]
        summary_lines = [
            "Meridian Pair Research Report",
            f"Erstellt: {time.strftime('%Y-%m-%d %H:%M:%S')}",
            f"Report Datum: {self.engine.report_date}",
            f"Berechnete Paare: {len(self.all_pairs)}",
            f"LONG Setups: {long_count}",
            f"SHORT Setups: {short_count}",
            f"Stärkste Währung: {strongest[0]} ({strongest[1].get('strength', 0):.1f})",
            f"Schwächste Währung: {weakest[0]} ({weakest[1].get('strength', 0):.1f})",
            "",
            "Top 10 Original Pair Ranking:",
            *top_lines,
            "",
            "Finale diversitätsoptimierte Watchlist:",
            *final_lines,
            "",
            "Meridian Engine Clean Flow AKTIV. Ebene 1 bestimmt die Richtung über den aktuellen Commercial Long/Short Überhang. Ebene 2 bestätigt oder dämpft über Commercial Long/Short Change, Large Spec Long/Short Change, Flow Beschleunigung, Open Interest und Seasonality. Der COT Index ist nur Kontext. Original CFTC Rohdaten bleiben unverändert.",
        ]
        summary_path.write_text("\n".join(summary_lines), encoding="utf-8")
        return pair_path, currency_path, summary_path

    def write_audit_files(self, auto=False):
        if not self.top3:
            raise RuntimeError("Noch kein Ergebnis vorhanden")
        AUDIT_DIR.mkdir(exist_ok=True)
        safe_date = str(self.engine.report_date).replace("/", "-").replace(":", "-")
        prefix = f"cot_audit_{safe_date}"
        json_path = AUDIT_DIR / f"{prefix}.json"
        csv_path = AUDIT_DIR / f"{prefix}_raw.csv"
        summary_path = AUDIT_DIR / f"{prefix}_summary.txt"

        audit = self.build_audit()
        json_path.write_text(json.dumps(audit, indent=2), encoding="utf-8")

        headers = [
            "currency", "latest_date", "market", "open_interest", "open_interest_change",
            "large_spec_net", "large_spec_change_1w", "large_spec_change_4w",
            "commercial_net", "commercial_change_1w", "commercial_change_4w",
            "weekly_strength",
            "commercial_position", "commercial_weekly_change",
            "large_spec_position", "large_spec_weekly_change",
            "open_interest_confirmation", "flow_trend_filter",
            "bias_score", "flow_score", "momentum_score", "participation_score",
            "large_spec_momentum", "commercial_flow",
            "alignment", "flow_consistency", "market_participation"
        ]
        with csv_path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=headers, extrasaction="ignore")
            writer.writeheader()
            for curr, data in sorted(self.strengths.items()):
                raw = data.get("raw_audit", {})
                row = {
                    "currency": curr,
                    "latest_date": data.get("latest_date", ""),
                    "market": raw.get("market", ""),
                    "open_interest": raw.get("open_interest", ""),
                    "open_interest_change": raw.get("open_interest_change", ""),
                    "large_spec_net": raw.get("large_spec_net", ""),
                    "large_spec_change_1w": raw.get("large_spec_change_1w", ""),
                    "large_spec_change_4w": raw.get("large_spec_change_4w", ""),
                    "commercial_net": raw.get("commercial_net", ""),
                    "commercial_change_1w": raw.get("commercial_change_1w", ""),
                    "commercial_change_4w": raw.get("commercial_change_4w", ""),
                    "weekly_strength": data.get("weekly_strength", ""),
                    "commercial_position": data.get("commercial_position", ""),
                    "commercial_weekly_change": data.get("commercial_weekly_change", ""),
                    "large_spec_position": data.get("large_spec_position", ""),
                    "large_spec_weekly_change": data.get("large_spec_weekly_change", ""),
                    "open_interest_confirmation": data.get("open_interest_confirmation", ""),
                    "flow_trend_filter": data.get("flow_trend_filter", ""),
                }
                writer.writerow(row)

        health = audit["data_health_check"]
        top_lines = []
        for i, p in enumerate(self.top3, 1):
            top_lines.append(f"#{i} {p['pair']} {p['direction']} | Confidence {p['confidence']:.1f} | Gap {p['diff']:.1f}")
        summary = [
            "Meridian COT Research Audit",
            f"Erstellt: {audit['created_at']}",
            f"Report Datum: {self.engine.report_date}",
            f"Datenstatus: {health['status']}",
            f"Report Alter in Tagen: {health['report_age_days']}",
            f"Gelesene Tabellenzeilen: {self.engine.rows_loaded}",
            f"Verwertbare Währungen: {health['usable_currencies']}",
            "",
            "Top 3:",
            *top_lines,
            "",
            "Warnungen:",
            *(health.get('errors') or []),
            *(health['warnings'] or ["Keine blockierenden Auffälligkeiten im automatischen Datencheck."]),
            "",
            "Transparente Hinweise:",
            *(health.get('notes') or ["Keine zusätzlichen Hinweise."]),
            "",
            "Hinweis: Confidence ist keine Trefferwahrscheinlichkeit, sondern ein Research Confidence Score.",
        ]
        summary_path.write_text("\n".join(summary), encoding="utf-8")
        return json_path, csv_path, summary_path

    def save_audit(self):
        if not self.top3:
            messagebox.showwarning("Noch kein Ergebnis", "Bitte zuerst die Top 3 berechnen.")
            return
        try:
            check_paths = self.write_engine_checkup_files()
            txt_path = check_paths[2]
            self.audit_lbl.config(text=f"Checkup gespeichert: {txt_path.name}", fg=COLORS["green"])
            messagebox.showinfo("Engine Checkup gespeichert", f"Engine Checkup gespeichert:\naudit/{txt_path.name}")
        except Exception as exc:
            self.audit_lbl.config(text=f"Checkup Fehler: {exc}", fg=COLORS["red"])
            messagebox.showerror("Checkup Fehler", str(exc))

    def format_cot_number(self, value, signed=False):
        if value in (None, "", "PROXY"):
            return str(value or "")
        try:
            n = float(value)
            sign = "+" if signed and n > 0 else ""
            return f"{sign}{int(round(n)):,}".replace(",", ".")
        except Exception:
            return str(value)

    def relevant_top3_currencies(self):
        currencies = []
        for item in self.top3:
            pair = item.get("pair", "")
            if "/" in pair:
                for curr in pair.split("/"):
                    if curr and curr not in currencies:
                        currencies.append(curr)
        # Die COT Ampel soll neben den Top 3 Forex Währungen auch die vier
        # Zusatzmärkte zeigen, damit Gold, Silber, Nasdaq 100 und S&P 500
        # nicht in einer separaten Brokerliste fehlen.
        for asset in SINGLE_ASSET_MARKETS:
            if asset in getattr(self, "strengths", {}) and asset not in currencies:
                currencies.append(asset)
        return currencies

    def cot_flow_status(self, currency, data):
        strength = safe_float(data.get("strength", 50), 50)
        signed_strength = safe_float(data.get("signed_strength", (strength - 50.0) * 2.0), (strength - 50.0) * 2.0)
        raw = data.get("raw_audit", {})
        if raw.get("market") == "SYNTHETIC USD PROXY FROM CURRENT NON USD Meridian QUALITÄTS":
            if signed_strength >= 35:
                return COLORS["blue"], "Proxy stark bullish"
            if signed_strength <= -35:
                return COLORS["blue"], "Proxy stark bärisch"
            return COLORS["blue"], "Proxy neutral"

        if signed_strength >= 60:
            return COLORS["green"], "Stark bullish"
        if signed_strength >= 20:
            return COLORS["green"], "Leicht bullish"
        if signed_strength <= -60:
            return COLORS["red"], "Stark bärisch"
        if signed_strength <= -20:
            return COLORS["orange"], "Leicht bärisch"
        return COLORS["yellow"], "Neutral"

    def direction_word(self, value, positive="steigend", negative="fallend", neutral="kaum Veränderung"):
        try:
            n = float(value)
            if n > 0:
                return positive
            if n < 0:
                return negative
        except Exception:
            pass
        return neutral

    def net_word(self, value, pos="netto Long", neg="netto Short", neutral="neutral"):
        try:
            n = float(value)
            if n > 0:
                return pos
            if n < 0:
                return neg
        except Exception:
            pass
        return neutral

    def interpret_currency_cot(self, curr, data):
        raw = data.get("raw_audit", {})
        if raw.get("market") == "SYNTHETIC USD PROXY FROM CURRENT NON USD Meridian QUALITÄTS":
            return "USD Proxy. Der Dollar wird aus den übrigen Währungen abgeleitet, solange kein echter Dollar Index Datensatz erkannt wurde. Deshalb ist der Wert nur ein Vergleichsfilter."

        comm_4w = safe_float(raw.get("commercial_change_4w", raw.get("commercial_change_1w", 0)), 0)
        spec_4w = safe_float(raw.get("large_spec_change_4w", raw.get("large_spec_change_1w", 0)), 0)
        oi_4w = safe_float(raw.get("open_interest_change_4w", raw.get("open_interest_change", 0)), 0)
        signed_strength = safe_float(data.get("signed_strength", round((safe_float(data.get("strength", 50), 50)-50)*2, 1)), 0)

        def signed(n):
            try:
                return f"{int(round(n)):+,}".replace(",", ".")
            except Exception:
                return str(n)

        parts = []
        if comm_4w > 0:
            parts.append(f"Commercials verbessern ihre Netto Position über vier COT Berichte um {signed(comm_4w)}.")
        elif comm_4w < 0:
            parts.append(f"Commercials reduzieren ihre Netto Position über vier COT Berichte um {signed(comm_4w)}.")
        else:
            parts.append("Commercials sind über vier COT Berichte praktisch neutral.")

        if spec_4w > 0:
            parts.append(f"Large Specs bauen über vier COT Berichte netto auf {signed(spec_4w)}.")
        elif spec_4w < 0:
            parts.append(f"Large Specs bauen über vier COT Berichte netto ab {signed(spec_4w)}.")
        else:
            parts.append("Large Specs sind über vier COT Berichte praktisch neutral.")

        if oi_4w > 0:
            parts.append(f"Open Interest steigt über vier Berichte um {signed(oi_4w)} und bestätigt Aktivität im Markt.")
        elif oi_4w < 0:
            parts.append(f"Open Interest fällt über vier Berichte um {signed(oi_4w)} und wirkt als Erschöpfungsfilter.")
        else:
            parts.append("Open Interest verändert sich über vier Berichte kaum.")

        if signed_strength >= 70:
            verdict = "Gesamttrend: stark bullish."
        elif signed_strength >= 25:
            verdict = "Gesamttrend: leicht bullish."
        elif signed_strength <= -70:
            verdict = "Gesamttrend: stark bärisch."
        elif signed_strength <= -25:
            verdict = "Gesamttrend: leicht bärisch."
        else:
            verdict = "Gesamttrend: neutral."
        return " ".join(parts + [verdict])

    def build_pair_reason_lines(self):
        lines = []
        for p in self.top3:
            pair = p.get("pair", "")
            if "/" not in pair:
                continue
            base, quote = pair.split("/")
            direction = p.get("direction", "")
            strong = p.get("strong", "")
            weak = p.get("weak", "")
            conf = safe_float(p.get("confidence", 0), 0)
            lines.append(f"{pair} {direction}: {strong} wird gegenüber {weak} stärker bewertet. COT Qualität {conf:.1f}.")
        return lines

    def build_cot_transparency_rows(self):
        rows = []
        for curr in self.relevant_top3_currencies():
            data = self.strengths.get(curr)
            if not data:
                continue
            raw = data.get("raw_audit", {})
            color, signal = self.cot_flow_status(curr, data)
            rows.append({
                "currency": SINGLE_ASSET_MARKETS.get(curr, {}).get("label", curr),
                "symbol": curr,
                "signal": signal,
                "color": color,
                "market": raw.get("market", ""),
                "commercial_net": raw.get("commercial_net", ""),
                "commercial_change_1w": raw.get("commercial_change_1w", ""),
                "commercial_long_change": raw.get("commercial_long_change", ""),
                "commercial_short_change": raw.get("commercial_short_change", ""),
                "commercial_long_change_4w": raw.get("commercial_long_change_4w", ""),
                "commercial_short_change_4w": raw.get("commercial_short_change_4w", ""),
                "large_spec_net": raw.get("large_spec_net", ""),
                "large_spec_change_1w": raw.get("large_spec_change_1w", ""),
                "large_spec_long_change": raw.get("large_spec_long_change", ""),
                "large_spec_short_change": raw.get("large_spec_short_change", ""),
                "large_spec_long_change_4w": raw.get("large_spec_long_change_4w", ""),
                "large_spec_short_change_4w": raw.get("large_spec_short_change_4w", ""),
                "commercial_change_4w": raw.get("commercial_change_4w", ""),
                "large_spec_change_4w": raw.get("large_spec_change_4w", ""),
                "open_interest_change": raw.get("open_interest_change", ""),
                "open_interest_change_4w": raw.get("open_interest_change_4w", ""),
                "commercial_net_text": self.net_word(raw.get("commercial_net", 0), "Commercials netto Long", "Commercials netto Short"),
                "commercial_change_text": self.direction_word(raw.get("commercial_change_1w", 0), "Commercial Veränderung steigt", "Commercial Veränderung fällt"),
                "large_spec_net_text": self.net_word(raw.get("large_spec_net", 0), "Specs netto Long", "Specs netto Short"),
                "large_spec_change_text": self.direction_word(raw.get("large_spec_change_1w", 0), "Specs bauen netto auf", "Specs bauen netto ab"),
                "open_interest_text": self.direction_word(raw.get("open_interest_change_4w", raw.get("open_interest_change", 0)), "Marktaktivität 4W steigt", "Marktaktivität 4W fällt"),
                "interpretation": self.interpret_currency_cot(curr, data),
                "strength": data.get("strength", ""),
                "signed_strength": data.get("signed_strength", round((safe_float(data.get("strength", 50), 50)-50)*2, 1)),
                "latest_date": data.get("latest_date", ""),
                "is_proxy": bool(data.get("is_proxy")),
            })
        return rows

    def build_cftc_source_verification_rows(self):
        rows = []
        required = ["EUR", "GBP", "CHF", "JPY", "CAD", "AUD", "NZD", "USD", "XAU", "XAG", "NAS100", "SP500"]
        for curr in required:
            data = self.strengths.get(curr)
            if not data:
                rows.append({
                    "status": "FEHLT",
                    "currency": SINGLE_ASSET_MARKETS.get(curr, {}).get("label", curr),
                    "note": "Kein aktueller Markt in der Meridian Engine gefunden."
                })
                continue
            raw = data.get("raw_audit", {})
            rows.append({
                "status": "OK" if data.get("latest_date") == self.engine.report_date else "DATUM PRUEFEN",
                "currency": SINGLE_ASSET_MARKETS.get(curr, {}).get("label", curr),
                "symbol": curr,
                "report_date": data.get("latest_date", ""),
                "engine_report_date": self.engine.report_date,
                "market": raw.get("market", ""),
                "source_file": raw.get("source_file", ""),
                "source_url": raw.get("source_url", ""),
                "source_sha256": raw.get("source_sha256", ""),
                "source_row": raw.get("source_row", ""),
                "cftc_contract_market_code": raw.get("cftc_contract_market_code", ""),
                "cftc_market_code": raw.get("cftc_market_code", ""),
                "cftc_commodity_code": raw.get("cftc_commodity_code", ""),
                "commercial_long": raw.get("commercial_long", ""),
                "commercial_short": raw.get("commercial_short", ""),
                "commercial_net_formula": "commercial_long - commercial_short",
                "commercial_net": raw.get("commercial_net", ""),
                "commercial_long_change": raw.get("commercial_long_change", ""),
                "commercial_short_change": raw.get("commercial_short_change", ""),
                "commercial_change_formula": "commercial_long_change - commercial_short_change",
                "commercial_change_1w": raw.get("commercial_change_1w", ""),
                "large_spec_long": raw.get("large_spec_long", ""),
                "large_spec_short": raw.get("large_spec_short", ""),
                "large_spec_net_formula": "large_spec_long - large_spec_short",
                "large_spec_net": raw.get("large_spec_net", ""),
                "large_spec_long_change": raw.get("large_spec_long_change", ""),
                "large_spec_short_change": raw.get("large_spec_short_change", ""),
                "large_spec_change_formula": "large_spec_long_change - large_spec_short_change",
                "large_spec_change_1w": raw.get("large_spec_change_1w", ""),
                "open_interest": raw.get("open_interest", ""),
                "open_interest_change": raw.get("open_interest_change", ""),
                "note": "Diese Werte stammen aus den offiziellen CFTC Legacy Feldern des angegebenen deacot Source Files."
            })
        return rows

    def write_cftc_source_verification_file(self):
        if not self.strengths:
            return None
        AUDIT_DIR.mkdir(exist_ok=True)
        safe_date = str(self.engine.report_date).replace("/", "-").replace(":", "-")
        path = AUDIT_DIR / f"cftc_source_verification_{safe_date}.csv"
        headers = [
            "status", "symbol", "currency", "report_date", "engine_report_date", "market", "source_file", "source_url",
            "source_sha256", "source_row", "cftc_contract_market_code", "cftc_market_code", "cftc_commodity_code",
            "commercial_long", "commercial_short", "commercial_net_formula", "commercial_net",
            "commercial_long_change", "commercial_short_change", "commercial_change_formula", "commercial_change_1w",
            "large_spec_long", "large_spec_short", "large_spec_net_formula", "large_spec_net",
            "large_spec_long_change", "large_spec_short_change", "large_spec_change_formula", "large_spec_change_1w",
            "open_interest", "open_interest_change", "note"
        ]
        rows = self.build_cftc_source_verification_rows()
        with path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=headers, extrasaction="ignore")
            writer.writeheader()
            for row in rows:
                writer.writerow({h: row.get(h, "") for h in headers})
        return path

    def write_cot_transparency_table(self):
        if not self.top3:
            return None
        AUDIT_DIR.mkdir(exist_ok=True)
        safe_date = str(self.engine.report_date).replace("/", "-").replace(":", "-")
        path = AUDIT_DIR / f"cot_transparency_table_{safe_date}.csv"
        headers = [
            "symbol", "currency", "signal", "latest_date", "market", "commercial_net", "commercial_net_text",
            "commercial_change_1w", "commercial_long_change", "commercial_short_change", "commercial_change_4w", "commercial_long_change_4w", "commercial_short_change_4w", "commercial_change_text", "large_spec_net", "large_spec_net_text",
            "large_spec_change_1w", "large_spec_long_change", "large_spec_short_change", "large_spec_change_4w", "large_spec_long_change_4w", "large_spec_short_change_4w", "large_spec_change_text", "open_interest_change", "open_interest_change_4w", "open_interest_text",
            "strength", "signed_strength", "interpretation", "is_proxy"
        ]
        rows = self.build_cot_transparency_rows()
        with path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=headers, extrasaction="ignore")
            writer.writeheader()
            for row in rows:
                clean = {h: row.get(h, "") for h in headers}
                writer.writerow(clean)
        return path



    def market_pulse_candidates(self):
        # Market Pulse beobachtet bewusst nur die aktuellen Top 3 aus der Wochenwatchlist
        # plus die vier internen Basiswerte Gold, Silber, NAS100 und SP500.
        # Die Engine, Rankings und Watchlist bleiben unverändert.
        source = list(getattr(self, "final_watchlist", []) or getattr(self, "top3", []) or [])[:3]
        singles = list(self.get_single_asset_results())
        allowed_single_pairs = {cfg.get("pair") for cfg in SINGLE_ASSET_MARKETS.values()}
        singles = [item for item in singles if item.get("pair") in allowed_single_pairs]
        by_pair = {}
        for item in source + singles:
            pair = item.get("pair")
            if pair and pair not in by_pair:
                by_pair[pair] = dict(item)
        return list(by_pair.values())

    def show_market_pulse(self):
        candidates = self.market_pulse_candidates()
        if not candidates:
            messagebox.showinfo("Meridian Market Pulse", "Bitte zuerst die COT Analyse starten.")
            return
        win = tk.Toplevel(self)
        win.title("Meridian Market Pulse")
        win.geometry("1260x820")
        win.minsize(1120, 720)
        win.configure(bg=COLORS["bg"])
        win.market_pulse_data = None
        win.market_pulse_cards = []
        win.market_pulse_table = None
        win.market_pulse_summary = None
        win.market_pulse_status = None
        win.market_pulse_button = None
        win.market_pulse_story = None
        win.market_pulse_progress = None
        win.market_pulse_countdown_job = None
        win.market_pulse_queue = queue.Queue()
        win.market_pulse_candidates = candidates

        shell = tk.Frame(win, bg=COLORS["bg"])
        shell.pack(fill="both", expand=True)
        canvas = tk.Canvas(shell, bg=COLORS["bg"], highlightthickness=0)
        scrollbar = tk.Scrollbar(shell, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        outer = tk.Frame(canvas, bg=COLORS["bg"])
        canvas_window = canvas.create_window((0, 0), window=outer, anchor="nw")

        def _sync_scroll(_event=None):
            canvas.configure(scrollregion=canvas.bbox("all"))
        def _sync_width(event):
            canvas.itemconfigure(canvas_window, width=event.width)
        outer.bind("<Configure>", _sync_scroll)
        canvas.bind("<Configure>", _sync_width)
        def _wheel(event):
            delta = -1 * int(event.delta / 120) if event.delta else 0
            canvas.yview_scroll(delta, "units")
        canvas.bind_all("<MouseWheel>", _wheel)

        content = tk.Frame(outer, bg=COLORS["bg"])
        content.pack(fill="both", expand=True, padx=12, pady=10)

        header = self.card(content, COLORS["header"])
        header.pack(fill="x", pady=(0, 10))
        pulse_title = tk.Frame(header, bg=COLORS["header"])
        pulse_title.pack(fill="x", padx=16, pady=(12, 0))
        tk.Label(pulse_title, text="Meridian Market Pulse", font=("Segoe UI", 24, "bold"), fg=COLORS["text"], bg=COLORS["header"]).pack(side="left")
        self.help_button(pulse_title, "market_pulse", COLORS["header"], compact=False).pack(side="left", padx=(8, 0))
        tk.Label(header, text="Schnellblick: Läuft der Markt aktuell in Richtung der COT Setups?", font=("Segoe UI", 11, "bold"), fg=COLORS["muted"], bg=COLORS["header"]).pack(anchor="w", padx=16, pady=(2, 4))
        win.market_pulse_story = tk.Label(header, text="Nach dem Preisabruf entsteht hier eine kurze Marktstory für die Top Setups.", font=("Segoe UI", 12, "bold"), fg=COLORS["blue"], bg=COLORS["header"], wraplength=1100, justify="left")
        win.market_pulse_story.pack(anchor="w", padx=16, pady=(0, 12))

        card_row = tk.Frame(content, bg=COLORS["bg"])
        card_row.pack(fill="x", pady=(0, 10))
        top_source = list(getattr(self, "final_watchlist", []) or getattr(self, "top3", []) or [])[:3]
        for i in range(3):
            card = self.card(card_row, COLORS["card2"])
            card.pack(side="left", fill="both", expand=True, padx=(0 if i == 0 else 8, 0))
            win.market_pulse_cards.append(card)

        toolbar = self.card(content, COLORS["card"])
        toolbar.pack(fill="x", pady=(0, 10))
        win.market_pulse_button = self.button(toolbar, "↻  Realtime Preise abrufen", lambda: self.start_market_pulse_fetch(win), COLORS["green"], COLORS["dark"])
        win.market_pulse_button.config(activebackground=COLORS["green"], activeforeground=COLORS["dark"], disabledforeground=COLORS["dark"])
        win.market_pulse_button.pack(side="left", padx=14, pady=10, ipadx=24, ipady=10)
        status_box = tk.Frame(toolbar, bg=COLORS["card"])
        status_box.pack(side="left", fill="x", expand=True, padx=10, pady=8)
        win.market_pulse_status = tk.Label(status_box, text="Noch nicht aktualisiert", font=("Segoe UI", 10, "bold"), fg=COLORS["muted"], bg=COLORS["card"], justify="left", anchor="w")
        win.market_pulse_status.pack(anchor="w", fill="x")
        win.market_pulse_progress = tk.Canvas(status_box, height=6, bg=COLORS["dark"], highlightthickness=0)
        win.market_pulse_progress.pack(anchor="w", fill="x", pady=(6, 0))
        self.market_pulse_set_progress(win, 0, COLORS["line"])

        summary_card = self.card(content, COLORS["card"])
        summary_card.pack(fill="x", pady=(0, 10))
        pulse_dash_title = tk.Frame(summary_card, bg=COLORS["card"])
        pulse_dash_title.pack(fill="x", padx=14, pady=(12, 4))
        tk.Label(pulse_dash_title, text="Pulse Dashboard", font=("Segoe UI", 16, "bold"), fg=COLORS["text"], bg=COLORS["card"]).pack(side="left")
        self.help_button(pulse_dash_title, "pulse_dashboard", COLORS["card"]).pack(side="left", padx=(7, 0))
        win.market_pulse_summary = tk.Frame(summary_card, bg=COLORS["card"])
        win.market_pulse_summary.pack(fill="x", padx=14, pady=(0, 12))

        details_card = self.card(content, COLORS["card"])
        details_card.pack(fill="both", expand=True, pady=(0, 12))
        pulse_watch_title = tk.Frame(details_card, bg=COLORS["card"])
        pulse_watch_title.pack(fill="x", padx=14, pady=(12, 0))
        tk.Label(pulse_watch_title, text="Beobachtungsliste", font=("Segoe UI", 15, "bold"), fg=COLORS["text"], bg=COLORS["card"]).pack(side="left")
        self.help_button(pulse_watch_title, "watchlist", COLORS["card"]).pack(side="left", padx=(7, 0))
        tk.Label(details_card, text="Nur Top 3 plus interne Basiswerte. Ein Pullback ist eine kurzfristige Marktbewegung, kein Engine Urteil.", font=("Segoe UI", 9, "bold"), fg=COLORS["muted"], bg=COLORS["card"]).pack(anchor="w", padx=14, pady=(2, 8))
        win.market_pulse_table = tk.Frame(details_card, bg=COLORS["card"])
        win.market_pulse_table.pack(fill="both", expand=True, padx=14, pady=(0, 12))

        self.render_market_pulse_cards(win, top_source, {})
        self.render_market_pulse_dashboard(win, [])
        self.render_market_pulse_table(win, [])
        self.load_market_pulse_cache_into_window(win)


    def market_pulse_parse_dt(self, value):
        try:
            if not value:
                return None
            return datetime.fromisoformat(str(value).replace("Z", ""))
        except Exception:
            return None

    def market_pulse_payload_from_cache(self, candidates):
        provider = MarketPulsePriceProvider()
        cache = provider.load_cache()
        markets = cache.get("markets", {})
        data = {}
        for item in candidates:
            pair = item.get("pair")
            cached = markets.get(pair)
            if cached and cached.get("series"):
                data[pair] = {
                    "series": cached.get("series", []),
                    "source": cached.get("source", "Cache"),
                    "cache": True,
                    "updated_at": cached.get("updated_at", cache.get("created", "")),
                    "current_price": cached.get("current_price"),
                    "previous_close": cached.get("previous_close"),
                    "previous_close_date": cached.get("previous_close_date", ""),
                    "today_change_percent": cached.get("today_change_percent"),
                    "today_change_source": cached.get("today_change_source", ""),
                    "reference_price": cached.get("reference_price"),
                    "reference_date": cached.get("reference_date", ""),
                    "week_reference_price": cached.get("week_reference_price"),
                    "week_reference_date": cached.get("week_reference_date", ""),
                    "provider_symbol": cached.get("provider_symbol", ""),
                    "daily_reference_source": cached.get("daily_reference_source", ""),
                    "cot_reference_source": cached.get("cot_reference_source", ""),
                    "provider_debug": cached.get("provider_debug", {}),
                }
        return {"results": data, "used_cache_only": True, "complete_success": False, "updated_at": cache.get("created", "")}

    def market_pulse_last_data_time(self, payload_or_none=None):
        times = []
        payload = payload_or_none or {}
        for item in (payload.get("results") or {}).values():
            dt = self.market_pulse_parse_dt(item.get("updated_at"))
            if dt:
                times.append(dt)
        dt = self.market_pulse_parse_dt(payload.get("updated_at"))
        if dt:
            times.append(dt)
        return max(times) if times else None

    def market_pulse_next_live_time(self, last_dt):
        if not last_dt:
            return None
        return last_dt + timedelta(hours=12)

    def market_pulse_live_locked(self, candidates):
        payload = self.market_pulse_payload_from_cache(candidates)
        last_dt = self.market_pulse_last_data_time(payload)
        next_dt = self.market_pulse_next_live_time(last_dt)
        requested = {item.get("pair") for item in candidates if item.get("pair")}
        available = set((payload.get("results") or {}).keys())
        complete_cache = bool(requested) and requested.issubset(available)
        if complete_cache:
            for pair in requested:
                cached = (payload.get("results") or {}).get(pair, {})
                if len(cached.get("series") or []) < 2 or cached.get("current_price") is None or cached.get("previous_close") is None:
                    complete_cache = False
                    break
                # Alte Metall Caches mit dem unzuverlässigeren Kassasymbol
                # dürfen keinen neuen, sauberen Abruf blockieren.
                if pair == "XAU/USD" and cached.get("provider_symbol") not in ("GC=F", "xauusd", "gc.f"):
                    complete_cache = False
                    break
                if pair == "XAG/USD" and cached.get("provider_symbol") not in ("SI=F", "xagusd", "si.f"):
                    complete_cache = False
                    break
        return bool(last_dt and next_dt and datetime.now() < next_dt and complete_cache), payload, last_dt, next_dt

    def market_pulse_required_pairs(self):
        """Ermittelt die vereinigten Kandidaten aller drei COT Engines plus Zusatzmärkte."""
        pairs = []

        def add_pair(value):
            pair = str(value or "").strip().upper()
            if pair in MARKET_PULSE_ALL_PAIRS and pair not in pairs:
                pairs.append(pair)

        for row in list(getattr(self, "top3", []) or []):
            add_pair(row.get("pair"))

        for rows in (getattr(self, "entry_engine_engine_rows", {}) or {}).values():
            for row in list(rows or [])[:3]:
                add_pair(row.get("pair"))

        if getattr(self.engine, "report_date", None):
            for engine_key in (ENGINE_CLASSIC, ENGINE_FLOW, ENGINE_HYBRID):
                try:
                    clone = copy.copy(self.engine)
                    clone.progress = lambda pct, text: None
                    clone.set_analysis_engine(engine_key)
                    strengths = clone.compute_current_strengths()
                    engine_top3, _ = clone.compute_pairs(strengths)
                    for row in list(engine_top3 or [])[:3]:
                        add_pair(row.get("pair"))
                except Exception:
                    continue

        for pair in ("XAU/USD", "XAG/USD", "NAS100/USD", "SP500/USD"):
            add_pair(pair)

        return pairs

    def market_pulse_format_data_age(self, last_dt):
        if not last_dt:
            return "Datenstand: kein Cache vorhanden"
        return f"Datenstand: {last_dt.strftime('%d.%m.%Y, %H:%M Uhr')}"

    def market_pulse_format_countdown(self, next_dt):
        if not next_dt:
            return "Live Abruf ist möglich."
        remaining = next_dt - datetime.now()
        if remaining.total_seconds() <= 0:
            return "Live Abruf ist wieder möglich."
        hours = int(remaining.total_seconds() // 3600)
        minutes = int((remaining.total_seconds() % 3600) // 60)
        if hours > 0:
            return f"Live Abruf wieder möglich in {hours} Std. {minutes:02d} Min."
        return f"Live Abruf wieder möglich in {minutes} Min."

    def market_pulse_set_progress(self, win, percent, color=None):
        canvas = getattr(win, "market_pulse_progress", None)
        if not canvas or not canvas.winfo_exists():
            return
        try:
            canvas.delete("all")
            width = max(1, canvas.winfo_width())
            if width <= 1:
                width = 420
            height = max(4, canvas.winfo_height())
            canvas.create_rectangle(0, 0, width, height, fill=COLORS["dark"], outline="")
            fill_w = int(width * max(0, min(100, percent)) / 100)
            if fill_w > 0:
                canvas.create_rectangle(0, 0, fill_w, height, fill=color or COLORS["green"], outline="")
        except Exception:
            pass

    def market_pulse_update_cache_status(self, win, payload=None, prefix=None, color=None):
        if not win.winfo_exists():
            return
        payload = payload or getattr(win, "market_pulse_data", None) or self.market_pulse_payload_from_cache(win.market_pulse_candidates)
        last_dt = self.market_pulse_last_data_time(payload)
        next_dt = self.market_pulse_next_live_time(last_dt)
        line1 = prefix or ("Cache Daten angezeigt." if payload.get("used_cache_only") else "Market Pulse aktualisiert.")
        line2 = self.market_pulse_format_data_age(last_dt)
        line3 = self.market_pulse_format_countdown(next_dt)
        win.market_pulse_status.config(text=f"{line1}\n{line2}\n{line3}", fg=color or COLORS["yellow"])
        locked = bool(last_dt and next_dt and datetime.now() < next_dt)
        btn_text = "Cache Daten anzeigen" if locked else "↻  Realtime Preise abrufen"
        win.market_pulse_button.config(state="normal", text=btn_text, bg=COLORS["green"], fg=COLORS["dark"], activebackground=COLORS["green"], activeforeground=COLORS["dark"])
        self.market_pulse_set_progress(win, 100 if locked else 0, COLORS["green"] if locked else COLORS["line"])
        old_job = getattr(win, "market_pulse_countdown_job", None)
        if old_job:
            try:
                self.after_cancel(old_job)
            except Exception:
                pass
        if locked:
            win.market_pulse_countdown_job = self.after(60000, lambda: self.market_pulse_update_cache_status(win, payload, prefix=line1, color=color or COLORS["yellow"]))

    def load_market_pulse_cache_into_window(self, win):
        payload = self.market_pulse_payload_from_cache(win.market_pulse_candidates)
        if payload.get("results"):
            win.market_pulse_data = payload
            self.render_market_pulse_payload(win, payload)
            self.market_pulse_update_cache_status(win, payload, prefix="Cache Daten angezeigt. Live Check erst nach Ablauf des Counters.", color=COLORS["yellow"])

    def start_market_pulse_fetch(self, win):
        candidates = win.market_pulse_candidates
        pairs = self.market_pulse_required_pairs()
        if not pairs:
            messagebox.showinfo("Meridian Market Pulse", "Keine Märkte für den Market Pulse vorhanden.")
            return
        required_candidates = [{"pair": pair} for pair in pairs]
        locked, cache_payload, last_dt, next_dt = self.market_pulse_live_locked(required_candidates)
        if locked:
            win.market_pulse_data = cache_payload
            self.render_market_pulse_payload(win, cache_payload)
            self.market_pulse_update_cache_status(win, cache_payload, prefix="Cache Daten geladen. Live Preise sind noch gesperrt.", color=COLORS["yellow"])
            return
        win.market_pulse_button.config(state="disabled", text="Marktdaten werden aktualisiert", bg=COLORS["yellow"], fg=COLORS["dark"], activebackground=COLORS["yellow"], activeforeground=COLORS["dark"])
        win.market_pulse_status.config(text="Marktdaten werden aktualisiert...\nProvider Fallback System aktiv.\nBitte kurz warten.", fg=COLORS["yellow"])
        self.market_pulse_set_progress(win, 18, COLORS["yellow"])
        start_date = getattr(self.engine, "report_date", None) or (datetime.now() - timedelta(days=21)).strftime("%Y-%m-%d")

        def worker():
            try:
                provider = MarketPulsePriceProvider()
                payload = provider.fetch_many(pairs, start_date)
                win.market_pulse_queue.put(("done", payload))
            except Exception as exc:
                win.market_pulse_queue.put(("error", str(exc)))

        threading.Thread(target=worker, daemon=True).start()
        self.after(150, lambda: self.poll_market_pulse_fetch(win, 25))

    def poll_market_pulse_fetch(self, win, progress=25):
        if not win.winfo_exists():
            return
        try:
            kind, payload = win.market_pulse_queue.get_nowait()
        except queue.Empty:
            progress = min(92, progress + 7)
            self.market_pulse_set_progress(win, progress, COLORS["yellow"])
            self.after(180, lambda: self.poll_market_pulse_fetch(win, progress))
            return
        if kind == "error":
            win.market_pulse_button.config(state="normal", text="↻  Realtime Preise abrufen", bg=COLORS["green"], fg=COLORS["dark"], activebackground=COLORS["green"], activeforeground=COLORS["dark"])
            self.market_pulse_set_progress(win, 0, COLORS["red"])
            win.market_pulse_status.config(text=f"Kursabruf fehlgeschlagen: {payload}", fg=COLORS["red"])
            return
        win.market_pulse_data = payload
        self.render_market_pulse_payload(win, payload)
        if payload.get("complete_success"):
            self.market_pulse_set_progress(win, 100, COLORS["green"])
            self.market_pulse_update_cache_status(win, payload, prefix="Market Pulse erfolgreich aktualisiert.", color=COLORS["green"])
        elif payload.get("results"):
            self.market_pulse_set_progress(win, 100, COLORS["yellow"])
            self.market_pulse_update_cache_status(win, payload, prefix="Cache oder Teilabruf angezeigt.", color=COLORS["yellow"])
        else:
            win.market_pulse_button.config(state="normal", text="↻  Realtime Preise abrufen", bg=COLORS["green"], fg=COLORS["dark"], activebackground=COLORS["green"], activeforeground=COLORS["dark"])
            self.market_pulse_set_progress(win, 0, COLORS["red"])
            win.market_pulse_status.config(text="Keine Kursdaten geladen. Bitte später erneut versuchen.", fg=COLORS["red"])

    def render_market_pulse_payload(self, win, payload):
        self._begin_result_motion("market_pulse")
        candidates = win.market_pulse_candidates
        by_pair = payload.get("results", {})
        top_source = list(getattr(self, "final_watchlist", []) or getattr(self, "top3", []) or [])[:3]
        rows = []
        for item in candidates:
            pair = item.get("pair")
            price_info = by_pair.get(pair, {})
            metrics = self.market_pulse_metrics(item, price_info)
            metrics["source"] = price_info.get("source", "")
            metrics["cache"] = bool(price_info.get("cache"))
            metrics["item"] = item
            metrics["is_top_setup"] = pair in {x.get("pair") for x in top_source}
            rows.append(metrics)
        rows.sort(key=lambda x: (0 if x.get("is_top_setup") else 1, -x.get("cot", -999)))
        self.render_market_pulse_cards(win, top_source, by_pair)
        self.render_market_pulse_dashboard(win, rows)
        self.render_market_pulse_table(win, rows)

    def market_pulse_metrics(self, item, price_info):
        direction = item.get("direction", "")
        pair = item.get("pair", "")
        price_info = price_info or {}
        series = price_info.get("series", []) if isinstance(price_info, dict) else (price_info or [])
        if not series or len(series) < 2:
            status, color = "Noch keine Daten", COLORS["muted"]
            return {
                "pair": pair, "display_pair": market_pulse_display_name(pair), "direction": direction,
                "today": 0.0, "week": 0.0, "cot": 0.0,
                "today_raw": 0.0, "week_raw": 0.0, "cot_raw": 0.0,
                "market_today": 0.0, "signal_today": 0.0,
                "market_since_cot": 0.0, "signal_since_cot": 0.0,
                "week_signal": -999, "status": status, "color": color,
                "plain_hint": "Keine Cache Daten verfügbar oder Preis beim letzten Abruf nicht geladen.", "series": [],
                "pulse_score": 0, "has_data": False
            }
        closes = [float(x.get("close")) for x in series if x.get("close")]
        current = price_info.get("current_price")
        previous_close = price_info.get("previous_close")
        reference_price = price_info.get("reference_price")
        week_reference_price = price_info.get("week_reference_price")
        try:
            current = float(current) if current is not None else closes[-1]
        except Exception:
            current = closes[-1]
        try:
            previous_close = float(previous_close) if previous_close is not None else closes[-2]
        except Exception:
            previous_close = closes[-2]
        try:
            reference_price = float(reference_price) if reference_price is not None else closes[0]
        except Exception:
            reference_price = closes[0]
        try:
            week_reference_price = float(week_reference_price) if week_reference_price is not None else closes[max(0, len(closes) - 6)]
        except Exception:
            week_reference_price = closes[max(0, len(closes) - 6)]
        provider_today = price_info.get("today_change_percent")
        try:
            today_raw = float(provider_today) if provider_today is not None else market_pulse_percent(current, previous_close)
        except Exception:
            today_raw = market_pulse_percent(current, previous_close)
        week_raw = market_pulse_percent(current, week_reference_price)
        cot_raw = market_pulse_percent(current, reference_price)
        today = market_pulse_signal_return(today_raw, direction)
        week = market_pulse_signal_return(week_raw, direction)
        cot = market_pulse_signal_return(cot_raw, direction)
        status, color = market_pulse_status(cot)
        plain_hint = self.market_pulse_plain_hint(direction, cot_raw, cot)
        pulse_score = max(0, min(100, int(round(50 + cot * 12))))
        return {
            "pair": pair, "display_pair": market_pulse_display_name(pair), "direction": direction,
            "today": today, "week": week, "cot": cot,
            "today_raw": today_raw, "week_raw": week_raw, "cot_raw": cot_raw,
            "market_today": today_raw, "signal_today": today,
            "market_since_cot": cot_raw, "signal_since_cot": cot,
            "week_signal": week, "status": status, "color": color,
            "plain_hint": plain_hint, "series": series, "pulse_score": pulse_score, "has_data": True,
            "current_price": current, "previous_close": previous_close, "reference_price": reference_price,
            "week_reference_price": week_reference_price,
            "previous_close_date": price_info.get("previous_close_date", ""),
            "reference_date": price_info.get("reference_date", ""),
            "week_reference_date": price_info.get("week_reference_date", ""),
            "provider_symbol": price_info.get("provider_symbol", ""),
            "daily_reference_source": price_info.get("daily_reference_source", ""),
            "today_change_source": price_info.get("today_change_source", ""),
            "cot_reference_source": price_info.get("cot_reference_source", ""),
        }

    def market_pulse_plain_hint(self, direction, raw_move, signal_move):
        if abs(signal_move) < 0.35:
            return "Noch abwartend. Erst bei klarer Bewegung wird das Setup bestätigt."
        if direction == "SHORT":
            if raw_move < 0:
                return "Markt fällt. Das Short Setup profitiert."
            return "Pullback nach oben. Das Short Setup bleibt auf Beobachtung."
        if direction == "LONG":
            if raw_move > 0:
                return "Markt steigt. Das Long Setup profitiert."
            return "Pullback nach unten. Das Long Setup bleibt auf Beobachtung."
        return "Signalrichtung nicht eindeutig."


    def render_market_pulse_cards(self, win, top_source, by_pair):
        for i, card in enumerate(win.market_pulse_cards):
            self.clear(card)
            if i >= len(top_source):
                tk.Label(card, text="KEIN SETUP", font=("Segoe UI", 20, "bold"), fg=COLORS["muted"], bg=COLORS["card2"]).pack(anchor="w", padx=16, pady=24)
                continue
            item = top_source[i]
            pair = item.get("pair", "")
            direction = item.get("direction", "")
            metrics = self.market_pulse_metrics(item, by_pair.get(pair, {}))
            card_motion_delay = self._next_result_motion_delay("market_pulse")

            top = tk.Frame(card, bg=COLORS["card2"])
            top.pack(fill="x", padx=16, pady=(14, 0))
            left = tk.Frame(top, bg=COLORS["card2"])
            left.pack(side="left", fill="both", expand=True)
            tk.Label(left, text=market_pulse_display_name(pair), font=("Segoe UI", 23, "bold"), fg=COLORS["text"], bg=COLORS["card2"]).pack(anchor="w")
            dcol = COLORS["green"] if direction == "LONG" else COLORS["red"]
            tk.Label(left, text=f"COT Signal: {direction}", font=("Segoe UI", 12, "bold"), fg=dcol, bg=COLORS["card2"]).pack(anchor="w", pady=(0, 4))
            self.draw_market_pulse_sparkline(top, metrics.get("series", []), metrics.get("color", COLORS["muted"]), metrics.get("cot", 0.0))

            main = tk.Frame(card, bg=COLORS["card2"])
            main.pack(fill="x", padx=16, pady=(2, 8))
            tk.Label(main, text="SIGNAL PERFORMANCE SEIT COT", font=("Segoe UI", 8, "bold"), fg=COLORS["muted"], bg=COLORS["card2"]).pack(anchor="w")
            main_col = COLORS["green"] if metrics["cot"] > 0 else COLORS["orange"] if metrics["cot"] < 0 else COLORS["muted"]
            main_value = f"{metrics['cot']:+.2f} %" if metrics.get("has_data") else "Keine Cache Daten verfügbar"
            main_value_label = tk.Label(main, text=main_value, font=("Segoe UI", 27 if metrics.get("has_data") else 15, "bold"), fg=main_col, bg=COLORS["card2"])
            main_value_label.pack(anchor="w")
            if metrics.get("has_data"):
                self._animate_number_label(
                    main_value_label,
                    metrics.get("cot", 0.0),
                    lambda value: f"{value:+.2f} %",
                    delay=card_motion_delay,
                )
            tk.Label(main, text=metrics.get("plain_hint", ""), font=("Segoe UI", 9, "bold"), fg=metrics.get("color", COLORS["muted"]), bg=COLORS["card2"], wraplength=350, justify="left").pack(anchor="w", pady=(0, 6))

            bar_wrap = tk.Frame(card, bg=COLORS["card2"])
            bar_wrap.pack(fill="x", padx=16, pady=(0, 8))
            pulse_value = safe_float(metrics.get("pulse_score", 0), 0)
            pulse_label = tk.Label(bar_wrap, text=f"Setup Pulse  {pulse_value:.0f} %", font=("Segoe UI", 8, "bold"), fg=COLORS["muted"], bg=COLORS["card2"])
            pulse_label.pack(anchor="w")
            if metrics.get("has_data"):
                self._animate_number_label(
                    pulse_label,
                    pulse_value,
                    lambda value: f"Setup Pulse  {value:.0f} %",
                    delay=card_motion_delay,
                )
            self.market_pulse_bar(
                bar_wrap,
                pulse_value,
                metrics.get("color", COLORS["muted"]),
                width=210,
                height=10,
                motion_delay=card_motion_delay,
            ).pack(anchor="w", pady=(3, 0))

            grid = tk.Frame(card, bg=COLORS["card2"])
            grid.pack(fill="x", padx=16, pady=(0, 10))
            vals = (
                ("Markt heute", metrics["market_today"]),
                ("Signal heute", metrics["signal_today"]),
                ("Markt seit COT", metrics["market_since_cot"]),
                ("Signal seit COT", metrics["signal_since_cot"]),
            )
            for c, (label, value) in enumerate(vals):
                box = tk.Frame(grid, bg=COLORS["card2"])
                box.grid(row=0, column=c, sticky="w", padx=(0, 18))
                tk.Label(box, text=label, font=("Segoe UI", 8, "bold"), fg=COLORS["muted"], bg=COLORS["card2"]).pack(anchor="w")
                col = COLORS["green"] if value > 0 else COLORS["orange"] if value < 0 else COLORS["muted"]
                if label in ("Markt heute", "Markt seit COT"):
                    col = COLORS["green"] if value > 0 else COLORS["red"] if value < 0 else COLORS["muted"]
                value_text = f"{value:+.2f} %" if metrics.get("has_data") else "Nicht geladen"
                tk.Label(box, text=value_text, font=("Segoe UI", 12, "bold"), fg=col, bg=COLORS["card2"]).pack(anchor="w")

            status_line = tk.Frame(card, bg=COLORS["card2"])
            status_line.pack(anchor="w", padx=16, pady=(0, 12))
            self.status_dot(status_line, metrics.get("color", COLORS["muted"]), 13).pack(side="left", padx=(0, 7))
            extra = "Cache Daten" if by_pair.get(pair, {}).get("cache") else "Live Daten" if by_pair.get(pair, {}) else ""
            txt = metrics["status"] if not extra else f"{metrics['status']}  |  {extra}"
            tk.Label(status_line, text=txt, font=("Segoe UI", 9, "bold"), fg=metrics.get("color", COLORS["muted"]), bg=COLORS["card2"]).pack(side="left")


    def draw_market_pulse_sparkline(self, parent, series, color, signal_return=0.0):
        canvas = tk.Canvas(parent, width=180, height=96, bg=COLORS["card2"], highlightthickness=0)
        canvas.pack(side="right", padx=(8, 0), pady=(0, 0))
        values = [float(x.get("close")) for x in (series or []) if x.get("close")]
        if len(values) < 2:
            canvas.create_rectangle(18, 72, 162, 73, fill=COLORS["line"], outline="")
            canvas.create_oval(155, 65, 169, 79, fill=COLORS["muted"], outline=COLORS["card2"], width=2)
            return canvas
        values = values[-32:]
        mn, mx = min(values), max(values)
        if mx == mn:
            mx = mn + 0.0001
        pts = []
        for idx, val in enumerate(values):
            x = 16 + idx * (148 / max(1, len(values) - 1))
            y = 74 - ((val - mn) / (mx - mn)) * 56
            pts.append((x, y))
        flat = [n for p in pts for n in p]
        shade = color if abs(signal_return) >= 0.35 else COLORS["line"]
        # dezente Premium Fläche, ohne neue Farben und ohne Heatmap
        for step in range(7):
            ybase = 82 - step * 2
            poly = [(pts[0][0], ybase)] + [(x, min(y + 8 + step, ybase)) for x, y in pts] + [(pts[-1][0], ybase)]
            canvas.create_polygon([n for p in poly for n in p], fill=COLORS["dark"] if step % 2 == 0 else COLORS["card"], outline="")
        # Glow durch mehrere Linienlagen
        for off, width, fill in ((4, 7, COLORS["dark"]), (2, 5, COLORS["line"]), (0, 3, shade)):
            shifted = []
            for x, y in pts:
                shifted.extend([x, y + off])
            canvas.create_line(*shifted, fill=fill, width=width, smooth=True, capstyle="round", joinstyle="round")
        canvas.create_line(*flat, fill=shade, width=2, smooth=True, capstyle="round", joinstyle="round")
        ex, ey = pts[-1]
        canvas.create_oval(ex - 8, ey - 8, ex + 8, ey + 8, fill=COLORS["card2"], outline=shade, width=2)
        canvas.create_oval(ex - 4, ey - 4, ex + 4, ey + 4, fill=shade, outline="")
        # leichte Richtungsmarche oben rechts
        arrow = "↗" if values[-1] >= values[0] else "↘"
        canvas.create_text(158, 18, text=arrow, fill=shade, font=("Segoe UI", 16, "bold"))
        return canvas


    def market_pulse_bar(self, parent, score, color, width=220, height=10, motion_delay=None):
        score = max(0, min(100, int(score or 0)))
        canvas = tk.Canvas(parent, width=width, height=height, bg=parent["bg"], highlightthickness=0)
        target_ratio = score / 100.0
        delay = self._next_result_motion_delay("market_pulse") if motion_delay is None else motion_delay
        highlight = self._blend_ui_color(color, COLORS["text"], 0.16)
        motion_head = self._blend_ui_color(color, COLORS["text"], 0.46)

        def draw_bar(active_canvas, reveal):
            actual_width = max(2, int(active_canvas.winfo_width()) or width)
            actual_height = max(2, int(active_canvas.winfo_height()) or height)
            fill_width = int(actual_width * target_ratio * reveal)
            active_canvas.delete("all")
            active_canvas.create_rectangle(0, 0, actual_width - 1, actual_height - 1, fill=COLORS["dark"], outline=COLORS["line"])
            if fill_width <= 0:
                return
            active_canvas.create_rectangle(0, 0, fill_width, actual_height, fill=color, outline="")
            if fill_width > 7:
                active_canvas.create_rectangle(1, 1, max(2, fill_width - 1), max(2, actual_height // 2), fill=highlight, outline="")
            if reveal < 0.995 and fill_width > 4:
                active_canvas.create_rectangle(max(0, fill_width - 3), 0, fill_width, actual_height, fill=motion_head, outline="")

        self._animate_canvas_result(canvas, draw_bar, delay=delay)
        return canvas


    def render_market_pulse_dashboard(self, win, rows):
        box = win.market_pulse_summary
        self.clear(box)
        rows = [r for r in rows if r.get("has_data")]
        top_rows = [r for r in rows if r.get("is_top_setup")]
        if not rows:
            if getattr(win, "market_pulse_story", None):
                win.market_pulse_story.config(text="Nach dem Preisabruf entsteht hier eine kurze Marktstory für die Top Setups.", fg=COLORS["blue"])
            hints = [
                {"title": "TOP Setup Heute", "value": "offen", "note": "Realtime Daten abrufen, danach wird der heutige Setup Pulse berechnet.", "score": 0, "color": COLORS["muted"], "kind": "open"},
                {"title": "Seit COT", "value": "offen", "note": "Trennt Marktbewegung und Entwicklung in Signalrichtung.", "score": 0, "color": COLORS["muted"], "kind": "open"},
                {"title": "Stärkstes Setup", "value": "offen", "note": "Wird aus den aktuellen Kursen abgeleitet.", "score": 0, "color": COLORS["muted"], "kind": "metric"},
                {"title": "Beobachten", "value": "offen", "note": "Pullback bedeutet keine Änderung der Engine.", "score": 0, "color": COLORS["muted"], "kind": "metric"},
            ]
        else:
            today_pos = sum(1 for r in top_rows if r.get("today", 0) > 0)
            confirmed = sum(1 for r in top_rows if r.get("cot", 0) >= 0.35)
            week_pos = sum(1 for r in top_rows if r.get("signal_since_cot", 0) > 0)
            best = max(top_rows or rows, key=lambda r: r.get("cot", -999))
            weakest = min(top_rows or rows, key=lambda r: r.get("cot", 999))
            total = max(1, len(top_rows))
            story_col = COLORS["green"] if today_pos >= 2 else COLORS["yellow"] if today_pos == 1 else COLORS["orange"]
            if getattr(win, "market_pulse_story", None):
                win.market_pulse_story.config(text=f"Heute laufen {today_pos} von {total} Top Setups in Richtung des COT Signals. {best.get('display_pair', best.get('pair'))} entwickelt sich seit COT momentan am stärksten.", fg=story_col)
            col1 = COLORS["green"] if today_pos >= 2 else COLORS["yellow"] if today_pos == 1 else COLORS["orange"]
            col2 = COLORS["green"] if week_pos >= 2 else COLORS["yellow"] if week_pos == 1 else COLORS["orange"]
            hints = [
                {"title": "TOP Setup Heute", "value": f"{today_pos} von {total}", "note": "laufen heute in Richtung des COT Signals", "score": today_pos, "total": total, "color": col1, "kind": "count"},
                {"title": "Seit COT", "value": f"{week_pos} von {total}", "note": "entwickeln sich seit dem COT Referenzkurs positiv", "score": week_pos, "total": total, "color": col2, "kind": "count"},
                {"title": "Stärkstes Setup", "value": f"{best.get('display_pair', best.get('pair'))} {best.get('cot',0):+.2f} %", "note": "Beste Entwicklung in Signalrichtung.", "score": max(0, min(100, best.get('pulse_score', 0))), "color": COLORS["green"] if best.get("cot",0) >= 0 else COLORS["yellow"], "kind": "metric"},
                {"title": "Beobachten", "value": f"{weakest.get('display_pair', weakest.get('pair'))} {weakest.get('cot',0):+.2f} %", "note": "Nur aktueller Market Pulse, kein neues Signal.", "score": max(0, min(100, weakest.get('pulse_score', 0))), "color": weakest.get("color", COLORS["muted"]), "kind": "metric"},
            ]
        for i, info in enumerate(hints):
            tile = self.card(box, COLORS["card2"])
            tile.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 8, 0), pady=0)
            box.grid_columnconfigure(i, weight=1)
            tk.Label(tile, text=info["title"], font=("Segoe UI", 9, "bold"), fg=COLORS["muted"], bg=COLORS["card2"]).pack(anchor="w", padx=12, pady=(10, 0))
            tk.Label(tile, text=info["value"], font=("Segoe UI", 21 if info.get("kind") == "count" else 17, "bold"), fg=info["color"], bg=COLORS["card2"]).pack(anchor="w", padx=12, pady=(2, 0))
            if info.get("kind") == "count":
                dots = tk.Frame(tile, bg=COLORS["card2"])
                dots.pack(anchor="w", padx=12, pady=(5, 2))
                score = int(info.get("score", 0) or 0)
                total = int(info.get("total", 3) or 3)
                for n in range(total):
                    dot_color = info["color"] if n < score else COLORS["line"]
                    self.status_dot(dots, dot_color, 15).pack(side="left", padx=(0, 6))
            else:
                self.market_pulse_bar(tile, info.get("score", 0), info["color"], width=180, height=8).pack(anchor="w", padx=12, pady=(4, 0))
            tk.Label(tile, text=info["note"], font=("Segoe UI", 8, "bold"), fg=COLORS["muted"], bg=COLORS["card2"], wraplength=250, justify="left").pack(anchor="w", padx=12, pady=(4, 10))


    def render_market_pulse_table(self, win, rows):
        table = win.market_pulse_table
        self.clear(table)
        headers = ["Markt", "Signal", "Markt heute", "Signal heute", "Markt seit COT", "Signal seit COT", "Pulse", "Einordnung"]
        widths = [16, 8, 12, 12, 13, 13, 16, 34]
        for c, h in enumerate(headers):
            tk.Label(table, text=h, font=("Segoe UI", 10, "bold"), fg=COLORS["muted"], bg=COLORS["card"], anchor="w").grid(row=0, column=c, sticky="ew", padx=7, pady=(4, 8))
            table.grid_columnconfigure(c, weight=1 if c in (0, 7) else 0)
        if not rows:
            tk.Label(table, text="Nach dem Abruf erscheinen hier nur die Top 3 plus Gold, Silber, NASDAQ 100 und S&P 500.", font=("Segoe UI", 11, "bold"), fg=COLORS["muted"], bg=COLORS["card"]).grid(row=1, column=0, columnspan=len(headers), sticky="w", padx=8, pady=16)
            return
        for r, row in enumerate(rows, start=1):
            bg = COLORS["card2"] if r % 2 else COLORS["card"]
            status = row.get("status", "")
            if status == "Läuft gegen Signal":
                status = "Kurzfristiger Pullback"
            if status == "Kurzfristiger Pullback":
                status = "Pullback, weiter beobachten"
            has_data = bool(row.get("has_data"))
            market_today = row.get("market_today", 0)
            signal_today = row.get("signal_today", 0)
            market_cot = row.get("market_since_cot", 0)
            signal_cot = row.get("signal_since_cot", 0)
            market_arrow = "▲" if market_today > 0.05 else "▼" if market_today < -0.05 else "→"
            signal_arrow = "▲" if signal_today > 0.05 else "▼" if signal_today < -0.05 else "→"
            values = [
                row.get("display_pair", row.get("pair", "")),
                row.get("direction", ""),
                f"{market_arrow} {market_today:+.2f} %" if has_data else "Nicht geladen",
                f"{signal_arrow} {signal_today:+.2f} %" if has_data else "Nicht geladen",
                f"{market_cot:+.2f} %" if has_data else "Nicht geladen",
                f"{signal_cot:+.2f} %" if has_data else "Nicht geladen",
                "",
                status + ("  |  Cache Daten" if row.get("cache") else ""),
            ]
            for c, val in enumerate(values):
                col = COLORS["text"]
                if c == 1:
                    col = COLORS["green"] if val == "LONG" else COLORS["red"]
                if c in (2, 4):
                    num = market_today if c == 2 else market_cot
                    col = COLORS["green"] if num > 0 else COLORS["red"] if num < 0 else COLORS["muted"]
                if c in (3, 5):
                    num = signal_today if c == 3 else signal_cot
                    col = COLORS["green"] if num > 0 else COLORS["orange"] if num < 0 else COLORS["muted"]
                if c == 7:
                    col = row.get("color", COLORS["muted"])
                lab = tk.Label(table, text=val, width=widths[c], font=("Segoe UI", 10, "bold" if c in (0, 1, 7) else "normal"), fg=col, bg=bg, anchor="w")
                lab.grid(row=r, column=c, sticky="ew", padx=7, pady=5)
            pulse_cell = tk.Frame(table, bg=bg)
            pulse_cell.grid(row=r, column=6, sticky="ew", padx=7, pady=5)
            pulse_value = safe_float(row.get("pulse_score", 0), 0)
            pulse_delay = self._next_result_motion_delay("market_pulse")
            self.market_pulse_bar(
                pulse_cell,
                pulse_value,
                row.get("color", COLORS["muted"]),
                width=120,
                height=8,
                motion_delay=pulse_delay,
            ).pack(side="left")
            pulse_label = tk.Label(pulse_cell, text=f" {pulse_value:.0f} %", font=("Segoe UI", 9, "bold"), fg=row.get("color", COLORS["muted"]), bg=bg)
            pulse_label.pack(side="left")
            self._animate_number_label(
                pulse_label,
                pulse_value,
                lambda value: f" {value:.0f} %",
                delay=pulse_delay,
            )


    def build_strength_matrix_rows(self):
        """Bereitet ausschließlich vorhandene Engine Werte für die Strength Matrix UI auf."""
        change_by_currency = {}
        movers = getattr(self, "weekly_movers", {}) or {}
        for item in movers.get("all", []) or []:
            curr = item.get("currency")
            if curr:
                change_by_currency[curr] = item

        rows = []
        for curr, data in (getattr(self, "strengths", {}) or {}).items():
            if curr not in MARKETS:
                continue
            strength = round(safe_float(data.get("strength", 50.0), 50.0), 1)
            mover = change_by_currency.get(curr, {})
            if mover:
                previous_strength = mover.get("previous_strength", "")
                change = round(safe_float(mover.get("change", 0.0), 0.0), 1)
                change_available = True
            else:
                previous_strength = ""
                change = 0.0
                change_available = False
            rows.append({
                "currency": curr,
                "name": SINGLE_ASSET_MARKETS.get(curr, {}).get("label", curr),
                "strength": strength,
                "change": change,
                "abs_change": abs(change),
                "change_available": change_available,
                "previous_strength": previous_strength,
                "is_proxy": bool(data.get("is_proxy")),
                "latest_date": data.get("latest_date", getattr(self.engine, "report_date", "")),
            })

        sorted_by_strength = sorted(rows, key=lambda x: x.get("strength", 0.0), reverse=True)
        strongest = sorted_by_strength[:6]
        strongest_currencies = {row.get("currency") for row in strongest}

        # Flops bleiben ein reines Gegenstück zum aktuellen Meridian Qualitätswert.
        # Währungen aus der Top Auswahl werden bewusst nicht wiederholt.
        weakest = [
            row for row in sorted(rows, key=lambda x: x.get("strength", 0.0))
            if row.get("currency") not in strongest_currencies
        ][:6]

        with_change = [row for row in rows if row.get("change_available")]
        gainers = sorted(
            [row for row in with_change if safe_float(row.get("change", 0.0), 0.0) > 0],
            key=lambda x: x.get("change", 0.0),
            reverse=True,
        )[:4]
        losers = sorted(
            [row for row in with_change if safe_float(row.get("change", 0.0), 0.0) < 0],
            key=lambda x: x.get("change", 0.0),
        )[:4]
        return strongest, weakest, gainers, losers

    def show_strength_matrix(self):
        if not getattr(self, "strengths", None):
            messagebox.showinfo("Meridian Strength Matrix", "Bitte zuerst die COT Analyse starten.")
            return

        strongest, weakest, gainers, losers = self.build_strength_matrix_rows()
        if not strongest and not weakest:
            messagebox.showinfo("Meridian Strength Matrix", "Keine Währungsdaten für die Strength Matrix gefunden.")
            return

        self._begin_result_motion("strength_matrix")

        win = tk.Toplevel(self)
        win.title("Meridian Currency Strength Matrix")
        win.configure(bg=COLORS["bg"])
        win.geometry("1200x860")
        win.minsize(1040, 720)
        win.transient(self)

        outer = tk.Frame(win, bg=COLORS["bg"])
        outer.pack(fill="both", expand=True, padx=16, pady=16)

        header = tk.Frame(outer, bg=COLORS["header"], highlightthickness=1, highlightbackground=COLORS["line"])
        header.pack(fill="x", pady=(0, 10))
        header.grid_columnconfigure(0, weight=1)
        header.grid_columnconfigure(1, weight=0)

        title_box = tk.Frame(header, bg=COLORS["header"])
        title_box.grid(row=0, column=0, sticky="w", padx=16, pady=12)
        tk.Label(title_box, text="Meridian Currency Strength Matrix", font=("Segoe UI", 21, "bold"), fg=COLORS["text"], bg=COLORS["header"]).pack(anchor="w")
        tk.Label(title_box, text="Top & Flops der Handelswoche", font=("Segoe UI", 11, "bold"), fg=COLORS["muted"], bg=COLORS["header"]).pack(anchor="w", pady=(2, 0))

        legend = tk.Frame(header, bg=COLORS["header"])
        legend.grid(row=0, column=1, sticky="e", padx=16, pady=12)
        for symbol, text, color in (("▲", "WoW Verbesserung", COLORS["green"]), ("▼", "WoW Verschlechterung", COLORS["red"]), ("●", "WoW unverändert", COLORS["muted"])):
            row = tk.Frame(legend, bg=COLORS["header"])
            row.pack(anchor="e", pady=1)
            tk.Label(row, text=symbol, font=("Segoe UI", 10, "bold"), fg=color, bg=COLORS["header"]).pack(side="left", padx=(0, 6))
            tk.Label(row, text=text, font=("Segoe UI", 9), fg=COLORS["muted"], bg=COLORS["header"]).pack(side="left")

        scroll_shell = tk.Frame(outer, bg=COLORS["bg"])
        scroll_shell.pack(fill="both", expand=True)

        content_canvas = tk.Canvas(scroll_shell, bg=COLORS["bg"], highlightthickness=0, bd=0)
        content_scrollbar = tk.Scrollbar(scroll_shell, orient="vertical", command=content_canvas.yview)
        content_canvas.configure(yscrollcommand=content_scrollbar.set)

        content_scrollbar.pack(side="right", fill="y")
        content_canvas.pack(side="left", fill="both", expand=True)

        content = tk.Frame(content_canvas, bg=COLORS["bg"])
        content_window = content_canvas.create_window((0, 0), window=content, anchor="nw")

        def _sync_scroll_region(event=None):
            content_canvas.configure(scrollregion=content_canvas.bbox("all"))

        def _sync_content_width(event):
            content_canvas.itemconfigure(content_window, width=event.width)

        def _on_mousewheel(event):
            if event.delta:
                content_canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
            elif getattr(event, "num", None) == 4:
                content_canvas.yview_scroll(-1, "units")
            elif getattr(event, "num", None) == 5:
                content_canvas.yview_scroll(1, "units")

        content.bind("<Configure>", _sync_scroll_region)
        content_canvas.bind("<Configure>", _sync_content_width)

        def _bind_mousewheel(event=None):
            content_canvas.bind_all("<MouseWheel>", _on_mousewheel)
            content_canvas.bind_all("<Button-4>", _on_mousewheel)
            content_canvas.bind_all("<Button-5>", _on_mousewheel)

        def _release_mousewheel(event=None):
            content_canvas.unbind_all("<MouseWheel>")
            content_canvas.unbind_all("<Button-4>")
            content_canvas.unbind_all("<Button-5>")

        content_canvas.bind("<Enter>", _bind_mousewheel)
        content_canvas.bind("<Leave>", _release_mousewheel)
        win.bind("<Destroy>", _release_mousewheel, add="+")

        agenda = tk.Frame(content, bg=COLORS["card2"], highlightthickness=1, highlightbackground=COLORS["line"])
        agenda.pack(fill="x", pady=(0, 10))
        agenda.grid_columnconfigure(0, weight=1)
        agenda.grid_columnconfigure(1, weight=1)
        agenda.grid_columnconfigure(2, weight=1)

        agenda_items = (
            ("Top Währungen", "Aktuell stärkste Einzelwährungen nach dem vorhandenen Meridian Qualitätswert der COT Engine."),
            ("Flop Währungen", "Aktuell schwächste Einzelwährungen. Eine Währung kann schwach bleiben, obwohl sie sich zur Vorwoche verbessert."),
            ("Wochen Momentum", "Zeigt nur die Veränderung zur Vorwoche. Das ist Dynamik, keine finale Handelsentscheidung."),
        )
        for col, (title, text) in enumerate(agenda_items):
            box = tk.Frame(agenda, bg=COLORS["card2"])
            box.grid(row=0, column=col, sticky="nsew", padx=12, pady=9)
            tk.Label(box, text=title, font=("Segoe UI", 10, "bold"), fg=COLORS["text"], bg=COLORS["card2"]).pack(anchor="w")
            tk.Label(box, text=text, font=("Segoe UI", 8), fg=COLORS["muted"], bg=COLORS["card2"], justify="left", wraplength=330).pack(anchor="w", pady=(2, 0))

        body = tk.Frame(content, bg=COLORS["bg"])
        body.pack(fill="both", expand=True)
        body.grid_columnconfigure(0, weight=1, uniform="matrix")
        body.grid_columnconfigure(1, weight=1, uniform="matrix")
        body.grid_rowconfigure(0, weight=3)
        body.grid_rowconfigure(1, weight=1)

        left = tk.Frame(body, bg=COLORS["card"], highlightthickness=1, highlightbackground=COLORS["line"])
        right = tk.Frame(body, bg=COLORS["card"], highlightthickness=1, highlightbackground=COLORS["line"])
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 7), pady=(0, 10))
        right.grid(row=0, column=1, sticky="nsew", padx=(7, 0), pady=(0, 10))

        momentum = tk.Frame(body, bg=COLORS["card"], highlightthickness=1, highlightbackground=COLORS["line"])
        momentum.grid(row=1, column=0, columnspan=2, sticky="nsew")
        momentum.grid_columnconfigure(0, weight=1)
        momentum.grid_columnconfigure(1, weight=1)

        def render_score_bar(parent, bg, strength, bar_color):
            canvas = tk.Canvas(parent, height=16, bg=bg, highlightthickness=0, bd=0)
            canvas.grid(row=0, column=1, sticky="ew", padx=(0, 14), pady=(12, 0))
            target_ratio = clamp(safe_float(strength, 0.0), 0.0, 100.0) / 100.0
            motion_delay = self._next_result_motion_delay("strength_matrix")
            highlight = self._blend_ui_color(bar_color, COLORS["text"], 0.18)
            motion_head = self._blend_ui_color(bar_color, COLORS["text"], 0.48)

            def draw_bar(active_canvas, reveal):
                active_canvas.delete("all")
                width = max(active_canvas.winfo_width(), 1)
                height = 16
                track_y0 = 5
                track_y1 = 11
                active_canvas.create_rectangle(0, track_y0, width, track_y1, fill=COLORS["line"], outline="")
                fill_width = int(width * target_ratio * reveal)
                if fill_width > 0:
                    active_canvas.create_rectangle(0, track_y0, fill_width, track_y1, fill=bar_color, outline="")
                    if fill_width > 7:
                        active_canvas.create_rectangle(1, track_y0 + 1, max(2, fill_width - 1), track_y0 + 3, fill=highlight, outline="")
                    if reveal < 0.995 and fill_width > 4:
                        active_canvas.create_rectangle(max(0, fill_width - 3), track_y0, fill_width, track_y1, fill=motion_head, outline="")
                for tick in range(1, 10):
                    x = int(width * tick / 10)
                    active_canvas.create_line(x, track_y0, x, track_y1, fill=bg)

            self._animate_canvas_result(canvas, draw_bar, delay=motion_delay)
            return canvas, motion_delay

        def change_parts(row, compact=False):
            if not row.get("change_available"):
                return "●", "n/a", COLORS["muted"]
            change = safe_float(row.get("change", 0.0), 0.0)
            if change > 0:
                return "▲", f"+{change:.1f}", COLORS["green"]
            if change < 0:
                return "▼", f"{change:.1f}", COLORS["red"]
            return "●", "±0.0", COLORS["muted"]

        def render_empty_state(parent, text):
            empty = tk.Frame(parent, bg=COLORS["card2"], highlightthickness=1, highlightbackground=COLORS["line"])
            empty.pack(fill="x", padx=12, pady=8)
            tk.Label(empty, text=text, font=("Segoe UI", 10), fg=COLORS["muted"], bg=COLORS["card2"], wraplength=430, justify="left").pack(anchor="w", padx=14, pady=14)

        def render_column(parent, heading, rows, heading_color, bar_color, side_label):
            tk.Label(parent, text=heading, font=("Segoe UI", 16, "bold"), fg=heading_color, bg=COLORS["card"]).pack(anchor="w", padx=16, pady=(15, 4))
            tk.Label(parent, text=side_label, font=("Segoe UI", 9), fg=COLORS["muted"], bg=COLORS["card"]).pack(anchor="w", padx=16, pady=(0, 10))

            if not rows:
                render_empty_state(parent, "Keine weiteren Einzelwährungen außerhalb der Top Auswahl.")
                return

            for idx, row in enumerate(rows, 1):
                bg = COLORS["card2"] if idx % 2 else COLORS["card"]
                item = tk.Frame(parent, bg=bg, highlightthickness=1, highlightbackground=COLORS["line"])
                item.pack(fill="x", padx=12, pady=5)
                item.grid_columnconfigure(0, weight=0)
                item.grid_columnconfigure(1, weight=1)
                item.grid_columnconfigure(2, weight=0)
                item.grid_columnconfigure(3, weight=0)

                name_box = tk.Frame(item, bg=bg)
                name_box.grid(row=0, column=0, rowspan=2, sticky="w", padx=(14, 10), pady=10)
                tk.Label(name_box, text=row.get("currency", ""), font=("Segoe UI", 18, "bold"), fg=COLORS["text"], bg=bg, width=4, anchor="w").pack(anchor="w")
                sub = row.get("name", row.get("currency", ""))
                if row.get("is_proxy"):
                    sub = f"{sub} | Proxy"
                tk.Label(name_box, text=sub, font=("Segoe UI", 8), fg=COLORS["muted"], bg=bg).pack(anchor="w", pady=(1, 0))

                _, score_motion_delay = render_score_bar(item, bg, row.get("strength", 0.0), bar_color)
                tk.Label(item, text="aktueller Meridian Score", font=("Segoe UI", 8), fg=COLORS["muted"], bg=bg).grid(row=1, column=1, sticky="w", padx=(0, 14), pady=(0, 10))

                score_box = tk.Frame(item, bg=bg)
                score_box.grid(row=0, column=2, rowspan=2, sticky="e", padx=(8, 18))
                strength_value = safe_float(row.get("strength", 0), 0)
                score_label = tk.Label(score_box, text=f"{strength_value:.1f}", font=("Segoe UI", 23, "bold"), fg=COLORS["yellow"], bg=bg, width=5, anchor="e")
                score_label.pack(anchor="e")
                self._animate_number_label(
                    score_label,
                    strength_value,
                    lambda value: f"{value:.1f}",
                    delay=score_motion_delay,
                )
                symbol, change_text, color = change_parts(row)
                tk.Label(score_box, text=f"WoW {symbol} {change_text}", font=("Segoe UI", 8, "bold"), fg=color, bg=bg, anchor="e").pack(anchor="e", pady=(0, 2))

        def render_momentum_list(parent, title, rows, color, empty_text):
            frame = tk.Frame(parent, bg=COLORS["card"])
            frame.pack(fill="both", expand=True, padx=14, pady=(0, 12))
            tk.Label(frame, text=title, font=("Segoe UI", 12, "bold"), fg=color, bg=COLORS["card"]).pack(anchor="w", pady=(0, 6))
            if not rows:
                tk.Label(frame, text=empty_text, font=("Segoe UI", 9), fg=COLORS["muted"], bg=COLORS["card"], justify="left").pack(anchor="w")
                return
            for row in rows:
                line = tk.Frame(frame, bg=COLORS["card2"], highlightthickness=1, highlightbackground=COLORS["line"])
                line.pack(fill="x", pady=3)
                line.grid_columnconfigure(1, weight=1)
                symbol, change_text, change_color = change_parts(row)
                tk.Label(line, text=row.get("currency", ""), font=("Segoe UI", 12, "bold"), fg=COLORS["text"], bg=COLORS["card2"], width=5, anchor="w").grid(row=0, column=0, sticky="w", padx=(10, 4), pady=6)
                tk.Label(line, text=f"Score {row.get('strength', 0):.1f}", font=("Segoe UI", 9), fg=COLORS["muted"], bg=COLORS["card2"]).grid(row=0, column=1, sticky="w", padx=4, pady=6)
                tk.Label(line, text=f"{symbol} {change_text}", font=("Segoe UI", 12, "bold"), fg=change_color, bg=COLORS["card2"], width=9, anchor="e").grid(row=0, column=2, sticky="e", padx=(4, 10), pady=6)

        render_column(
            left,
            "Stärkste Währungen",
            strongest,
            COLORS["green"],
            COLORS["green"],
            "Aktueller Zustand, sortiert nach Meridian Qualitätswert der COT Engine",
        )
        render_column(
            right,
            "Schwächste Währungen",
            weakest,
            COLORS["red"],
            COLORS["red"],
            "Aktueller Zustand, ohne Dopplung der links gezeigten Top Währungen",
        )

        tk.Label(momentum, text="Wochen Momentum", font=("Segoe UI", 15, "bold"), fg=COLORS["text"], bg=COLORS["card"]).grid(row=0, column=0, columnspan=2, sticky="w", padx=16, pady=(12, 2))
        tk.Label(momentum, text="Momentum zeigt nur die Veränderung gegenüber der Vorwoche. Ein starker Anstieg bedeutet nicht automatisch, dass die Währung bereits stark ist.", font=("Segoe UI", 9), fg=COLORS["muted"], bg=COLORS["card"]).grid(row=1, column=0, columnspan=2, sticky="w", padx=16, pady=(0, 8))

        gain_box = tk.Frame(momentum, bg=COLORS["card"])
        loss_box = tk.Frame(momentum, bg=COLORS["card"])
        gain_box.grid(row=2, column=0, sticky="nsew", padx=(0, 6))
        loss_box.grid(row=2, column=1, sticky="nsew", padx=(6, 0))
        render_momentum_list(gain_box, "Größte Gewinner der Woche", gainers, COLORS["green"], "Keine positiven Wochenveränderungen verfügbar.")
        render_momentum_list(loss_box, "Größte Verlierer der Woche", losers, COLORS["red"], "Keine negativen Wochenveränderungen verfügbar.")

        note = tk.Frame(content, bg=COLORS["card2"], highlightthickness=1, highlightbackground=COLORS["line"])
        note.pack(fill="x", pady=(12, 0))
        note_text = "Hinweis: Die Strength Matrix dient ausschließlich der Marktübersicht einzelner Währungen.\nDie finale Handelsentscheidung erfolgt weiterhin ausschließlich über die Meridian Watchlist."
        tk.Label(note, text=note_text, font=("Segoe UI", 9), fg=COLORS["muted"], bg=COLORS["card2"], justify="left").pack(anchor="w", padx=14, pady=10)

    def show_cot_raw_table(self):
        if not self.top3:
            messagebox.showwarning("Noch kein COT Ergebnis", "Bitte zuerst die COT Analyse starten.")
            return

        rows = self.build_cot_transparency_rows()
        if not rows:
            messagebox.showwarning("Keine Rohdaten", "Für die aktuelle Watchlist wurden keine COT Daten gefunden.")
            return

        try:
            csv_path = self.write_cot_transparency_table()
        except Exception:
            csv_path = None

        def num(value):
            try:
                return float(value)
            except Exception:
                return 0.0

        def fmt(value):
            return self.format_cot_number(value, signed=True)

        def commercial_bias_text(row):
            net = num(row.get("commercial_net"))
            if net > 0:
                return "Commercials sind aktuell netto LONG. Das ist die bullische Grundrichtung der Meridian Engine."
            if net < 0:
                return "Commercials sind aktuell netto SHORT. Das ist die bärische Grundrichtung der Meridian Engine."
            return "Commercials sind aktuell nahezu ausgeglichen. Kein klarer Grundbias."

        def commercial_flow_text(row):
            net = num(row.get("commercial_net"))
            l1 = num(row.get("commercial_long_change"))
            s1 = num(row.get("commercial_short_change"))
            l4 = num(row.get("commercial_long_change_4w"))
            s4 = num(row.get("commercial_short_change_4w"))
            if net > 0:
                if l1 > 0 and s1 < 0:
                    return "Sehr bullisch: Commercials bauen Longs auf und reduzieren Shorts."
                if l1 > 0:
                    return "Bullisch: Commercials bauen Long Positionen auf."
                if s1 < 0:
                    return "Bullisch: Commercials reduzieren Short Positionen."
                return "Grundbias bullisch, aber der frische Commercial Flow bestätigt nur schwach."
            if net < 0:
                if s1 > 0 and l1 < 0:
                    return "Sehr bärisch: Commercials bauen Shorts auf und reduzieren Longs."
                if s1 > 0:
                    return "Bärisch: Commercials bauen Short Positionen auf."
                if l1 < 0:
                    return "Bärisch: Commercials reduzieren Long Positionen."
                return "Grundbias bärisch, aber der frische Commercial Flow bestätigt nur schwach."
            if l4 > s4:
                return "Commercial Flow kippt eher bullish."
            if s4 > l4:
                return "Commercial Flow kippt eher bärisch."
            return "Commercial Flow ist neutral."

        def spec_flow_text(row):
            net = num(row.get("commercial_net"))
            l1 = num(row.get("large_spec_long_change"))
            s1 = num(row.get("large_spec_short_change"))
            if net > 0:
                if l1 > 0 and s1 <= 0:
                    return "Large Specs bestätigen bullish durch Long Aufbau."
                if s1 > 0 and l1 <= 0:
                    return "Konflikt: Large Specs bauen eher Shorts auf."
                return "Large Specs liefern keine klare Zusatzbestätigung."
            if net < 0:
                if s1 > 0 and l1 <= 0:
                    return "Large Specs bestätigen bärisch durch Short Aufbau."
                if l1 > 0 and s1 <= 0:
                    return "Konflikt: Large Specs bauen eher Longs auf."
                return "Large Specs liefern keine klare Zusatzbestätigung."
            return "Large Specs sind nur Zusatzfilter, kein Richtungsgeber."

        def oi_text(row):
            oi = num(row.get("open_interest_change_4w"))
            if oi > 0:
                return f"Open Interest 4W {fmt(oi)}: steigende Marktteilnahme, Bewegung wird ernster genommen."
            if oi < 0:
                return f"Open Interest 4W {fmt(oi)}: fallende Marktteilnahme, Signal etwas vorsichtiger werten."
            return "Open Interest 4W neutral."

        win = tk.Toplevel(self)
        win.title("Meridian COT Ampel, einfach erklärt")
        win.configure(bg=COLORS["bg"])
        win.geometry("1320x780")
        win.minsize(1040, 620)
        win.transient(self)

        outer = tk.Frame(win, bg=COLORS["bg"])
        outer.pack(fill="both", expand=True, padx=14, pady=14)

        header = tk.Frame(outer, bg=COLORS["header"], highlightthickness=1, highlightbackground=COLORS["line"])
        header.pack(fill="x", pady=(0, 8))
        tk.Label(header, text="Meridian COT Ampel, einsteigerfreundliche Meridian Engine Übersicht", font=("Segoe UI", 17, "bold"), fg=COLORS["text"], bg=COLORS["header"]).pack(anchor="w", padx=14, pady=(10, 2))
        info = f"Report: {self.engine.report_date}  |  Die Richtung kommt aus dem aktuellen Commercial Long/Short Überhang. 1W Changes werden aus zwei Reports selbst gegengeprüft. Qualität kommt aus Commercial Change, Large Specs und Open Interest."
        tk.Label(header, text=info, font=("Segoe UI", 10), fg=COLORS["muted"], bg=COLORS["header"], wraplength=1240, justify="left").pack(anchor="w", padx=14, pady=(0, 10))

        method = tk.Frame(outer, bg=COLORS["card2"], highlightthickness=1, highlightbackground=COLORS["line"])
        method.pack(fill="x", pady=(0, 8))
        steps = [
            ("1. Richtung", "Commercials netto Long oder netto Short. Das ist der Meridian Grundbias."),
            ("2. Veränderung", "1W = aktueller Report minus Vorwoche. Long und Short Veränderungen werden getrennt gelesen."),
            ("3. Qualität", "Large Specs und Open Interest bestätigen, dämpfen oder zeigen Konflikt. Sie drehen keinen klaren Commercial Bias."),
        ]
        for title, text in steps:
            box = tk.Frame(method, bg=COLORS["card2"])
            box.pack(side="left", fill="both", expand=True, padx=10, pady=10)
            tk.Label(box, text=title, font=("Segoe UI", 11, "bold"), fg=COLORS["yellow"], bg=COLORS["card2"]).pack(anchor="w")
            tk.Label(box, text=text, font=("Segoe UI", 9), fg=COLORS["muted"], bg=COLORS["card2"], wraplength=390, justify="left").pack(anchor="w", pady=(3, 0))

        reason = tk.Frame(outer, bg=COLORS["card"], highlightthickness=1, highlightbackground=COLORS["line"])
        reason.pack(fill="x", pady=(0, 8))
        tk.Label(reason, text="Warum diese Watchlist entstand", font=("Segoe UI", 12, "bold"), fg=COLORS["yellow"], bg=COLORS["card"]).pack(anchor="w", padx=12, pady=(8, 3))
        for line in self.build_pair_reason_lines()[:3]:
            row_f = tk.Frame(reason, bg=COLORS["card"])
            row_f.pack(fill="x", padx=12, pady=1)
            self.status_dot(row_f, COLORS["green"], 10).pack(side="left", padx=(0, 8))
            tk.Label(row_f, text=line, font=("Segoe UI", 9, "bold"), fg=COLORS["text"], bg=COLORS["card"], wraplength=1220, justify="left").pack(anchor="w", side="left")

        table_frame = tk.Frame(outer, bg=COLORS["card"], highlightthickness=1, highlightbackground=COLORS["line"])
        table_frame.pack(fill="both", expand=True)

        canvas = tk.Canvas(table_frame, bg=COLORS["card"], highlightthickness=0)
        scroll_y = tk.Scrollbar(table_frame, orient="vertical", command=canvas.yview)
        inner = tk.Frame(canvas, bg=COLORS["card"])
        inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas_window = canvas.create_window((0, 0), window=inner, anchor="nw")
        canvas.configure(yscrollcommand=scroll_y.set)
        canvas.pack(side="left", fill="both", expand=True)
        scroll_y.pack(side="right", fill="y")
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(canvas_window, width=e.width))

        tk.Label(inner, text="Meridian Engine Diagnose je Markt", font=("Segoe UI", 13, "bold"), fg=COLORS["text"], bg=COLORS["card"]).pack(anchor="w", padx=12, pady=(10, 4))

        for i, row in enumerate(rows, 1):
            card_bg = COLORS["card2"] if i % 2 else COLORS["card"]
            card = tk.Frame(inner, bg=card_bg, highlightthickness=1, highlightbackground=COLORS["line"])
            card.pack(fill="x", padx=10, pady=6)

            top = tk.Frame(card, bg=card_bg)
            top.pack(fill="x", padx=12, pady=(10, 6))
            self.status_dot(top, row["color"], 13).pack(side="left", padx=(0, 8))
            tk.Label(top, text=f"{row['currency']}  |  {row['signal']}", font=("Segoe UI", 12, "bold"), fg=row["color"], bg=card_bg).pack(side="left")
            tk.Label(top, text=f"COT Qualität {safe_float(row.get('strength', 0), 0):.1f}", font=("Segoe UI", 12, "bold"), fg=COLORS["yellow"], bg=card_bg).pack(side="right")

            cols = tk.Frame(card, bg=card_bg)
            cols.pack(fill="x", padx=12, pady=(0, 10))
            for c in range(4):
                cols.grid_columnconfigure(c, weight=1, uniform="cotcols")

            panels = [
                ("Ebene 1, Commercial Bias", commercial_bias_text(row), f"Commercial Net: {fmt(row.get('commercial_net'))}", row["color"]),
                ("Commercial Veränderung", commercial_flow_text(row), f"1W: Long {fmt(row.get('commercial_long_change'))}, Short {fmt(row.get('commercial_short_change'))}\n4W: Long {fmt(row.get('commercial_long_change_4w'))}, Short {fmt(row.get('commercial_short_change_4w'))}", COLORS["text"]),
                ("Large Spec Veränderung", spec_flow_text(row), f"1W: Long {fmt(row.get('large_spec_long_change'))}, Short {fmt(row.get('large_spec_short_change'))}\n4W: Long {fmt(row.get('large_spec_long_change_4w'))}, Short {fmt(row.get('large_spec_short_change_4w'))}", COLORS["text"]),
                ("Open Interest", oi_text(row), f"4W: {fmt(row.get('open_interest_change_4w'))}", COLORS["text"]),
            ]

            for c, (title, desc, value, fg) in enumerate(panels):
                p = tk.Frame(cols, bg=COLORS["header"], highlightthickness=1, highlightbackground=COLORS["line"])
                p.grid(row=0, column=c, sticky="nsew", padx=4)
                tk.Label(p, text=title, font=("Segoe UI", 9, "bold"), fg=COLORS["yellow"], bg=COLORS["header"]).pack(anchor="w", padx=8, pady=(7, 2))
                tk.Label(p, text=desc, font=("Segoe UI", 9), fg=COLORS["text"], bg=COLORS["header"], wraplength=285, justify="left").pack(anchor="w", padx=8)
                tk.Label(p, text=value, font=("Segoe UI", 9, "bold"), fg=fg, bg=COLORS["header"], wraplength=285, justify="left").pack(anchor="w", padx=8, pady=(5, 8))

            kurz = tk.Frame(card, bg=card_bg)
            kurz.pack(fill="x", padx=12, pady=(0, 10))
            tk.Label(kurz, text="Kurzfazit:", font=("Segoe UI", 9, "bold"), fg=COLORS["yellow"], bg=card_bg).pack(anchor="w", side="left", padx=(0, 8))
            tk.Label(kurz, text=row.get("interpretation", ""), font=("Segoe UI", 9), fg=COLORS["muted"], bg=card_bg, wraplength=1160, justify="left").pack(anchor="w", side="left")

        legend = tk.Frame(outer, bg=COLORS["card2"], highlightthickness=1, highlightbackground=COLORS["line"])
        legend.pack(fill="x", pady=(8, 0))
        legend_text = "Einsteiger Lesart: Erst Commercial Netto lesen. Dann 1W Veränderung prüfen: Long Aufbau oder Short Abbau bestätigt bullisch, Short Aufbau oder Long Abbau bestätigt bärisch. Alle 1W Werte werden vom Analyzer aus zwei CFTC Reports neu berechnet. Der COT Index ist nur Kontext."
        if csv_path:
            legend_text += f"  CSV Export: audit/{csv_path.name}"
        tk.Label(legend, text=legend_text, font=("Segoe UI", 9), fg=COLORS["muted"], bg=COLORS["card2"], wraplength=1220, justify="left").pack(anchor="w", padx=12, pady=8)


    def build_hybrid_logic_audit(self):
        """Deterministische Szenario und Schnittstellenprüfung der Hybrid Engine."""
        scenarios = [
            {
                "name": "Positiver Bestand mit stark negativem Flow",
                "expected": "BEARISH_OR_NEUTRAL",
                "values": [82, 18, 24, 22, 30],
                "oi": 72,
            },
            {
                "name": "Negativer Bestand mit stark positivem Flow",
                "expected": "BULLISH_OR_NEUTRAL",
                "values": [18, 84, 78, 80, 72],
                "oi": 75,
            },
            {
                "name": "Breite bullische Übereinstimmung",
                "expected": "BULLISH",
                "values": [72, 82, 76, 74, 70],
                "oi": 80,
            },
            {
                "name": "Breite bearische Übereinstimmung",
                "expected": "BEARISH",
                "values": [28, 18, 24, 26, 30],
                "oi": 78,
            },
            {
                "name": "Uneinheitlicher neutraler Kontext",
                "expected": "NEUTRAL",
                "values": [54, 47, 53, 48, 50],
                "oi": 50,
            },
        ]
        rows = []
        for scenario in scenarios:
            position, commercial, specs, acceleration, context = scenario["values"]
            sample = {
                "strength": 50,
                "classic_engine_score": 50,
                "commercial_position": position,
                "commercial_weekly_change": commercial,
                "large_spec_weekly_change": specs,
                "commercial_4w_net_trend": context,
                "large_spec_4w_net_trend_absolute": context,
                "flow_acceleration": acceleration,
                "oi_participation": scenario["oi"],
                "quality": 100,
                "components": {
                    "hybrid_commercial_position_context": position,
                    "hybrid_commercial_flow": commercial,
                    "hybrid_large_spec_flow": specs,
                    "hybrid_flow_acceleration": acceleration,
                    "hybrid_four_week_context": context,
                },
                "raw_audit": {
                    "commercial_4w_quality_pct": 75,
                    "large_spec_4w_quality_pct": 75,
                },
            }
            profile = self.engine.calculate_analysis_profile(sample, ENGINE_HYBRID)
            score = profile["hybrid_score"]
            bias = "BULLISH" if score >= 58 else "BEARISH" if score <= 42 else "NEUTRAL"
            expected = scenario["expected"]
            passed = (
                bias == expected
                or expected == "BEARISH_OR_NEUTRAL" and bias in ("BEARISH", "NEUTRAL")
                or expected == "BULLISH_OR_NEUTRAL" and bias in ("BULLISH", "NEUTRAL")
            )
            rows.append({
                "scenario": scenario["name"],
                "expected": expected,
                "actual_bias": bias,
                "hybrid_score": round(score, 1),
                "hybrid_quality": round(profile["hybrid_quality"], 1),
                "status": "PASS" if passed else "FAIL",
                "components": profile["hybrid_components"],
            })

        required_fields = ("strength", "weekly_strength", "confidence", "probability", "bias", "signed_strength", "analysis_engine")
        interface_rows = []
        for currency, data in (self.strengths or {}).items():
            missing = [field for field in required_fields if field not in data]
            ranges_ok = (
                0 <= safe_float(data.get("strength", -1), -1) <= 100
                and 0 <= safe_float(data.get("confidence", -1), -1) <= 100
                and -100 <= safe_float(data.get("signed_strength", -999), -999) <= 100
                and data.get("bias") in ("BULLISH", "BEARISH", "NEUTRAL")
            )
            interface_rows.append({
                "currency": currency,
                "missing_fields": missing,
                "ranges_ok": ranges_ok,
                "status": "PASS" if not missing and ranges_ok else "FAIL",
            })

        forex_currencies = {"AUD", "CAD", "CHF", "EUR", "GBP", "JPY", "NZD", "USD"}

        def is_forex_pair(item):
            pair = str((item or {}).get("pair", ""))
            if pair.count("/") != 1 or (item or {}).get("is_single_asset"):
                return False
            base, quote = pair.split("/", 1)
            return base in forex_currencies and quote in forex_currencies and base != quote

        top3_rows = list(self.top3 or [])
        top3_structure_ok = all(
            item.get("pair") and item.get("direction") and "confidence" in item
            for item in top3_rows
        )
        top3_count_ok = len(top3_rows) == 3
        top3_forex_only_ok = top3_count_ok and all(is_forex_pair(item) for item in top3_rows)
        top3_unique_ok = len({item.get("pair") for item in top3_rows}) == len(top3_rows)
        top3_ok = top3_structure_ok and top3_count_ok and top3_forex_only_ok and top3_unique_ok

        pair_ranking_ok = bool(self.all_pairs) and all(
            "base_components" in item and "quote_components" in item
            for item in self.all_pairs[:3]
        )
        additional_markets_separate = all(
            item.get("pair") not in {row.get("pair") for row in top3_rows}
            for item in (self.all_pairs or []) if item.get("is_single_asset")
        )

        final_rows = list(getattr(self, "final_watchlist", []) or [])
        final_watchlist_ready = bool(final_rows)
        top3_pairs = [item.get("pair") for item in top3_rows]
        final_pairs = [item.get("pair") for item in final_rows]
        final_watchlist_same_set = (
            len(final_pairs) == 3
            and len(set(final_pairs)) == 3
            and set(final_pairs) == set(top3_pairs)
        ) if final_watchlist_ready else None
        final_watchlist_order_changed = (
            bool(final_watchlist_same_set) and final_pairs != top3_pairs
        ) if final_watchlist_ready else None
        final_watchlist_ok = (
            len(final_rows) == 3
            and all(is_forex_pair(item) for item in final_rows)
            and bool(final_watchlist_same_set)
        ) if final_watchlist_ready else None

        macro_rows = list(getattr(self, "macro_results", []) or [])
        macro_ready = bool(macro_rows)
        macro_pairs = [item.get("pair") for item in macro_rows if is_forex_pair(item)]
        macro_ok = (
            len(macro_pairs) == 3
            and len(set(macro_pairs)) == 3
            and set(macro_pairs) == set(final_pairs)
        ) if macro_ready and final_watchlist_ready else None

        pulse_cache = MarketPulsePriceProvider().load_cache()
        pulse_markets = pulse_cache.get("markets", {}) if isinstance(pulse_cache, dict) else {}
        pulse_expected_pairs = self.market_pulse_required_pairs()
        pulse_valid_pairs = []
        pulse_invalid_pairs = []
        for pair in pulse_expected_pairs:
            data = pulse_markets.get(pair, {}) if isinstance(pulse_markets, dict) else {}
            series = data.get("series", []) if isinstance(data, dict) else []
            valid = bool(
                data
                and data.get("current_price") not in (None, 0)
                and data.get("previous_close") not in (None, 0)
                and data.get("reference_price") not in (None, 0)
                and isinstance(series, list)
                and len(series) >= 2
            )
            (pulse_valid_pairs if valid else pulse_invalid_pairs).append(pair)
        if not pulse_markets:
            market_pulse_status = "PENDING"
        elif not pulse_invalid_pairs:
            market_pulse_status = "PASS"
        else:
            market_pulse_status = "FAIL"

        scenario_ok = all(row["status"] == "PASS" for row in rows)
        interface_ok = all(row["status"] == "PASS" for row in interface_rows)
        watchlist_macro_ok = top3_ok and pair_ranking_ok
        if final_watchlist_ready:
            watchlist_macro_ok = watchlist_macro_ok and bool(final_watchlist_ok)
        if macro_ready:
            watchlist_macro_ok = watchlist_macro_ok and bool(macro_ok)

        return {
            "method": "Hybrid Independent Context 104W",
            "scenario_status": "PASS" if scenario_ok else "FAIL",
            "interface_status": "PASS" if interface_ok else "FAIL",
            "top3_integration": "PASS" if top3_ok else "FAIL",
            "top3_count": len(top3_rows),
            "top3_count_status": "PASS" if top3_count_ok else "FAIL",
            "top3_forex_only": "PASS" if top3_forex_only_ok else "FAIL",
            "top3_unique": "PASS" if top3_unique_ok else "FAIL",
            "additional_markets_separate": "PASS" if additional_markets_separate else "FAIL",
            "final_watchlist_status": ("PASS" if final_watchlist_ok else "FAIL") if final_watchlist_ready else "PENDING",
            "macro_top3_status": ("PASS" if macro_ok else "FAIL") if macro_ready and final_watchlist_ready else "PENDING",
            "pair_ranking_integration": "PASS" if pair_ranking_ok else "FAIL",
            "strength_matrix_contract": "PASS" if interface_ok else "FAIL",
            "market_pulse_contract": market_pulse_status,
            "market_pulse_markets_valid": len(pulse_valid_pairs),
            "market_pulse_markets_expected": len(pulse_expected_pairs),
            "market_pulse_invalid_pairs": pulse_invalid_pairs,
            "market_pulse_cache_created": pulse_cache.get("created", "") if isinstance(pulse_cache, dict) else "",
            "watchlist_macro_contract": "PASS" if watchlist_macro_ok else "FAIL",
            "top3_pairs": top3_pairs,
            "final_watchlist_pairs": final_pairs,
            "final_watchlist_same_pair_set": "PASS" if final_watchlist_same_set else ("FAIL" if final_watchlist_ready else "PENDING"),
            "final_watchlist_order": "RESORTED" if final_watchlist_order_changed else ("UNCHANGED" if final_watchlist_ready else "PENDING"),
            "macro_pairs": macro_pairs,
            "scenarios": rows,
            "interfaces": interface_rows,
        }

    def build_all_engine_profile_audit(self):
        """Berechnet einen reinen Auditvergleich aller Analyseprofile.

        Die CFTC Rohdaten werden nicht erneut geladen. Jedes Profil erhält eine
        Kopie derselben bereits validierten Währungsdaten. Anschließend werden
        nur der profilspezifische Strength Score und die bestehende Paarbildung
        angewendet. Die aktive Benutzer Engine und ihre Ergebnisse bleiben
        unverändert.
        """
        profiles = {}
        original_engine = self.engine.analysis_engine
        try:
            for engine_key in (ENGINE_CLASSIC, ENGINE_FLOW, ENGINE_HYBRID):
                profile_strengths = copy.deepcopy(self.strengths)
                for currency, data in profile_strengths.items():
                    profile_result = self.engine.calculate_analysis_profile(data, engine_key)
                    classic_score = profile_result["classic_score"]
                    momentum_score = profile_result["momentum_score"]
                    selected_score = profile_result["selected_score"]
                    data["analysis_engine"] = engine_key
                    data["analysis_engine_label"] = ENGINE_LABELS[engine_key]
                    data["analysis_engine_weights"] = ENGINE_PROFILE_WEIGHTS[engine_key]
                    data["analysis_engine_reason"] = ENGINE_REASONS[engine_key]
                    data["strength"] = round(selected_score, 1)
                    data["weekly_strength"] = round(selected_score, 1)
                    data["confidence"] = round(profile_result["selected_confidence"], 1)
                    data["probability"] = data["confidence"]
                    data["hybrid_engine_score"] = round(profile_result["hybrid_score"], 1)
                    data["hybrid_quality_score"] = round(profile_result["hybrid_quality"], 1)
                    data["signed_strength"] = round((selected_score - 50.0) * 2.0, 1)
                    if engine_key != ENGINE_CLASSIC:
                        data["bias"] = "BULLISH" if selected_score >= 58 else "BEARISH" if selected_score <= 42 else "NEUTRAL"
                    data.setdefault("components", {})["selected_engine_score"] = round(selected_score, 1)
                    data.setdefault("raw_audit", {})["analysis_engine"] = engine_key
                    data["raw_audit"]["analysis_engine_label"] = ENGINE_LABELS[engine_key]

                self.engine.analysis_engine = engine_key
                top3, all_pairs = self.engine.compute_pairs(profile_strengths)
                profiles[engine_key] = {
                    "engine_key": engine_key,
                    "engine_label": ENGINE_LABELS[engine_key],
                    "engine_weights": ENGINE_PROFILE_WEIGHTS[engine_key],
                    "engine_reason": ENGINE_REASONS[engine_key],
                    "currency_ranking": sorted(
                        ({
                            "currency": currency,
                            "selected_score": data.get("strength"),
                            "classic_score": data.get("classic_engine_score"),
                            "momentum_score": data.get("momentum_engine_score"),
                            "hybrid_score": data.get("hybrid_engine_score"),
                            "hybrid_quality": data.get("hybrid_quality_score"),
                            "bias": data.get("bias"),
                        } for currency, data in profile_strengths.items()),
                        key=lambda item: safe_float(item.get("selected_score"), 50),
                        reverse=True,
                    ),
                    "top3": copy.deepcopy(top3),
                    "pair_ranking": copy.deepcopy(all_pairs),
                }
        finally:
            self.engine.analysis_engine = original_engine
        return profiles

    def write_all_engine_profile_audit_files(self, profiles, safe_date):
        json_path = AUDIT_DIR / f"engine_profiles_all_{safe_date}.json"
        csv_path = AUDIT_DIR / f"engine_profiles_all_{safe_date}.csv"
        txt_path = AUDIT_DIR / f"engine_profiles_all_{safe_date}.txt"
        json_path.write_text(json.dumps(sanitize_audit_payload({
            "created_at": datetime.now().isoformat(timespec="seconds"),
            "report_date": self.engine.report_date,
            "app_version": APP_VERSION,
            "profiles": profiles,
        }), indent=2, ensure_ascii=False), encoding="utf-8")

        fields = [
            "engine_key", "engine_label", "rank", "selected_top3", "pair", "direction",
            "confidence", "selection_score", "original_rank", "diversity_penalty",
            "diversity_note", "strong", "weak", "signed_pair_spread",
        ]
        with csv_path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
            writer.writeheader()
            for engine_key, profile in profiles.items():
                selected = {item.get("pair") for item in profile.get("top3", [])}
                selected_rank = {item.get("pair"): index for index, item in enumerate(profile.get("top3", []), 1)}
                for rank, item in enumerate(profile.get("pair_ranking", []), 1):
                    writer.writerow({
                        "engine_key": engine_key,
                        "engine_label": profile.get("engine_label"),
                        "rank": rank,
                        "selected_top3": "YES" if item.get("pair") in selected else "NO",
                        "pair": item.get("pair"),
                        "direction": item.get("direction"),
                        "confidence": item.get("confidence"),
                        "selection_score": item.get("selection_score", item.get("confidence")),
                        "original_rank": item.get("original_rank", rank),
                        "diversity_penalty": item.get("diversity_penalty", 0),
                        "diversity_note": item.get("diversity_note", ""),
                        "strong": item.get("strong", ""),
                        "weak": item.get("weak", ""),
                        "signed_pair_spread": item.get("signed_pair_spread", item.get("diff", "")),
                    })

        lines = [
            "Meridian Engine Profilvergleich",
            f"Erstellt: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            f"App Version: {APP_VERSION}",
            f"COT Report: {self.engine.report_date}",
            "Alle Profile verwenden dieselben bereits validierten CFTC Rohdaten.",
            "Es wird keine Berechnungslogik verändert und kein weiterer Download ausgeführt.",
        ]
        for engine_key in (ENGINE_CLASSIC, ENGINE_FLOW, ENGINE_HYBRID):
            profile = profiles.get(engine_key, {})
            lines += ["", f"{profile.get('engine_label', engine_key)}:"]
            for index, item in enumerate(profile.get("top3", []), 1):
                lines.append(
                    f"{index}. {item.get('pair')} {item.get('direction')} | "
                    f"Qualität {item.get('confidence')} | stark {item.get('strong')} | "
                    f"schwach {item.get('weak')} | {item.get('diversity_note', '')}"
                )
        txt_path.write_text("\n".join(lines), encoding="utf-8")
        return json_path, csv_path, txt_path

    def write_market_pulse_debug_audit_files(self, safe_date):
        """Exportiert die Rohdaten des letzten Market Pulse Abrufs ohne neuen Internetzugriff.

        Der Bericht zeigt exakt, welche Providerwerte im Cache lagen und welche
        Referenzen der Analyzer für Heute und Seit COT verwendet. Damit lassen
        sich abweichende Broker Tagesgrenzen und Provider Metafelder erkennen.
        """
        AUDIT_DIR.mkdir(exist_ok=True)
        json_path = AUDIT_DIR / f"market_pulse_realtime_debug_{safe_date}.json"
        csv_path = AUDIT_DIR / f"market_pulse_realtime_debug_{safe_date}.csv"
        txt_path = AUDIT_DIR / f"market_pulse_realtime_debug_{safe_date}.txt"

        cache = MarketPulsePriceProvider().load_cache()
        markets = cache.get("markets", {}) if isinstance(cache, dict) else {}
        direction_map = {}
        for item in list(getattr(self, "top3", []) or []) + list(getattr(self, "all_pairs", []) or []):
            pair = item.get("pair")
            if pair and pair not in direction_map:
                direction_map[pair] = item.get("direction", "")

        expected_pairs = self.market_pulse_required_pairs()
        rows = []
        warning_total = 0
        for pair in expected_pairs:
            data = markets.get(pair, {}) if isinstance(markets, dict) else {}
            debug = data.get("provider_debug", {}) if isinstance(data, dict) else {}
            series = data.get("series", []) if isinstance(data, dict) else []
            current = data.get("current_price")
            previous = data.get("previous_close")
            cot_ref = data.get("reference_price")
            direction = direction_map.get(pair, "")
            cached_today = data.get("today_change_percent") if isinstance(data, dict) else None
            try:
                today_raw = float(cached_today) if cached_today is not None else market_pulse_percent(current, previous)
            except Exception:
                today_raw = market_pulse_percent(current, previous)
            cot_raw = market_pulse_percent(current, cot_ref)
            today_signal = market_pulse_signal_return(today_raw, direction) if direction else None
            cot_signal = market_pulse_signal_return(cot_raw, direction) if direction else None
            warnings = []

            if not data:
                warnings.append("Keine Cache Daten vorhanden")
            if current in (None, 0) or previous in (None, 0):
                warnings.append("Aktueller Kurs oder Vortagesschluss fehlt")
            if series and len(series) >= 2:
                tail_previous = series[-2].get("close")
                try:
                    if previous is not None and tail_previous is not None and abs(float(previous) - float(tail_previous)) > max(abs(float(tail_previous)) * 1e-8, 1e-10):
                        warnings.append("Verwendeter Vortagesschluss weicht vom vorletzten 1D Serienwert ab")
                except Exception:
                    pass
            meta_previous = debug.get("regular_market_previous_close_quote")
            if meta_previous is None:
                meta_previous = debug.get("chart_previous_close_quote")
            try:
                if previous is not None and meta_previous is not None:
                    delta_pct = market_pulse_percent(float(meta_previous), float(previous))
                    if abs(delta_pct) >= 0.10:
                        warnings.append(f"Yahoo Previous Close Metafeld weicht um {delta_pct:+.2f} Prozent von 1D Referenz ab")
            except Exception:
                pass
            symbol = data.get("provider_symbol", "") if isinstance(data, dict) else ""
            if pair == "XAU/USD" and symbol == "GC=F":
                warnings.append("Anzeige XAU/USD verwendet Gold Future GC=F")
            if pair == "XAG/USD" and symbol == "SI=F":
                warnings.append("Anzeige XAG/USD verwendet Silber Future SI=F")
            if pair in ("NAS100/USD", "SP500/USD") and symbol in ("NQ=F", "ES=F"):
                warnings.append("Index Anzeige verwendet Futures Fallback")
            market_time = debug.get("regular_market_time")
            if market_time:
                try:
                    age_hours = max(0.0, (datetime.now().timestamp() - float(market_time)) / 3600.0)
                    if age_hours > 36:
                        warnings.append(f"Aktueller Provider Timestamp ist {age_hours:.1f} Stunden alt")
                except Exception:
                    age_hours = None
            else:
                age_hours = None
            warning_total += len(warnings)
            rows.append({
                "pair": pair,
                "display_name": market_pulse_display_name(pair),
                "direction": direction,
                "cache_created": cache.get("created", "") if isinstance(cache, dict) else "",
                "source": data.get("source", "") if isinstance(data, dict) else "",
                "provider_symbol": symbol,
                "updated_at": data.get("updated_at", "") if isinstance(data, dict) else "",
                "exchange_name": debug.get("exchange_name", ""),
                "instrument_type": debug.get("instrument_type", ""),
                "currency": debug.get("currency", ""),
                "exchange_timezone_name": debug.get("exchange_timezone_name", ""),
                "timezone": debug.get("timezone", ""),
                "gmtoffset": debug.get("gmtoffset", ""),
                "market_state": debug.get("market_state", ""),
                "regular_market_time": debug.get("regular_market_time", ""),
                "regular_market_time_local": debug.get("regular_market_time_local", ""),
                "provider_age_hours": round(age_hours, 2) if age_hours is not None else "",
                "current_price_used": current,
                "previous_close_used": previous,
                "previous_close_date": data.get("previous_close_date", "") if isinstance(data, dict) else "",
                "cot_reference_used": cot_ref,
                "cot_reference_date": data.get("reference_date", "") if isinstance(data, dict) else "",
                "week_reference_used": data.get("week_reference_price") if isinstance(data, dict) else None,
                "week_reference_date": data.get("week_reference_date", "") if isinstance(data, dict) else "",
                "market_today_pct": today_raw,
                "signal_today_pct": today_signal,
                "today_change_source": data.get("today_change_source", "") if isinstance(data, dict) else "",
                "regular_market_change_percent_snapshot": debug.get("regular_market_change_percent_snapshot"),
                "change_percent_snapshot": debug.get("change_percent_snapshot"),
                "regular_market_previous_close_snapshot": debug.get("regular_market_previous_close_snapshot"),
                "market_since_cot_pct": cot_raw,
                "signal_since_cot_pct": cot_signal,
                "regular_market_price_quote": debug.get("regular_market_price_quote"),
                "regular_market_price_history": debug.get("regular_market_price_history"),
                "regular_market_previous_close_quote": debug.get("regular_market_previous_close_quote"),
                "chart_previous_close_quote": debug.get("chart_previous_close_quote"),
                "regular_market_previous_close_history": debug.get("regular_market_previous_close_history"),
                "chart_previous_close_history": debug.get("chart_previous_close_history"),
                "daily_reference_source": data.get("daily_reference_source", "") if isinstance(data, dict) else "",
                "cot_reference_source": data.get("cot_reference_source", "") if isinstance(data, dict) else "",
                "history_url": debug.get("history_url", ""),
                "quote_url": debug.get("quote_url", ""),
                "snapshot_url": debug.get("snapshot_url", ""),
                "selected_snapshot_url": debug.get("selected_snapshot_url", ""),
                "snapshot_attempts": debug.get("snapshot_attempts", []),
                "snapshot_mode": debug.get("snapshot_mode", ""),
                "quote_snapshot_full": debug.get("quote_snapshot_full", {}),
                "quote_chart_response_full": debug.get("quote_chart_response_full", {}),
                "history_chart_response_full": debug.get("history_chart_response_full", {}),
                "quote_chart_meta_full": debug.get("quote_chart_meta_full", {}),
                "history_chart_meta_full": debug.get("history_chart_meta_full", {}),
                "daily_series_tail": debug.get("daily_series_tail", series[-12:] if series else []),
                "intraday_series_tail": debug.get("intraday_series_tail", []),
                "warnings": warnings,
                "warning_count": len(warnings),
            })

        payload = {
            "created_at": datetime.now().isoformat(timespec="seconds"),
            "app_version": APP_VERSION,
            "cache_version_expected": MARKET_PULSE_CACHE_VERSION,
            "cache_created": cache.get("created", "") if isinstance(cache, dict) else "",
            "markets_expected": len(expected_pairs),
            "markets_with_cache": sum(1 for row in rows if row.get("source")),
            "warning_count": warning_total,
            "note": "Kein neuer Internetabruf. Der Bericht analysiert die Rohwerte des letzten Market Pulse Cache. Für aktuelle Diagnosen zuerst Realtime Preise abrufen und danach Engine Checkup starten.",
            "markets": rows,
        }
        json_path.write_text(json.dumps(sanitize_audit_payload(payload), indent=2, ensure_ascii=False), encoding="utf-8")

        csv_fields = [
            "pair", "display_name", "direction", "source", "provider_symbol", "updated_at",
            "exchange_name", "instrument_type", "currency", "exchange_timezone_name", "timezone",
            "market_state", "regular_market_time_local", "provider_age_hours", "current_price_used",
            "previous_close_used", "previous_close_date", "cot_reference_used", "cot_reference_date",
            "market_today_pct", "signal_today_pct", "market_since_cot_pct", "signal_since_cot_pct",
            "regular_market_price_quote", "regular_market_price_history",
            "regular_market_previous_close_quote", "chart_previous_close_quote",
            "regular_market_previous_close_history", "chart_previous_close_history",
            "daily_reference_source", "cot_reference_source", "snapshot_url",
            "selected_snapshot_url", "snapshot_attempt_count", "snapshot_success_count",
            "warning_count", "warnings",
        ]
        with csv_path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=csv_fields, extrasaction="ignore")
            writer.writeheader()
            for row in rows:
                csv_row = dict(row)
                attempts = row.get("snapshot_attempts", []) or []
                csv_row["snapshot_attempt_count"] = len(attempts)
                csv_row["snapshot_success_count"] = sum(1 for attempt in attempts if attempt.get("status") == "ok")
                csv_row["warnings"] = " | ".join(row.get("warnings", []))
                writer.writerow(csv_row)

        lines = [
            "Meridian Market Pulse Realtime Debug",
            f"Erstellt: {payload['created_at']}",
            f"App Version: {APP_VERSION}",
            f"Cache erstellt: {payload['cache_created'] or 'nicht vorhanden'}",
            f"Märkte mit Cache: {payload['markets_with_cache']} von {payload['markets_expected']}",
            f"Automatische Hinweise: {warning_total}",
            "Kein neuer Internetabruf. Erst Realtime Preise abrufen, danach Engine Checkup starten.",
            "",
        ]
        for row in rows:
            lines.append(
                f"{row['pair']} | {row.get('source') or 'KEINE DATEN'} {row.get('provider_symbol') or ''} | "
                f"Aktuell {row.get('current_price_used')} | Vortag {row.get('previous_close_used')} ({row.get('previous_close_date')}) | "
                f"Heute {row.get('market_today_pct')} % | COT Ref {row.get('cot_reference_used')} ({row.get('cot_reference_date')}) | "
                f"Seit COT {row.get('market_since_cot_pct')} % | TZ {row.get('exchange_timezone_name') or row.get('timezone')} | "
                f"State {row.get('market_state')}"
            )
            lines.append(f"  Quelle Markt heute: {row.get('today_change_source') or 'nicht bestimmt'}")
            lines.append(f"  Quote Snapshot Modus: {row.get('snapshot_mode') or 'nicht angegeben'}")
            lines.append(f"  Gewählter Snapshot Endpunkt: {row.get('selected_snapshot_url') or row.get('snapshot_url') or 'keiner, bewusst deaktiviert'}")
            snapshot = row.get("quote_snapshot_full") or {}
            for field_name in (
                "regularMarketPrice", "regularMarketPreviousClose", "regularMarketChange",
                "regularMarketChangePercent", "changePercent", "previousClose"
            ):
                present = field_name in snapshot
                value = snapshot.get(field_name)
                value_type = type(value).__name__ if present else "missing"
                lines.append(f"  Feld {field_name}: vorhanden={present} | Wert={value} | Typ={value_type}")
            attempts = row.get("snapshot_attempts", []) or []
            lines.append(f"  Snapshot Versuche: {len(attempts)} (zusätzliche Quote Requests deaktiviert)")
            for attempt in attempts:
                available = ", ".join(attempt.get("available_fields", []) or []) or "keine"
                lines.append(
                    f"    {attempt.get('endpoint', '')} | Status {attempt.get('status', '')} | "
                    f"Felder {available} | URL {attempt.get('url', '')}"
                )
                if attempt.get("error"):
                    lines.append(f"      Fehler: {attempt.get('error')}")
            lines.append("  Vollständige rohe Providerantworten stehen in der zugehörigen Realtime Debug JSON Datei.")
            if row.get("warnings"):
                for warning in row["warnings"]:
                    lines.append(f"  WARNUNG: {warning}")
        txt_path.write_text("\n".join(lines), encoding="utf-8")
        return json_path, csv_path, txt_path

    def write_engine_checkup_files(self):
        if not getattr(self, "strengths", None):
            raise RuntimeError("Bitte zuerst die COT Analyse starten.")
        safe_date = str(self.engine.report_date).replace("-", "_")
        # Checkup Dateien werden bewusst überschrieben, damit der Audit Ordner sauber bleibt.
        # Neue Dateien entstehen nur, wenn der Nutzer den Engine Checkup Button drückt.
        for pattern in (
            "engine_checkup_meridian_method_details_*", "engine_checkup_meridian_method_summary_*",
            "engine_checkup_meridian_method_full_*", "engine_trace_meridian_method_*",
            "engine_checkup_pair_ranking_*",
            "engine_profiles_all_*",
            "macro_audit_*",
            "seasonality_audit_*",
            "market_pulse_realtime_debug_*",
        ):
            for old_file in AUDIT_DIR.glob(pattern):
                try:
                    old_file.unlink()
                except Exception:
                    pass
        detail_path = AUDIT_DIR / f"engine_checkup_meridian_method_details_{safe_date}.csv"
        summary_path = AUDIT_DIR / f"engine_checkup_meridian_method_summary_{safe_date}.csv"
        txt_path = AUDIT_DIR / f"engine_checkup_meridian_method_summary_{safe_date}.txt"
        json_path = AUDIT_DIR / f"engine_checkup_meridian_method_full_{safe_date}.json"
        trace_path = AUDIT_DIR / f"engine_trace_meridian_method_{safe_date}.csv"
        pair_path = AUDIT_DIR / f"engine_checkup_pair_ranking_{safe_date}.csv"

        detail_fields = ["currency", "report_slot", "report_date", "market", "source_file", "source_url", "source_sha256", "source_row", "commercial_long", "commercial_short", "commercial_net_formula", "commercial_net_engine", "commercial_net_match", "commercial_net_delta_vs_prev", "large_spec_long", "large_spec_short", "large_spec_net_formula", "large_spec_net_engine", "large_spec_net_match", "large_spec_net_delta_vs_prev", "open_interest", "open_interest_delta_vs_prev", "commercial_net_oi", "large_spec_net_oi"]
        summary_fields = ["currency", "status", "market", "latest_report", "reports_used", "source_files", "source_ok", "commercial_net_4w_calc", "commercial_net_4w_engine", "commercial_4w_match", "commercial_weekly_deltas", "commercial_alignment_pct", "commercial_consistency_pct", "commercial_quality_pct", "large_spec_net_4w_calc", "large_spec_net_4w_engine", "large_spec_4w_match", "large_spec_weekly_deltas", "large_spec_alignment_pct", "large_spec_consistency_pct", "large_spec_quality_pct", "open_interest_4w_calc", "open_interest_4w_engine", "open_interest_4w_match", "open_interest_weekly_deltas", "open_interest_alignment_pct", "open_interest_consistency_pct", "commercial_trend_score", "large_spec_trend_score", "cot_index_trend_score", "flow_acceleration_score", "oi_participation_score", "strength_0_100", "signed_strength_minus100_plus100", "bias", "is_proxy", "notes"]
        trace_fields = ["currency", "component", "desired_direction", "report_dates", "long_values", "short_values", "net_values", "net_oi_values", "weekly_net_deltas", "weekly_net_oi_deltas", "four_week_delta", "alignment_pct", "consistency_pct", "quality_pct", "component_score", "score_weight", "weighted_points", "interpretation"]
        pair_fields = ["rank", "selected_top3", "pair", "direction", "cot_confidence", "selection_score", "diversity_penalty", "signed_currency_gap", "strong_currency", "weak_currency", "base", "quote", "base_strength", "quote_strength", "matrix_relative_strength", "matrix_position", "matrix_flow", "matrix_momentum", "matrix_market_activity", "reason"]
        detail_rows, summary_rows, trace_rows, pair_rows = [], [], [], []
        full = {"created_at": datetime.now().isoformat(timespec="seconds"), "app_version": APP_VERSION, "engine": ENGINE_LABELS.get(self.engine.analysis_engine, self.engine.analysis_engine), "engine_key": self.engine.analysis_engine, "engine_weights": ENGINE_PROFILE_WEIGHTS.get(self.engine.analysis_engine, {}), "engine_reason": ENGINE_REASONS.get(self.engine.analysis_engine, ""), "report_date": self.engine.report_date, "source_files": getattr(self.engine, "source_files", []), "years_loaded": self.engine.years_loaded, "rows_loaded": self.engine.rows_loaded, "usd_proxy_used": bool(getattr(self.engine, "used_usd_proxy", False)), "cot_index_formula": "CFTC liefert keinen COT Index. Der Analyzer berechnet den Commercial COT Index selbst aus der lokal geladenen Meridian Historie: (aktueller Commercial Net/OI minus Kontext Minimum) / (Kontext Maximum minus Kontext Minimum) * 100. In Meridian Engine ist dieser Wert nur Kontext, nicht Richtungsgeber.", "cot_index_lookback_weeks": COT_INDEX_LOOKBACK_WEEKS, "weights": {"classic": {"commercial_bias": 0.40, "fresh_capital_flow": 0.30, "relative_strength": 0.15, "open_interest": 0.10, "flow_acceleration": 0.05}, "hybrid": {"commercial_position_context": 0.20, "commercial_flow": 0.30, "large_spec_flow": 0.25, "flow_acceleration": 0.15, "four_week_context": 0.10, "open_interest": "Qualität, keine Richtung"}, "commercial_cot_index": "Kontext aus lokaler Meridian Historie, keine alleinige Richtungsentscheidung", "seasonality": "Finaler Filter nach COT", "macro_check": "Eigenständige Bond und Event Qualitätsprüfung, verändert COT und Seasonality nicht"}, "data_health_check": self.build_data_health(), "weekly_movers": getattr(self.engine, "weekly_movers", {}), "macro_results": getattr(self, "macro_results", []), "champions": getattr(self, "champions_results", {}), "champions_ready": bool(getattr(self, "champions_ready", False)), "currency_ranking": sorted(({"currency": c, "score": d.get("strength", 50), "classic": d.get("classic_engine_score"), "momentum": d.get("momentum_engine_score")} for c, d in self.strengths.items()), key=lambda x: x["score"], reverse=True), "winner_ranking": [{"rank": i + 1, "pair": p.get("pair"), "direction": p.get("direction"), "score": p.get("confidence"), "hybrid_decision": p.get("hybrid_target"), "momentum_decision": {"base": p.get("base_components", {}).get("momentum_engine_score"), "quote": p.get("quote_components", {}).get("momentum_engine_score")}, "diversification_decision": p.get("diversity_note")} for i, p in enumerate(self.top3)], "top3": self.top3, "pair_ranking": self.all_pairs, "currency_checks": {}}
        all_engine_profiles = self.build_all_engine_profile_audit()
        hybrid_logic_audit = self.build_hybrid_logic_audit()
        full["hybrid_logic_audit"] = hybrid_logic_audit
        full["all_engine_profiles"] = all_engine_profiles
        profile_json_path, profile_csv_path, profile_txt_path = self.write_all_engine_profile_audit_files(all_engine_profiles, safe_date)
        market_debug_json_path, market_debug_csv_path, market_debug_txt_path = self.write_market_pulse_debug_audit_files(safe_date)
        full["market_pulse_realtime_debug"] = {
            "json": market_debug_json_path.name,
            "csv": market_debug_csv_path.name,
            "summary": market_debug_txt_path.name,
            "note": "Analysiert den letzten Market Pulse Cache ohne neuen Internetzugriff.",
        }

        for curr, data in sorted(self.strengths.items()):
            raw = data.get("raw_audit", {})
            is_proxy = bool(data.get("is_proxy")) or raw.get("source_file") == "PROXY"
            if is_proxy:
                summary = {"currency": curr, "status": "PROXY", "market": raw.get("market", "PROXY"), "latest_report": data.get("latest_date", ""), "reports_used": "PROXY", "source_files": "PROXY", "source_ok": "PROXY", "commercial_net_4w_calc": "PROXY", "commercial_net_4w_engine": raw.get("commercial_change_4w", "PROXY"), "commercial_4w_match": "PROXY", "large_spec_net_4w_calc": "PROXY", "large_spec_net_4w_engine": raw.get("large_spec_change_4w", "PROXY"), "large_spec_4w_match": "PROXY", "open_interest_4w_calc": "PROXY", "open_interest_4w_engine": raw.get("open_interest_change_4w", "PROXY"), "open_interest_4w_match": "PROXY", "commercial_trend_score": data.get("commercial_4w_net_trend", ""), "large_spec_trend_score": data.get("large_spec_4w_net_trend", ""), "cot_index_trend_score": data.get("cot_index_4w_trend", ""), "flow_acceleration_score": data.get("flow_acceleration", ""), "oi_participation_score": data.get("oi_participation", ""), "strength_0_100": data.get("strength", ""), "signed_strength_minus100_plus100": data.get("signed_strength", ""), "bias": data.get("bias", ""), "is_proxy": True, "notes": "Proxy, keine direkten 4W CFTC Rohwerte"}
                summary_rows.append(summary)
                full["currency_checks"][curr] = {"status": "PROXY", "raw_audit": raw, "summary": summary, "scores": data}
                continue

            notes = []
            series = self.engine.records.get(curr, [])
            recent = self.engine.window(series, self.engine.lookback_weeks, len(series)) if series else []
            dates = [r.get("date").strftime("%Y-%m-%d") for r in recent if r.get("date")]
            files = sorted(set(str(r.get("source_file", "")) for r in recent))
            source_ok = all(str(f).startswith("deacot") and str(f).endswith(".zip") for f in files) if files else False
            if len(recent) != self.engine.lookback_weeks:
                notes.append(f"Nur {len(recent)} Reports statt {self.engine.lookback_weeks}")
            if not source_ok:
                notes.append("Quelle ist nicht durchgehend deacotYYYY.zip")
            if data.get("latest_date") != self.engine.report_date:
                notes.append("Latest Date weicht vom Engine Report Date ab")

            for i, r in enumerate(recent, start=1):
                prev = recent[i - 2] if i > 1 else None
                comm_formula = round(safe_float(r.get("commercial_long", 0)) - safe_float(r.get("commercial_short", 0)))
                spec_formula = round(safe_float(r.get("large_spec_long", 0)) - safe_float(r.get("large_spec_short", 0)))
                comm_engine = round(safe_float(r.get("commercial_net", 0)))
                spec_engine = round(safe_float(r.get("spec_net", 0)))
                comm_delta_prev = "" if prev is None else round(safe_float(r.get("commercial_net", 0)) - safe_float(prev.get("commercial_net", 0)))
                spec_delta_prev = "" if prev is None else round(safe_float(r.get("spec_net", 0)) - safe_float(prev.get("spec_net", 0)))
                oi_delta_prev = "" if prev is None else round(safe_float(r.get("open_interest", 0)) - safe_float(prev.get("open_interest", 0)))
                detail_rows.append({"currency": curr, "report_slot": i, "report_date": r.get("date").strftime("%Y-%m-%d") if r.get("date") else "", "market": r.get("market", ""), "source_file": r.get("source_file", ""), "source_url": r.get("source_url", ""), "source_sha256": r.get("source_sha256", ""), "source_row": r.get("source_row", ""), "commercial_long": round(safe_float(r.get("commercial_long", 0))), "commercial_short": round(safe_float(r.get("commercial_short", 0))), "commercial_net_formula": comm_formula, "commercial_net_engine": comm_engine, "commercial_net_match": comm_formula == comm_engine, "commercial_net_delta_vs_prev": comm_delta_prev, "large_spec_long": round(safe_float(r.get("large_spec_long", 0))), "large_spec_short": round(safe_float(r.get("large_spec_short", 0))), "large_spec_net_formula": spec_formula, "large_spec_net_engine": spec_engine, "large_spec_net_match": spec_formula == spec_engine, "large_spec_net_delta_vs_prev": spec_delta_prev, "open_interest": round(safe_float(r.get("open_interest", 0))), "open_interest_delta_vs_prev": oi_delta_prev, "commercial_net_oi": round(safe_float(r.get("commercial_net_oi", 0)), 8), "large_spec_net_oi": round(safe_float(r.get("spec_net_oi", 0)), 8)})

            if recent:
                comm_4w_calc = round(safe_float(recent[-1].get("commercial_net", 0)) - safe_float(recent[0].get("commercial_net", 0)))
                spec_4w_calc = round(safe_float(recent[-1].get("spec_net", 0)) - safe_float(recent[0].get("spec_net", 0)))
                oi_4w_calc = round(safe_float(recent[-1].get("open_interest", 0)) - safe_float(recent[0].get("open_interest", 0)))
            else:
                comm_4w_calc = spec_4w_calc = oi_4w_calc = 0
            comm_4w_engine = raw.get("commercial_change_4w", data.get("commercial_change_4w", ""))
            spec_4w_engine = raw.get("large_spec_change_4w", data.get("spec_change_4w", ""))
            oi_4w_engine = raw.get("open_interest_change_4w", "")
            comm_match = str(comm_4w_calc) == str(comm_4w_engine)
            spec_match = str(spec_4w_calc) == str(spec_4w_engine)
            oi_match = str(oi_4w_calc) == str(oi_4w_engine)
            if not comm_match: notes.append("Commercial 4W Abweichung")
            if not spec_match: notes.append("Large Spec 4W Abweichung")
            if not oi_match: notes.append("Open Interest 4W Abweichung")
            summary = {"currency": curr, "status": "OK" if not notes else "PRÜFEN", "market": raw.get("market", ""), "latest_report": data.get("latest_date", ""), "reports_used": " | ".join(dates), "source_files": " | ".join(files), "source_ok": source_ok, "commercial_net_4w_calc": comm_4w_calc, "commercial_net_4w_engine": comm_4w_engine, "commercial_4w_match": comm_match, "commercial_weekly_deltas": " | ".join(map(str, raw.get("commercial_net_4w_deltas", []))), "commercial_alignment_pct": raw.get("commercial_4w_alignment_pct", ""), "commercial_consistency_pct": raw.get("commercial_4w_consistency_pct", ""), "commercial_quality_pct": raw.get("commercial_4w_quality_pct", ""), "large_spec_net_4w_calc": spec_4w_calc, "large_spec_net_4w_engine": spec_4w_engine, "large_spec_4w_match": spec_match, "large_spec_weekly_deltas": " | ".join(map(str, raw.get("large_spec_net_4w_deltas", []))), "large_spec_alignment_pct": raw.get("large_spec_4w_alignment_pct", ""), "large_spec_consistency_pct": raw.get("large_spec_4w_consistency_pct", ""), "large_spec_quality_pct": raw.get("large_spec_4w_quality_pct", ""), "open_interest_4w_calc": oi_4w_calc, "open_interest_4w_engine": oi_4w_engine, "open_interest_4w_match": oi_match, "open_interest_weekly_deltas": " | ".join(map(str, raw.get("open_interest_4w_deltas", []))), "open_interest_alignment_pct": raw.get("oi_4w_alignment_pct", ""), "open_interest_consistency_pct": raw.get("oi_4w_consistency_pct", ""), "commercial_trend_score": data.get("commercial_4w_net_trend", ""), "large_spec_trend_score": data.get("large_spec_4w_net_trend", ""), "cot_index_trend_score": data.get("cot_index_4w_trend", ""), "flow_acceleration_score": data.get("flow_acceleration", ""), "oi_participation_score": data.get("oi_participation", ""), "strength_0_100": data.get("strength", ""), "signed_strength_minus100_plus100": data.get("signed_strength", ""), "bias": data.get("bias", ""), "is_proxy": False, "notes": "; ".join(notes)}
            
            def _join(vals, digits=None):
                out = []
                for v in vals:
                    try:
                        if digits is None:
                            out.append(str(round(safe_float(v))))
                        else:
                            out.append(str(round(safe_float(v), digits)))
                    except Exception:
                        out.append(str(v))
                return " | ".join(out)

            comm_net_vals = [safe_float(r.get("commercial_net", 0)) for r in recent]
            spec_net_vals = [safe_float(r.get("spec_net", 0)) for r in recent]
            comm_net_oi_vals = [safe_float(r.get("commercial_net_oi", 0)) for r in recent]
            spec_net_oi_vals = [safe_float(r.get("spec_net_oi", 0)) for r in recent]
            oi_vals = [safe_float(r.get("open_interest", 0)) for r in recent]
            cot_idx_vals = raw.get("cot_index_4w_values", [])
            date_join = " | ".join(dates)

            trace_rows.append({"currency": curr, "component": "Commercial Long Short Change", "desired_direction": "Bias Richtung bestätigen", "report_dates": date_join, "long_values": _join([r.get("commercial_long", 0) for r in recent]), "short_values": _join([r.get("commercial_short", 0) for r in recent]), "net_values": "", "net_oi_values": "", "weekly_net_deltas": f"1W Long {raw.get('commercial_long_change', '')} / 1W Short {raw.get('commercial_short_change', '')}", "weekly_net_oi_deltas": f"4W Long {raw.get('commercial_long_change_4w', '')} / 4W Short {raw.get('commercial_short_change_4w', '')}", "four_week_delta": raw.get("commercial_change_4w", ""), "alignment_pct": "", "consistency_pct": "", "quality_pct": "", "component_score": data.get("commercial_long_short_flow", ""), "score_weight": "36 Prozent Qualität", "weighted_points": data.get("weighted_points", {}).get("commercial_long_short_flow", ""), "interpretation": "Bullisch: Commercial Longs steigen und Shorts fallen. Bearisch: Commercial Shorts steigen und Longs fallen. Beides wird getrennt gemessen, nicht nur netto."})
            trace_rows.append({"currency": curr, "component": "Large Spec Long Short Change", "desired_direction": "Commercial Bias bestätigen", "report_dates": date_join, "long_values": _join([r.get("large_spec_long", 0) for r in recent]), "short_values": _join([r.get("large_spec_short", 0) for r in recent]), "net_values": "", "net_oi_values": "", "weekly_net_deltas": f"1W Long {raw.get('large_spec_long_change', '')} / 1W Short {raw.get('large_spec_short_change', '')}", "weekly_net_oi_deltas": f"4W Long {raw.get('large_spec_long_change_4w', '')} / 4W Short {raw.get('large_spec_short_change_4w', '')}", "four_week_delta": raw.get("large_spec_change_4w", ""), "alignment_pct": "", "consistency_pct": "", "quality_pct": "", "component_score": data.get("large_spec_long_short_flow", ""), "score_weight": "30 Prozent Qualität", "weighted_points": data.get("weighted_points", {}).get("large_spec_long_short_flow", ""), "interpretation": "Large Specs zeigen, ob spekulatives institutionelles Kapital dieselbe Richtung durch eigene Long oder Short Veränderungen bestätigt."})
            trace_rows.append({"currency": curr, "component": "Commercial Net", "desired_direction": "steigend = bullish", "report_dates": date_join, "long_values": _join([r.get("commercial_long", 0) for r in recent]), "short_values": _join([r.get("commercial_short", 0) for r in recent]), "net_values": _join(comm_net_vals), "net_oi_values": _join(comm_net_oi_vals, 8), "weekly_net_deltas": " | ".join(map(str, raw.get("commercial_net_4w_deltas", []))), "weekly_net_oi_deltas": _join(raw.get("commercial_net_oi_4w_deltas", []), 8), "four_week_delta": comm_4w_calc, "alignment_pct": raw.get("commercial_4w_alignment_pct", ""), "consistency_pct": raw.get("commercial_4w_consistency_pct", ""), "quality_pct": raw.get("commercial_4w_quality_pct", ""), "component_score": data.get("commercial_4w_net_trend", ""), "score_weight": "Ebene 2 Bestätigung", "weighted_points": data.get("weighted_points", {}).get("commercial_4w_net_trend", ""), "interpretation": "Commercial Long minus Short bestimmt die Grundrichtung. Die Veränderung von Longs und Shorts bewertet danach die Qualität des Setups."})
            trace_rows.append({"currency": curr, "component": "Large Spec Net", "desired_direction": "steigend = bullish", "report_dates": date_join, "long_values": _join([r.get("large_spec_long", 0) for r in recent]), "short_values": _join([r.get("large_spec_short", 0) for r in recent]), "net_values": _join(spec_net_vals), "net_oi_values": _join(spec_net_oi_vals, 8), "weekly_net_deltas": " | ".join(map(str, raw.get("large_spec_net_4w_deltas", []))), "weekly_net_oi_deltas": _join(raw.get("large_spec_net_oi_4w_deltas", []), 8), "four_week_delta": spec_4w_calc, "alignment_pct": raw.get("large_spec_4w_alignment_pct", ""), "consistency_pct": raw.get("large_spec_4w_consistency_pct", ""), "quality_pct": raw.get("large_spec_4w_quality_pct", ""), "component_score": data.get("large_spec_4w_net_trend", ""), "score_weight": "Ebene 2 Bestätigung", "weighted_points": data.get("weighted_points", {}).get("large_spec_4w_net_trend", ""), "interpretation": "Large Specs netto steigen stärkt die Währung, Large Specs netto fallen schwächt die Währung."})
            trace_rows.append({"currency": curr, "component": "COT Index", "desired_direction": "steigend = bullish", "report_dates": date_join, "long_values": "", "short_values": "", "net_values": _join(cot_idx_vals, 1), "net_oi_values": "", "weekly_net_deltas": _join([cot_idx_vals[i] - cot_idx_vals[i-1] for i in range(1, len(cot_idx_vals))], 1) if len(cot_idx_vals) > 1 else "", "weekly_net_oi_deltas": "", "four_week_delta": round(safe_float(cot_idx_vals[-1]) - safe_float(cot_idx_vals[0]), 1) if cot_idx_vals else "", "alignment_pct": raw.get("cot_index_4w_alignment_pct", ""), "consistency_pct": raw.get("cot_index_4w_consistency_pct", ""), "quality_pct": "", "component_score": data.get("cot_index_4w_trend", ""), "score_weight": "Kontext", "weighted_points": "0", "interpretation": "Der Commercial COT Index zeigt, wie extrem die aktuelle Commercial Netto Position im lokal geladenen Meridian Kontext liegt. Er ist sichtbar, aber nicht Hauptauslöser der Richtung."})
            trace_rows.append({"currency": curr, "component": "Open Interest", "desired_direction": "steigende Teilnahme bestätigt frischen Flow", "report_dates": date_join, "long_values": "", "short_values": "", "net_values": _join(oi_vals), "net_oi_values": "", "weekly_net_deltas": " | ".join(map(str, raw.get("open_interest_4w_deltas", []))), "weekly_net_oi_deltas": "", "four_week_delta": oi_4w_calc, "alignment_pct": raw.get("oi_4w_alignment_pct", ""), "consistency_pct": raw.get("oi_4w_consistency_pct", ""), "quality_pct": "", "component_score": data.get("oi_participation", ""), "score_weight": "Ebene 2 Bestätigung", "weighted_points": data.get("weighted_points", {}).get("oi_participation", ""), "interpretation": "Open Interest bewertet frische Marktteilnahme. Steigende Teilnahme bestätigt starken Flow, fallende Teilnahme dämpft den Bias."})

            summary_rows.append(summary)
            full["currency_checks"][curr] = {"status": summary["status"], "reports_used": dates, "source_files": files, "source_ok": source_ok, "raw_audit": raw, "summary": summary, "scores": data}

        top3_pairs = {p.get("pair") for p in self.top3}
        for rank, pair_data in enumerate(self.all_pairs or [], start=1):
            pair = pair_data.get("pair", "")
            base, quote = (pair.split("/") + ["", ""])[:2] if "/" in pair else (pair, "")
            reason = f"{pair_data.get('strong', '')} gegen {pair_data.get('weak', '')}, Gap {pair_data.get('diff', '')}, Auswahl {pair_data.get('selection_score', pair_data.get('confidence', ''))}"
            pair_rows.append({
                "rank": rank,
                "selected_top3": "YES" if pair in top3_pairs else "NO",
                "pair": pair,
                "direction": pair_data.get("direction", ""),
                "cot_confidence": pair_data.get("confidence", ""),
                "selection_score": pair_data.get("selection_score", pair_data.get("confidence", "")),
                "diversity_penalty": pair_data.get("diversity_penalty", 0),
                "signed_currency_gap": pair_data.get("diff", ""),
                "strong_currency": pair_data.get("strong", ""),
                "weak_currency": pair_data.get("weak", ""),
                "base": base,
                "quote": quote,
                "base_strength": self.strengths.get(base, {}).get("strength", ""),
                "quote_strength": self.strengths.get(quote, {}).get("strength", ""),
                "matrix_relative_strength": pair_data.get("matrix_relative_strength", ""),
                "matrix_position": pair_data.get("matrix_position", ""),
                "matrix_flow": pair_data.get("matrix_flow", ""),
                "matrix_momentum": pair_data.get("matrix_momentum", ""),
                "matrix_market_activity": pair_data.get("matrix_market_activity", ""),
                "reason": reason,
            })

        with detail_path.open("w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=detail_fields); w.writeheader(); w.writerows(detail_rows)
        with summary_path.open("w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=summary_fields); w.writeheader(); w.writerows(summary_rows)
        with trace_path.open("w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=trace_fields); w.writeheader(); w.writerows(trace_rows)
        with pair_path.open("w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=pair_fields); w.writeheader(); w.writerows(pair_rows)
        json_path.write_text(json.dumps(sanitize_audit_payload(full), indent=2, ensure_ascii=False), encoding="utf-8")

        ok_count = sum(1 for r in summary_rows if r.get("status") == "OK")
        proxy_count = sum(1 for r in summary_rows if r.get("status") == "PROXY")
        check_count = len(summary_rows) - ok_count - proxy_count
        txt_lines = ["Meridian Engine Checkup", f"Erstellt: {full['created_at']}", f"App Version: {APP_VERSION}", f"Report Date: {self.engine.report_date}", f"Geladene Jahre: {', '.join(map(str, sorted(self.engine.years_loaded)))}", f"Gelesene CFTC Zeilen: {self.engine.rows_loaded}", "Quelle: CFTC Legacy deacotYYYY.zip", "Meridian Engine lädt standardmäßig nur aktuelles Jahr plus Vorjahr. Das reicht für aktuelle 1W und 4W Signale und spart Downloadzeit.", f"USD Proxy verwendet: {bool(getattr(self.engine, 'used_usd_proxy', False))}", "", "Formeln:", "Commercial Net = Commercial Long minus Commercial Short", "Large Spec Net = Non Commercial Long minus Non Commercial Short", "Netto 4W = aktueller Net Wert minus ältester Net Wert im 4 Report Fenster", "Classic Methodik = Commercial Long/Short Überhang bleibt Richtungsanker. Hybrid Methodik = Commercial Position ist nur 20 Prozent Kontext; Commercial Flow, Large Spec Flow, Beschleunigung und Vier Wochen Kontext wirken unabhängig und dürfen die Richtung drehen. 1W Changes werden aus aktueller Woche minus Vorwoche selbst berechnet.", "Gewichtung der Meridian Qualität: Commercial Bias 40 Prozent, frischer Kapitalfluss 30 Prozent, relative Stärke 15 Prozent, Open Interest 10 Prozent, Flow Beschleunigung 5 Prozent", "", "Wochengewinner und Wochenverlierer: Aktueller Meridian Strength Score minus direkter Vorwochen Score. Die Anzeige macht sichtbar, welche Währung durch den neuen COT Report am stärksten zugelegt oder verloren hat.",
            "Classic Trendqualität bestätigt oder dämpft den Commercial Bias. Hybrid besitzt keinen festen Commercial Richtungsanker und darf bei ausreichender Gegenbewegung neutralisieren oder drehen.", "Net OI = Net Position geteilt durch Open Interest", f"Commercial COT Index = selbst berechnet aus Commercial Net/OI im lokal geladenen {COT_INDEX_LOOKBACK_WEEKS} Wochen Kontext. 0 extrem bearish, 100 extrem bullish. Kontextwert, kein Hauptsignal.", "", f"Status: {ok_count} OK, {proxy_count} Proxy, {check_count} Prüfen", "", "Top 3:"]
        for i, pair_data in enumerate(self.top3, start=1):
            txt_lines.append(f"{i}. {pair_data.get('pair')} {pair_data.get('direction')} | Meridian Qualität {pair_data.get('score')} | stark {pair_data.get('strong')} {pair_data.get('strong_signed_strength')} | schwach {pair_data.get('weak')} {pair_data.get('weak_signed_strength')}")
        single_asset_rows = [p for p in (self.all_pairs or []) if p.get("is_single_asset")]
        macro_rows = list(getattr(self, "macro_results", []) or [])
        if macro_rows:
            txt_lines += ["", "Makro Meridian Engine:", "Status: GEPRÜFT", "Quellen: Offizielle Bondquellen je Währung, bestehende Anbieter als technische Reserve sowie Wirtschaftskalender für relevante Events", "Hinweis: COT bleibt der Basiswert. Seasonality wirkt mit höchstens acht Punkten, Makro mit höchstens fünf Punkten und Termine mit höchstens vier Punkten Abschlag auf die finale Qualität."]
            for r in macro_rows:
                txt_lines.append(f"{r.get('pair')} {r.get('direction')}: COT Basis {r.get('cot_basis', r.get('cot_score'))} | Saison {safe_float(r.get('seasonality_adjustment', 0), 0):+.1f} | Makro {r.get('macro_label')} mit {safe_float(r.get('macro_adjustment', 0), 0):+.1f} | 2Y Spread {r.get('spread_2y')} | 10Y Spread {r.get('spread_10y')} | Curve Differenz {r.get('curve_spread')} | Zinsimpuls {r.get('impulse_label', 'STABIL')} mit Score {r.get('score_impulse', 50)}, 5T {r.get('impulse_change_5d')}, 20T {r.get('impulse_change_20d')} | Events {len(r.get('events') or [])}, erwartete Volatilität {r.get('event_volatility', 1)}/10, Abschlag {r.get('event_penalty', 0)} | Finale Qualität {r.get('final_quality', r.get('final_confluence'))}")
        else:
            txt_lines += ["", "Makro Meridian Engine: noch nicht geprüft. Button 3 startet Bond Yield Spread und High Impact Event Prüfung."]

        if getattr(self, "champions_ready", False):
            txt_lines += ["", "Engine Champions: FREIGESCHALTET"]
            for key in (ENGINE_CLASSIC, ENGINE_FLOW, ENGINE_HYBRID):
                row = (getattr(self, "champions_results", {}) or {}).get(key, {})
                txt_lines.append(f"{ENGINE_LABELS[key]}: {row.get('pair', '—')} {row.get('direction', '')} | Finale Qualität {safe_float(row.get('final_quality', 0), 0):.1f}")
        else:
            txt_lines += ["", "Engine Champions: noch nicht erstellt oder nicht freigeschaltet."]

        if single_asset_rows:
            txt_lines += ["", "Zusatzmärkte:"]
            for item in single_asset_rows:
                txt_lines.append(f"{item.get('display_name', item.get('pair'))}: {item.get('direction')} | Meridian Qualität {safe_float(item.get('confidence', 0), 0):.1f} | Rang {item.get('original_rank', '')} | Markt {item.get('base_raw_audit', {}).get('market', item.get('asset', ''))}")
        else:
            txt_lines += ["", "Zusatzmärkte: keine Daten gefunden"]

        txt_lines += ["", "Währungsprüfung:"]
        for r in summary_rows:
            txt_lines.append(f"{r['currency']}: {r['status']} | Reports: {r['reports_used']} | Comm 4W {r['commercial_net_4w_calc']} [{r.get('commercial_weekly_deltas', '')}] Q {r.get('commercial_quality_pct', '')} | Specs 4W {r['large_spec_net_4w_calc']} [{r.get('large_spec_weekly_deltas', '')}] Q {r.get('large_spec_quality_pct', '')} | OI 4W {r['open_interest_4w_calc']} | Stärke {r['signed_strength_minus100_plus100']} | {r['notes']}")
        txt_lines += [
            "", "Hybrid Intelligence Audit:",
            f"Logik Szenarien: {hybrid_logic_audit.get('scenario_status')}",
            f"Schnittstellen: {hybrid_logic_audit.get('interface_status')}",
            f"Strength Matrix Vertrag: {hybrid_logic_audit.get('strength_matrix_contract')}",
            f"Market Pulse Realtime: {hybrid_logic_audit.get('market_pulse_contract')} ({hybrid_logic_audit.get('market_pulse_markets_valid', 0)} von {hybrid_logic_audit.get('market_pulse_markets_expected', 0)} Märkten vollständig)",
            f"Forex Top 3 Anzahl: {hybrid_logic_audit.get('top3_count_status')} ({hybrid_logic_audit.get('top3_count')})",
            f"Forex Only: {hybrid_logic_audit.get('top3_forex_only')}",
            f"Top 3 eindeutig: {hybrid_logic_audit.get('top3_unique')}",
            f"Zusatzmärkte separat: {hybrid_logic_audit.get('additional_markets_separate')}",
            f"Finale Watchlist: {hybrid_logic_audit.get('final_watchlist_status')}",
            f"Watchlist Paarmenge: {hybrid_logic_audit.get('final_watchlist_same_pair_set')} | Reihenfolge: {hybrid_logic_audit.get('final_watchlist_order')}",
            f"Makro Top 3: {hybrid_logic_audit.get('macro_top3_status')}",
            f"Watchlist und Makro Vertrag: {hybrid_logic_audit.get('watchlist_macro_contract')}",
            f"Pair Ranking Integration: {hybrid_logic_audit.get('pair_ranking_integration')}",
            f"COT Top 3 Paare: {' | '.join(hybrid_logic_audit.get('top3_pairs', []))}",
            f"Finale Watchlist Paare: {' | '.join(hybrid_logic_audit.get('final_watchlist_pairs', [])) or 'noch offen'}",
            f"Makro Paare: {' | '.join(hybrid_logic_audit.get('macro_pairs', [])) or 'noch offen'}",
        ]
        for scenario in hybrid_logic_audit.get("scenarios", []):
            txt_lines.append(
                f"{scenario.get('status')}: {scenario.get('scenario')} | erwartet {scenario.get('expected')} | "
                f"tatsächlich {scenario.get('actual_bias')} | Score {scenario.get('hybrid_score')} | Qualität {scenario.get('hybrid_quality')}"
            )
        txt_lines += [
            "", "Engine Profilvergleich:",
            "Classic Meridian, Flow Momentum und Hybrid Intelligence wurden mit derselben CFTC Datenbasis separat berechnet.",
        ]
        for engine_key in (ENGINE_CLASSIC, ENGINE_FLOW, ENGINE_HYBRID):
            profile = all_engine_profiles.get(engine_key, {})
            top_text = " | ".join(
                f"{item.get('pair')} {item.get('direction')} ({item.get('confidence')})"
                for item in profile.get("top3", [])
            )
            txt_lines.append(f"{profile.get('engine_label', engine_key)}: {top_text}")
        txt_lines += ["", "Market Pulse Realtime Debug:", "Der Debug Bericht verwendet den letzten Cache und führt keinen zusätzlichen Internetabruf aus.", f"Realtime Debug JSON: {market_debug_json_path.name}", f"Realtime Debug CSV: {market_debug_csv_path.name}", f"Realtime Debug Summary: {market_debug_txt_path.name}"]
        txt_lines += ["", "Checkup Dateien:", f"Detail CSV: {detail_path.name}", f"Summary CSV: {summary_path.name}", f"Engine Trace CSV: {trace_path.name}", f"Pair Ranking CSV: {pair_path.name}", f"Full JSON: {json_path.name}", f"Alle Engines JSON: {profile_json_path.name}", f"Alle Engines CSV: {profile_csv_path.name}", f"Alle Engines Summary: {profile_txt_path.name}", f"Market Pulse Debug JSON: {market_debug_json_path.name}", f"Market Pulse Debug CSV: {market_debug_csv_path.name}", f"Market Pulse Debug Summary: {market_debug_txt_path.name}"]
        txt_path.write_text("\n".join(txt_lines), encoding="utf-8")
        return detail_path, summary_path, txt_path, json_path, trace_path, pair_path, profile_json_path, profile_csv_path, profile_txt_path, market_debug_json_path, market_debug_csv_path, market_debug_txt_path

    def show_diagnose(self):
        check_paths = None
        check_error = None
        if getattr(self, "strengths", None):
            try:
                check_paths = self.write_engine_checkup_files()
            except Exception as exc:
                check_error = exc
        lines = [
            f"Datenordner: {DATA_DIR}",
            f"Audit Ordner: {AUDIT_DIR}",
            f"Geladene Jahre: {', '.join(map(str, sorted(self.engine.years_loaded)))}",
            f"Gelesene Zeilen: {self.engine.rows_loaded}",
            "",
            "Wochen je Währung:",
            *self.engine.debug,
            "",
            "Engine Fokus:",
            f"Meridian Analyzer Pro {APP_VERSION}. COT Engine und Seasonality Rohberechnung bleiben erhalten. Die Bond Makro Engine ergänzt 2Y, 10Y und Yield Curve um den Zinsimpuls über 5 und 20 Handelstage. Die finale Qualitäts Watchlist nutzt COT als Basis und begrenzt den gesamten Makrobeitrag weiterhin dynamisch. Der Checkup speichert Datenprüfung, Währungsdiagnose, Rechentrace, Pair Ranking und JSON Gesamtdaten zentral im Audit Ordner.",
            "Netto Formeln: Commercial Long minus Short, Large Specs Long minus Short. Netto 4W = aktueller Net Wert minus ältester Net Wert im 4 Report Fenster. Classic behält den Commercial Richtungsanker. Hybrid bewertet Position, Commercial Flow, Large Spec Flow, Beschleunigung und Vier Wochen Kontext unabhängig; Open Interest misst dort die Qualität.",
        ]
        if check_paths:
            detail_path, summary_path, txt_path, json_path, trace_path, pair_path = check_paths[:6]
            profile_paths = check_paths[6:9]
            market_debug_paths = check_paths[9:12]
            lines += ["", "Engine Checkup erstellt:", f"Detail CSV: audit/{detail_path.name}", f"Summary CSV: audit/{summary_path.name}", f"Summary TXT: audit/{txt_path.name}", f"Engine Trace CSV: audit/{trace_path.name}", f"Pair Ranking CSV: audit/{pair_path.name}", f"Full JSON: audit/{json_path.name}"]
            if len(profile_paths) == 3:
                lines += [f"Alle Engines JSON: audit/{profile_paths[0].name}", f"Alle Engines CSV: audit/{profile_paths[1].name}", f"Alle Engines Summary: audit/{profile_paths[2].name}"]
            if len(market_debug_paths) == 3:
                lines += ["", "Market Pulse Realtime Debug:", f"JSON: audit/{market_debug_paths[0].name}", f"CSV: audit/{market_debug_paths[1].name}", f"Summary: audit/{market_debug_paths[2].name}", "Hinweis: Für aktuelle Rohwerte zuerst Realtime Preise abrufen."]
            if getattr(self, "macro_results", None):
                lines += ["", "Makro Check: geprüft", f"Paare: {len(self.macro_results)}", "Bond Spread und High Impact Events sind im Audit enthalten."]
            else:
                lines += ["", "Makro Check: noch offen"]
        elif check_error:
            lines += ["", f"Engine Checkup Fehler: {check_error}"]
        else:
            lines += ["", "Engine Checkup: erst nach abgeschlossener COT Analyse verfügbar."]
        if self.engine.validation_warnings:
            lines += ["", "Validierungshinweise:", *self.engine.validation_warnings[:12]]
        if self.engine.validation_errors:
            lines += ["", "Validierungsfehler:", *self.engine.validation_errors[:12]]
        if self.engine.errors:
            lines += ["", "COT Download Hinweise:", *self.engine.errors[:12]]
        if getattr(self, "season_engine", None) and self.season_engine.errors:
            lines += ["", "Seasonality Hinweise:", *self.season_engine.errors[:12]]
        if getattr(self, "macro_engine", None) and self.macro_engine.errors:
            # Makro Quellen werden bewusst mit Fallbacks abgefragt. Fehlgeschlagene
            # Erstquellen wie TradingEconomics 410 Gone oder einzelne Bond API
            # Versuche sind technische Trace Informationen und sollen Kunden nicht
            # als Fehler angezeigt werden, wenn der Makro Check am Ende Daten
            # geliefert hat. Die Details bleiben in den Audit Dateien erhalten.
            show_macro_errors = not getattr(self, "macro_results", None)
            if show_macro_errors:
                lines += ["", "Makro Hinweise:", *self.macro_engine.errors[:12]]
        messagebox.showinfo("Engine Checkup", "\n".join(lines))

if __name__ == "__main__":
    from license_guard import run_with_license_guard

    run_with_license_guard(lambda: App().mainloop())
